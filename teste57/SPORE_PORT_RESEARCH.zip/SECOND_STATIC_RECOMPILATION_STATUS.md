# Spore Android — segunda função recompilada estaticamente

## Identidade e evidência Ghidra

- Executável selecionado: `C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe`
- SHA-256 do executável e do export Ghidra: `6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`
- Função: `FUN_00479c00`, VA `0x00479C00`, RVA `0x00079C00`, offset no arquivo `0x79000`, seção `.text`
- Tamanho: 128 bytes; SHA-256 dos bytes da função: `b2357a25cf2767d7710ffd1362433bf961e9f5fc130395a22210d4e5b51a3d73`
- Export Ghidra: `C:\SporeAnalysis\spore_function_00479c00.json`
- Instruções exportadas: 47/47; blocos básicos: 8/8; referências de chamada de entrada: 7; chamadas internas: zero; pseudocódigo concluído e não truncado.
- Ghidra informa convenção de chamada `unknown`. A chamada `__cdecl` no harness nativo foi compatível com o `ret` observado e os argumentos na pilha, mas não transforma a inferência em prova para todos os callers.

O hash é diferente do hash histórico bloqueado (`290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74`). Esta função foi exportada e validada contra o executável escolhido nesta fase; os resultados históricos não foram alterados.

## Semântica recuperada

O pseudocódigo e as instruções mostram quatro argumentos de pilha:

1. `param_1`: endereço de um slot de saída;
2. `param_2`: início da sequência fonte;
3. `param_3`: fim da sequência fonte;
4. `param_4`: início da sequência destino.

Enquanto o cursor fonte for diferente do fim, a rotina avança fonte e destino em 8 bytes. Se o destino corrente não for nulo, copia dois valores de 32 bits usando `FLD`/`FSTP`; ao final grava o cursor destino resultante em `*param_1` e retorna `param_1`. O corpo implementado é autônomo e não contém `call`.

O destino nulo foi testado somente para zero ou um registro. Para mais registros, o próprio código de máquina avança o ponteiro nulo e tenta gravar no endereço resultante (por exemplo, endereço 8 na segunda iteração); esse caso não é tratado como um destino de descarte válido.

## Geração e cobertura

`GenerateStaticCopyLift.py` verifica o hash completo do PE, o hash do export, a entrada/tamanho no CSV, o limite completo da função e a igualdade byte a byte entre a sequência de instruções Ghidra e os bytes do PE. A geração é feita instrução por instrução, com labels e desvios estáticos; o executável ARM64 não busca nem interpreta instruções x86.

Resultado de cobertura em `spore_00479c00_instruction_coverage.json`:

- **PASSOU:** 47/47 instruções aceitas;
- **PASSOU:** 128/128 bytes cobertos (100%);
- **PASSOU:** zero instruções rejeitadas;
- **PASSOU:** ramos fora do corpo e opcodes não suportados são rejeitados pelos testes do gerador.

`FLD`/`FSTP` no trecho executam um round-trip binary32 sem aritmética. O lowering preserva os bits ordinários e reproduz a quieting bit observada em NaNs signaling. O status/flags do x87 não são reproduzidos no estado de ponto flutuante do Android; equivalência de estado x87 não foi testada nem reivindicada.

## Validação

| Critério | Status | Evidência |
|---|---|---|
| Identidade e bytes do alvo | **PASSOU** | Hash do PE confirmado; export vinculado ao mesmo hash; 128 bytes conferidos em `.text` no offset `0x79000`. |
| Geração automática a partir do export | **PASSOU** | 47 instruções geram `spore_00479c00_arm64.cpp`; SHA-256 `8f7a5ae81f714d79ae227ccaf51afc42a093b23b6f4630378baef45ff701fc59`. |
| Compilação ARM64 | **PASSOU** | ELF AArch64 PIE compilado com Android NDK; SHA-256 `8072aa4351fa77aef004ac412e6534d677d3578e1362e88baafc0b1b2693a7c1`. |
| Execução x86 original | **PASSOU** | Corpo original de 128 bytes conferido e executado em página RX num processo x86 nativo no host físico; 5/5 casos. |
| Execução ARM64 | **PASSOU** | Binário executado no dispositivo físico `2303ERA42L`, ABI `arm64-v8a`, Android 15; 5/5 casos. |
| Comparação entre arquiteturas | **PASSOU** | 5/5 casos compartilhados com offset de saída e hash dos dados copiados idênticos; `copy_lift_cross_arch_comparison.json`. |
| Testes dos geradores | **PASSOU** | 8/8 testes nos dois geradores: export válido, bytes alterados, opcode não suportado e desvio externo. |
| Semântica para qualquer chamada possível | **PENDENTE** | Os casos fora dos vetores, regiões inválidas, sobreposição entre fonte/destino e estado de exceção x87 não foram abrangidos. |
| Integração no runtime/boot do Spore | **PENDENTE** | A função está isolada em harness; nenhum boot do jogo ou integração Android foi implementado. |

Casos compartilhados: vazio; um registro; sequência com zero, zero negativo, subnormais, finitos, infinitos, NaNs quiet/signaling; stress determinístico de 256 registros; destino nulo com um registro. O teste verifica posição final, conteúdo, guardas de memória e hash. Nenhum emulador ou tradutor dinâmico foi usado.

## Como reproduzir no Windows

Geração e testes dos lifters:

```powershell
$root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
python "$root\GenerateStaticCopyLift.py" `
  --exe 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe' `
  --csv 'C:\SporeAnalysis\spore_functions.csv' `
  --export 'C:\SporeAnalysis\spore_function_00479c00.json' `
  --output "$root\spore_00479c00_arm64.cpp" `
  --coverage "$root\spore_00479c00_instruction_coverage.json"
Set-Location $root
python -m unittest -v test_static_copy_lift_generator.py test_static_lift_generator.py
```

Referência x86 nativa e validação no telefone físico:

```powershell
.\run_native_copy_x86_reference.ps1
.\build_second_static_lift.ps1
.\run_second_static_lift_on_device.ps1
python .\compare_copy_lift_results.py
```

## Artefatos

- `spore_00479c00_arm64.cpp` — código C++ estático gerado; não editar manualmente.
- `spore_00479c00_instruction_coverage.json` — cobertura/identidade do código gerado.
- `SporeCopyLiftRuntime.hpp` — memória convidada e estado auxiliar restrito ao harness.
- `FirstStaticCopyHarness.cpp` — vetores ARM64.
- `FirstNativeCopyX86Reference.cpp` — harness que executa os bytes originais em x86 nativo.
- `build_second_static_lift.ps1`, `run_second_static_lift_on_device.ps1`, `run_native_copy_x86_reference.ps1` — passos reproduzíveis.
- `compare_copy_lift_results.py`, `copy_lift_cross_arch_comparison.json` — comparação x86/ARM64.
- `native_copy_x86_reference.log`, `arm64_copy_device_validation.log` — logs de execução.
