#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_00c2ebc0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;

    L_00c2ebc0: // 83797c05 CMP
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x0000007cu), t0a)) return BatchLiftStatus::invalid_memory;
        t0b = 0x00000005u;
        t0r = static_cast<std::uint32_t>(t0a - t0b) & 0xffffffffu;
        batch_set_sub_flags(state, t0a, t0b, t0r, 32u);
    L_00c2ebc4: // 7407 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_00c2ebcd;
    L_00c2ebc6: // c7417c04000000 MOV
        t2 = 0x00000004u;
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[1] + 0x0000007cu), t2)) return BatchLiftStatus::invalid_memory;
    L_00c2ebcd: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
