#include "BatchStaticLiftRuntime.hpp"

#include <array>
#include <cstdint>
#include <cstdio>
#include <initializer_list>
#include <string_view>

BatchLiftStatus spore_lift_00c2e4e0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00a6ca00(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_006bb640(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00b3d220(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_011861a0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0118a790(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_011e13c0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00921580(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_009215c0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00edba80(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_005d67f0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0119afe0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0041e920(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0041e990(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0041ea00(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0041ea70(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00423890(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0117dde0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_011874d0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00743b50(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0077f010(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_011895f0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0093c710(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0119af70(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0091e020(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_006b5870(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_009267a0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0119b160(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0088b850(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0092ea70(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_005c1cc0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0117afe0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_011e8b20(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_0117e310(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_008db8c0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00a0fdf0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00925f30(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00926a30(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00705250(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00c7ea30(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_005728f0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00e5c780(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_011849c0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_005e8ff0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_009216a0(BatchLiftMemory&, BatchLiftState&);

namespace {

constexpr std::uint32_t kArgumentAddress = 0x20000000u;
constexpr std::uint32_t kValueAddress = 0x20001000u;

bool run_constant_case(
    const char* label,
    BatchLiftStatus (*function)(BatchLiftMemory&, BatchLiftState&),
    std::uint32_t expected,
    std::uint32_t stack_cleanup) {
    BatchLiftMemory memory;
    if (stack_cleanup > 4u &&
        (!memory.store32(BatchLiftMemory::kEntryEsp + 4u, 0u) ||
         !memory.store32(BatchLiftMemory::kEntryEsp + 8u, 0u) ||
         !memory.store32(BatchLiftMemory::kEntryEsp + 12u, 0u))) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = function(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + stack_cleanup;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status),
        passed ? 1u : 0u);
    return passed;
}

bool run_initializer_0118a790() {
    std::array<std::uint8_t, 0x60> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }

    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0118a790(memory, state);
    std::uint32_t field0 = 0;
    std::uint32_t field4 = 0;
    if (!memory.load32(kArgumentAddress, field0) ||
        !memory.load32(kArgumentAddress + 4u, field4)) {
        return false;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == 1u && field0 == 0x67452301u &&
        field4 == 0xefcdab89u &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=0118a790_initializer result=%08x field0=%08x field4=%08x PASS=%u\n",
        state.regs[0], field0, field4, passed ? 1u : 0u);
    return passed;
}

bool run_validate_image_base_case(
    const char* label,
    std::uint16_t mz,
    std::uint32_t pe,
    std::uint16_t machine,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x80> image{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, image.data(), image.size(), true) ||
        !memory.store16(kArgumentAddress, mz) ||
        !memory.store32(kArgumentAddress + 0x3cu, 0x40u) ||
        !memory.store32(kArgumentAddress + 0x40u, pe) ||
        !memory.store16(kArgumentAddress + 0x58u, machine) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_011e13c0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

bool run_node_walk_case(
    const char* label,
    std::uint32_t object_field,
    std::uint32_t head_field,
    std::uint32_t node_field,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x20> object{};
    std::array<std::uint8_t, 0x10> node{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, node.data(), node.size(), true) ||
        !memory.store32(kArgumentAddress, object_field) ||
        !memory.store32(kArgumentAddress + 8u, head_field) ||
        !memory.store32(kValueAddress, node_field) ||
        !memory.store32(kValueAddress + 4u, 0u) ||
        !memory.store32(kValueAddress + 8u, 0u) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_00921580(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

bool run_tree_node_case(
    const char* label,
    std::uint32_t header_parent,
    std::uint32_t header_left,
    std::uint32_t root_left,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x80> object{};
    BatchLiftMemory memory;
    const auto header = kArgumentAddress + 0x20u;
    const auto root = kArgumentAddress + 0x50u;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress, 0x76543210u) ||
        !memory.store32(kArgumentAddress + 4u, root_left == 0xffffffffu ? 0u : root) ||
        !memory.store32(kArgumentAddress + 8u, header) ||
        !memory.store32(header + 4u, header_left) ||
        !memory.store32(header + 8u, header_parent) ||
        !memory.store32(root, root_left) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_009215c0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

bool run_branch(const char* label, std::uint32_t argument, std::uint32_t expected) {
    std::array<std::uint8_t, 4> argument_bytes{};
    argument_bytes[0] = static_cast<std::uint8_t>(argument);
    argument_bytes[1] = static_cast<std::uint8_t>(argument >> 8u);
    argument_bytes[2] = static_cast<std::uint8_t>(argument >> 16u);
    argument_bytes[3] = static_cast<std::uint8_t>(argument >> 24u);
    BatchLiftMemory memory;
    std::array<std::uint8_t, 4> value_bytes{{0x21, 0x43, 0x65, 0x87}};
    if (!memory.map_region(kArgumentAddress, argument_bytes.data(), argument_bytes.size(), true) ||
        !memory.map_region(kValueAddress, value_bytes.data(), value_bytes.size(), true)) {
        return false;
    }
    if (!memory.store32(BatchLiftMemory::kEntryEsp + 4u, argument)) return false;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.eflags = 0x202u;
    const auto status = spore_lift_0117dde0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_pointer_chain() {
    std::array<std::uint8_t, 0x10> object{};
    std::array<std::uint8_t, 4> value{{0x21, 0x43, 0x65, 0x87}};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, value.data(), value.size(), true) ||
        !memory.store32(kArgumentAddress + 8u, kValueAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.eflags = 0x202u;
    const auto status = spore_lift_011874d0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == kValueAddress &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=011874d0_field result=%08x expected=%08x status=%u PASS=%u\n",
        state.regs[0], kValueAddress, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_write_case() {
    std::array<std::uint8_t, 4> object{{0x78, 0x56, 0x34, 0x12}};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true)) return false;
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    if (spore_lift_00743b50(memory, state) != BatchLiftStatus::returned) return false;
    const bool passed = object[0] == 0 && object[1] == 0 &&
        object[2] == 0 && object[3] == 0 && state.regs[0] == kArgumentAddress;
    std::printf("case=00743b50_write result=%08x expected=00000000 PASS=%u\n",
        object[0] | (object[1] << 8u) | (object[2] << 16u) | (object[3] << 24u),
        passed ? 1u : 0u);
    return passed;
}

bool run_field_case() {
    std::array<std::uint8_t, 0x220> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, 0x13579bdfu)) return false;
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0077f010(memory, state);
    std::uint32_t result = 0;
    if (!memory.load32(kArgumentAddress + 0x21cu, result)) return false;
    const bool passed = status == BatchLiftStatus::returned && result == 0x13579bdfu &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 8u;
    std::printf("case=0077f010_field result=%08x expected=13579bdf status=%u PASS=%u\n",
        result, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_branching_field_case(
    const char* label,
    std::uint32_t first,
    std::uint32_t second,
    std::uint32_t expected) {
    std::array<std::uint8_t, 8> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress, first) ||
        !memory.store32(kArgumentAddress + 4u, second) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_011895f0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_count_case(
    const char* label,
    const std::initializer_list<std::uint32_t>& values,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x20> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true)) return false;
    std::size_t offset = 0;
    for (const auto value : values) {
        if (!memory.store32(kArgumentAddress + static_cast<std::uint32_t>(offset), value)) {
            return false;
        }
        offset += 4;
    }
    if (!memory.store32(kArgumentAddress + static_cast<std::uint32_t>(offset), 0u) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0093c710(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_exchange_case() {
    std::array<std::uint8_t, 8> object{};
    std::array<std::uint8_t, 4> target{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, target.data(), target.size(), true) ||
        !memory.store32(kArgumentAddress + 4u, kValueAddress) ||
        !memory.store32(kValueAddress, 0x2468ace0u) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, 0xdeadbeefu) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0119af70(memory, state);
    std::uint32_t stored = 0;
    if (!memory.load32(kValueAddress, stored)) return false;
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == 0x2468ace0u && stored == 0xdeadbeefu &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=0119af70_exchange result=%08x stored=%08x status=%u PASS=%u\n",
        state.regs[0], stored, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_optional_store_case(
    const char* label,
    std::uint32_t initial,
    std::uint32_t first_value,
    std::uint32_t second_value,
    bool expect_store) {
    std::array<std::uint8_t, 0x20> object{};
    std::array<std::uint8_t, 0x20> target{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, target.data(), target.size(), true) ||
        !memory.store32(kArgumentAddress, initial) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, first_value) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, second_value)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0091e020(memory, state);
    std::uint32_t stored_first = 0;
    std::uint32_t stored_second = 0;
    const std::uint32_t target_address = expect_store ? kValueAddress : kArgumentAddress;
    if (!memory.load32(target_address + 0x0cu, stored_first) ||
        !memory.load32(target_address + 0x10u, stored_second)) {
        return false;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 12u &&
        (!expect_store || (stored_first == first_value && stored_second == second_value)) &&
        (expect_store || (stored_first == 0u && stored_second == 0u));
    std::printf("case=%s stored=%08x,%08x status=%u PASS=%u\n",
        label, stored_first, stored_second, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_constant_init_case() {
    std::array<std::uint8_t, 8> object{{0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true)) return false;
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_006b5870(memory, state);
    std::uint32_t first = 0;
    std::uint32_t second = 0;
    if (!memory.load32(kArgumentAddress, first) ||
        !memory.load32(kArgumentAddress + 4u, second)) return false;
    const bool passed = status == BatchLiftStatus::returned &&
        first == 0x01409b74u && second == 0u &&
        state.regs[0] == kArgumentAddress &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=006b5870_constant_init stored=%08x,%08x status=%u PASS=%u\n",
        first, second, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_align_case(
    const char* label,
    std::uint32_t value,
    std::uint32_t expected) {
    BatchLiftMemory memory;
    if (!memory.store32(BatchLiftMemory::kEntryEsp + 4u, value)) return false;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_009267a0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_flagged_lookup_case(
    const char* label,
    std::uint32_t flags,
    std::uint32_t direct_value,
    std::uint32_t direct_argument,
    std::uint32_t indirect_value,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x20> object{};
    std::array<std::uint8_t, 0x20> indirect{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, indirect.data(), indirect.size(), true) ||
        !memory.store32(kArgumentAddress, flags) ||
        !memory.store32(kArgumentAddress + 8u, kValueAddress) ||
        !memory.store32(kValueAddress, indirect_value) ||
        !memory.store32(kValueAddress + 4u, direct_value) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, direct_argument) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, kArgumentAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0119b160(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_character_class_case(
    const char* label,
    std::uint32_t value,
    std::uint32_t expected) {
    BatchLiftMemory memory;
    if (!memory.store32(BatchLiftMemory::kEntryEsp + 4u, value)) return false;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0088b850(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_object_branch_case(
    const char* label,
    std::uint32_t first,
    std::uint32_t second,
    std::uint32_t third,
    std::uint32_t indirect_value,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x40> object{};
    std::array<std::uint8_t, 0x100> indirect{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, indirect.data(), indirect.size(), true) ||
        !memory.store32(kArgumentAddress + 0x18u, first) ||
        !memory.store32(kArgumentAddress + 0x1cu, second) ||
        !memory.store32(kArgumentAddress + 0x24u, third)) {
        return false;
    }
    if (first == second && !memory.store32(third - 4u, indirect_value)) return false;
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0092ea70(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_vector_search_case(
    const char* label,
    const std::initializer_list<std::uint32_t>& values,
    std::uint32_t target,
    std::uint32_t expected_offset) {
    std::array<std::uint8_t, 0x40> vector{};
    std::array<std::uint8_t, 4> target_memory{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, vector.data(), vector.size(), true) ||
        !memory.map_region(kValueAddress, target_memory.data(), target_memory.size(), true) ||
        !memory.store32(kValueAddress, target)) {
        return false;
    }
    std::size_t offset = 0;
    for (const auto value : values) {
        if (!memory.store32(kArgumentAddress + static_cast<std::uint32_t>(offset), value)) {
            return false;
        }
        offset += 4;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    if (!memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u,
            kArgumentAddress + static_cast<std::uint32_t>(values.size() * 4u)) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, kValueAddress)) {
        return false;
    }
    const auto status = spore_lift_005c1cc0(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == kArgumentAddress + expected_offset &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], kArgumentAddress + expected_offset,
        static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_flag_store_case(
    const char* label,
    std::uint32_t object_field,
    std::uint32_t argument,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x20> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress + 4u, object_field) ||
        !memory.store32(kArgumentAddress + 0xcu, 0xffffffffu) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, argument)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0117afe0(memory, state);
    std::uint32_t stored = 0;
    if (!memory.load32(kArgumentAddress + 0xcu, stored)) return false;
    const bool passed = status == BatchLiftStatus::returned &&
        stored == expected && state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s stored=%08x expected=%08x status=%u PASS=%u\n",
        label, stored, expected, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_byte_copy_case(
    const char* label,
    const std::initializer_list<std::uint8_t>& source_values) {
    std::array<std::uint8_t, 0x20> destination{};
    std::array<std::uint8_t, 0x20> source{};
    std::size_t offset = 0;
    for (const auto value : source_values) {
        source[offset++] = value;
    }
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, destination.data(), destination.size(), true) ||
        !memory.map_region(kValueAddress, source.data(), source.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, kValueAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_011e8b20(memory, state);
    bool copied = true;
    for (std::size_t index = 0; index <= source_values.size(); ++index) {
        std::uint32_t value = 0;
        if (!memory.load8(kArgumentAddress + static_cast<std::uint32_t>(index), value)) {
            return false;
        }
        const auto expected = index < source_values.size() ? source[index] : 0u;
        copied = copied && value == expected;
    }
    const bool passed = status == BatchLiftStatus::returned && copied &&
        state.regs[0] == kArgumentAddress &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], kArgumentAddress, static_cast<unsigned>(status),
        passed ? 1u : 0u);
    return passed;
}

bool run_pointer_validation_case(
    const char* label,
    std::uint32_t limit,
    std::uint8_t first,
    std::uint8_t second,
    std::uint32_t expected_result,
    std::uint32_t expected_pointer) {
    std::array<std::uint8_t, 4> object{};
    std::array<std::uint8_t, 2> pointed_bytes{{first, second}};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, pointed_bytes.data(), pointed_bytes.size(), true) ||
        !memory.store32(kArgumentAddress, kValueAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, limit)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0117e310(memory, state);
    std::uint32_t stored_pointer = 0;
    if (!memory.load32(kArgumentAddress, stored_pointer)) return false;
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected_result &&
        stored_pointer == expected_pointer &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x pointer=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected_result, stored_pointer,
        static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_object_initializer_case(const char* label, std::uint32_t initial) {
    std::array<std::uint8_t, 0x20> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress, initial)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[2] = 0xdeadbeefu;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_008db8c0(memory, state);
    std::uint32_t field0 = 0;
    std::uint32_t field8 = 0;
    std::uint32_t fieldc = 0;
    std::uint32_t field10 = 0;
    std::uint32_t field18 = 0;
    std::uint32_t field14 = 0xff;
    if (!memory.load32(kArgumentAddress, field0) ||
        !memory.load32(kArgumentAddress + 8u, field8) ||
        !memory.load32(kArgumentAddress + 0xcu, fieldc) ||
        !memory.load32(kArgumentAddress + 0x10u, field10) ||
        !memory.load8(kArgumentAddress + 0x14u, field14) ||
        !memory.load32(kArgumentAddress + 0x18u, field18)) {
        return false;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == kArgumentAddress && field0 == 0xffffffffu &&
        field8 == kArgumentAddress + 8u && fieldc == kArgumentAddress + 8u &&
        field10 == 0u && field14 == 0u && field18 == 0u &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x field0=%08x fieldc=%08x PASS=%u\n",
        label, state.regs[0], field0, fieldc, passed ? 1u : 0u);
    return passed;
}

bool run_zero_structure_case(const char* label, std::uint32_t initial) {
    std::array<std::uint8_t, 0x50> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress, initial)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_00a0fdf0(memory, state);
    bool fields_zero = true;
    for (const std::uint32_t offset : {0u, 4u, 8u, 0x2cu, 0x30u, 0x34u,
                                       0x38u, 0x3cu, 0x40u, 0x44u, 0x48u}) {
        std::uint32_t value = 0xffffffffu;
        if (!memory.load32(kArgumentAddress + offset, value)) return false;
        fields_zero = fields_zero && value == 0u;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == kArgumentAddress && fields_zero &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x zero_fields=%u PASS=%u\n",
        label, state.regs[0], kArgumentAddress, fields_zero ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

bool run_three_argument_initializer_case(
    const char* label,
    std::uint32_t first,
    std::uint32_t second,
    std::uint32_t third) {
    std::array<std::uint8_t, 0x24> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, first) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, second) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, third)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_00925f30(memory, state);
    std::uint32_t field0 = 0;
    std::uint32_t field4 = 0;
    std::uint32_t field8 = 0;
    std::uint32_t fieldc = 0;
    std::uint32_t field10 = 0;
    std::uint32_t field14 = 0;
    std::uint32_t field18 = 0;
    std::uint32_t field1c = 0;
    if (!memory.load32(kArgumentAddress, field0) ||
        !memory.load32(kArgumentAddress + 4u, field4) ||
        !memory.load32(kArgumentAddress + 8u, field8) ||
        !memory.load32(kArgumentAddress + 0xcu, fieldc) ||
        !memory.load32(kArgumentAddress + 0x10u, field10) ||
        !memory.load32(kArgumentAddress + 0x14u, field14) ||
        !memory.load32(kArgumentAddress + 0x18u, field18) ||
        !memory.load32(kArgumentAddress + 0x1cu, field1c)) {
        return false;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == kArgumentAddress &&
        field0 == 0x0143e104u && field4 == first &&
        field8 == 0u && fieldc == 0u && field10 == 0u &&
        field14 == third && field18 == second && field1c == 0u &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 16u;
    std::printf("case=%s result=%08x field4=%08x field14=%08x PASS=%u\n",
        label, state.regs[0], field4, field14, passed ? 1u : 0u);
    return passed;
}

bool run_node_lookup_case(
    const char* label,
    std::uint32_t current,
    std::uint32_t argument,
    std::uint32_t current_span,
    std::uint32_t next,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x500> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress + 0x460u, current) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, argument)) {
        return false;
    }
    if (current != kArgumentAddress + 0x448u) {
        if (!memory.store32(current + 4u, current_span) ||
            !memory.store32(current + 0x18u, next)) {
            return false;
        }
        if (next != kArgumentAddress + 0x448u &&
            (!memory.store32(next + 4u, current_span) ||
             !memory.store32(next + 0x18u, kArgumentAddress + 0x448u))) {
            return false;
        }
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[6] = 0xdeadbeefu;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_00926a30(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 8u &&
        state.regs[6] == 0xdeadbeefu;
    std::printf("case=%s result=%08x expected=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, static_cast<unsigned>(status),
        passed ? 1u : 0u);
    return passed;
}

bool run_copy_dwords_case(const char* label, std::size_t count) {
    std::array<std::uint8_t, 0x40> source{};
    std::array<std::uint8_t, 0x40> destination{};
    for (std::size_t index = 0; index < count * 4u; ++index) {
        const auto value = static_cast<std::uint32_t>(0x1000u + index * 0x1111u);
        source[index * 4u] = static_cast<std::uint8_t>(value);
        source[index * 4u + 1u] = static_cast<std::uint8_t>(value >> 8u);
        source[index * 4u + 2u] = static_cast<std::uint8_t>(value >> 16u);
        source[index * 4u + 3u] = static_cast<std::uint8_t>(value >> 24u);
    }
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, source.data(), source.size(), true) ||
        !memory.map_region(kValueAddress, destination.data(), destination.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u,
            kArgumentAddress + static_cast<std::uint32_t>(count * 0x10u)) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, kValueAddress)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[6] = 0xdeadbeefu;
    const auto status = spore_lift_00705250(memory, state);
    bool copied = true;
    for (std::size_t index = 0; index < count * 0x10u; ++index) {
        std::uint32_t actual = 0;
        if (!memory.load8(kValueAddress + static_cast<std::uint32_t>(index), actual)) return false;
        copied = copied && actual == source[index];
    }
    const bool passed = status == BatchLiftStatus::returned && copied &&
        state.regs[0] == kValueAddress + static_cast<std::uint32_t>(count * 0x10u) &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u &&
        state.regs[6] == 0xdeadbeefu;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n", label,
        state.regs[0], kValueAddress + static_cast<std::uint32_t>(count * 0x10u),
        passed ? 1u : 0u);
    return passed;
}

bool run_reverse_word_set_search_case(
    const char* label,
    std::uint32_t cursor_offset,
    std::uint32_t lower_offset,
    std::initializer_list<std::uint16_t> values,
    std::uint32_t expected_offset) {
    std::array<std::uint8_t, 0x80> storage{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, storage.data(), storage.size(), true) ||
        !memory.store16(kArgumentAddress, 0x10u) ||
        !memory.store16(kArgumentAddress + 2u, 0x20u) ||
        !memory.store16(kArgumentAddress + 4u, 0x30u) ||
        !memory.store16(kArgumentAddress + 6u, 0x40u)) {
        return false;
    }
    const auto values_begin = kArgumentAddress + 0x40u;
    auto values_end = values_begin;
    for (const auto value : values) {
        if (!memory.store16(values_end, value)) return false;
        values_end += 2u;
    }
    if (!memory.store32(BatchLiftMemory::kEntryEsp + 4u,
            kArgumentAddress + cursor_offset) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u,
            kArgumentAddress + lower_offset) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, values_begin) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 16u, values_end)) {
        return false;
    }
    constexpr std::uint32_t saved_ebx = 0x13579bdfu;
    constexpr std::uint32_t saved_esi = 0x2468ace0u;
    constexpr std::uint32_t saved_edi = 0x0badf00du;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[3] = saved_ebx;
    state.regs[6] = saved_esi;
    state.regs[7] = saved_edi;
    const auto status = spore_lift_005728f0(memory, state);
    const auto expected = kArgumentAddress + expected_offset;
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected && state.regs[3] == saved_ebx &&
        state.regs[6] == saved_esi && state.regs[7] == saved_edi &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

bool run_tree_lookup_case(
    const char* label,
    std::uint32_t query,
    bool empty_tree,
    std::uint32_t expected_offset) {
    std::array<std::uint8_t, 0x20> object{};
    std::array<std::uint8_t, 0x100> tree{};
    constexpr std::uint32_t root = kValueAddress;
    constexpr std::uint32_t upper = kValueAddress + 0x40u;
    constexpr std::uint32_t lower = kValueAddress + 0x80u;
    constexpr std::uint32_t key_address = kValueAddress + 0xc0u;
    constexpr std::uint32_t output_address = kValueAddress + 0xc4u;
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, tree.data(), tree.size(), true) ||
        !memory.store32(kArgumentAddress + 0x0cu, empty_tree ? 0u : root) ||
        !memory.store32(root, upper) ||
        !memory.store32(root + 4u, lower) ||
        !memory.store32(root + 0x10u, 0x20u) ||
        !memory.store32(upper + 0x10u, 0x30u) ||
        !memory.store32(lower + 0x10u, 0x10u) ||
        !memory.store32(key_address, query) ||
        !memory.store32(output_address, 0xdeadbeefu) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, output_address) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, key_address)) {
        return false;
    }
    constexpr std::uint32_t saved_esi = 0x2468ace0u;
    constexpr std::uint32_t saved_edi = 0x0badf00du;
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[6] = saved_esi;
    state.regs[7] = saved_edi;
    const auto status = spore_lift_00e5c780(memory, state);
    std::uint32_t output = 0;
    if (!memory.load32(output_address, output)) return false;
    const auto expected = expected_offset == 0xffffffffu
        ? kArgumentAddress + 4u
        : kValueAddress + expected_offset;
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == output_address && output == expected &&
        state.regs[6] == saved_esi && state.regs[7] == saved_edi &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 12u;
    std::printf(
        "case=%s result=%08x output=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], output, expected, passed ? 1u : 0u);
    return passed;
}

bool run_bounded_append_case(
    const char* label,
    std::string_view initial,
    std::string_view source_text,
    std::uint32_t capacity,
    std::string_view expected_text,
    std::uint32_t expected_length) {
    std::array<std::uint8_t, 0x20> destination{};
    std::array<std::uint8_t, 0x20> source{};
    std::array<std::uint8_t, 0x20> expected_destination{};
    destination.fill(0xa5u);
    source.fill(0xa5u);
    for (std::size_t index = 0; index < initial.size(); ++index) {
        destination[index] = static_cast<std::uint8_t>(initial[index]);
    }
    if (initial.size() < destination.size()) destination[initial.size()] = 0u;
    expected_destination = destination;
    for (std::size_t index = 0; index < source_text.size(); ++index) {
        source[index] = static_cast<std::uint8_t>(source_text[index]);
    }
    source[source_text.size()] = 0u;
    if (capacity != 0u) {
        for (std::size_t index = 0; index < expected_text.size(); ++index) {
            expected_destination[index] =
                static_cast<std::uint8_t>(expected_text[index]);
        }
        if (expected_text.size() < capacity) {
            expected_destination[expected_text.size()] = 0u;
        }
    } else {
        expected_destination = destination;
    }
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, destination.data(),
            destination.size(), true) ||
        !memory.map_region(kValueAddress, source.data(), source.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, kValueAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, capacity)) {
        return false;
    }
    constexpr std::uint32_t saved_ebx = 0x13579bdfu;
    constexpr std::uint32_t saved_esi = 0x2468ace0u;
    constexpr std::uint32_t saved_edi = 0x0badf00du;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[3] = saved_ebx;
    state.regs[6] = saved_esi;
    state.regs[7] = saved_edi;
    const auto status = spore_lift_011849c0(memory, state);
    const bool memory_matches = destination == expected_destination;
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected_length && memory_matches &&
        state.regs[3] == saved_ebx && state.regs[6] == saved_esi &&
        state.regs[7] == saved_edi &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected_length, passed ? 1u : 0u);
    return passed;
}

bool run_word_pattern_search_case(
    const char* label,
    std::initializer_list<std::uint16_t> text,
    std::initializer_list<std::uint16_t> pattern,
    std::size_t expected_index) {
    std::array<std::uint16_t, 8> text_storage{};
    std::array<std::uint16_t, 8> pattern_storage{};
    std::size_t index = 0;
    for (const auto value : text) text_storage[index++] = value;
    index = 0;
    for (const auto value : pattern) pattern_storage[index++] = value;
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress,
            reinterpret_cast<std::uint8_t*>(text_storage.data()),
            sizeof(text_storage), true) ||
        !memory.map_region(kValueAddress,
            reinterpret_cast<std::uint8_t*>(pattern_storage.data()),
            sizeof(pattern_storage), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u,
            kArgumentAddress + static_cast<std::uint32_t>(text.size() * 2u)) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, kValueAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 16u,
            kValueAddress + static_cast<std::uint32_t>(pattern.size() * 2u))) {
        return false;
    }
    constexpr std::uint32_t saved_ebx = 0x13579bdfu;
    constexpr std::uint32_t saved_ebp = 0x31415926u;
    constexpr std::uint32_t saved_esi = 0x2468ace0u;
    constexpr std::uint32_t saved_edi = 0x0badf00du;
    constexpr std::uint32_t saved_ecx = 0x76543210u;
    BatchLiftState state{};
    state.regs[1] = saved_ecx;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[3] = saved_ebx;
    state.regs[5] = saved_ebp;
    state.regs[6] = saved_esi;
    state.regs[7] = saved_edi;
    const auto status = spore_lift_005e8ff0(memory, state);
    const auto expected = kArgumentAddress +
        static_cast<std::uint32_t>(expected_index * 2u);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected && state.regs[3] == saved_ebx &&
        state.regs[5] == saved_ebp &&
        state.regs[6] == saved_esi && state.regs[7] == saved_edi &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf(
        "case=%s result=%08x expected=%08x ecx=%08x ebx=%08x ebp=%08x "
        "esi=%08x edi=%08x esp=%08x eip=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected, state.regs[1], state.regs[3],
        state.regs[5], state.regs[6], state.regs[7], state.regs[4],
        state.eip, static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_red_black_insert_case(const char* label, unsigned mode) {
    std::array<std::uint8_t, 0x10> header_bytes{};
    std::array<std::uint8_t, 0x80> tree_bytes{};
    BatchLiftMemory memory;
    constexpr std::uint32_t root_address = kValueAddress;
    constexpr std::uint32_t parent_address = kValueAddress + 0x20u;
    constexpr std::uint32_t uncle_address = kValueAddress + 0x40u;
    constexpr std::uint32_t node_address = kValueAddress + 0x60u;
    const auto write_words = [&](std::uint32_t address,
                                 const std::array<std::uint32_t, 4>& words) {
        for (std::size_t index = 0; index < words.size(); ++index) {
            if (!memory.store32(address + static_cast<std::uint32_t>(index * 4u),
                    words[index])) {
                return false;
            }
        }
        return true;
    };
    const auto read_words = [&](std::uint32_t address,
                                std::array<std::uint32_t, 4>& words) {
        for (std::size_t index = 0; index < words.size(); ++index) {
            if (!memory.load32(address + static_cast<std::uint32_t>(index * 4u),
                    words[index])) {
                return false;
            }
        }
        return true;
    };
    if (!memory.map_region(kArgumentAddress, header_bytes.data(),
            header_bytes.size(), true) ||
        !memory.map_region(kValueAddress, tree_bytes.data(),
            tree_bytes.size(), true)) {
        return false;
    }

    std::array<std::uint32_t, 4> header{{
        kArgumentAddress, kArgumentAddress, kArgumentAddress, 0u}};
    std::array<std::uint32_t, 4> root{};
    std::array<std::uint32_t, 4> parent_node{};
    std::array<std::uint32_t, 4> uncle{};
    std::array<std::uint32_t, 4> node{};
    std::uint32_t parent = kArgumentAddress;
    std::uint32_t direction = 0;
    if (mode != 0u) {
        root[2] = kArgumentAddress;
        root[3] = 1u;
        header[0] = root_address;
        header[1] = root_address;
        header[2] = root_address;
        parent = root_address;
    }
    if (mode == 2u) direction = 1u;
    if (mode == 3u) {
        root[0] = parent_address;
        root[1] = uncle_address;
        parent_node[2] = root_address;
        uncle[2] = root_address;
        header[0] = parent_address;
        header[1] = uncle_address;
        parent = parent_address;
        direction = 1u;
    } else if (mode == 4u) {
        root[0] = parent_address;
        parent_node[2] = root_address;
        header[0] = parent_address;
        header[1] = root_address;
        parent = parent_address;
        direction = 1u;
    }
    if (!write_words(kArgumentAddress, header) ||
        !write_words(root_address, root) ||
        !write_words(parent_address, parent_node) ||
        !write_words(uncle_address, uncle) ||
        !write_words(node_address, node) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, node_address) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, parent) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 16u, direction)) {
        return false;
    }

    auto expected_header = header;
    auto expected_root = root;
    auto expected_parent = parent_node;
    auto expected_uncle = uncle;
    auto expected_node = node;
    std::uint32_t expected_result = node_address;
    switch (mode) {
    case 0u:
        expected_header[0] = node_address;
        expected_header[1] = node_address;
        expected_header[2] = node_address;
        expected_node[2] = kArgumentAddress;
        expected_node[3] = 1u;
        break;
    case 1u:
        expected_header[1] = node_address;
        expected_root[1] = node_address;
        expected_node[2] = root_address;
        break;
    case 2u:
        expected_header[0] = node_address;
        expected_root[0] = node_address;
        expected_node[2] = root_address;
        break;
    case 3u:
        expected_header[0] = node_address;
        expected_parent[0] = node_address;
        expected_parent[3] = 1u;
        expected_uncle[3] = 1u;
        expected_node[2] = parent_address;
        expected_result = root_address;
        break;
    case 4u:
        expected_header[0] = node_address;
        expected_header[1] = root_address;
        expected_header[2] = parent_address;
        expected_root[0] = 0u;
        expected_root[2] = parent_address;
        expected_root[3] = 0u;
        expected_parent[0] = node_address;
        expected_parent[1] = root_address;
        expected_parent[2] = kArgumentAddress;
        expected_parent[3] = 1u;
        expected_node[2] = parent_address;
        expected_result = node_address;
        break;
    default:
        return false;
    }

    constexpr std::uint32_t saved_ebx = 0x13579bdfu;
    constexpr std::uint32_t saved_ebp = 0x31415926u;
    constexpr std::uint32_t saved_esi = 0x2468ace0u;
    constexpr std::uint32_t saved_edi = 0x0badf00du;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[3] = saved_ebx;
    state.regs[5] = saved_ebp;
    state.regs[6] = saved_esi;
    state.regs[7] = saved_edi;
    const auto status = spore_lift_009216a0(memory, state);
    std::array<std::uint32_t, 4> actual_header{};
    std::array<std::uint32_t, 4> actual_root{};
    std::array<std::uint32_t, 4> actual_parent{};
    std::array<std::uint32_t, 4> actual_uncle{};
    std::array<std::uint32_t, 4> actual_node{};
    if (!read_words(kArgumentAddress, actual_header) ||
        !read_words(root_address, actual_root) ||
        !read_words(parent_address, actual_parent) ||
        !read_words(uncle_address, actual_uncle) ||
        !read_words(node_address, actual_node)) {
        return false;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected_result &&
        actual_header == expected_header && actual_root == expected_root &&
        actual_parent == expected_parent && actual_uncle == expected_uncle &&
        actual_node == expected_node && state.regs[3] == saved_ebx &&
        state.regs[5] == saved_ebp && state.regs[6] == saved_esi &&
        state.regs[7] == saved_edi &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf(
        "case=%s result=%08x expected=%08x root=%08x "
        "ebx=%08x ebp=%08x esi=%08x edi=%08x esp=%08x status=%u PASS=%u\n",
        label, state.regs[0], expected_result, actual_header[2],
        state.regs[3], state.regs[5], state.regs[6], state.regs[7],
        state.regs[4], static_cast<unsigned>(status), passed ? 1u : 0u);
    return passed;
}

bool run_reverse_block_copy_case(const char* label, std::size_t count) {
    std::array<std::uint8_t, 0x40> source{};
    std::array<std::uint8_t, 0x40> destination{};
    for (std::size_t index = 0; index < source.size(); ++index) {
        source[index] = static_cast<std::uint8_t>(index * 7u + 3u);
    }
    BatchLiftMemory memory;
    const auto bytes = static_cast<std::uint32_t>(count * 0x10u);
    if (!memory.map_region(kArgumentAddress, source.data(), source.size(), true) ||
        !memory.map_region(kValueAddress, destination.data(), destination.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, kArgumentAddress + bytes) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, kValueAddress + bytes)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[6] = 0xdeadbeefu;
    const auto status = spore_lift_00edba80(memory, state);
    bool copied = true;
    for (std::uint32_t index = 0; index < bytes; ++index) {
        std::uint32_t actual = 0;
        if (!memory.load8(kValueAddress + index, actual)) return false;
        copied = copied && actual == source[index];
    }
    const auto expected = kValueAddress;
    const bool passed = status == BatchLiftStatus::returned && copied &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u &&
        state.regs[6] == 0xdeadbeefu;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

bool run_initializer_005d67f0() {
    std::array<std::uint8_t, 0x48> object;
    object.fill(0xffu);
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_005d67f0(memory, state);
    std::uint32_t field0 = 0;
    std::uint32_t field4 = 0;
    if (!memory.load32(kArgumentAddress, field0) ||
        !memory.load32(kArgumentAddress + 4u, field4)) {
        return false;
    }
    bool zeroed = true;
    for (std::uint32_t offset = 8u; offset <= 0x44u; offset += 4u) {
        std::uint32_t value = 0xffffffffu;
        if (!memory.load32(kArgumentAddress + offset, value)) return false;
        zeroed = zeroed && value == 0u;
    }
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == kArgumentAddress &&
        field0 == 0x013f8bf4u && field4 == 0x013f8bf0u && zeroed &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=005d67f0_initializer result=%08x first=%08x second=%08x PASS=%u\n",
        state.regs[0], field0, field4, passed ? 1u : 0u);
    return passed;
}

bool run_block_copy_case(
    const char* label,
    std::size_t count,
    bool null_source) {
    std::array<std::uint8_t, 0x40> source{};
    std::array<std::uint8_t, 0x40> destination{};
    for (std::size_t index = 0; index < source.size(); ++index) {
        source[index] = static_cast<std::uint8_t>(index * 7u + 3u);
    }
    destination.fill(0xa5u);
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, source.data(), source.size(), true) ||
        !memory.map_region(kValueAddress, destination.data(), destination.size(), true) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kValueAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u,
            kValueAddress + static_cast<std::uint32_t>(count * 0x10u)) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u,
            null_source ? 0u : kArgumentAddress)) {
        return false;
    }
    constexpr std::uint32_t saved_esi = 0x13579bdfu;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[6] = saved_esi;
    const auto status = spore_lift_00c7ea30(memory, state);
    bool memory_matches = true;
    for (std::size_t index = 0; index < destination.size(); ++index) {
        const auto expected = !null_source && index < count * 0x10u
            ? source[index]
            : 0xa5u;
        memory_matches = memory_matches && destination[index] == expected;
    }
    const auto source_address = null_source ? 0u : kArgumentAddress;
    const auto expected_result = source_address +
        static_cast<std::uint32_t>(count * 0x10u);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected_result && memory_matches &&
        state.regs[6] == saved_esi &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf(
        "case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected_result, passed ? 1u : 0u);
    return passed;
}

bool run_conditional_initializer_case(
    const char* label,
    std::uint32_t context,
    std::uint32_t record,
    std::uint8_t flags,
    std::uint32_t offset,
    bool expect_initialize) {
    std::array<std::uint8_t, 0x20> object{};
    std::array<std::uint8_t, 0x200> storage{};
    constexpr std::uint32_t descriptor = kValueAddress + 0x40u;
    constexpr std::uint32_t record_address = kValueAddress;
    constexpr std::uint32_t target = kValueAddress + 0x180u;
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.map_region(kValueAddress, storage.data(), storage.size(), true) ||
        !memory.store32(kArgumentAddress, context) ||
        !memory.store32(descriptor + 0x10u, record) ||
        !memory.store8(record_address + 4u, flags) ||
        !memory.store32(record_address + 0x14u, offset) ||
        !memory.store32(target, 0xaaaaaaaau) ||
        !memory.store32(target + 4u, 0xbbbbbbbbu) ||
        !memory.store32(target + 8u, 0xccccccccu) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u, kArgumentAddress) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u, descriptor)) {
        return false;
    }
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    const auto status = spore_lift_0119afe0(memory, state);
    std::uint32_t first = 0, second = 0, third = 0;
    if (!memory.load32(target, first) || !memory.load32(target + 4u, second) ||
        !memory.load32(target + 8u, third)) {
        return false;
    }
    const bool target_matches = expect_initialize
        ? first == 0u && second == 0u && third == 1u
        : first == 0xaaaaaaaau && second == 0xbbbbbbbbu &&
            third == 0xccccccccu;
    const bool passed = status == BatchLiftStatus::returned && target_matches &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s values=%08x,%08x,%08x PASS=%u\n",
        label, first, second, third, passed ? 1u : 0u);
    return passed;
}

bool run_mode_selector_case(
    const char* label,
    BatchLiftStatus (*function)(BatchLiftMemory&, BatchLiftState&),
    std::uint16_t mode,
    std::uint16_t flags,
    std::uint32_t expected) {
    std::array<std::uint8_t, 0x20> object{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, object.data(), object.size(), true) ||
        !memory.store32(kArgumentAddress, 0xdeadbeefu) ||
        !memory.store16(kArgumentAddress + 0x10u, flags) ||
        !memory.store16(kArgumentAddress + 0x12u, mode)) {
        return false;
    }
    constexpr std::uint32_t saved_ebp = 0x13572468u;
    BatchLiftState state{};
    state.regs[1] = kArgumentAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[5] = saved_ebp;
    const auto status = function(memory, state);
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected && state.regs[5] == saved_ebp &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

bool run_backward_word_search_case(
    const char* label,
    std::uint32_t cursor_offset,
    std::uint32_t lower_offset,
    std::uint16_t value,
    std::uint32_t expected_offset) {
    std::array<std::uint8_t, 0x10> words{};
    BatchLiftMemory memory;
    if (!memory.map_region(kArgumentAddress, words.data(), words.size(), true) ||
        !memory.store16(kArgumentAddress, 0x10u) ||
        !memory.store16(kArgumentAddress + 2u, 0x20u) ||
        !memory.store16(kArgumentAddress + 4u, 0x30u) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 4u,
            kArgumentAddress + cursor_offset) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 8u,
            kArgumentAddress + lower_offset) ||
        !memory.store32(BatchLiftMemory::kEntryEsp + 12u, value)) {
        return false;
    }
    constexpr std::uint32_t saved_ebp = 0x24681357u;
    BatchLiftState state{};
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[5] = saved_ebp;
    const auto status = spore_lift_00423890(memory, state);
    const auto expected = kArgumentAddress + expected_offset;
    const bool passed = status == BatchLiftStatus::returned &&
        state.regs[0] == expected && state.regs[5] == saved_ebp &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, state.regs[0], expected, passed ? 1u : 0u);
    return passed;
}

}

int main() {
    std::size_t failures = 0;
    failures += !run_constant_case(
        "00c2e4e0_void_return", spore_lift_00c2e4e0, 0u, 4u);
    failures += !run_constant_case(
        "00a6ca00_ret12", spore_lift_00a6ca00, 0u, 16u);
    failures += !run_constant_case(
        "006bb640_constant", spore_lift_006bb640, 0x01531cdcu, 4u);
    failures += !run_constant_case(
        "00b3d220_constant", spore_lift_00b3d220, 0x0167eac0u, 4u);
    failures += !run_constant_case(
        "011861a0_constant", spore_lift_011861a0, 0x015cd8c0u, 4u);
    failures += !run_initializer_0118a790();
    failures += !run_validate_image_base_case(
        "011e13c0_bad_mz", 0u, 0u, 0u, 0u);
    failures += !run_validate_image_base_case(
        "011e13c0_bad_pe", 0x5a4du, 0u, 0u, 0u);
    failures += !run_validate_image_base_case(
        "011e13c0_valid", 0x5a4du, 0x4550u, 0x010bu, 1u);
    failures += !run_node_walk_case(
        "00921580_direct", kValueAddress, 0u, 0x1234u, kValueAddress);
    failures += !run_node_walk_case(
        "00921580_head", 0u, kValueAddress, 0x1234u, kValueAddress);
    failures += !run_tree_node_case(
        "009215c0_header_case", kArgumentAddress, 0u, 0u, 0x76543210u);
    failures += !run_tree_node_case(
        "009215c0_empty", 0u, 0xdeadbeefu, 0xffffffffu,
        kArgumentAddress + 0x20u);
    failures += !run_tree_node_case(
        "009215c0_root_without_left", 0u, 0xdeadbeefu, 0u,
        kArgumentAddress + 0x50u);
    failures += !run_branch("0117dde0_null", 0u, 0xffffffffu);
    failures += !run_branch("0117dde0_value", kValueAddress, 0x87654321u);
    failures += !run_pointer_chain();
    failures += !run_write_case();
    failures += !run_field_case();
    failures += !run_branching_field_case(
        "011895f0_second_nonzero", 0x11223344u, 1u, 0x11223344u);
    failures += !run_branching_field_case(
        "011895f0_first_five", 5u, 0u, 5u);
    failures += !run_branching_field_case(
        "011895f0_zero_result", 6u, 0u, 0u);
    failures += !run_count_case("0093c710_empty", {}, 0u);
    failures += !run_count_case("0093c710_one", {1u}, 1u);
    failures += !run_count_case("0093c710_two", {1u, 2u}, 2u);
    failures += !run_exchange_case();
    failures += !run_optional_store_case(
        "0091e020_null", 0u, 0x11111111u, 0x22222222u, false);
    failures += !run_optional_store_case(
        "0091e020_non_null", kValueAddress, 0x11111111u, 0x22222222u, true);
    failures += !run_constant_init_case();
    failures += !run_align_case("009267a0_aligned_mask", 0x00000015u, 0x00000020u);
    failures += !run_align_case("009267a0_lower_bound", 0x00000005u, 0x00000010u);
    failures += !run_align_case("009267a0_upper_bound", 0x00000004u, 0x00000010u);
    failures += !run_flagged_lookup_case(
        "0119b160_direct", 0x400u, 0x10u, 0x10u, 0x20u, 0x10u);
    failures += !run_flagged_lookup_case(
        "0119b160_flagged", 0u, 0x10u, kValueAddress + 4u, 0x20u,
        kValueAddress + 0x10u);
    failures += !run_character_class_case("0088b850_backslash", 0x5cu, 1u);
    failures += !run_character_class_case("0088b850_slash", 0x2fu, 1u);
    failures += !run_character_class_case("0088b850_colon", 0x3au, 1u);
    failures += !run_character_class_case("0088b850_other", 0x41u, 0u);
    failures += !run_object_branch_case(
        "0092ea70_direct", 0x100u, 0x200u, 0x300u, 0u, 0xd0u);
    failures += !run_object_branch_case(
        "0092ea70_indirect", 0x1234u, 0x1234u, kValueAddress + 4u,
        0x40u, 0xd0u);
    failures += !run_vector_search_case("005c1cc0_empty", {}, 0x20u, 0u);
    failures += !run_vector_search_case("005c1cc0_first", {0x20u, 0x30u}, 0x20u, 0u);
    failures += !run_vector_search_case("005c1cc0_later", {0x10u, 0x20u}, 0x20u, 4u);
    failures += !run_vector_search_case("005c1cc0_absent", {0x10u, 0x30u}, 0x20u, 8u);
    failures += !run_flag_store_case("0117afe0_null_argument", 0x1234u, 0u, 0u);
    failures += !run_flag_store_case("0117afe0_null_field", 0u, 1u, 0u);
    failures += !run_flag_store_case("0117afe0_set_flag", 0x1234u, 1u, 1u);
    failures += !run_byte_copy_case("011e8b20_empty", {});
    failures += !run_byte_copy_case("011e8b20_copy", {0x53u, 0x70u, 0x6f, 0x72, 0x65u});
    failures += !run_pointer_validation_case(
        "0117e310_limit_low", 1u, 0u, 0u, 0u, kValueAddress);
    failures += !run_pointer_validation_case(
        "0117e310_advance", 2u, 0u, 0u, 1u, kValueAddress + 2u);
    failures += !run_pointer_validation_case(
        "0117e310_nonzero", 2u, 1u, 0u, 0u, kValueAddress);
    failures += !run_object_initializer_case("008db8c0_zero", 0u);
    failures += !run_object_initializer_case("008db8c0_seeded", 0x12345678u);
    failures += !run_zero_structure_case("00a0fdf0_zero", 0u);
    failures += !run_zero_structure_case("00a0fdf0_seeded", 0xa5a5a5a5u);
    failures += !run_three_argument_initializer_case(
        "00925f30_values", 0x11111111u, 0x22222222u, 0x33333333u);
    failures += !run_three_argument_initializer_case(
        "00925f30_zero_third", 0xabcdef01u, 0x12345678u, 0u);
    const auto sentinel = kArgumentAddress + 0x448u;
    const auto first_node = kArgumentAddress + 0x100u;
    const auto second_node = kArgumentAddress + 0x180u;
    failures += !run_node_lookup_case(
        "00926a30_empty", sentinel, 0x20000000u, 0u, 0u, 0u);
    failures += !run_node_lookup_case(
        "00926a30_current", first_node, first_node + 4u, 0x20u,
        sentinel, first_node);
    failures += !run_node_lookup_case(
        "00926a30_next", first_node, second_node + 4u, 0x80u,
        second_node, second_node);
    failures += !run_copy_dwords_case("00705250_empty", 0u);
    failures += !run_copy_dwords_case("00705250_one", 1u);
    failures += !run_copy_dwords_case("00705250_three", 3u);
    failures += !run_reverse_block_copy_case("00edba80_empty", 0u);
    failures += !run_reverse_block_copy_case("00edba80_one", 1u);
    failures += !run_reverse_block_copy_case("00edba80_three", 3u);
    failures += !run_initializer_005d67f0();
    failures += !run_conditional_initializer_case(
        "0119afe0_null_context", 0u, 0u, 0u, 0u, false);
    failures += !run_conditional_initializer_case(
        "0119afe0_null_record", kValueAddress + 0x100u, 0u, 0u, 0u, false);
    failures += !run_conditional_initializer_case(
        "0119afe0_flag_clear", kValueAddress + 0x100u,
        kValueAddress, 0u, 0x140u, false);
    failures += !run_conditional_initializer_case(
        "0119afe0_zero_address", kValueAddress + 0x100u,
        kValueAddress, 2u, 0u - (kValueAddress + 0x100u), false);
    failures += !run_conditional_initializer_case(
        "0119afe0_initialized", kValueAddress + 0x100u,
        kValueAddress, 2u, 0x80u, true);
    failures += !run_mode_selector_case(
        "0041e920_mode1_mask_set", spore_lift_0041e920,
        1u, 0x30u, 0xdeadbeefu);
    failures += !run_mode_selector_case(
        "0041e920_mode1_mask_clear", spore_lift_0041e920,
        1u, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041e920_mode10", spore_lift_0041e920,
        0x10u, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041e920_other_mode", spore_lift_0041e920,
        2u, 0x30u, 0x015d115du);
    failures += !run_mode_selector_case(
        "0041e990_mode9_mask_set", spore_lift_0041e990,
        9u, 0x30u, 0xdeadbeefu);
    failures += !run_mode_selector_case(
        "0041e990_mode9_mask_clear", spore_lift_0041e990,
        9u, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041e990_mode10", spore_lift_0041e990,
        0x10u, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041e990_other_mode", spore_lift_0041e990,
        2u, 0x30u, 0x015d1160u);
    failures += !run_mode_selector_case(
        "0041ea00_mode10_mask_set", spore_lift_0041ea00,
        0x0au, 0x30u, 0xdeadbeefu);
    failures += !run_mode_selector_case(
        "0041ea00_mode10_mask_clear", spore_lift_0041ea00,
        0x0au, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041ea00_mode10", spore_lift_0041ea00,
        0x10u, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041ea00_other_mode", spore_lift_0041ea00,
        2u, 0x30u, 0x015d1164u);
    failures += !run_mode_selector_case(
        "0041ea70_mode13_mask_set", spore_lift_0041ea70,
        0x0du, 0x30u, 0xdeadbeefu);
    failures += !run_mode_selector_case(
        "0041ea70_mode13_mask_clear", spore_lift_0041ea70,
        0x0du, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041ea70_mode10", spore_lift_0041ea70,
        0x10u, 0u, kArgumentAddress);
    failures += !run_mode_selector_case(
        "0041ea70_other_mode", spore_lift_0041ea70,
        2u, 0x30u, 0x015d1168u);
    failures += !run_backward_word_search_case(
        "00423890_empty", 0u, 0u, 0x10u, 0u);
    failures += !run_backward_word_search_case(
        "00423890_last_match", 6u, 0u, 0x30u, 6u);
    failures += !run_backward_word_search_case(
        "00423890_previous_match", 6u, 0u, 0x20u, 4u);
    failures += !run_backward_word_search_case(
        "00423890_not_found", 6u, 0u, 0x40u, 0u);
    failures += !run_block_copy_case("00c7ea30_empty", 0u, false);
    failures += !run_block_copy_case("00c7ea30_one_block", 1u, false);
    failures += !run_block_copy_case("00c7ea30_two_blocks", 2u, false);
    failures += !run_block_copy_case("00c7ea30_null_source", 1u, true);
    failures += !run_reverse_word_set_search_case(
        "005728f0_cursor_at_lower", 0u, 0u, {0x30u}, 0u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_empty_values", 8u, 0u, {}, 0u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_match_last", 8u, 0u, {0x40u}, 8u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_match_previous", 8u, 0u, {0x30u}, 6u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_not_found", 8u, 0u, {0x99u}, 0u);
    failures += !run_tree_lookup_case(
        "00e5c780_empty", 0x20u, true, 0xffffffffu);
    failures += !run_tree_lookup_case("00e5c780_root_match", 0x20u, false, 0u);
    failures += !run_tree_lookup_case("00e5c780_upper_match", 0x30u, false, 0x40u);
    failures += !run_tree_lookup_case("00e5c780_lower_match", 0x10u, false, 0x80u);
    failures += !run_tree_lookup_case(
        "00e5c780_no_match", 0x25u, false, 0xffffffffu);
    failures += !run_bounded_append_case(
        "011849c0_empty_destination", "", "abc", 8u, "abc", 3u);
    failures += !run_bounded_append_case(
        "011849c0_append", "ab", "cde", 8u, "abcde", 5u);
    failures += !run_bounded_append_case(
        "011849c0_truncated", "ab", "cdefg", 5u, "abcd", 7u);
    failures += !run_bounded_append_case(
        "011849c0_full_destination", "abcd", "xy", 4u, "abcd", 6u);
    failures += !run_bounded_append_case(
        "011849c0_zero_capacity", "a", "xy", 0u, "a", 2u);
    failures += !run_bounded_append_case(
        "011849c0_empty_source", "xy", "", 8u, "xy", 2u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_empty_pattern", {0x10u, 0x20u}, {}, 0u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_empty_text", {}, {0x20u}, 0u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_single_match", {0x10u, 0x20u, 0x30u}, {0x20u}, 1u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_pattern_at_start",
        {0x10u, 0x20u, 0x30u}, {0x10u, 0x20u}, 0u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_retry_after_prefix",
        {0x10u, 0x20u, 0x10u, 0x30u}, {0x10u, 0x30u}, 2u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_not_found",
        {0x10u, 0x20u, 0x30u}, {0x20u, 0x10u}, 3u);
    failures += !run_red_black_insert_case("009216a0_empty_root", 0u);
    failures += !run_red_black_insert_case("009216a0_black_parent_right", 1u);
    failures += !run_red_black_insert_case("009216a0_black_parent_left", 2u);
    failures += !run_red_black_insert_case("009216a0_red_uncle_recolor", 3u);
    failures += !run_red_black_insert_case("009216a0_left_left_rotation", 4u);
    std::printf("arm64 summary cases=124 failures=%zu\n", failures);
    return failures == 0 ? 0 : 1;
}
