param(
    [string]$LogPath
)

$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
$executable = "C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe"
$expectedHash = "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b"
$source = Join-Path $root "BatchStaticLiftBranchReference.cpp"
$output = Join-Path $env:TEMP ("BatchStaticLiftBranchReference-" + [Guid]::NewGuid().ToString("N") + ".exe")
$log = if ($LogPath) {
    [System.IO.Path]::GetFullPath($LogPath)
} else {
    Join-Path $root "batch_static_lift_01180160_x86_v1.log"
}
$vswhere = "C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"

if (Test-Path -LiteralPath $log) {
    throw "Reference log already exists; preserve it before rerunning: $log"
}
foreach ($required in @($executable, $source, $vswhere)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Required x86 reference input not found: $required"
    }
}
$hash = (Get-FileHash -LiteralPath $executable -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne $expectedHash) {
    throw "Selected SporeApp.exe hash changed: $hash"
}
$processor = Get-CimInstance Win32_Processor | Select-Object -First 1
if ($processor.Architecture -ne 9 -and $processor.Architecture -ne 0) {
    throw "The original-code reference must run on physical x86/x86-64 hardware."
}
$vsPath = & $vswhere -products "*" -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vsPath) {
    throw "Visual Studio C++ x86/x64 build tools were not found."
}
$vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvarsall.bat"
if (-not (Test-Path -LiteralPath $vcvars)) {
    throw "vcvarsall.bat not found: $vcvars"
}

try {
    $command = 'call "' + $vcvars + '" x86 >nul && cd /d "' + $root +
        '" && cl /nologo /EHsc /std:c++17 /O2 /W4 /I "' + $root +
        '" "' + $source + '" /Fe:"' + $output + '" && "' + $output +
        '" "' + $executable + '" > "' + $log + '" 2>&1'
    & $env:ComSpec /d /s /c $command
    if ($LASTEXITCODE -ne 0) {
        if (Test-Path -LiteralPath $log) {
            Get-Content -LiteralPath $log
        }
        throw "Native x86 reference build or execution failed."
    }
    Select-String -LiteralPath $log -Pattern "summary|FAIL"
    Write-Output "Full native x86 reference log: $log"
} finally {
    if (Test-Path -LiteralPath $output) {
        Remove-Item -LiteralPath $output -Force
    }
}
