#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <initializer_list>
#include <string_view>
#include <vector>

#if !defined(_M_IX86)
#error This reference harness must run as a native 32-bit x86 process.
#endif

namespace {

constexpr std::array<std::uint8_t, 1> kVoidReturnBytes{{0xc3}};
constexpr std::array<std::uint8_t, 3> kRet12Bytes{{0xc2, 0x0c, 0x00}};
constexpr std::array<std::uint8_t, 6> kConstant006bb640Bytes{{
    0xb8, 0xdc, 0x1c, 0x53, 0x01, 0xc3,
}};
constexpr std::array<std::uint8_t, 6> kConstant00b3d220Bytes{{
    0xb8, 0xc0, 0xea, 0x67, 0x01, 0xc3,
}};
constexpr std::array<std::uint8_t, 6> kConstant011861a0Bytes{{
    0xb8, 0xc0, 0xd8, 0x5c, 0x01, 0xc3,
}};
constexpr std::array<std::uint8_t, 53> kInitializer0118a790Bytes{{
    0x8b, 0x44, 0x24, 0x04, 0x33, 0xc9, 0xc7, 0x00, 0x01, 0x23,
    0x45, 0x67, 0xc7, 0x40, 0x04, 0x89, 0xab, 0xcd, 0xef, 0xc7,
    0x40, 0x08, 0xfe, 0xdc, 0xba, 0x98, 0xc7, 0x40, 0x0c, 0x76,
    0x54, 0x32, 0x10, 0xc7, 0x40, 0x10, 0xf0, 0xe1, 0xd2, 0xc3,
    0x89, 0x48, 0x14, 0x89, 0x48, 0x18, 0x89, 0x48, 0x5c, 0x8d,
    0x41, 0x01, 0xc3,
}};
constexpr std::array<std::uint8_t, 53> kValidateImageBaseBytes{{
    0x8b, 0xff, 0x55, 0x8b, 0xec, 0x8b, 0x4d, 0x08, 0xb8, 0x4d,
    0x5a, 0x00, 0x00, 0x66, 0x39, 0x01, 0x74, 0x04, 0x33, 0xc0,
    0x5d, 0xc3, 0x8b, 0x41, 0x3c, 0x03, 0xc1, 0x81, 0x38, 0x50,
    0x45, 0x00, 0x00, 0x75, 0xef, 0x33, 0xd2, 0xb9, 0x0b, 0x01,
    0x00, 0x00, 0x66, 0x39, 0x48, 0x18, 0x0f, 0x94, 0xc2, 0x8b,
    0xc2, 0x5d, 0xc3,
}};
constexpr std::array<std::uint8_t, 50> kNodeWalkBytes{{
    0x8b, 0x4c, 0x24, 0x04, 0x8b, 0x01, 0x85, 0xc0, 0x74, 0x11,
    0x8b, 0x48, 0x04, 0x85, 0xc9, 0x74, 0x20, 0x8b, 0xc1, 0x8b,
    0x48, 0x04, 0x85, 0xc9, 0x75, 0xf7, 0xc3, 0x8b, 0x41, 0x08,
    0x3b, 0x08, 0x75, 0x09, 0x8b, 0xc8, 0x8b, 0x40, 0x08, 0x3b,
    0x08, 0x74, 0xf7, 0x39, 0x01, 0x75, 0x02, 0x8b, 0xc1, 0xc3,
}};
constexpr std::array<std::uint8_t, 61> kTreeNodeBytes{{
    0x8b, 0x4c, 0x24, 0x04, 0x8b, 0x51, 0x08, 0x39, 0x4a, 0x08,
    0x75, 0x09, 0x80, 0x79, 0x0c, 0x00, 0x75, 0x03, 0x8b, 0x01,
    0xc3, 0x8b, 0x41, 0x04, 0x85, 0xc0, 0x74, 0x0f, 0x8b, 0x08,
    0x85, 0xc9, 0x74, 0x1a, 0x8b, 0xc1, 0x8b, 0x08, 0x85, 0xc9,
    0x75, 0xf8, 0xc3, 0x8b, 0xc2, 0x3b, 0x48, 0x04, 0x75, 0x0a,
    0x8b, 0xc8, 0x8b, 0x40, 0x08, 0x3b, 0x48, 0x04, 0x74, 0xf6,
    0xc3,
}};
constexpr std::array<std::uint8_t, 15> kBranchBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x85, 0xc0, 0x75, 0x04,
    0x83, 0xc8, 0xff, 0xc3, 0x8b, 0x00, 0xc3,
}};

std::uint32_t call_no_arguments(void* function) {
    std::uint32_t result = 0;
    __asm {
        xor eax, eax
        call function
        mov result, eax
    }
    return result;
}

std::uint32_t call_backward_word_search(
    void* function,
    std::uint32_t cursor,
    std::uint32_t lower,
    std::uint32_t value) {
    std::uint32_t result = 0;
    __asm {
        push value
        push lower
        push cursor
        call function
        add esp, 12
        mov result, eax
    }
    return result;
}

void call_conditional_initializer(
    void* function, std::uint32_t object, std::uint32_t descriptor) {
    __asm {
        push descriptor
        push object
        call function
        add esp, 8
    }
}

std::uint32_t call_ret12(void* function) {
    std::uint32_t result = 0;
    __asm {
        xor eax, eax
        push 0
        push 0
        push 0
        call function
        mov result, eax
    }
    return result;
}

std::uint32_t call_validate_image_base(void* function, std::uint32_t image) {
    std::uint32_t result = 0;
    __asm {
        push image
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}
constexpr std::array<std::uint8_t, 8> kPointerBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x8b, 0x40, 0x08, 0xc3,
}};
constexpr std::array<std::uint8_t, 9> kWriteBytes{{
    0x8b, 0xc1, 0xc7, 0x00, 0x00, 0x00, 0x00, 0x00, 0xc3,
}};
constexpr std::array<std::uint8_t, 13> kFieldBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x89, 0x81, 0x1c, 0x02,
    0x00, 0x00, 0xc2, 0x04, 0x00,
}};
constexpr std::array<std::uint8_t, 21> kBranchingFieldBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x83, 0x78, 0x04, 0x00,
    0x75, 0x08, 0x83, 0x38, 0x05, 0x74, 0x03, 0x33,
    0xc0, 0xc3, 0x8b, 0x00, 0xc3,
}};
constexpr std::array<std::uint8_t, 18> kCountBytes{{
    0x8b, 0x4c, 0x24, 0x04, 0x83, 0xc8, 0xff, 0x8b, 0x11,
    0x40, 0x83, 0xc1, 0x04, 0x85, 0xd2, 0x75, 0xf6, 0xc3,
}};
constexpr std::array<std::uint8_t, 22> kExchangeBytes{{
    0x8b, 0x44, 0x24, 0x0c, 0x8b, 0x48, 0x04, 0x8b,
    0x54, 0x24, 0x04, 0x03, 0x0a, 0x8b, 0x54, 0x24,
    0x08, 0x8b, 0x01, 0x89, 0x11, 0xc3,
}};
constexpr std::array<std::uint8_t, 23> kOptionalStoreBytes{{
    0x8b, 0x01, 0x85, 0xc0, 0x74, 0x0e, 0x8b, 0x4c,
    0x24, 0x04, 0x8b, 0x54, 0x24, 0x08, 0x89, 0x48,
    0x0c, 0x89, 0x50, 0x10, 0xc2, 0x08, 0x00,
}};
constexpr std::array<std::uint8_t, 16> kConstantInitBytes{{
    0x8b, 0xc1, 0xc7, 0x40, 0x04, 0x00, 0x00, 0x00,
    0x00, 0xc7, 0x00, 0x74, 0x9b, 0x40, 0x01, 0xc3,
}};
constexpr std::array<std::uint8_t, 22> kAlignBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x83, 0xc0, 0x0b, 0x83,
    0xf8, 0x10, 0x76, 0x04, 0x83, 0xe0, 0xf8, 0xc3,
    0xb8, 0x10, 0x00, 0x00, 0x00, 0xc3,
}};
constexpr std::array<std::uint8_t, 27> kFlaggedLookupBytes{{
    0x8b, 0x44, 0x24, 0x08, 0xf7, 0x00, 0x00, 0x04, 0x00,
    0x00, 0x74, 0x05, 0x8b, 0x44, 0x24, 0x04, 0xc3, 0x8b,
    0x40, 0x08, 0x8b, 0x4c, 0x24, 0x04, 0x03, 0x01, 0xc3,
}};
constexpr std::array<std::uint8_t, 28> kCharacterClassBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x83, 0xf8, 0x5c, 0x74, 0x0d,
    0x83, 0xf8, 0x2f, 0x74, 0x08, 0x83, 0xf8, 0x3a, 0x74,
    0x03, 0x33, 0xc0, 0xc3, 0xb8, 0x01, 0x00, 0x00, 0x00, 0xc3,
}};
constexpr std::array<std::uint8_t, 29> kObjectBranchBytes{{
    0x8b, 0x41, 0x18, 0x8b, 0x51, 0x1c, 0x8b, 0x49, 0x24,
    0x3b, 0xc2, 0x75, 0x0c, 0x83, 0xe9, 0x04, 0x8b, 0x09,
    0x8d, 0x81, 0x90, 0x00, 0x00, 0x00, 0xc3, 0x83, 0xc0,
    0xd0, 0xc3,
}};
constexpr std::array<std::uint8_t, 30> kVectorSearchBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x8b, 0x4c, 0x24, 0x08, 0x3b, 0xc1,
    0x74, 0x11, 0x8b, 0x54, 0x24, 0x0c, 0x8b, 0x12, 0x39, 0x10,
    0x74, 0x07, 0x83, 0xc0, 0x04, 0x3b, 0xc1, 0x75, 0xf5, 0xc3,
}};
constexpr std::array<std::uint8_t, 33> kFlagStoreBytes{{
    0x83, 0x7c, 0x24, 0x08, 0x00, 0x8b, 0x44, 0x24, 0x04,
    0x74, 0x0e, 0x83, 0x78, 0x04, 0x00, 0x74, 0x08,
    0xc7, 0x40, 0x0c, 0x01, 0x00, 0x00, 0x00, 0xc3,
    0xc7, 0x40, 0x0c, 0x00, 0x00, 0x00, 0x00, 0xc3,
}};
constexpr std::array<std::uint8_t, 33> kByteCopyBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x56, 0x8b, 0x74, 0x24, 0x0c,
    0x8a, 0x0e, 0x84, 0xc9, 0x8b, 0xd0, 0x74, 0x0b,
    0x88, 0x0a, 0x8a, 0x4e, 0x01, 0x42, 0x46, 0x84, 0xc9,
    0x75, 0xf5, 0xc6, 0x02, 0x00, 0x5e, 0xc3,
}};
constexpr std::array<std::uint8_t, 34> kPointerValidationBytes{{
    0x83, 0x7c, 0x24, 0x04, 0x02, 0x7c, 0x18, 0x8b, 0x01,
    0x80, 0x38, 0x00, 0x75, 0x11, 0x80, 0x78, 0x01, 0x00,
    0x75, 0x0b, 0x83, 0xc0, 0x02, 0x89, 0x01, 0xb8, 0x01,
    0x00, 0x00, 0x00, 0xc3, 0x33, 0xc0, 0xc3,
}};
constexpr std::array<std::uint8_t, 37> kObjectInitializerBytes{{
    0x8b, 0xc1, 0xc7, 0x00, 0xff, 0xff, 0xff, 0xff, 0x33, 0xd2,
    0x8d, 0x48, 0x08, 0x89, 0x51, 0x04, 0x89, 0x51, 0x08,
    0x89, 0x51, 0x0c, 0x89, 0x09, 0x89, 0x48, 0x0c, 0x89,
    0x50, 0x10, 0x88, 0x50, 0x14, 0x89, 0x50, 0x18, 0xc3,
}};
constexpr std::array<std::uint8_t, 40> kZeroStructureBytes{{
    0x8b, 0xc1, 0x33, 0xc9, 0x89, 0x08, 0x89, 0x48, 0x04,
    0x89, 0x48, 0x08, 0x89, 0x48, 0x2c, 0x89, 0x48, 0x30,
    0x89, 0x48, 0x34, 0x89, 0x48, 0x38, 0x89, 0x48, 0x3c,
    0x89, 0x48, 0x40, 0x89, 0x48, 0x44, 0x89, 0x48, 0x48,
    0x89, 0x48, 0x4c, 0xc3,
}};
constexpr std::array<std::uint8_t, 46> kThreeArgumentInitializerBytes{{
    0x8b, 0x54, 0x24, 0x0c, 0x8b, 0xc1, 0x8b, 0x4c, 0x24,
    0x04, 0x89, 0x48, 0x04, 0x33, 0xc9, 0x89, 0x50, 0x14,
    0x8b, 0x54, 0x24, 0x08, 0x89, 0x48, 0x08, 0x89, 0x48,
    0x0c, 0x89, 0x48, 0x10, 0x89, 0x50, 0x18, 0xc7, 0x00,
    0x04, 0xe1, 0x43, 0x01, 0x89, 0x48, 0x1c, 0xc2, 0x0c,
    0x00,
}};
constexpr std::array<std::uint8_t, 47> kNodeLookupBytes{{
    0x8b, 0x81, 0x60, 0x04, 0x00, 0x00, 0x8d, 0x91, 0x48, 0x04,
    0x00, 0x00, 0x56, 0x3b, 0xc2, 0x74, 0x18, 0x8b, 0x4c, 0x24,
    0x08, 0x3b, 0xc8, 0x72, 0x09, 0x8b, 0x70, 0x04, 0x03, 0xf0,
    0x3b, 0xce, 0x72, 0x09, 0x8b, 0x40, 0x18, 0x3b, 0xc2, 0x75,
    0xec, 0x33, 0xc0, 0x5e, 0xc2, 0x04, 0x00,
}};
constexpr std::array<std::uint8_t, 51> kCopyDwordsBytes{{
    0x8b, 0x4c, 0x24, 0x04, 0x8b, 0x54, 0x24, 0x08, 0x8b, 0x44,
    0x24, 0x0c, 0x3b, 0xca, 0x74, 0x22, 0x56, 0x8b, 0x31, 0x89,
    0x30, 0x8b, 0x71, 0x04, 0x89, 0x70, 0x04, 0x8b, 0x71, 0x08,
    0x89, 0x70, 0x08, 0x8b, 0x71, 0x0c, 0x89, 0x70, 0x0c, 0x83,
    0xc1, 0x10, 0x83, 0xc0, 0x10, 0x3b, 0xca, 0x75, 0xe0, 0x5e,
    0xc3,
}};
constexpr std::array<std::uint8_t, 52> kReverseBlockCopyBytes{{
    0x8b, 0x4c, 0x24, 0x08, 0x8b, 0x54, 0x24, 0x04, 0x8b, 0x44,
    0x24, 0x0c, 0x3b, 0xca, 0x74, 0x23, 0x56, 0x8b, 0x71, 0xf0,
    0x83, 0xe9, 0x10, 0x83, 0xe8, 0x10, 0x89, 0x30, 0x8b, 0x71,
    0x04, 0x89, 0x70, 0x04, 0x8b, 0x71, 0x08, 0x89, 0x70, 0x08,
    0x8b, 0x71, 0x0c, 0x89, 0x70, 0x0c, 0x3b, 0xca, 0x75, 0xdf,
    0x5e, 0xc3,
}};
constexpr std::array<std::uint8_t, 73> kInitializer005d67f0Bytes{{
    0x8b, 0xc1, 0x33, 0xc9, 0xc7, 0x40, 0x04, 0x94, 0xf0, 0x3e,
    0x01, 0x89, 0x48, 0x08, 0xc7, 0x00, 0xf4, 0x8b, 0x3f, 0x01,
    0xc7, 0x40, 0x04, 0xf0, 0x8b, 0x3f, 0x01, 0x89, 0x48, 0x0c,
    0x89, 0x48, 0x10, 0x89, 0x48, 0x14, 0x89, 0x48, 0x18, 0x89,
    0x48, 0x1c, 0x89, 0x48, 0x20, 0x89, 0x48, 0x24, 0x89, 0x48,
    0x28, 0x89, 0x48, 0x2c, 0x89, 0x48, 0x30, 0x89, 0x48, 0x34,
    0x89, 0x48, 0x38, 0x89, 0x48, 0x3c, 0x89, 0x48, 0x40, 0x89,
    0x48, 0x44, 0xc3,
}};
constexpr std::array<std::uint8_t, 59> kConditionalInitializer0119afe0Bytes{{
    0x8b, 0x44, 0x24, 0x04, 0x85, 0xc0, 0x74, 0x32, 0x8b, 0x08,
    0x85, 0xc9, 0x74, 0x2c, 0x8b, 0x44, 0x24, 0x08, 0x8b, 0x40,
    0x10, 0x85, 0xc0, 0x74, 0x21, 0xf6, 0x40, 0x04, 0x02, 0x74,
    0x1b, 0x8b, 0x40, 0x14, 0x03, 0xc1, 0x74, 0x14, 0xc7, 0x00,
    0x00, 0x00, 0x00, 0x00, 0xc7, 0x40, 0x04, 0x00, 0x00, 0x00,
    0x00, 0xc7, 0x40, 0x08, 0x01, 0x00, 0x00, 0x00, 0xc3,
}};
constexpr std::array<std::uint8_t, 97> kCandidate0041e920Bytes{{
    0x55, 0x8b, 0xec, 0x83, 0xec, 0x08, 0x89, 0x4d, 0xf8, 0x8b,
    0x45, 0xf8, 0x0f, 0xb7, 0x48, 0x12, 0x83, 0xf9, 0x01, 0x74,
    0x0c, 0x8b, 0x55, 0xf8, 0x0f, 0xb7, 0x42, 0x12, 0x83, 0xf8,
    0x10, 0x75, 0x37, 0x8b, 0x4d, 0xf8, 0x0f, 0xb7, 0x51, 0x10,
    0x83, 0xe2, 0x30, 0x74, 0x0c, 0x8b, 0x45, 0xf8, 0x8b, 0x08,
    0x89, 0x4d, 0xfc, 0xeb, 0x1c, 0xeb, 0x13, 0x8b, 0x55, 0xf8,
    0x0f, 0xb7, 0x42, 0x12, 0x85, 0xc0, 0x74, 0x08, 0x8b, 0x4d,
    0xf8, 0x89,
    0x4d, 0xfc, 0xeb, 0x07, 0xc7, 0x45, 0xfc, 0x00, 0x00, 0x00,
    0x00, 0x8b, 0x45, 0xfc, 0xeb, 0x05, 0xb8, 0x5d, 0x11, 0x5d,
    0x01, 0x8b, 0xe5, 0x5d, 0xc3,
}};
constexpr std::array<std::uint8_t, 97> kCandidate0041e990Bytes{{
    0x55, 0x8b, 0xec, 0x83, 0xec, 0x08, 0x89, 0x4d, 0xf8, 0x8b,
    0x45, 0xf8, 0x0f, 0xb7, 0x48, 0x12, 0x83, 0xf9, 0x09, 0x74,
    0x0c, 0x8b, 0x55, 0xf8, 0x0f, 0xb7, 0x42, 0x12, 0x83, 0xf8,
    0x10, 0x75, 0x37, 0x8b, 0x4d, 0xf8, 0x0f, 0xb7, 0x51, 0x10,
    0x83, 0xe2, 0x30, 0x74, 0x0c, 0x8b, 0x45, 0xf8, 0x8b, 0x08,
    0x89, 0x4d, 0xfc, 0xeb, 0x1c, 0xeb, 0x13, 0x8b, 0x55, 0xf8,
    0x0f, 0xb7, 0x42, 0x12, 0x85, 0xc0, 0x74, 0x08, 0x8b, 0x4d,
    0xf8, 0x89, 0x4d, 0xfc, 0xeb, 0x07, 0xc7, 0x45, 0xfc, 0x00,
    0x00, 0x00, 0x00, 0x8b, 0x45, 0xfc, 0xeb, 0x05, 0xb8, 0x60,
    0x11, 0x5d, 0x01, 0x8b, 0xe5, 0x5d, 0xc3,
}};
constexpr std::array<std::uint8_t, 47> kBackwardWordSearch00423890Bytes{{
    0x55, 0x8b, 0xec, 0x8b, 0x45, 0x08, 0x3b, 0x45, 0x0c, 0x76,
    0x1f, 0x8b, 0x4d, 0x08, 0x0f, 0xb7, 0x51, 0xfe, 0x0f, 0xb7,
    0x45, 0x10, 0x3b, 0xd0, 0x75, 0x05, 0x8b, 0x45, 0x08, 0xeb,
    0x0e, 0x8b, 0x4d, 0x08, 0x83, 0xe9, 0x02, 0x89, 0x4d, 0x08,
    0xeb, 0xd9, 0x8b, 0x45, 0x0c, 0x5d, 0xc3,
}};
constexpr std::array<std::uint8_t, 55> kBlockCopy00c7ea30Bytes{{
    0x8b, 0x4c, 0x24, 0x04, 0x8b, 0x54, 0x24, 0x08, 0x8b, 0x44,
    0x24, 0x0c, 0x3b, 0xca, 0x74, 0x26, 0x56, 0x85, 0xc0, 0x74,
    0x16, 0x8b, 0x31, 0x89, 0x30, 0x8b, 0x71, 0x04, 0x89, 0x70,
    0x04, 0x8b, 0x71, 0x08, 0x89, 0x70, 0x08, 0x8b, 0x71, 0x0c,
    0x89, 0x70, 0x0c, 0x83, 0xc1, 0x10, 0x83, 0xc0, 0x10, 0x3b,
    0xca, 0x75, 0xdc, 0x5e, 0xc3,
}};
constexpr std::array<std::uint8_t, 58> kReverseWordSetSearch005728f0Bytes{{
    0x8b, 0x44, 0x24, 0x04, 0x53, 0x8b, 0x5c, 0x24, 0x0c, 0x56,
    0x57, 0x3b, 0xc3, 0x74, 0x25, 0x8b, 0x54, 0x24, 0x1c, 0x8b,
    0x7c, 0x24, 0x18, 0x8b, 0xcf, 0x3b, 0xfa, 0x74, 0x10, 0x0f,
    0xb7, 0x70, 0xfe, 0x66, 0x3b, 0x31, 0x74, 0x10, 0x83, 0xc1,
    0x02, 0x3b, 0xca, 0x75, 0xf4, 0x83, 0xe8, 0x02, 0x3b, 0xc3,
    0x75, 0xe3, 0x8b, 0xc3, 0x5f, 0x5e, 0x5b, 0xc3,
}};
constexpr std::array<std::uint8_t, 70> kTreeLookup00e5c780Bytes{{
    0x8b, 0x41, 0x0c, 0x8d, 0x51, 0x04, 0x57, 0x8b, 0x7c, 0x24,
    0x0c, 0x8b, 0xca, 0x85, 0xc0, 0x74, 0x16, 0x56, 0x8b, 0x37,
    0x39, 0x70, 0x10, 0x72, 0x07, 0x8b, 0xc8, 0x8b, 0x40, 0x04,
    0xeb, 0x02, 0x8b, 0x00, 0x85, 0xc0, 0x75, 0xee, 0x5e, 0x3b,
    0xca, 0x74, 0x11, 0x8b, 0x07, 0x3b, 0x41, 0x10, 0x72, 0x0a,
    0x8b, 0x44, 0x24, 0x08, 0x89, 0x08, 0x5f, 0xc2, 0x08, 0x00,
    0x8b, 0x44, 0x24, 0x08, 0x89, 0x10, 0x5f, 0xc2, 0x08, 0x00,
}};
constexpr std::array<std::uint8_t, 86> kBoundedAppend011849c0Bytes{{
    0x8b, 0x44, 0x24, 0x0c, 0x8b, 0x4c, 0x24, 0x04, 0x53, 0x33,
    0xdb, 0x57, 0x85, 0xc0, 0x76, 0x0c, 0x80, 0x39, 0x00, 0x74,
    0x07, 0x48, 0x43, 0x41, 0x85, 0xc0, 0x77, 0xf4, 0x33, 0xff,
    0x56, 0x8b, 0x74, 0x24, 0x14, 0x83, 0xf8, 0x01, 0x76, 0x11,
    0x8a, 0x16, 0x84, 0xd2, 0x74, 0x0b, 0x88, 0x11, 0x48, 0x41,
    0x46, 0x47, 0x83, 0xf8, 0x01, 0x77, 0xef, 0x85, 0xc0, 0x74,
    0x03, 0xc6, 0x01, 0x00, 0x8b, 0xc6, 0x8d, 0x50, 0x01, 0x5e,
    0x8a, 0x08, 0x40, 0x84, 0xc9, 0x75, 0xf9, 0x2b, 0xc2, 0x03,
    0xc7, 0x5f, 0x03, 0xc3, 0x5b, 0xc3,
}};
constexpr std::array<std::uint8_t, 176> kWordPatternSearch005e8ff0Bytes{{
    0x51, 0x8b, 0x4c, 0x24, 0x10, 0x8b, 0x44, 0x24, 0x14, 0x53, 0x55, 0x56,
    0x57, 0x3b, 0xc8, 0x0f, 0x84, 0x91, 0x00, 0x00, 0x00, 0x8d, 0x51, 0x02,
    0x3b, 0xd0, 0x8b, 0x44, 0x24, 0x18, 0x89, 0x54, 0x24, 0x10, 0x75, 0x21,
    0x8b, 0x54, 0x24, 0x1c, 0x3b, 0xc2, 0x0f, 0x84, 0x7a, 0x00, 0x00, 0x00,
    0x0f, 0xb7, 0x09, 0x66, 0x39, 0x08, 0x74, 0x72, 0x83, 0xc0, 0x02, 0x3b,
    0xc2, 0x75, 0xf4, 0x5f, 0x5e, 0x5d, 0x5b, 0x59, 0xc3, 0x8b, 0x74, 0x24,
    0x1c, 0x3b, 0xc6, 0x74, 0x5d, 0x8d, 0x49, 0x00, 0x0f, 0xb7, 0x09, 0x66,
    0x39, 0x08, 0x74, 0x0f, 0x83, 0xc0, 0x02, 0x3b, 0xc6, 0x75, 0xf4, 0x5f,
    0x8b, 0xc6, 0x5e, 0x5d, 0x5b, 0x59, 0xc3, 0x3b, 0xc6, 0x74, 0xf4, 0x8d,
    0x78, 0x02, 0x8b, 0xcf, 0x3b, 0xce, 0x74, 0xeb, 0x66, 0x8b, 0x19, 0x66,
    0x3b, 0x1a, 0x75, 0x1e, 0x8b, 0x5c, 0x24, 0x24, 0x83, 0xc2, 0x02, 0x3b,
    0xd3, 0x74, 0x23, 0x83, 0xc1, 0x02, 0x3b, 0xce, 0x74, 0xd1, 0x66, 0x8b,
    0x29, 0x66, 0x3b, 0x2a, 0x74, 0xea, 0x8b, 0x54, 0x24, 0x10, 0x8b, 0xc7,
    0x3b, 0xc6, 0x74, 0x0a, 0x8b, 0x4c, 0x24, 0x20, 0xeb, 0xaa, 0x8b, 0x44,
    0x24, 0x18, 0x5f, 0x5e, 0x5d, 0x5b, 0x59, 0xc3,
}};
constexpr std::array<std::uint8_t, 475> kRedBlackInsert009216a0Bytes{{
    0x8b, 0x44, 0x24, 0x04, 0x8b, 0x4c, 0x24, 0x08, 0x53, 0x33, 0xdb, 0x56,
    0x8b, 0x74, 0x24, 0x14, 0x89, 0x48, 0x08, 0x89, 0x18, 0x89, 0x58, 0x04,
    0x88, 0x58, 0x0c, 0x39, 0x5c, 0x24, 0x18, 0x75, 0x16, 0x89, 0x41, 0x04,
    0x3b, 0xce, 0x75, 0x05, 0x89, 0x46, 0x08, 0xeb, 0x10, 0x3b, 0x4e, 0x04,
    0x75, 0x0d, 0x89, 0x46, 0x04, 0xeb, 0x08, 0x89, 0x01, 0x3b, 0x0e, 0x75,
    0x02, 0x89, 0x06, 0x3b, 0x46, 0x08, 0x0f, 0x84, 0x7d, 0x01, 0x00, 0x00,
    0x55, 0x57, 0x8d, 0x9b, 0x00, 0x00, 0x00, 0x00, 0x8b, 0x50, 0x08, 0x38,
    0x5a, 0x0c, 0x0f, 0x85, 0x73, 0x01, 0x00, 0x00, 0x8b, 0x4a, 0x08, 0x8b,
    0x79, 0x04, 0x3b, 0xd7, 0x0f, 0x85, 0xa8, 0x00, 0x00, 0x00, 0x8b, 0x39,
    0x3b, 0xfb, 0x74, 0x17, 0x38, 0x5f, 0x0c, 0x75, 0x12, 0xc6, 0x42, 0x0c,
    0x01, 0xc6, 0x47, 0x0c, 0x01, 0x88, 0x59, 0x0c, 0x8b, 0xc1, 0xe9, 0x29,
    0x01, 0x00, 0x00, 0x3b, 0x02, 0x75, 0x3c, 0x8b, 0x6e, 0x08, 0x8b, 0xc2,
    0x8b, 0x10, 0x8b, 0x7a, 0x04, 0x89, 0x38, 0x8b, 0x7a, 0x04, 0x3b, 0xfb,
    0x74, 0x03, 0x89, 0x47, 0x08, 0x8b, 0x78, 0x08, 0x89, 0x7a, 0x08, 0x3b,
    0xc5, 0x75, 0x04, 0x8b, 0xea, 0xeb, 0x0f, 0x8b, 0x78, 0x08, 0x3b, 0x47,
    0x04, 0x75, 0x05, 0x89, 0x57, 0x04, 0xeb, 0x02, 0x89, 0x17, 0x89, 0x42,
    0x04, 0x89, 0x50, 0x08, 0x89, 0x6e, 0x08, 0x8b, 0x50, 0x08, 0xc6, 0x42,
    0x0c, 0x01, 0x8b, 0x51, 0x04, 0x88, 0x59, 0x0c, 0x8b, 0x3a, 0x8b, 0x6e,
    0x08, 0x89, 0x79, 0x04, 0x8b, 0x3a, 0x3b, 0xfb, 0x74, 0x03, 0x89, 0x4f,
    0x08, 0x8b, 0x79, 0x08, 0x89, 0x7a, 0x08, 0x3b, 0xcd, 0x75, 0x09, 0x8b,
    0xea, 0x89, 0x0a, 0xe9, 0xb2, 0x00, 0x00, 0x00, 0x8b, 0x79, 0x08, 0x3b,
    0x0f, 0x75, 0x09, 0x89, 0x17, 0x89, 0x0a, 0xe9, 0xa2, 0x00, 0x00, 0x00,
    0x89, 0x57, 0x04, 0x89, 0x0a, 0xe9, 0x98, 0x00, 0x00, 0x00, 0x3b, 0xfb,
    0x74, 0x17, 0x38, 0x5f, 0x0c, 0x75, 0x12, 0xc6, 0x42, 0x0c, 0x01, 0xc6,
    0x47, 0x0c, 0x01, 0x88, 0x59, 0x0c, 0x8b, 0xc1, 0xe9, 0x83, 0x00, 0x00,
    0x00, 0x3b, 0x42, 0x04, 0x75, 0x3a, 0x8b, 0x6e, 0x08, 0x8b, 0xc2, 0x8b,
    0x50, 0x04, 0x8b, 0x3a, 0x89, 0x78, 0x04, 0x8b, 0x3a, 0x3b, 0xfb, 0x74,
    0x03, 0x89, 0x47, 0x08, 0x8b, 0x78, 0x08, 0x89, 0x7a, 0x08, 0x3b, 0xc5,
    0x75, 0x04, 0x8b, 0xea, 0xeb, 0x0e, 0x8b, 0x78, 0x08, 0x3b, 0x07, 0x75,
    0x04, 0x89, 0x17, 0xeb, 0x03, 0x89, 0x57, 0x04, 0x89, 0x02, 0x89, 0x50,
    0x08, 0x89, 0x6e, 0x08, 0x8b, 0x50, 0x08, 0xc6, 0x42, 0x0c, 0x01, 0x8b,
    0x11, 0x88, 0x59, 0x0c, 0x8b, 0x7a, 0x04, 0x8b, 0x6e, 0x08, 0x89, 0x39,
    0x8b, 0x7a, 0x04, 0x3b, 0xfb, 0x74, 0x03, 0x89, 0x4f, 0x08, 0x8b, 0x79,
    0x08, 0x89, 0x7a, 0x08, 0x3b, 0xcd, 0x75, 0x04, 0x8b, 0xea, 0xeb, 0x0f,
    0x8b, 0x79, 0x08, 0x3b, 0x4f, 0x04, 0x75, 0x05, 0x89, 0x57, 0x04, 0xeb,
    0x02, 0x89, 0x17, 0x89, 0x4a, 0x04, 0x89, 0x51, 0x08, 0x89, 0x6e, 0x08,
    0x3b, 0x46, 0x08, 0x0f, 0x85, 0x97, 0xfe, 0xff, 0xff, 0x8b, 0x46, 0x08,
    0x5f, 0x5d, 0x5e, 0xc6, 0x40, 0x0c, 0x01, 0x5b, 0xc3, 0x8b, 0x4e, 0x08,
    0x5e, 0xc6, 0x41, 0x0c, 0x01, 0x5b, 0xc3, 0x8b, 0x56, 0x08, 0x5f, 0x5d,
    0x5e, 0xc6, 0x42, 0x0c, 0x01, 0x5b, 0xc3,
}};
constexpr std::array<std::uint8_t, 97> kCandidate0041ea00Bytes{{
    0x55, 0x8b, 0xec, 0x83, 0xec, 0x08, 0x89, 0x4d, 0xf8, 0x8b,
    0x45, 0xf8, 0x0f, 0xb7, 0x48, 0x12, 0x83, 0xf9, 0x0a, 0x74,
    0x0c, 0x8b, 0x55, 0xf8, 0x0f, 0xb7, 0x42, 0x12, 0x83, 0xf8,
    0x10, 0x75, 0x37, 0x8b, 0x4d, 0xf8, 0x0f, 0xb7, 0x51, 0x10,
    0x83, 0xe2, 0x30, 0x74, 0x0c, 0x8b, 0x45, 0xf8, 0x8b, 0x08,
    0x89, 0x4d, 0xfc, 0xeb, 0x1c, 0xeb, 0x13, 0x8b, 0x55, 0xf8,
    0x0f, 0xb7, 0x42, 0x12, 0x85, 0xc0, 0x74, 0x08, 0x8b, 0x4d,
    0xf8, 0x89, 0x4d, 0xfc, 0xeb, 0x07, 0xc7, 0x45, 0xfc, 0x00,
    0x00, 0x00, 0x00, 0x8b, 0x45, 0xfc, 0xeb, 0x05, 0xb8, 0x64,
    0x11, 0x5d, 0x01, 0x8b, 0xe5, 0x5d, 0xc3,
}};
constexpr std::array<std::uint8_t, 97> kCandidate0041ea70Bytes{{
    0x55, 0x8b, 0xec, 0x83, 0xec, 0x08, 0x89, 0x4d, 0xf8, 0x8b,
    0x45, 0xf8, 0x0f, 0xb7, 0x48, 0x12, 0x83, 0xf9, 0x0d, 0x74,
    0x0c, 0x8b, 0x55, 0xf8, 0x0f, 0xb7, 0x42, 0x12, 0x83, 0xf8,
    0x10, 0x75, 0x37, 0x8b, 0x4d, 0xf8, 0x0f, 0xb7, 0x51, 0x10,
    0x83, 0xe2, 0x30, 0x74, 0x0c, 0x8b, 0x45, 0xf8, 0x8b, 0x08,
    0x89, 0x4d, 0xfc, 0xeb, 0x1c, 0xeb, 0x13, 0x8b, 0x55, 0xf8,
    0x0f, 0xb7, 0x42, 0x12, 0x85, 0xc0, 0x74, 0x08, 0x8b, 0x4d,
    0xf8, 0x89, 0x4d, 0xfc, 0xeb, 0x07, 0xc7, 0x45, 0xfc, 0x00,
    0x00, 0x00, 0x00, 0x8b, 0x45, 0xfc, 0xeb, 0x05, 0xb8, 0x68,
    0x11, 0x5d, 0x01, 0x8b, 0xe5, 0x5d, 0xc3,
}};

void* load_code(
    const char* path,
    std::uint32_t va,
    const std::uint8_t* expected,
    std::size_t length) {
    std::ifstream input(path, std::ios::binary);
    IMAGE_DOS_HEADER dos{};
    DWORD signature = 0;
    IMAGE_FILE_HEADER file{};
    IMAGE_OPTIONAL_HEADER32 optional{};
    input.read(reinterpret_cast<char*>(&dos), sizeof(dos));
    input.seekg(dos.e_lfanew, std::ios::beg);
    input.read(reinterpret_cast<char*>(&signature), sizeof(signature));
    input.read(reinterpret_cast<char*>(&file), sizeof(file));
    input.read(reinterpret_cast<char*>(&optional), sizeof(optional));
    if (!input || dos.e_magic != IMAGE_DOS_SIGNATURE ||
        signature != IMAGE_NT_SIGNATURE || file.Machine != IMAGE_FILE_MACHINE_I386 ||
        optional.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) {
        return nullptr;
    }
    const std::uint32_t rva = va - optional.ImageBase;
    input.seekg(dos.e_lfanew + sizeof(DWORD) + sizeof(IMAGE_FILE_HEADER) +
        file.SizeOfOptionalHeader, std::ios::beg);
    std::uint32_t raw = 0;
    bool found = false;
    for (unsigned i = 0; i < file.NumberOfSections; ++i) {
        IMAGE_SECTION_HEADER section{};
        input.read(reinterpret_cast<char*>(&section), sizeof(section));
        const auto span = (std::max)(section.Misc.VirtualSize, section.SizeOfRawData);
        if (section.VirtualAddress <= rva &&
            static_cast<std::uint64_t>(rva - section.VirtualAddress) + length <= span) {
            const auto offset = rva - section.VirtualAddress;
            if (offset + length > section.SizeOfRawData) return nullptr;
            raw = section.PointerToRawData + offset;
            found = true;
            break;
        }
    }
    if (!found) return nullptr;
    std::vector<std::uint8_t> bytes(length);
    input.seekg(raw, std::ios::beg);
    input.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(length));
    if (input.gcount() != static_cast<std::streamsize>(length) ||
        std::memcmp(bytes.data(), expected, length) != 0) return nullptr;
    void* code = VirtualAlloc(nullptr, length, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!code) return nullptr;
    std::memcpy(code, bytes.data(), length);
    DWORD old_protection = 0;
    if (!VirtualProtect(code, length, PAGE_EXECUTE_READ, &old_protection) ||
        !FlushInstructionCache(GetCurrentProcess(), code, length)) {
        VirtualFree(code, 0, MEM_RELEASE);
        return nullptr;
    }
    return code;
}

bool check(const char* label, std::uint32_t actual, std::uint32_t expected) {
    const bool pass = actual == expected;
    std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
        label, actual, expected, pass ? 1u : 0u);
    return pass;
}

std::uint32_t call_branch(void* function, std::uint32_t argument) {
    std::uint32_t result = 0;
    __asm {
        push argument
        mov eax, function
        call eax
        add esp, 4
        mov result, eax
    }
    return result;
}

void call_this(void* function, std::uint32_t this_value) {
    __asm {
        mov ecx, this_value
        call function
    }
}

std::uint32_t call_this_result(void* function, std::uint32_t this_value) {
    std::uint32_t result = 0;
    __asm {
        mov ecx, this_value
        call function
        mov result, eax
    }
    return result;
}

void call_this_arg(void* function, std::uint32_t this_value, std::uint32_t argument) {
    __asm {
        mov ecx, this_value
        push argument
        call function
        add esp, 4
    }
}

std::uint32_t call_branching_field(
    void* function,
    std::uint32_t object_address) {
    std::uint32_t result = 0;
    __asm {
        push object_address
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}

std::uint32_t call_count(void* function, std::uint32_t object_address) {
    std::uint32_t result = 0;
    __asm {
        push object_address
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}

std::uint32_t call_exchange(
    void* function,
    std::uint32_t first,
    std::uint32_t second,
    std::uint32_t object_address) {
    std::uint32_t result = 0;
    __asm {
        push object_address
        push second
        push first
        call function
        add esp, 12
        mov result, eax
    }
    return result;
}

void call_optional_store(
    void* function,
    std::uint32_t object_address,
    std::uint32_t first,
    std::uint32_t second) {
    __asm {
        push second
        push first
        mov ecx, object_address
        call function
    }
}

void call_constant_init(void* function, std::uint32_t object_address) {
    __asm {
        mov ecx, object_address
        call function
    }
}

std::uint32_t call_align(void* function, std::uint32_t value) {
    std::uint32_t result = 0;
    __asm {
        push value
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}

std::uint32_t call_flagged_lookup(
    void* function,
    std::uint32_t direct_value,
    std::uint32_t object_address) {
    std::uint32_t result = 0;
    __asm {
        push object_address
        push direct_value
        mov eax, function
        call eax
        add esp, 8
        mov result, eax
    }
    return result;
}

std::uint32_t call_character_class(void* function, std::uint32_t value) {
    std::uint32_t result = 0;
    __asm {
        push value
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}

std::uint32_t call_object_branch(void* function, std::uint32_t object_address) {
    std::uint32_t result = 0;
    __asm {
        mov ecx, object_address
        call function
        mov result, eax
    }
    return result;
}

std::uint32_t call_vector_search(
    void* function,
    std::uint32_t begin,
    std::uint32_t end,
    std::uint32_t target) {
    std::uint32_t result = 0;
    __asm {
        push target
        push end
        push begin
        mov eax, function
        call eax
        add esp, 12
        mov result, eax
    }
    return result;
}

void call_flag_store(void* function, std::uint32_t object, std::uint32_t argument) {
    __asm {
        push argument
        push object
        mov eax, function
        call eax
        add esp, 8
    }
}

std::uint32_t call_byte_copy(
    void* function,
    std::uint32_t destination,
    std::uint32_t source) {
    std::uint32_t result = 0;
    __asm {
        push source
        push destination
        call function
        add esp, 8
        mov result, eax
    }
    return result;
}

std::uint32_t call_pointer_validation(
    void* function,
    std::uint32_t object,
    std::uint32_t limit) {
    std::uint32_t result = 0;
    __asm {
        push limit
        mov ecx, object
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}

std::uint32_t call_object_initializer(void* function, std::uint32_t object) {
    std::uint32_t result = 0;
    __asm {
        mov ecx, object
        mov edx, 0deadbeefh
        call function
        mov result, eax
    }
    return result;
}

std::uint32_t call_zero_structure(void* function, std::uint32_t object) {
    std::uint32_t result = 0;
    __asm {
        mov ecx, object
        call function
        mov result, eax
    }
    return result;
}

std::uint32_t call_three_argument_initializer(
    void* function,
    std::uint32_t object,
    std::uint32_t first,
    std::uint32_t second,
    std::uint32_t third) {
    std::uint32_t result = 0;
    __asm {
        push third
        push second
        push first
        mov ecx, object
        call function
        mov result, eax
    }
    return result;
}

std::uint32_t call_node_lookup(
    void* function,
    std::uint32_t object,
    std::uint32_t argument) {
    std::uint32_t result = 0;
    __asm {
        push argument
        mov ecx, object
        call function
        add esp, 4
        mov result, eax
    }
    return result;
}

std::uint32_t call_copy_dwords(
    void* function,
    std::uint32_t source,
    std::uint32_t end,
    std::uint32_t destination) {
    std::uint32_t result = 0;
    __asm {
        push destination
        push end
        push source
        call function
        add esp, 12
        mov result, eax
    }
    return result;
}

std::uint32_t call_block_copy(
    void* function,
    std::uint32_t destination,
    std::uint32_t end,
    std::uint32_t source,
    std::uint32_t& observed_esi) {
    std::uint32_t result = 0;
    std::uint32_t esi_after_call = 0;
    __asm {
        push esi
        mov esi, 13579bdfh
        push source
        push end
        push destination
        call function
        add esp, 12
        mov result, eax
        mov esi_after_call, esi
        pop esi
    }
    observed_esi = esi_after_call;
    return result;
}

bool run_block_copy_case(
    const char* label,
    void* function,
    std::size_t count,
    bool null_source) {
    std::array<std::uint8_t, 0x40> source{};
    std::array<std::uint8_t, 0x40> destination{};
    for (std::size_t index = 0; index < source.size(); ++index) {
        source[index] = static_cast<std::uint8_t>(index * 7u + 3u);
    }
    destination.fill(0xa5u);
    const auto source_address = null_source
        ? 0u
        : reinterpret_cast<std::uint32_t>(source.data());
    const auto destination_address =
        reinterpret_cast<std::uint32_t>(destination.data());
    const auto end_address = destination_address +
        static_cast<std::uint32_t>(count * 0x10u);
    std::uint32_t observed_esi = 0;
    const auto result = call_block_copy(
        function, destination_address, end_address, source_address, observed_esi);
    bool memory_matches = true;
    for (std::size_t index = 0; index < destination.size(); ++index) {
        const auto expected = !null_source && index < count * 0x10u
            ? source[index]
            : 0xa5u;
        memory_matches = memory_matches && destination[index] == expected;
    }
    const auto expected_result = source_address +
        static_cast<std::uint32_t>(count * 0x10u);
    const bool passed = result == expected_result && memory_matches &&
        observed_esi == 0x13579bdfu;
    std::printf(
        "case=%s result=%08x expected=%08x esi=%08x PASS=%u\n",
        label, result, expected_result, observed_esi, passed ? 1u : 0u);
    return passed;
}

std::uint32_t call_reverse_word_set_search(
    void* function,
    std::uint32_t cursor,
    std::uint32_t lower,
    std::uint32_t values_begin,
    std::uint32_t values_end,
    std::uint32_t& observed_ebx,
    std::uint32_t& observed_esi,
    std::uint32_t& observed_edi) {
    std::uint32_t result = 0;
    std::uint32_t ebx_after_call = 0;
    std::uint32_t esi_after_call = 0;
    std::uint32_t edi_after_call = 0;
    __asm {
        push ebx
        push esi
        push edi
        mov ebx, 13579bdfh
        mov esi, 2468ace0h
        mov edi, 0badf00dh
        push values_end
        push values_begin
        push lower
        push cursor
        call function
        add esp, 16
        mov result, eax
        mov ebx_after_call, ebx
        mov esi_after_call, esi
        mov edi_after_call, edi
        pop edi
        pop esi
        pop ebx
    }
    observed_ebx = ebx_after_call;
    observed_esi = esi_after_call;
    observed_edi = edi_after_call;
    return result;
}

bool run_reverse_word_set_search_case(
    const char* label,
    void* function,
    std::uint32_t cursor_offset,
    std::uint32_t lower_offset,
    const std::uint16_t* values,
    std::size_t value_count,
    std::uint32_t expected_offset) {
    std::array<std::uint16_t, 4> words{{0x10u, 0x20u, 0x30u, 0x40u}};
    std::array<std::uint16_t, 4> search_values{};
    for (std::size_t index = 0; index < value_count; ++index) {
        search_values[index] = values[index];
    }
    const auto words_address = reinterpret_cast<std::uint32_t>(words.data());
    const auto values_address =
        reinterpret_cast<std::uint32_t>(search_values.data());
    std::uint32_t observed_ebx = 0, observed_esi = 0, observed_edi = 0;
    const auto result = call_reverse_word_set_search(
        function,
        words_address + cursor_offset,
        words_address + lower_offset,
        values_address,
        values_address + static_cast<std::uint32_t>(value_count * 2u),
        observed_ebx,
        observed_esi,
        observed_edi);
    const bool passed = result == words_address + expected_offset &&
        observed_ebx == 0x13579bdfu && observed_esi == 0x2468ace0u &&
        observed_edi == 0x0badf00du;
    std::printf(
        "case=%s result=%08x expected=%08x ebx=%08x esi=%08x edi=%08x PASS=%u\n",
        label, result, words_address + expected_offset, observed_ebx,
        observed_esi, observed_edi, passed ? 1u : 0u);
    return passed;
}

std::uint32_t call_tree_lookup(
    void* function,
    std::uint32_t object,
    std::uint32_t key_address,
    std::uint32_t output_address,
    std::uint32_t& observed_esi,
    std::uint32_t& observed_edi) {
    std::uint32_t result = 0;
    std::uint32_t esi_after_call = 0;
    std::uint32_t edi_after_call = 0;
    __asm {
        push esi
        push edi
        mov esi, 2468ace0h
        mov edi, 0badf00dh
        push key_address
        push output_address
        mov ecx, object
        call function
        mov result, eax
        mov esi_after_call, esi
        mov edi_after_call, edi
        pop edi
        pop esi
    }
    observed_esi = esi_after_call;
    observed_edi = edi_after_call;
    return result;
}

bool run_tree_lookup_case(
    const char* label,
    void* function,
    std::uint32_t query,
    bool empty_tree,
    std::uint32_t expected_node_index) {
    std::array<std::uint32_t, 8> object{};
    std::array<std::uint32_t, 5> root{};
    std::array<std::uint32_t, 5> upper{};
    std::array<std::uint32_t, 5> lower{};
    std::array<std::uint32_t, 2> key_and_output{{query, 0xdeadbeefu}};
    const auto object_address = reinterpret_cast<std::uint32_t>(object.data());
    const auto root_address = reinterpret_cast<std::uint32_t>(root.data());
    const auto upper_address = reinterpret_cast<std::uint32_t>(upper.data());
    const auto lower_address = reinterpret_cast<std::uint32_t>(lower.data());
    const auto key_address = reinterpret_cast<std::uint32_t>(key_and_output.data());
    const auto output_address =
        reinterpret_cast<std::uint32_t>(key_and_output.data() + 1);
    root[0] = upper_address;
    root[1] = lower_address;
    root[4] = 0x20u;
    upper[4] = 0x30u;
    lower[4] = 0x10u;
    object[3] = empty_tree ? 0u : root_address;
    std::uint32_t expected_node = object_address + 4u;
    if (expected_node_index == 1u) expected_node = root_address;
    if (expected_node_index == 2u) expected_node = upper_address;
    if (expected_node_index == 3u) expected_node = lower_address;
    std::uint32_t observed_esi = 0, observed_edi = 0;
    const auto result = call_tree_lookup(
        function, object_address, key_address, output_address,
        observed_esi, observed_edi);
    const bool passed = result == output_address &&
        key_and_output[1] == expected_node &&
        observed_esi == 0x2468ace0u && observed_edi == 0x0badf00du;
    std::printf(
        "case=%s result=%08x output=%08x expected=%08x PASS=%u\n",
        label, result, key_and_output[1], expected_node, passed ? 1u : 0u);
    return passed;
}

std::uint32_t call_bounded_append(
    void* function,
    std::uint32_t destination,
    std::uint32_t source,
    std::uint32_t capacity,
    std::uint32_t& observed_ebx,
    std::uint32_t& observed_esi,
    std::uint32_t& observed_edi) {
    std::uint32_t result = 0;
    std::uint32_t ebx_after_call = 0;
    std::uint32_t esi_after_call = 0;
    std::uint32_t edi_after_call = 0;
    __asm {
        push ebx
        push esi
        push edi
        mov ebx, 13579bdfh
        mov esi, 2468ace0h
        mov edi, 0badf00dh
        push capacity
        push source
        push destination
        call function
        add esp, 12
        mov result, eax
        mov ebx_after_call, ebx
        mov esi_after_call, esi
        mov edi_after_call, edi
        pop edi
        pop esi
        pop ebx
    }
    observed_ebx = ebx_after_call;
    observed_esi = esi_after_call;
    observed_edi = edi_after_call;
    return result;
}

bool run_bounded_append_case(
    const char* label,
    void* function,
    std::string_view initial,
    std::string_view source_text,
    std::uint32_t capacity,
    std::string_view expected_text,
    std::uint32_t expected_length) {
    std::array<std::uint8_t, 0x20> destination{};
    std::array<std::uint8_t, 0x20> source{};
    std::array<std::uint8_t, 0x20> expected_destination{};
    destination.fill(0xa5u);
    source.fill(0xa5u);
    for (std::size_t index = 0; index < initial.size(); ++index) {
        destination[index] = static_cast<std::uint8_t>(initial[index]);
    }
    if (initial.size() < destination.size()) destination[initial.size()] = 0u;
    expected_destination = destination;
    for (std::size_t index = 0; index < source_text.size(); ++index) {
        source[index] = static_cast<std::uint8_t>(source_text[index]);
    }
    source[source_text.size()] = 0u;
    if (capacity != 0u) {
        for (std::size_t index = 0; index < expected_text.size(); ++index) {
            expected_destination[index] =
                static_cast<std::uint8_t>(expected_text[index]);
        }
        if (expected_text.size() < capacity) {
            expected_destination[expected_text.size()] = 0u;
        }
    } else {
        expected_destination = destination;
    }
    std::uint32_t observed_ebx = 0, observed_esi = 0, observed_edi = 0;
    const auto result = call_bounded_append(
        function,
        reinterpret_cast<std::uint32_t>(destination.data()),
        reinterpret_cast<std::uint32_t>(source.data()),
        capacity,
        observed_ebx,
        observed_esi,
        observed_edi);
    const bool memory_matches = destination == expected_destination;
    const bool passed = result == expected_length && memory_matches &&
        observed_ebx == 0x13579bdfu && observed_esi == 0x2468ace0u &&
        observed_edi == 0x0badf00du;
    std::printf(
        "case=%s result=%08x expected=%08x PASS=%u\n",
        label, result, expected_length, passed ? 1u : 0u);
    return passed;
}

std::uint32_t call_word_pattern_search(
    void* function,
    std::uint32_t text_begin,
    std::uint32_t text_end,
    std::uint32_t pattern_begin,
    std::uint32_t pattern_end,
    std::uint32_t& observed_ebx,
    std::uint32_t& observed_esi,
    std::uint32_t& observed_edi) {
    std::uint32_t result = 0;
    std::uint32_t ebx_after_call = 0;
    std::uint32_t esi_after_call = 0;
    std::uint32_t edi_after_call = 0;
    __asm {
        push ebx
        push esi
        push edi
        mov ebx, 13579bdfh
        mov esi, 2468ace0h
        mov edi, 0badf00dh
        push pattern_end
        push pattern_begin
        push text_end
        push text_begin
        call function
        add esp, 16
        mov result, eax
        mov ebx_after_call, ebx
        mov esi_after_call, esi
        mov edi_after_call, edi
        pop edi
        pop esi
        pop ebx
    }
    observed_ebx = ebx_after_call;
    observed_esi = esi_after_call;
    observed_edi = edi_after_call;
    return result;
}

bool run_word_pattern_search_case(
    const char* label,
    void* function,
    std::initializer_list<std::uint16_t> text,
    std::initializer_list<std::uint16_t> pattern,
    std::size_t expected_index) {
    std::array<std::uint16_t, 8> text_storage{};
    std::array<std::uint16_t, 8> pattern_storage{};
    std::size_t index = 0;
    for (const auto value : text) text_storage[index++] = value;
    index = 0;
    for (const auto value : pattern) pattern_storage[index++] = value;
    const auto text_begin = reinterpret_cast<std::uint32_t>(text_storage.data());
    const auto pattern_begin =
        reinterpret_cast<std::uint32_t>(pattern_storage.data());
    std::uint32_t observed_ebx = 0, observed_esi = 0, observed_edi = 0;
    const auto result = call_word_pattern_search(
        function,
        text_begin,
        text_begin + static_cast<std::uint32_t>(text.size() * 2u),
        pattern_begin,
        pattern_begin + static_cast<std::uint32_t>(pattern.size() * 2u),
        observed_ebx,
        observed_esi,
        observed_edi);
    const auto expected = text_begin +
        static_cast<std::uint32_t>(expected_index * 2u);
    const bool passed = result == expected &&
        observed_ebx == 0x13579bdfu && observed_esi == 0x2468ace0u &&
        observed_edi == 0x0badf00du;
    std::printf(
        "case=%s result=%08x expected=%08x PASS=%u\n",
        label, result, expected, passed ? 1u : 0u);
    return passed;
}

std::uint32_t call_red_black_insert(
    void* function,
    std::uint32_t node,
    std::uint32_t parent,
    std::uint32_t header,
    std::uint32_t direction,
    std::uint32_t& observed_ebx,
    std::uint32_t& observed_esi,
    std::uint32_t& observed_edi) {
    std::uint32_t result = 0;
    std::uint32_t ebx_after_call = 0;
    std::uint32_t esi_after_call = 0;
    std::uint32_t edi_after_call = 0;
    __asm {
        push ebx
        push esi
        push edi
        mov ebx, 13579bdfh
        mov esi, 2468ace0h
        mov edi, 0badf00dh
        push direction
        push header
        push parent
        push node
        call function
        add esp, 16
        mov result, eax
        mov ebx_after_call, ebx
        mov esi_after_call, esi
        mov edi_after_call, edi
        pop edi
        pop esi
        pop ebx
    }
    observed_ebx = ebx_after_call;
    observed_esi = esi_after_call;
    observed_edi = edi_after_call;
    return result;
}

bool run_red_black_insert_case(
    const char* label, void* function, unsigned mode) {
    std::array<std::uint32_t, 4> header{};
    std::array<std::uint32_t, 4> root{};
    std::array<std::uint32_t, 4> parent_node{};
    std::array<std::uint32_t, 4> uncle{};
    std::array<std::uint32_t, 4> node{};
    const auto header_address =
        reinterpret_cast<std::uint32_t>(header.data());
    const auto root_address = reinterpret_cast<std::uint32_t>(root.data());
    const auto parent_address =
        reinterpret_cast<std::uint32_t>(parent_node.data());
    const auto uncle_address = reinterpret_cast<std::uint32_t>(uncle.data());
    const auto node_address = reinterpret_cast<std::uint32_t>(node.data());
    header = {{header_address, header_address, header_address, 0u}};
    std::uint32_t parent = header_address;
    std::uint32_t direction = 0;

    if (mode != 0u) {
        root[2] = header_address;
        root[3] = 1u;
        header[0] = root_address;
        header[1] = root_address;
        header[2] = root_address;
        parent = root_address;
    }
    if (mode == 2u) direction = 1u;
    if (mode == 3u) {
        root[0] = parent_address;
        root[1] = uncle_address;
        parent_node[2] = root_address;
        uncle[2] = root_address;
        header[0] = parent_address;
        header[1] = uncle_address;
        parent = parent_address;
        direction = 1u;
    } else if (mode == 4u) {
        root[0] = parent_address;
        parent_node[2] = root_address;
        header[0] = parent_address;
        header[1] = root_address;
        parent = parent_address;
        direction = 1u;
    }

    auto expected_header = header;
    auto expected_root = root;
    auto expected_parent = parent_node;
    auto expected_uncle = uncle;
    auto expected_node = node;
    std::uint32_t expected_result = node_address;
    switch (mode) {
    case 0u:
        expected_header[0] = node_address;
        expected_header[1] = node_address;
        expected_header[2] = node_address;
        expected_node[2] = header_address;
        expected_node[3] = 1u;
        break;
    case 1u:
        expected_header[1] = node_address;
        expected_root[1] = node_address;
        expected_node[2] = root_address;
        break;
    case 2u:
        expected_header[0] = node_address;
        expected_root[0] = node_address;
        expected_node[2] = root_address;
        break;
    case 3u:
        expected_header[0] = node_address;
        expected_parent[0] = node_address;
        expected_parent[3] = 1u;
        expected_uncle[3] = 1u;
        expected_node[2] = parent_address;
        expected_result = root_address;
        break;
    case 4u:
        expected_header[0] = node_address;
        expected_header[1] = root_address;
        expected_header[2] = parent_address;
        expected_root[0] = 0u;
        expected_root[2] = parent_address;
        expected_root[3] = 0u;
        expected_parent[0] = node_address;
        expected_parent[1] = root_address;
        expected_parent[2] = header_address;
        expected_parent[3] = 1u;
        expected_node[2] = parent_address;
        expected_result = node_address;
        break;
    default:
        return false;
    }

    std::uint32_t observed_ebx = 0, observed_esi = 0, observed_edi = 0;
    const auto result = call_red_black_insert(
        function, node_address, parent, header_address, direction,
        observed_ebx, observed_esi, observed_edi);
    const bool passed = result == expected_result &&
        header == expected_header && root == expected_root &&
        parent_node == expected_parent && uncle == expected_uncle &&
        node == expected_node && observed_ebx == 0x13579bdfu &&
        observed_esi == 0x2468ace0u && observed_edi == 0x0badf00du;
    std::printf(
        "case=%s result=%08x expected=%08x root=%08x "
        "ebx=%08x esi=%08x edi=%08x PASS=%u\n",
        label, result, expected_result, header[2], observed_ebx,
        observed_esi, observed_edi, passed ? 1u : 0u);
    if (!passed) {
        std::printf(
            "  addresses header=%08x root=%08x parent=%08x uncle=%08x node=%08x\n",
            header_address, root_address, parent_address, uncle_address,
            node_address);
        std::printf(
            "  header=%08x,%08x,%08x,%08x root=%08x,%08x,%08x,%08x\n"
            "  parent=%08x,%08x,%08x,%08x uncle=%08x,%08x,%08x,%08x "
            "node=%08x,%08x,%08x,%08x\n",
            header[0], header[1], header[2], header[3],
            root[0], root[1], root[2], root[3],
            parent_node[0], parent_node[1], parent_node[2], parent_node[3],
            uncle[0], uncle[1], uncle[2], uncle[3],
            node[0], node[1], node[2], node[3]);
    }
    return passed;
}

}

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    void* void_return_code = load_code(argv[1], 0x00c2e4e0u,
        kVoidReturnBytes.data(), kVoidReturnBytes.size());
    void* ret12_code = load_code(argv[1], 0x00a6ca00u,
        kRet12Bytes.data(), kRet12Bytes.size());
    void* constant_006bb640_code = load_code(argv[1], 0x006bb640u,
        kConstant006bb640Bytes.data(), kConstant006bb640Bytes.size());
    void* constant_00b3d220_code = load_code(argv[1], 0x00b3d220u,
        kConstant00b3d220Bytes.data(), kConstant00b3d220Bytes.size());
    void* constant_011861a0_code = load_code(argv[1], 0x011861a0u,
        kConstant011861a0Bytes.data(), kConstant011861a0Bytes.size());
    void* initializer_0118a790_code = load_code(argv[1], 0x0118a790u,
        kInitializer0118a790Bytes.data(), kInitializer0118a790Bytes.size());
    void* validate_image_base_code = load_code(argv[1], 0x011e13c0u,
        kValidateImageBaseBytes.data(), kValidateImageBaseBytes.size());
    void* node_walk_code = load_code(argv[1], 0x00921580u,
        kNodeWalkBytes.data(), kNodeWalkBytes.size());
    void* tree_node_code = load_code(argv[1], 0x009215c0u,
        kTreeNodeBytes.data(), kTreeNodeBytes.size());
    void* branch_code = load_code(argv[1], 0x0117dde0u,
        kBranchBytes.data(), kBranchBytes.size());
    void* pointer_code = load_code(argv[1], 0x011874d0u,
        kPointerBytes.data(), kPointerBytes.size());
    void* write_code = load_code(argv[1], 0x00743b50u,
        kWriteBytes.data(), kWriteBytes.size());
    void* field_code = load_code(argv[1], 0x0077f010u,
        kFieldBytes.data(), kFieldBytes.size());
    void* branching_field_code = load_code(argv[1], 0x011895f0u,
        kBranchingFieldBytes.data(), kBranchingFieldBytes.size());
    void* count_code = load_code(argv[1], 0x0093c710u,
        kCountBytes.data(), kCountBytes.size());
    void* exchange_code = load_code(argv[1], 0x0119af70u,
        kExchangeBytes.data(), kExchangeBytes.size());
    void* optional_store_code = load_code(argv[1], 0x0091e020u,
        kOptionalStoreBytes.data(), kOptionalStoreBytes.size());
    void* constant_init_code = load_code(argv[1], 0x006b5870u,
        kConstantInitBytes.data(), kConstantInitBytes.size());
    void* align_code = load_code(argv[1], 0x009267a0u,
        kAlignBytes.data(), kAlignBytes.size());
    void* flagged_lookup_code = load_code(argv[1], 0x0119b160u,
        kFlaggedLookupBytes.data(), kFlaggedLookupBytes.size());
    void* character_class_code = load_code(argv[1], 0x0088b850u,
        kCharacterClassBytes.data(), kCharacterClassBytes.size());
    void* object_branch_code = load_code(argv[1], 0x0092ea70u,
        kObjectBranchBytes.data(), kObjectBranchBytes.size());
    void* vector_search_code = load_code(argv[1], 0x005c1cc0u,
        kVectorSearchBytes.data(), kVectorSearchBytes.size());
    void* flag_store_code = load_code(argv[1], 0x0117afe0u,
        kFlagStoreBytes.data(), kFlagStoreBytes.size());
    void* byte_copy_code = load_code(argv[1], 0x011e8b20u,
        kByteCopyBytes.data(), kByteCopyBytes.size());
    void* pointer_validation_code = load_code(argv[1], 0x0117e310u,
        kPointerValidationBytes.data(), kPointerValidationBytes.size());
    void* object_initializer_code = load_code(argv[1], 0x008db8c0u,
        kObjectInitializerBytes.data(), kObjectInitializerBytes.size());
    void* zero_structure_code = load_code(argv[1], 0x00a0fdf0u,
        kZeroStructureBytes.data(), kZeroStructureBytes.size());
    void* three_argument_initializer_code = load_code(argv[1], 0x00925f30u,
        kThreeArgumentInitializerBytes.data(), kThreeArgumentInitializerBytes.size());
    void* node_lookup_code = load_code(argv[1], 0x00926a30u,
        kNodeLookupBytes.data(), kNodeLookupBytes.size());
    void* copy_dwords_code = load_code(argv[1], 0x00705250u,
        kCopyDwordsBytes.data(), kCopyDwordsBytes.size());
    void* reverse_block_copy_code = load_code(argv[1], 0x00edba80u,
        kReverseBlockCopyBytes.data(), kReverseBlockCopyBytes.size());
    void* initializer_005d67f0_code = load_code(argv[1], 0x005d67f0u,
        kInitializer005d67f0Bytes.data(), kInitializer005d67f0Bytes.size());
    void* conditional_initializer_code = load_code(argv[1], 0x0119afe0u,
        kConditionalInitializer0119afe0Bytes.data(),
        kConditionalInitializer0119afe0Bytes.size());
    void* candidate_0041e920_code = load_code(argv[1], 0x0041e920u,
        kCandidate0041e920Bytes.data(), kCandidate0041e920Bytes.size());
    void* candidate_0041e990_code = load_code(argv[1], 0x0041e990u,
        kCandidate0041e990Bytes.data(), kCandidate0041e990Bytes.size());
    void* candidate_0041ea00_code = load_code(argv[1], 0x0041ea00u,
        kCandidate0041ea00Bytes.data(), kCandidate0041ea00Bytes.size());
    void* candidate_0041ea70_code = load_code(argv[1], 0x0041ea70u,
        kCandidate0041ea70Bytes.data(), kCandidate0041ea70Bytes.size());
    void* backward_word_search_code = load_code(argv[1], 0x00423890u,
        kBackwardWordSearch00423890Bytes.data(),
        kBackwardWordSearch00423890Bytes.size());
    void* block_copy_00c7ea30_code = load_code(argv[1], 0x00c7ea30u,
        kBlockCopy00c7ea30Bytes.data(), kBlockCopy00c7ea30Bytes.size());
    void* reverse_word_set_search_code = load_code(argv[1], 0x005728f0u,
        kReverseWordSetSearch005728f0Bytes.data(),
        kReverseWordSetSearch005728f0Bytes.size());
    void* tree_lookup_00e5c780_code = load_code(argv[1], 0x00e5c780u,
        kTreeLookup00e5c780Bytes.data(), kTreeLookup00e5c780Bytes.size());
    void* bounded_append_011849c0_code = load_code(argv[1], 0x011849c0u,
        kBoundedAppend011849c0Bytes.data(),
        kBoundedAppend011849c0Bytes.size());
    void* word_pattern_search_005e8ff0_code = load_code(argv[1], 0x005e8ff0u,
        kWordPatternSearch005e8ff0Bytes.data(),
        kWordPatternSearch005e8ff0Bytes.size());
    void* red_black_insert_009216a0_code = load_code(argv[1], 0x009216a0u,
        kRedBlackInsert009216a0Bytes.data(),
        kRedBlackInsert009216a0Bytes.size());
    if (!void_return_code || !ret12_code || !constant_006bb640_code ||
        !constant_00b3d220_code || !constant_011861a0_code ||
        !initializer_0118a790_code || !validate_image_base_code ||
        !node_walk_code || !tree_node_code ||
        !branch_code || !pointer_code || !write_code || !field_code ||
        !branching_field_code || !count_code || !exchange_code ||
        !optional_store_code || !constant_init_code || !align_code ||
        !flagged_lookup_code || !character_class_code || !object_branch_code ||
        !vector_search_code || !flag_store_code || !byte_copy_code ||
        !pointer_validation_code || !object_initializer_code || !zero_structure_code ||
        !three_argument_initializer_code || !node_lookup_code || !copy_dwords_code ||
        !reverse_block_copy_code || !initializer_005d67f0_code ||
        !conditional_initializer_code || !candidate_0041e920_code ||
        !candidate_0041e990_code || !candidate_0041ea00_code ||
        !candidate_0041ea70_code || !backward_word_search_code ||
        !block_copy_00c7ea30_code || !reverse_word_set_search_code ||
        !tree_lookup_00e5c780_code || !bounded_append_011849c0_code ||
        !word_pattern_search_005e8ff0_code ||
        !red_black_insert_009216a0_code) {
        std::fprintf(stderr, "load failure flagged=%u\n", flagged_lookup_code != nullptr);
        std::fprintf(stderr, "load failure branch=%u pointer=%u write=%u field=%u branching=%u count=%u exchange=%u optional=%u\n",
            branch_code != nullptr, pointer_code != nullptr, write_code != nullptr,
            field_code != nullptr, branching_field_code != nullptr, count_code != nullptr,
            exchange_code != nullptr, optional_store_code != nullptr);
        std::fprintf(stderr, "load failure conditional=%u candidate=%u\n",
            conditional_initializer_code != nullptr,
            candidate_0041e920_code != nullptr);
        return 2;
    }
    using Function = std::uint32_t(__cdecl*)(std::uint32_t*);
    auto pointer = reinterpret_cast<Function>(pointer_code);
    std::size_t failures = 0;
    failures += !check("00c2e4e0_void_return",
        call_no_arguments(void_return_code), 0u);
    failures += !check("00a6ca00_ret12",
        call_ret12(ret12_code), 0u);
    failures += !check("006bb640_constant",
        call_no_arguments(constant_006bb640_code), 0x01531cdcu);
    failures += !check("00b3d220_constant",
        call_no_arguments(constant_00b3d220_code), 0x0167eac0u);
    failures += !check("011861a0_constant",
        call_no_arguments(constant_011861a0_code), 0x015cd8c0u);
    std::array<std::uint32_t, 32> initializer_object{};
    failures += !check("0118a790_initializer",
        call_branch(initializer_0118a790_code,
            reinterpret_cast<std::uint32_t>(initializer_object.data())), 1u);
    failures += !check("0118a790_magic0", initializer_object[0], 0x67452301u);
    failures += !check("0118a790_magic1", initializer_object[1], 0xefcdab89u);
    std::array<std::uint8_t, 0x80> image{};
    *reinterpret_cast<std::uint32_t*>(image.data() + 0x3c) = 0x40u;
    failures += !check("011e13c0_bad_mz",
        call_validate_image_base(validate_image_base_code,
            reinterpret_cast<std::uint32_t>(image.data())), 0u);
    *reinterpret_cast<std::uint16_t*>(image.data()) = 0x5a4du;
    failures += !check("011e13c0_bad_pe",
        call_validate_image_base(validate_image_base_code,
            reinterpret_cast<std::uint32_t>(image.data())), 0u);
    *reinterpret_cast<std::uint32_t*>(image.data() + 0x40) = 0x4550u;
    *reinterpret_cast<std::uint16_t*>(image.data() + 0x58) = 0x010bu;
    failures += !check("011e13c0_valid",
        call_validate_image_base(validate_image_base_code,
            reinterpret_cast<std::uint32_t>(image.data())), 1u);
    std::uint32_t node_walk_object[4] = {};
    std::uint32_t node_walk_first[2] = {};
    node_walk_object[0] = reinterpret_cast<std::uint32_t>(node_walk_first);
    failures += !check("00921580_direct",
        call_branch(node_walk_code, reinterpret_cast<std::uint32_t>(node_walk_object)),
        reinterpret_cast<std::uint32_t>(node_walk_first));
    node_walk_object[0] = 0u;
    node_walk_object[2] = reinterpret_cast<std::uint32_t>(node_walk_first);
    node_walk_first[0] = 0x1234u;
    failures += !check("00921580_head",
        call_branch(node_walk_code, reinterpret_cast<std::uint32_t>(node_walk_object)),
        reinterpret_cast<std::uint32_t>(node_walk_first));
    std::uint32_t tree_argument[4] = {};
    std::uint32_t tree_header[4] = {};
    tree_argument[0] = 0x76543210u;
    tree_argument[2] = reinterpret_cast<std::uint32_t>(tree_header);
    tree_header[2] = reinterpret_cast<std::uint32_t>(tree_argument);
    failures += !check("009215c0_header_case",
        call_branch(tree_node_code,
            reinterpret_cast<std::uint32_t>(tree_argument)), 0x76543210u);
    tree_header[2] = 0u;
    tree_header[1] = 0xdeadbeefu;
    tree_argument[1] = 0u;
    failures += !check("009215c0_empty",
        call_branch(tree_node_code,
            reinterpret_cast<std::uint32_t>(tree_argument)),
        reinterpret_cast<std::uint32_t>(tree_header));
    std::uint32_t tree_root[3] = {};
    tree_argument[1] = reinterpret_cast<std::uint32_t>(tree_root);
    failures += !check("009215c0_root_without_left",
        call_branch(tree_node_code,
            reinterpret_cast<std::uint32_t>(tree_argument)),
        reinterpret_cast<std::uint32_t>(tree_root));
    failures += !check("0117dde0_null", call_branch(branch_code, 0u), 0xffffffffu);
    std::uint32_t pointed_value = 0x87654321u;
    auto* object = static_cast<std::uint32_t*>(VirtualAlloc(
        nullptr, 0x10, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    if (!object) return 2;
    object[2] = reinterpret_cast<std::uint32_t>(&pointed_value);
    failures += !check("0117dde0_value", call_branch(branch_code, object[2]), 0x87654321u);
    failures += !check("011874d0_field", pointer(object), object[2]);
    std::array<std::uint8_t, 4> write_object{{0x78, 0x56, 0x34, 0x12}};
    call_this(write_code, reinterpret_cast<std::uint32_t>(write_object.data()));
    failures += !check("00743b50_write",
        *reinterpret_cast<std::uint32_t*>(write_object.data()), 0u);
    std::array<std::uint8_t, 0x220> field_object{};
    call_this_arg(field_code,
        reinterpret_cast<std::uint32_t>(field_object.data()), 0x13579bdfu);
    failures += !check("0077f010_field",
        *reinterpret_cast<std::uint32_t*>(field_object.data() + 0x21c), 0x13579bdfu);
    std::array<std::uint32_t, 2> branching_object{};
    branching_object[0] = 0x11223344u;
    branching_object[1] = 1u;
    failures += !check("011895f0_second_nonzero",
        call_branching_field(branching_field_code,
            reinterpret_cast<std::uint32_t>(branching_object.data())), 0x11223344u);
    branching_object[0] = 5u;
    branching_object[1] = 0u;
    failures += !check("011895f0_first_five",
        call_branching_field(branching_field_code,
            reinterpret_cast<std::uint32_t>(branching_object.data())), 5u);
    branching_object[0] = 6u;
    failures += !check("011895f0_zero_result",
        call_branching_field(branching_field_code,
            reinterpret_cast<std::uint32_t>(branching_object.data())), 0u);
    std::array<std::uint32_t, 3> count_object{};
    failures += !check("0093c710_empty",
        call_count(count_code, reinterpret_cast<std::uint32_t>(count_object.data())),
        0u);
    count_object[0] = 1u;
    count_object[1] = 0u;
    failures += !check("0093c710_one",
        call_count(count_code, reinterpret_cast<std::uint32_t>(count_object.data())), 1u);
    count_object[1] = 2u;
    count_object[2] = 0u;
    failures += !check("0093c710_two",
        call_count(count_code, reinterpret_cast<std::uint32_t>(count_object.data())), 2u);
    std::uint32_t exchange_object[2] = {
        0u, reinterpret_cast<std::uint32_t>(&pointed_value)};
    *reinterpret_cast<std::uint32_t*>(exchange_object[1]) = 0x2468ace0u;
    failures += !check("0119af70_exchange",
        call_exchange(exchange_code,
            reinterpret_cast<std::uint32_t>(&exchange_object[0]),
            0xdeadbeefu,
            reinterpret_cast<std::uint32_t>(exchange_object)),
        0x2468ace0u);
    failures += !check("0119af70_stored",
        *reinterpret_cast<std::uint32_t*>(exchange_object[1]), 0xdeadbeefu);
    std::uint32_t optional_object[8] = {};
    std::uint32_t optional_target[8] = {};
    call_optional_store(optional_store_code,
        reinterpret_cast<std::uint32_t>(optional_object), 0x11111111u, 0x22222222u);
    const bool null_pass = optional_object[3] == 0u && optional_object[4] == 0u;
    std::printf("case=0091e020_null stored=%08x,%08x PASS=%u\n",
        optional_object[3], optional_object[4], null_pass ? 1u : 0u);
    failures += !null_pass;
    optional_object[0] = reinterpret_cast<std::uint32_t>(optional_target);
    call_optional_store(optional_store_code,
        reinterpret_cast<std::uint32_t>(optional_object), 0x11111111u, 0x22222222u);
    const bool non_null_pass =
        optional_target[3] == 0x11111111u && optional_target[4] == 0x22222222u;
    std::printf("case=0091e020_non_null stored=%08x,%08x PASS=%u\n",
        optional_target[3], optional_target[4], non_null_pass ? 1u : 0u);
    failures += !non_null_pass;
    std::uint32_t constant_object[2] = {0xffffffffu, 0xffffffffu};
    call_constant_init(constant_init_code,
        reinterpret_cast<std::uint32_t>(constant_object));
    const bool constant_pass =
        constant_object[0] == 0x01409b74u && constant_object[1] == 0u;
    std::printf("case=006b5870_constant_init stored=%08x,%08x PASS=%u\n",
        constant_object[0], constant_object[1], constant_pass ? 1u : 0u);
    failures += !constant_pass;
    failures += !check("009267a0_aligned_mask", call_align(align_code, 0x15u), 0x20u);
    failures += !check("009267a0_lower_bound", call_align(align_code, 0x05u), 0x10u);
    failures += !check("009267a0_upper_bound", call_align(align_code, 0x04u), 0x10u);
    std::uint32_t flagged_object[3] = {0u, 0u, 0u};
    std::uint32_t flagged_indirect[2] = {0x20u, 0x10u};
    flagged_object[0] = 0x400u;
    flagged_object[2] = reinterpret_cast<std::uint32_t>(flagged_indirect);
    failures += !check("0119b160_direct",
        call_flagged_lookup(flagged_lookup_code, 0x10u,
            reinterpret_cast<std::uint32_t>(flagged_object)), 0x10u);
    flagged_object[0] = 0u;
    failures += !check("0119b160_flagged",
        call_flagged_lookup(flagged_lookup_code,
            reinterpret_cast<std::uint32_t>(&flagged_indirect[1]),
            reinterpret_cast<std::uint32_t>(flagged_object)),
        reinterpret_cast<std::uint32_t>(&flagged_indirect[0]) + 0x10u);
    failures += !check("0088b850_backslash",
        call_character_class(character_class_code, 0x5cu), 1u);
    failures += !check("0088b850_slash",
        call_character_class(character_class_code, 0x2fu), 1u);
    failures += !check("0088b850_colon",
        call_character_class(character_class_code, 0x3au), 1u);
    failures += !check("0088b850_other",
        call_character_class(character_class_code, 0x41u), 0u);
    std::uint32_t object_branch[16] = {};
    object_branch[6] = 0x100u;
    object_branch[7] = 0x200u;
    object_branch[9] = 0x300u;
    failures += !check("0092ea70_direct",
        call_object_branch(object_branch_code,
            reinterpret_cast<std::uint32_t>(object_branch)), 0xd0u);
    std::uint32_t object_indirect[64] = {};
    object_indirect[0] = 0x40u;
    object_branch[6] = 0x1234u;
    object_branch[7] = 0x1234u;
    object_branch[9] = reinterpret_cast<std::uint32_t>(&object_indirect[1]);
    failures += !check("0092ea70_indirect",
        call_object_branch(object_branch_code,
            reinterpret_cast<std::uint32_t>(object_branch)),
        0xd0u);
    std::uint32_t vector[4] = {};
    std::uint32_t target_value = 0x20u;
    failures += !check("005c1cc0_empty",
        call_vector_search(vector_search_code,
            reinterpret_cast<std::uint32_t>(vector),
            reinterpret_cast<std::uint32_t>(vector), 
            reinterpret_cast<std::uint32_t>(&target_value)),
        reinterpret_cast<std::uint32_t>(vector));
    vector[0] = 0x20u; vector[1] = 0x30u;
    failures += !check("005c1cc0_first",
        call_vector_search(vector_search_code,
            reinterpret_cast<std::uint32_t>(vector),
            reinterpret_cast<std::uint32_t>(&vector[2]),
            reinterpret_cast<std::uint32_t>(&target_value)),
        reinterpret_cast<std::uint32_t>(vector));
    vector[0] = 0x10u; vector[1] = 0x20u;
    failures += !check("005c1cc0_later",
        call_vector_search(vector_search_code,
            reinterpret_cast<std::uint32_t>(vector),
            reinterpret_cast<std::uint32_t>(&vector[2]),
            reinterpret_cast<std::uint32_t>(&target_value)),
        reinterpret_cast<std::uint32_t>(&vector[1]));
    vector[0] = 0x10u; vector[1] = 0x30u;
    failures += !check("005c1cc0_absent",
        call_vector_search(vector_search_code,
            reinterpret_cast<std::uint32_t>(vector),
            reinterpret_cast<std::uint32_t>(&vector[2]),
            reinterpret_cast<std::uint32_t>(&target_value)),
        reinterpret_cast<std::uint32_t>(&vector[2]));
    std::uint32_t flag_object[8] = {};
    flag_object[1] = 0x1234u;
    flag_object[3] = 0xffffffffu;
    call_flag_store(flag_store_code,
        reinterpret_cast<std::uint32_t>(flag_object), 0u);
    failures += !check("0117afe0_null_argument", flag_object[3], 0u);
    flag_object[1] = 0u;
    call_flag_store(flag_store_code,
        reinterpret_cast<std::uint32_t>(flag_object), 1u);
    failures += !check("0117afe0_null_field", flag_object[3], 0u);
    flag_object[1] = 0x1234u;
    call_flag_store(flag_store_code,
        reinterpret_cast<std::uint32_t>(flag_object), 1u);
    failures += !check("0117afe0_set_flag", flag_object[3], 1u);
    std::array<std::uint8_t, 0x20> destination{};
    std::array<std::uint8_t, 0x20> source{};
    failures += !check("011e8b20_empty",
        call_byte_copy(byte_copy_code,
            reinterpret_cast<std::uint32_t>(destination.data()),
            reinterpret_cast<std::uint32_t>(source.data())),
        reinterpret_cast<std::uint32_t>(destination.data()));
    const bool empty_copy_pass = destination[0] == 0u;
    std::printf("case=011e8b20_empty_terminator stored=%02x expected=00 PASS=%u\n",
        destination[0], empty_copy_pass ? 1u : 0u);
    failures += !empty_copy_pass;
    source = {{0x53u, 0x70u, 0x6fu, 0x72u, 0x65u}};
    destination.fill(0);
    failures += !check("011e8b20_copy",
        call_byte_copy(byte_copy_code,
            reinterpret_cast<std::uint32_t>(destination.data()),
            reinterpret_cast<std::uint32_t>(source.data())),
        reinterpret_cast<std::uint32_t>(destination.data()));
    const bool copy_pass = std::memcmp(destination.data(), source.data(), source.size()) == 0;
    std::printf("case=011e8b20_copy_bytes stored=%02x%02x%02x%02x%02x expected=53706f7265 PASS=%u\n",
        destination[0], destination[1], destination[2], destination[3], destination[4],
        copy_pass ? 1u : 0u);
    failures += !copy_pass;
    std::uint32_t validation_object[1] = {};
    std::uint8_t validation_bytes[2] = {};
    validation_object[0] = reinterpret_cast<std::uint32_t>(validation_bytes);
    failures += !check("0117e310_limit_low",
        call_pointer_validation(pointer_validation_code,
            reinterpret_cast<std::uint32_t>(validation_object), 1u), 0u);
    failures += !check("0117e310_limit_low_pointer",
        validation_object[0], reinterpret_cast<std::uint32_t>(validation_bytes));
    validation_bytes[0] = 0u; validation_bytes[1] = 0u;
    failures += !check("0117e310_advance",
        call_pointer_validation(pointer_validation_code,
            reinterpret_cast<std::uint32_t>(validation_object), 2u), 1u);
    failures += !check("0117e310_advance_pointer",
        validation_object[0], reinterpret_cast<std::uint32_t>(validation_bytes) + 2u);
    validation_object[0] = reinterpret_cast<std::uint32_t>(validation_bytes);
    validation_bytes[0] = 1u;
    failures += !check("0117e310_nonzero",
        call_pointer_validation(pointer_validation_code,
            reinterpret_cast<std::uint32_t>(validation_object), 2u), 0u);
    std::uint32_t initialized[10] = {};
    initialized[0] = 0x12345678u;
    const auto initialized_address =
        reinterpret_cast<std::uint32_t>(initialized);
    failures += !check("008db8c0_zero",
        call_object_initializer(object_initializer_code, initialized_address),
        initialized_address);
    failures += !check("008db8c0_zero_field0", initialized[0], 0xffffffffu);
    failures += !check("008db8c0_zero_fieldc", initialized[3], initialized_address + 8u);
    failures += !check("008db8c0_zero_field10", initialized[4], 0u);
    failures += !check("008db8c0_zero_field18", initialized[6], 0u);
    initialized[0] = 0xa5a5a5a5u;
    failures += !check("008db8c0_seeded",
        call_object_initializer(object_initializer_code, initialized_address),
        initialized_address);
    failures += !check("008db8c0_seeded_field0", initialized[0], 0xffffffffu);
    failures += !check("008db8c0_seeded_fieldc", initialized[3], initialized_address + 8u);
    std::uint32_t zero_structure[20];
    std::fill(std::begin(zero_structure), std::end(zero_structure), 0xa5a5a5a5u);
    const auto zero_structure_address =
        reinterpret_cast<std::uint32_t>(zero_structure);
    failures += !check("00a0fdf0_zero",
        call_zero_structure(zero_structure_code, zero_structure_address),
        zero_structure_address);
    const std::uint32_t zero_offsets[] = {
        0u, 1u, 2u, 0xbu, 0xcu, 0xdu, 0xeu, 0xfu, 0x10u, 0x11u, 0x12u};
    for (const auto offset : zero_offsets) {
        failures += !check("00a0fdf0_zero_field",
            *reinterpret_cast<std::uint32_t*>(
                reinterpret_cast<std::uint8_t*>(zero_structure) + offset * 4u), 0u);
    }
    std::fill(std::begin(zero_structure), std::end(zero_structure), 0x12345678u);
    failures += !check("00a0fdf0_seeded",
        call_zero_structure(zero_structure_code, zero_structure_address),
        zero_structure_address);
    for (const auto offset : zero_offsets) {
        failures += !check("00a0fdf0_seeded_field",
            *reinterpret_cast<std::uint32_t*>(
                reinterpret_cast<std::uint8_t*>(zero_structure) + offset * 4u), 0u);
    }
    std::uint32_t three_argument_object[9] = {};
    const auto three_argument_address =
        reinterpret_cast<std::uint32_t>(three_argument_object);
    failures += !check("00925f30_values",
        call_three_argument_initializer(three_argument_initializer_code,
            three_argument_address, 0x11111111u, 0x22222222u, 0x33333333u),
        three_argument_address);
    failures += !check("00925f30_values_field0", three_argument_object[0], 0x0143e104u);
    failures += !check("00925f30_values_field4", three_argument_object[1], 0x11111111u);
    failures += !check("00925f30_values_field14", three_argument_object[5], 0x33333333u);
    failures += !check("00925f30_values_field18", three_argument_object[6], 0x22222222u);
    failures += !check("00925f30_values_field1c", three_argument_object[7], 0u);
    failures += !check("00925f30_zero_third",
        call_three_argument_initializer(three_argument_initializer_code,
            three_argument_address, 0xabcdef01u, 0x12345678u, 0u),
        three_argument_address);
    failures += !check("00925f30_zero_third_field4", three_argument_object[1], 0xabcdef01u);
    failures += !check("00925f30_zero_third_field14", three_argument_object[5], 0u);
    std::array<std::uint8_t, 0x500> node_object{};
    const auto node_object_address = reinterpret_cast<std::uint32_t>(node_object.data());
    const auto sentinel = node_object_address + 0x448u;
    const auto first_node = node_object_address + 0x100u;
    const auto second_node = node_object_address + 0x180u;
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x460u) = sentinel;
    failures += !check("00926a30_empty",
        call_node_lookup(node_lookup_code, node_object_address, node_object_address), 0u);
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x460u) = first_node;
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x104u) = 0x20u;
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x118u) = sentinel;
    failures += !check("00926a30_current",
        call_node_lookup(node_lookup_code, node_object_address, first_node + 4u),
        first_node);
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x118u) = second_node;
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x184u) = 0x20u;
    *reinterpret_cast<std::uint32_t*>(node_object.data() + 0x198u) = sentinel;
    failures += !check("00926a30_next",
        call_node_lookup(node_lookup_code, node_object_address, second_node + 4u),
        second_node);
    std::array<std::uint32_t, 16> source_dwords{};
    std::array<std::uint32_t, 16> destination_dwords{};
    for (std::size_t index = 0; index < source_dwords.size(); ++index) {
        source_dwords[index] = 0x1000u + static_cast<std::uint32_t>(index) * 0x1111u;
    }
    failures += !check("00705250_empty",
        call_copy_dwords(copy_dwords_code,
            reinterpret_cast<std::uint32_t>(source_dwords.data()),
            reinterpret_cast<std::uint32_t>(source_dwords.data()),
            reinterpret_cast<std::uint32_t>(destination_dwords.data())),
        reinterpret_cast<std::uint32_t>(destination_dwords.data()));
    failures += !check("00705250_one",
        call_copy_dwords(copy_dwords_code,
            reinterpret_cast<std::uint32_t>(source_dwords.data()),
            reinterpret_cast<std::uint32_t>(source_dwords.data() + 4),
            reinterpret_cast<std::uint32_t>(destination_dwords.data())),
        reinterpret_cast<std::uint32_t>(destination_dwords.data() + 4));
    failures += !check("00705250_three",
        call_copy_dwords(copy_dwords_code,
            reinterpret_cast<std::uint32_t>(source_dwords.data()),
            reinterpret_cast<std::uint32_t>(source_dwords.data() + 12),
            reinterpret_cast<std::uint32_t>(destination_dwords.data())),
        reinterpret_cast<std::uint32_t>(destination_dwords.data() + 12));
    failures += !check("00705250_three_data", destination_dwords[2], source_dwords[2]);
    std::array<std::uint8_t, 0x40> reverse_source{};
    std::array<std::uint8_t, 0x40> reverse_destination{};
    for (std::size_t index = 0; index < reverse_source.size(); ++index) {
        reverse_source[index] = static_cast<std::uint8_t>(index * 7u + 3u);
    }
    failures += !check("00edba80_empty",
        call_copy_dwords(reverse_block_copy_code,
            reinterpret_cast<std::uint32_t>(reverse_source.data()),
            reinterpret_cast<std::uint32_t>(reverse_source.data()),
            reinterpret_cast<std::uint32_t>(reverse_destination.data())),
        reinterpret_cast<std::uint32_t>(reverse_destination.data()));
    auto verify_reverse_copy = [&](const char* label, std::size_t count) {
        std::memset(reverse_destination.data(), 0, reverse_destination.size());
        const auto bytes = count * 0x10u;
        const auto source_begin = reinterpret_cast<std::uint32_t>(reverse_source.data());
        const auto destination_begin = reinterpret_cast<std::uint32_t>(reverse_destination.data());
        const auto result = call_copy_dwords(reverse_block_copy_code,
            source_begin, source_begin + static_cast<std::uint32_t>(bytes),
            destination_begin + static_cast<std::uint32_t>(bytes));
        const bool passed = result == destination_begin &&
            std::memcmp(reverse_destination.data(), reverse_source.data(), bytes) == 0;
        std::printf("case=%s result=%08x expected=%08x PASS=%u\n", label,
            result, destination_begin, passed ? 1u : 0u);
        return passed;
    };
    failures += !verify_reverse_copy("00edba80_one", 1u);
    failures += !verify_reverse_copy("00edba80_three", 3u);
    std::array<std::uint32_t, 18> initializer_005d67f0_object;
    std::fill(initializer_005d67f0_object.begin(),
        initializer_005d67f0_object.end(), 0xffffffffu);
    call_this(initializer_005d67f0_code,
        reinterpret_cast<std::uint32_t>(initializer_005d67f0_object.data()));
    bool initializer_005d67f0_pass = initializer_005d67f0_object[0] == 0x013f8bf4u &&
        initializer_005d67f0_object[1] == 0x013f8bf0u;
    for (std::size_t index = 2; index < initializer_005d67f0_object.size(); ++index) {
        initializer_005d67f0_pass = initializer_005d67f0_pass &&
            initializer_005d67f0_object[index] == 0u;
    }
    std::printf("case=005d67f0_initializer result=%08x first=%08x second=%08x PASS=%u\n",
        reinterpret_cast<std::uint32_t>(initializer_005d67f0_object.data()),
        initializer_005d67f0_object[0], initializer_005d67f0_object[1],
        initializer_005d67f0_pass ? 1u : 0u);
    failures += !initializer_005d67f0_pass;
    std::uint32_t conditional_object[1] = {};
    std::uint32_t conditional_context[1] = {};
    std::uint8_t conditional_record[0x20] = {};
    std::uint32_t conditional_target[3] = {0xaaaaaaaa, 0xbbbbbbbb, 0xcccccccc};
    const auto untouched = [&]() {
        return conditional_target[0] == 0xaaaaaaaau &&
            conditional_target[1] == 0xbbbbbbbbu &&
            conditional_target[2] == 0xccccccccu;
    };
    conditional_object[0] = 0u;
    call_conditional_initializer(conditional_initializer_code,
        reinterpret_cast<std::uint32_t>(conditional_object),
        reinterpret_cast<std::uint32_t>(conditional_record));
    bool conditional_null = untouched();
    std::printf("case=0119afe0_null_context PASS=%u\n", conditional_null ? 1u : 0u);
    failures += !conditional_null;
    conditional_object[0] = reinterpret_cast<std::uint32_t>(conditional_context);
    conditional_context[0] = 0u;
    call_conditional_initializer(conditional_initializer_code,
        reinterpret_cast<std::uint32_t>(conditional_object),
        reinterpret_cast<std::uint32_t>(conditional_record));
    bool conditional_null_record = untouched();
    std::printf("case=0119afe0_null_record PASS=%u\n", conditional_null_record ? 1u : 0u);
    failures += !conditional_null_record;
    *reinterpret_cast<std::uint32_t*>(conditional_record + 0x10) =
        reinterpret_cast<std::uint32_t>(conditional_record);
    *reinterpret_cast<std::uint32_t*>(conditional_record + 4) = 0u;
    call_conditional_initializer(conditional_initializer_code,
        reinterpret_cast<std::uint32_t>(conditional_object),
        reinterpret_cast<std::uint32_t>(conditional_record));
    bool conditional_flag_clear = untouched();
    std::printf("case=0119afe0_flag_clear PASS=%u\n", conditional_flag_clear ? 1u : 0u);
    failures += !conditional_flag_clear;
    *reinterpret_cast<std::uint32_t*>(conditional_record + 4) = 2u;
    *reinterpret_cast<std::uint32_t*>(conditional_record + 0x14) =
        0u - reinterpret_cast<std::uint32_t>(conditional_context);
    call_conditional_initializer(conditional_initializer_code,
        reinterpret_cast<std::uint32_t>(conditional_object),
        reinterpret_cast<std::uint32_t>(conditional_record));
    const bool conditional_zero_address = untouched();
    std::printf("case=0119afe0_zero_address PASS=%u\n",
        conditional_zero_address ? 1u : 0u);
    failures += !conditional_zero_address;
    *reinterpret_cast<std::uint32_t*>(conditional_record + 0x14) =
        reinterpret_cast<std::uint32_t>(conditional_target) -
        reinterpret_cast<std::uint32_t>(conditional_context);
    call_conditional_initializer(conditional_initializer_code,
        reinterpret_cast<std::uint32_t>(conditional_object),
        reinterpret_cast<std::uint32_t>(conditional_record));
    const bool conditional_initialized =
        conditional_target[0] == 0u && conditional_target[1] == 0u &&
        conditional_target[2] == 1u;
    std::printf("case=0119afe0_initialized values=%08x,%08x,%08x PASS=%u\n",
        conditional_target[0], conditional_target[1], conditional_target[2],
        conditional_initialized ? 1u : 0u);
    failures += !conditional_initialized;
    std::array<std::uint32_t, 8> candidate_object{};
    const auto test_mode_selector = [&](void* function, const char* label,
        std::uint16_t mode, std::uint16_t flags, std::uint32_t expected) {
        candidate_object.fill(0u);
        candidate_object[0] = 0xdeadbeefu;
        candidate_object[4] = static_cast<std::uint32_t>(flags) |
            (static_cast<std::uint32_t>(mode) << 16u);
        const auto result = call_this_result(function,
            reinterpret_cast<std::uint32_t>(candidate_object.data()));
        std::printf("case=%s result=%08x expected=%08x PASS=%u\n",
            label, result, expected, result == expected ? 1u : 0u);
        failures += result != expected;
    };
    test_mode_selector(candidate_0041e920_code,
        "0041e920_mode1_mask_set", 1u, 0x30u, 0xdeadbeefu);
    const auto candidate_object_address =
        reinterpret_cast<std::uint32_t>(candidate_object.data());
    test_mode_selector(candidate_0041e920_code,
        "0041e920_mode1_mask_clear", 1u, 0u, candidate_object_address);
    test_mode_selector(candidate_0041e920_code,
        "0041e920_mode10", 0x10u, 0u, candidate_object_address);
    test_mode_selector(candidate_0041e920_code,
        "0041e920_other_mode", 2u, 0x30u, 0x015d115du);
    test_mode_selector(candidate_0041e990_code,
        "0041e990_mode9_mask_set", 9u, 0x30u, 0xdeadbeefu);
    test_mode_selector(candidate_0041e990_code,
        "0041e990_mode9_mask_clear", 9u, 0u, candidate_object_address);
    test_mode_selector(candidate_0041e990_code,
        "0041e990_mode10", 0x10u, 0u, candidate_object_address);
    test_mode_selector(candidate_0041e990_code,
        "0041e990_other_mode", 2u, 0x30u, 0x015d1160u);
    test_mode_selector(candidate_0041ea00_code,
    "0041ea00_mode10_mask_set", 0x0au, 0x30u, 0xdeadbeefu);
    test_mode_selector(candidate_0041ea00_code,
    "0041ea00_mode10_mask_clear", 0x0au, 0u, candidate_object_address);
    test_mode_selector(candidate_0041ea00_code,
    "0041ea00_mode10", 0x10u, 0u, candidate_object_address);
    test_mode_selector(candidate_0041ea00_code,
    "0041ea00_other_mode", 2u, 0x30u, 0x015d1164u);
    test_mode_selector(candidate_0041ea70_code,
    "0041ea70_mode13_mask_set", 0x0du, 0x30u, 0xdeadbeefu);
    test_mode_selector(candidate_0041ea70_code,
    "0041ea70_mode13_mask_clear", 0x0du, 0u, candidate_object_address);
    test_mode_selector(candidate_0041ea70_code,
    "0041ea70_mode10", 0x10u, 0u, candidate_object_address);
    test_mode_selector(candidate_0041ea70_code,
    "0041ea70_other_mode", 2u, 0x30u, 0x015d1168u);
    std::array<std::uint16_t, 4> backward_word_values{{0x10u, 0x20u, 0x30u, 0u}};
    const auto backward_word_base =
    reinterpret_cast<std::uint32_t>(backward_word_values.data());
    failures += !check("00423890_empty",
    call_backward_word_search(backward_word_search_code,
        backward_word_base, backward_word_base, 0x10u),
    backward_word_base);
    failures += !check("00423890_last_match",
    call_backward_word_search(backward_word_search_code,
        backward_word_base + 6u, backward_word_base, 0x30u),
    backward_word_base + 6u);
    failures += !check("00423890_previous_match",
    call_backward_word_search(backward_word_search_code,
        backward_word_base + 6u, backward_word_base, 0x20u),
    backward_word_base + 4u);
    failures += !check("00423890_not_found",
    call_backward_word_search(backward_word_search_code,
        backward_word_base + 6u, backward_word_base, 0x40u),
    backward_word_base);
    failures += !run_block_copy_case(
        "00c7ea30_empty", block_copy_00c7ea30_code, 0u, false);
    failures += !run_block_copy_case(
        "00c7ea30_one_block", block_copy_00c7ea30_code, 1u, false);
    failures += !run_block_copy_case(
        "00c7ea30_two_blocks", block_copy_00c7ea30_code, 2u, false);
    failures += !run_block_copy_case(
        "00c7ea30_null_source", block_copy_00c7ea30_code, 1u, true);
    const std::array<std::uint16_t, 1> match_last{{0x40u}};
    const std::array<std::uint16_t, 1> match_previous{{0x30u}};
    const std::array<std::uint16_t, 1> no_match{{0x99u}};
    failures += !run_reverse_word_set_search_case(
        "005728f0_cursor_at_lower", reverse_word_set_search_code,
        0u, 0u, match_last.data(), match_last.size(), 0u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_empty_values", reverse_word_set_search_code,
        8u, 0u, no_match.data(), 0u, 0u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_match_last", reverse_word_set_search_code,
        8u, 0u, match_last.data(), match_last.size(), 8u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_match_previous", reverse_word_set_search_code,
        8u, 0u, match_previous.data(), match_previous.size(), 6u);
    failures += !run_reverse_word_set_search_case(
        "005728f0_not_found", reverse_word_set_search_code,
        8u, 0u, no_match.data(), no_match.size(), 0u);
    failures += !run_tree_lookup_case(
        "00e5c780_empty", tree_lookup_00e5c780_code, 0x20u, true, 0u);
    failures += !run_tree_lookup_case(
        "00e5c780_root_match", tree_lookup_00e5c780_code, 0x20u, false, 1u);
    failures += !run_tree_lookup_case(
        "00e5c780_upper_match", tree_lookup_00e5c780_code, 0x30u, false, 2u);
    failures += !run_tree_lookup_case(
        "00e5c780_lower_match", tree_lookup_00e5c780_code, 0x10u, false, 3u);
    failures += !run_tree_lookup_case(
        "00e5c780_no_match", tree_lookup_00e5c780_code, 0x25u, false, 0u);
    failures += !run_bounded_append_case(
        "011849c0_empty_destination", bounded_append_011849c0_code,
        "", "abc", 8u, "abc", 3u);
    failures += !run_bounded_append_case(
        "011849c0_append", bounded_append_011849c0_code,
        "ab", "cde", 8u, "abcde", 5u);
    failures += !run_bounded_append_case(
        "011849c0_truncated", bounded_append_011849c0_code,
        "ab", "cdefg", 5u, "abcd", 7u);
    failures += !run_bounded_append_case(
        "011849c0_full_destination", bounded_append_011849c0_code,
        "abcd", "xy", 4u, "abcd", 6u);
    failures += !run_bounded_append_case(
        "011849c0_zero_capacity", bounded_append_011849c0_code,
        "a", "xy", 0u, "a", 2u);
    failures += !run_bounded_append_case(
        "011849c0_empty_source", bounded_append_011849c0_code,
        "xy", "", 8u, "xy", 2u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_empty_pattern", word_pattern_search_005e8ff0_code,
        {0x10u, 0x20u}, {}, 0u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_empty_text", word_pattern_search_005e8ff0_code,
        {}, {0x20u}, 0u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_single_match", word_pattern_search_005e8ff0_code,
        {0x10u, 0x20u, 0x30u}, {0x20u}, 1u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_pattern_at_start", word_pattern_search_005e8ff0_code,
        {0x10u, 0x20u, 0x30u}, {0x10u, 0x20u}, 0u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_retry_after_prefix", word_pattern_search_005e8ff0_code,
        {0x10u, 0x20u, 0x10u, 0x30u}, {0x10u, 0x30u}, 2u);
    failures += !run_word_pattern_search_case(
        "005e8ff0_not_found", word_pattern_search_005e8ff0_code,
        {0x10u, 0x20u, 0x30u}, {0x20u, 0x10u}, 3u);
    failures += !run_red_black_insert_case(
        "009216a0_empty_root", red_black_insert_009216a0_code, 0u);
    failures += !run_red_black_insert_case(
        "009216a0_black_parent_right", red_black_insert_009216a0_code, 1u);
    failures += !run_red_black_insert_case(
        "009216a0_black_parent_left", red_black_insert_009216a0_code, 2u);
    failures += !run_red_black_insert_case(
        "009216a0_red_uncle_recolor", red_black_insert_009216a0_code, 3u);
    failures += !run_red_black_insert_case(
        "009216a0_left_left_rotation", red_black_insert_009216a0_code, 4u);
    std::printf("x86 summary cases=124 failures=%zu\n", failures);
    VirtualFree(branch_code, 0, MEM_RELEASE);
    VirtualFree(pointer_code, 0, MEM_RELEASE);
    VirtualFree(object, 0, MEM_RELEASE);
    return failures == 0 ? 0 : 1;
}
