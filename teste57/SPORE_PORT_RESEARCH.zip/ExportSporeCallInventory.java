// Ghidra 12.2 exporter for direct-call evidence in a selected batch manifest.
// The script reads existing Ghidra analysis and does not trigger re-analysis.
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.symbol.Reference;

public class ExportSporeCallInventory extends GhidraScript {
    private static final String EXPECTED_SHA256 =
        "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b";
    private static final String OUTPUT_DIRECTORY = "C:\\SporeAnalysis";
    private static final String OUTPUT_NAME = "spore_batch_call_inventory.csv";
    private static final long MAX_INPUT_BYTES = 256L * 1024L * 1024L;
    private static final long MAX_RUNTIME_MILLIS = 600_000L;
    private static final Pattern ENTRY_PATTERN = Pattern.compile(
        "\"function\"\\s*:\\s*\\{\\s*\"entry\"\\s*:\\s*\"(0x[0-9a-fA-F]+)\""
    );

    private long deadline;

    @Override
    protected void run() throws Exception {
        if (currentProgram == null) {
            throw new IllegalStateException("Open the selected Spore program in Ghidra first.");
        }
        File source = askFile(
            "Select the exact SporeApp.exe imported into the open Ghidra program",
            "Select"
        );
        if (source == null || !source.isFile() || source.length() > MAX_INPUT_BYTES) {
            throw new IllegalArgumentException("Select a regular SporeApp.exe under 256 MiB.");
        }
        if (!askYesNo(
                "Confirm source identity",
                "Is this the exact original SporeApp.exe used to create the currently open Ghidra program?")) {
            throw new IllegalStateException("Source identity was not confirmed; no inventory was exported.");
        }
        String sourceHash = sha256(source);
        if (!EXPECTED_SHA256.equalsIgnoreCase(sourceHash)) {
            throw new IllegalArgumentException(
                "Selected SporeApp.exe SHA-256 does not match the approved Phase 4 build: "
                    + sourceHash
            );
        }

        File batch = askFile(
            "Select the exported batch JSON",
            "Select"
        );
        if (batch == null || !batch.isFile() || batch.length() > 128L * 1024L * 1024L) {
            throw new IllegalArgumentException("Select a valid batch JSON under 128 MiB.");
        }
        Set<Long> selected = readSelectedEntries(batch);
        if (selected.isEmpty()) {
            throw new IllegalArgumentException("The batch JSON contains no selected function entries.");
        }

        File outputDirectory = new File(OUTPUT_DIRECTORY);
        File output = new File(outputDirectory, OUTPUT_NAME);
        if (!outputDirectory.isDirectory()) {
            throw new IllegalStateException("Output directory does not exist: " + OUTPUT_DIRECTORY);
        }
        if (output.exists()) {
            throw new IllegalStateException(
                "Output already exists; preserve it and move it before rerunning: "
                    + output.getCanonicalPath()
            );
        }

        deadline = System.currentTimeMillis() + MAX_RUNTIME_MILLIS;
        monitor.initialize(MAX_RUNTIME_MILLIS);
        Path temporaryFile = Files.createTempFile(
            outputDirectory.toPath(), "spore_batch_call_inventory_", ".tmp"
        );
        boolean published = false;
        try {
            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(temporaryFile.toFile()), StandardCharsets.UTF_8))) {
                writer.write("caller_entry,caller_name,call_site,target_address,reference_type,"
                    + "computed,target_entry,target_name,target_calling_convention,"
                    + "target_body_bytes,target_in_selected_batch\n");
                for (Long callerEntry : selected) {
                    checkDeadline();
                    Function caller = currentProgram.getFunctionManager()
                        .getFunctionAt(toAddr(callerEntry));
                    if (caller == null) {
                        writer.write(String.format(
                            "0x%08x,,,,,,,,,false\n", callerEntry
                        ));
                        continue;
                    }
                    InstructionIterator instructions = currentProgram.getListing()
                        .getInstructions(caller.getBody(), true);
                    while (instructions.hasNext()) {
                        checkDeadline();
                        Instruction instruction = instructions.next();
                        for (Reference reference : currentProgram.getReferenceManager()
                                .getReferencesFrom(instruction.getAddress())) {
                            if (!reference.getReferenceType().isCall()) {
                                continue;
                            }
                            Function target = currentProgram.getFunctionManager()
                                .getFunctionContaining(reference.getToAddress());
                            long targetEntry = target == null
                                ? reference.getToAddress().getOffset()
                                : target.getEntryPoint().getOffset();
                            writer.write(csv(callerEntry, caller.getName()));
                            writer.write(",");
                            writer.write(csv(instruction.getAddress().toString()));
                            writer.write(",");
                            writer.write(csv(String.format("0x%08x", reference.getToAddress().getOffset())));
                            writer.write(",");
                            writer.write(csv(reference.getReferenceType().toString()));
                            writer.write(",");
                            writer.write(Boolean.toString(reference.getReferenceType().isComputed()));
                            writer.write(",");
                            if (target == null || target.isExternal() || target.isThunk()) {
                                writer.write(",,,,false\n");
                            } else {
                                writer.write(csv(String.format("0x%08x", targetEntry)));
                                writer.write(",");
                                writer.write(csv(target.getName()));
                                writer.write(",");
                                writer.write(csv(target.getCallingConventionName()));
                                writer.write(",");
                                writer.write(Long.toString(target.getBody().getNumAddresses()));
                                writer.write(",");
                                writer.write(Boolean.toString(selected.contains(targetEntry)));
                                writer.write("\n");
                            }
                        }
                    }
                }
            }
            Files.move(temporaryFile, output.toPath(), StandardCopyOption.ATOMIC_MOVE);
            published = true;
        } finally {
            if (!published) {
                Files.deleteIfExists(temporaryFile);
            }
        }
        println("Exported direct-call evidence for " + selected.size()
            + " selected functions to " + output.getCanonicalPath());
        println("Selected executable SHA-256: " + sourceHash);
        println("No target code was executed and no whole-program analysis was triggered.");
    }

    private Set<Long> readSelectedEntries(File batch) throws Exception {
        Set<Long> result = new HashSet<>();
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(batch), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                text.append(line).append('\n');
            }
        }
        Matcher matcher = ENTRY_PATTERN.matcher(text);
        while (matcher.find()) {
            result.add(Long.parseLong(matcher.group(1).substring(2), 16));
        }
        return result;
    }

    private String csv(long callerEntry, String callerName) {
        return csv(String.format("0x%08x", callerEntry)) + "," + csv(callerName);
    }

    private String csv(String value) {
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[1024 * 1024];
        try (InputStream input = new BufferedInputStream(new FileInputStream(file))) {
            int count;
            while ((count = input.read(buffer)) != -1) {
                digest.update(buffer, 0, count);
            }
        }
        StringBuilder result = new StringBuilder(64);
        for (byte value : digest.digest()) {
            result.append(String.format("%02x", value & 0xff));
        }
        return result.toString();
    }

    private void checkDeadline() throws Exception {
        if (System.currentTimeMillis() > deadline || monitor.isCancelled()) {
            throw new IllegalStateException("Call inventory export cancelled or timed out.");
        }
    }
}
