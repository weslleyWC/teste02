$ErrorActionPreference = "Stop"

$ndk = "$env:LOCALAPPDATA\Android\Sdk\ndk\29.0.14206865"
$clangxx = "$ndk\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe"
$sysroot = "$ndk\toolchains\llvm\prebuilt\windows-x86_64\sysroot"
$executable = Join-Path $PSScriptRoot "spore_00404460_arm64"
$generatedSource = Join-Path $PSScriptRoot "spore_00404460_arm64.cpp"
$coverageReport = Join-Path $PSScriptRoot "spore_00404460_instruction_coverage.json"

if (-not (Test-Path $clangxx)) {
    throw "Android NDK clang++ not found: $clangxx"
}
if (-not (Test-Path $generatedSource) -or -not (Test-Path $coverageReport)) {
    throw "Generated source or coverage report is missing. Run GenerateStaticEqualLift.py first."
}
$coverage = Get-Content -LiteralPath $coverageReport -Raw | ConvertFrom-Json
if ($coverage.status -ne "generated" -or $coverage.rejected_instruction_count -ne 0) {
    throw "Coverage report does not authorize a build: status=$($coverage.status)."
}
$sourceHash = (Get-FileHash -LiteralPath $generatedSource -Algorithm SHA256).Hash.ToLowerInvariant()
if ($sourceHash -ne $coverage.generated_source_sha256) {
    throw "Generated C++ does not match the source hash recorded in the coverage report."
}

Push-Location $PSScriptRoot
try {
    & $clangxx --target=aarch64-linux-android21 --sysroot=$sysroot `
        -std=c++17 -O2 -Wall -Wextra -Wpedantic -Wno-unused-variable -Wno-unused-label `
        -fPIE -pie spore_00404460_arm64.cpp FirstStaticEqualHarness.cpp `
        -o $executable
    if ($LASTEXITCODE -ne 0) {
        throw "Static-equality ARM64 compilation failed, exit code $LASTEXITCODE."
    }
    Write-Output "Built $executable"
} finally {
    Pop-Location
}
