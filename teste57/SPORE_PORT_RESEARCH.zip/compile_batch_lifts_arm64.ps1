param(
    [Parameter(Mandatory = $true)]
    [string]$SourceDirectory
)

$ErrorActionPreference = "Stop"

$compiler = "C:\Users\wesll\AppData\Local\Android\Sdk\ndk\29.0.14206865\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe"
$root = $PSScriptRoot
$sourcePath = (Resolve-Path -LiteralPath $SourceDirectory).Path
$sources = @(Get-ChildItem -LiteralPath $sourcePath -Filter "*.cpp" -File | Sort-Object Name)
$batchSize = 100

if (-not (Test-Path -LiteralPath $compiler)) {
    throw "Android NDK clang++ not found: $compiler"
}
if ($sources.Count -eq 0) {
    throw "No generated C++ lift sources found in: $sourcePath"
}

for ($start = 0; $start -lt $sources.Count; $start += $batchSize) {
    $end = [Math]::Min($start + $batchSize, $sources.Count)
    $chunk = @($sources[$start..($end - 1)])
    $arguments = @(
        "--target=aarch64-linux-android35",
        "-std=c++17",
        "-O2",
        "-Wall",
        "-Wextra",
        "-Wno-unused-variable",
        "-Wno-unused-label",
        "-fsyntax-only",
        "-I$root",
        "-I$sourcePath"
    ) + @($chunk | ForEach-Object { $_.FullName })

    & $compiler @arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Android ARM64 syntax check failed for generated lifts $($start + 1)-$end."
    }
}
Write-Output "Android ARM64 syntax check passed for $($sources.Count) generated lifts in $sourcePath."
