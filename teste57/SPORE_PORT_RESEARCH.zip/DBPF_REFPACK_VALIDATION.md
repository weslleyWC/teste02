# DBPF 3.0 and RefPack reader: evidence and status

## What is verified in local package files

- All 23 local `.package` files have DBPF major/minor version `3.0`.
- Their indexes contain 154,576 entries in total; the inventory pass consumed
  each index exactly and found no duplicate TGI keys within an individual
  package or resource ranges outside the package data area.
- In the examined files, the 32-bit field at header offset `0x28` is zero.
  The index offset is read from the 64-bit field at `0x40`; the implementation
  does not require the zero legacy field to equal it.
- The header fields used by the reader are:

  | Offset | Field | Observed/used representation |
  |---:|---|---|
  | `0x00` | Magic | `DBPF` |
  | `0x04` | Major version | `u32`, value `3` |
  | `0x08` | Minor version | `u32`, value `0` |
  | `0x24` | Index entry count | `u32` |
  | `0x28` | Legacy index offset field | `u32`, zero in all 23 local packages examined |
  | `0x2C` | Index byte size | `u32` |
  | `0x3C` | Index minor version | `u32`, observed as `3` locally |
  | `0x40` | Index offset | `u64`; used by the reader |

- The local index layout contains optional shared type/group fields selected by
  index flags, followed by TGI/resource fields. Locally observed entries use a
  32-bit data offset, stored size with its high bit masked, memory size,
  compression label, saved byte and padding byte.
- The index flag bits observed/handled by the reader are bit 0 (shared type),
  bit 1 (shared group), and bit 2 (one extra 32-bit word). The exact semantic
  meaning of that extra word and the saved byte has not been established.
- Compression labels seen locally are `0` and `0xFFFF`. Compressed payloads
  observed across the installation include `10 FB` and `50 FB` RefPack
  signatures. No `90 FB` payload was found in the scan, so that header mode is
  not locally validated.

## Real-file cross-check

An independent Python validation pass parsed the real
`SPOREFILES\Data\Locale\en-us\Text.package` (724,533 bytes):

| Check | Result |
|---|---:|
| DBPF entries | 200 |
| Index bytes consumed exactly | Yes; 4,016 bytes |
| Compressed entries | 189 |
| RefPack outputs decoded and matched to index memory size | 189 / 189 |
| Compressed output bytes | 1,719,491 |
| Total extracted output, including 11 uncompressed entries | 1,720,447 |
| RefPack headers in this package | All `10 FB` |
| Largest decoded entry | 157,149 bytes |

After compiling with MSVC C++17, the CLI reported `verify=PASS`, 200 entries
and 1,720,447 decoded/extracted bytes. An independent comparison then extracted
all 200 entries through the C++ CLI and compared each output byte-for-byte with
the Python reference decoder: **200/200 matched**, including all 189 compressed
entries.

The C++ CLI also extracted a real `50 FB` resource from
`SPOREFILES\Data\Spore_Game.package` (entry 370; 31,525 stored bytes; 593,656
output bytes). Its output matched the independent decoder byte-for-byte.

The earlier installation-wide format scan observed 88,092 entries beginning
with `10 FB` and 9,306 beginning with `50 FB`. Those counts establish observed
signatures, not a complete semantic explanation of every RefPack flag.

## Reader implementation

- [dbpf_reader.hpp](./dbpf_reader.hpp) and
  [dbpf_reader.cpp](./dbpf_reader.cpp) implement a C++17 DBPF reader, TGI
  lookup, bounded entry reads, RefPack decompression and candidate FNV
  helpers.
- [dbpf_tool.cpp](./dbpf_tool.cpp) provides `info`, `list`, `verify`,
  `extract`, `hash` and `--self-test` commands.
- `--self-test` includes literal and overlapping-copy streams, an intentionally
  malformed stream, synthetic `90 FB` extended-size coverage, and fixed
  candidate FNV vectors. A malformed test vector that originally omitted its
  literal byte was corrected.
- The reader enforces file/index/resource bounds and a default 512 MiB decoded
  output limit. It does not modify package files.

## Build and verification status

- **Desktop MSVC C++17 build: verified.** The installed Visual Studio Build
  Tools compiler built `dbpf_reader.cpp` and `dbpf_tool.cpp` with `/W4` and
  `/permissive-`; the build completed without warnings.
- **CMake build: verified.** The checked-in `CMakeLists.txt` configured and
  built with the Visual Studio 18 2026 x64 generator.
- **Android NDK build: verified for `arm64-v8a`.** Android NDK r29
  (`29.0.14206865`) was installed from Google's official Windows archive
  after checking its published size (833,850,862 bytes) and SHA-1
  (`ab3bb30fbb9e6903666d60c55d11e78b04e07472`). CMake/Clang compiled and
  linked the CLI for Android API 26; `llvm-readelf` reports ELF64, AArch64,
  `/system/bin/linker64`, with Bionic and `libc++_shared.so` dependencies.
- **Android NDK build: verified for `x86_64`.** A second CMake build was
  produced for the installed Android emulator.
- **Android runtime test: PASS on API 37 `x86_64` emulator.** The binary ran
  `--self-test` and verified all 200 entries of `Text.package` (1,720,447
  output bytes). The temporary binary, C++ runtime and test package were
  removed from the emulator after the test.
- **C++ self-tests: PASS.** RefPack literal, overlapping-copy, extended-size,
  malformed-input rejection and candidate FNV vectors all passed.
- **All package indexes: PASS.** The C++ CLI opened all 23 packages and
  reported the expected total of 154,576 entries, with no parser failures.
- **Real DBPF CLI verification: PASS.** `Text.package` reported 200 entries
  and 1,720,447 total output bytes. Each of its 200 extracted resources also
  matched an independent decoder byte-for-byte.
- **Real `50 FB` resource: PASS.** `Spore_Game.package` entry 370 was
  decompressed by the C++ CLI and matched the independent decoder byte-for-byte.
- **Full decompression pass: PASS for all 23 packages.** The CLI successfully
  read 154,576 entries and decoded a total of 10,392,692,286 output bytes;
  no package or entry failed. This checks parser/decompressor acceptance and
  expected output sizes, not semantic correctness of every resource payload.
- The `arm64-v8a` output was cross-compiled and inspected as ELF64/AArch64 but
  has not been run on an ARM64 Android device. The available emulator is
  `x86_64`; no physical device was connected.
- The `90 FB` path is based on the supplied format notes and is not validated
  against a local package; only its synthetic self-test passes.
- The meaning of the `50 FB` distinction and the high bit in the stored-size
  field remains partly unresolved.
- Byte-for-byte comparison against an independent decoder covers all 200
  entries in `Text.package` and the real `50 FB` resource in `Spore_Game.package`.
  The remaining resources pass full C++ decompression/size checks but have not
  all been compared byte-for-byte against a second implementation.

## Reproducing the desktop build

From a Visual Studio Developer PowerShell, in the project directory:

```powershell
cl /nologo /std:c++17 /EHsc /W4 /permissive- dbpf_reader.cpp dbpf_tool.cpp /Fe:spore_dbpf_tool.exe
.\spore_dbpf_tool.exe --self-test
.\spore_dbpf_tool.exe verify "C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\Data\Locale\en-us\Text.package"
```

Expected: self-test PASS; the final command reports 200 entries and 1,720,447
output bytes. These commands do not change files inside `SPOREFILES`.
