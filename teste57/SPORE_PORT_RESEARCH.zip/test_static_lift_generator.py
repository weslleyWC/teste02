import copy
import csv
import json
import unittest
from pathlib import Path

import GenerateStaticLift as lifter


ROOT = Path(__file__).resolve().parent
EXE = ROOT.parent / "SPOREFILES" / "SporeBin" / "SporeApp.exe"
CSV_PATH = Path(r"C:\SporeAnalysis\spore_functions.csv")
EXPORT_PATH = Path(r"C:\SporeAnalysis\spore_function_00422430.json")


class StaticLiftGeneratorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.export = json.loads(EXPORT_PATH.read_text(encoding="utf-8"))
        cls._image, cls.section, cls.file_offset, cls.raw = lifter.load_pe_section_offset(
            EXE, lifter.EXPECTED_VA, lifter.EXPECTED_SIZE
        )
        with CSV_PATH.open(newline="", encoding="utf-8-sig") as stream:
            cls.row = next(
                row for row in csv.DictReader(stream)
                if int(row["address"], 16) == lifter.EXPECTED_VA
            )

    def test_verified_export_generates_all_original_instructions(self):
        source, accepted, rejected = lifter.generate_source(
            self.export, self.raw, self.row
        )
        self.assertEqual(len(accepted), 47)
        self.assertEqual(sum(len(bytes.fromhex(item["bytes"])) for item in accepted), 122)
        self.assertEqual(rejected, [])
        self.assertIn("L_00422430:", source)
        self.assertIn("L_004224a9:", source)
        self.assertNotIn("spore_lower_bound_candidate", source)

    def test_unsupported_opcode_is_reported_and_rejected(self):
        altered = copy.deepcopy(self.export)
        altered["function"]["instructions"][0]["mnemonic"] = "LZCNT"
        with self.assertRaises(lifter.UnsupportedInstructions) as raised:
            lifter.generate_source(altered, self.raw, self.row)
        self.assertEqual(raised.exception.rejected[0]["mnemonic"], "LZCNT")

    def test_changed_instruction_bytes_are_rejected(self):
        altered = copy.deepcopy(self.export)
        altered["function"]["instructions"][0]["bytes"] = "56"
        with self.assertRaisesRegex(ValueError, "encodings.*do not match"):
            lifter.generate_source(altered, self.raw, self.row)

    def test_branch_outside_exported_function_is_rejected(self):
        altered = copy.deepcopy(self.export)
        branch = next(
            instruction for instruction in altered["function"]["instructions"]
            if instruction["mnemonic"] == "JLE"
        )
        branch["operands"] = ["0x00400000"]
        with self.assertRaises(lifter.UnsupportedInstructions) as raised:
            lifter.generate_source(altered, self.raw, self.row)
        self.assertTrue(any("branch target" in item["reason"] for item in raised.exception.rejected))


if __name__ == "__main__":
    unittest.main()
