#include "BatchStaticLiftRuntime.hpp"

#include <array>
#include <cstdint>
#include <cstdio>

namespace {

constexpr std::uint32_t kObjectAddress = 0x10000000u;
constexpr std::uint32_t kMemoryOffset = 0x5cu;

BatchLiftStatus spore_tail_call_equivalent(
    BatchLiftMemory& memory,
    BatchLiftState& state) {
    std::uint32_t value = 0;
    if (!memory.load32(state.regs[1] + kMemoryOffset, value)) {
        return BatchLiftStatus::invalid_memory;
    }
    state.regs[1] = value;
    if (state.regs[1] == 0u) {
        return BatchLiftStatus::returned;
    }
    return BatchLiftStatus::returned;
}

bool run_case(const char* label, std::uint32_t member_value) {
    alignas(4) std::array<std::uint8_t, 0x60> object{};
    object[kMemoryOffset] = static_cast<std::uint8_t>(member_value);
    object[kMemoryOffset + 1] = static_cast<std::uint8_t>(member_value >> 8u);
    object[kMemoryOffset + 2] = static_cast<std::uint8_t>(member_value >> 16u);
    object[kMemoryOffset + 3] = static_cast<std::uint8_t>(member_value >> 24u);

    BatchLiftMemory memory;
    if (!memory.map_region(kObjectAddress, object.data(), object.size(), true)) {
        std::fprintf(stderr, "case=%s could not map object\n", label);
        return false;
    }
    BatchLiftState state{};
    state.regs[1] = kObjectAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.eflags = 0x8d5u;
    const BatchLiftStatus status = spore_tail_call_equivalent(memory, state);
    const bool passed =
        status == BatchLiftStatus::returned &&
        state.regs[1] == member_value &&
        state.eip == 0u &&
        state.regs[4] == BatchLiftMemory::kEntryEsp;
    std::printf(
        "case=%s ecx=%08x expected=%08x status=%u esp=%08x PASS=%u\n",
        label,
        state.regs[1],
        member_value,
        static_cast<unsigned>(status),
        state.regs[4],
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main() {
    const bool null_case = run_case("tail_null", 0u);
    const bool value_case = run_case("tail_value", 0x20000000u);
    std::printf(
        "arm64 tail-call summary cases=2 failures=%u\n",
        static_cast<unsigned>(!null_case + !value_case));
    return null_case && value_case ? 0 : 1;
}
