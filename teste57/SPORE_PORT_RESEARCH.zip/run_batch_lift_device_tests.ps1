$ErrorActionPreference = "Stop"

$adb = "C:\Users\wesll\AppData\Local\Android\Sdk\platform-tools\adb.exe"
$ndk = "C:\Users\wesll\AppData\Local\Android\Sdk\ndk\29.0.14206865"
$compiler = Join-Path $ndk "toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe"
$generated = Join-Path $PSScriptRoot "generated_batch_pilot_30_v4"
$sources = @(
    (Join-Path $generated "spore_00922a80_arm64.cpp"),
    (Join-Path $generated "spore_00a02bd0_arm64.cpp"),
    (Join-Path $generated "spore_00ef72c0_arm64.cpp")
)
$harness = Join-Path $PSScriptRoot "BatchStaticLiftDeviceHarness.cpp"
$outputDirectory = Join-Path $PSScriptRoot "batch_static_lift_harness"
$binary = Join-Path $outputDirectory "BatchStaticLiftDeviceHarness"
$log = Join-Path $PSScriptRoot "batch_static_lift_arm64_device.log"
$serial = "PJMZAEJRX4YLFIDI"
$remoteDirectory = "/data/local/tmp/spore-static-lift"
$remoteBinary = "$remoteDirectory/BatchStaticLiftDeviceHarness"

foreach ($required in @($adb, $compiler, $harness) + $sources) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Required device test input not found: $required"
    }
}
$deviceModel = (& $adb -s $serial shell getprop ro.product.model).Trim()
$deviceAbi = (& $adb -s $serial shell getprop ro.product.cpu.abi).Trim()
$isEmulator = (& $adb -s $serial shell getprop ro.kernel.qemu).Trim()
if ($LASTEXITCODE -ne 0) {
    throw "ADB could not query device $serial."
}
if ($deviceAbi -ne "arm64-v8a" -or $isEmulator -eq "1") {
    throw "Target is not a physical ARM64 device: model=$deviceModel abi=$deviceAbi emulator=$isEmulator"
}

New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
$arguments = @(
    "--target=aarch64-linux-android35",
    "-std=c++17",
    "-O2",
    "-Wall",
    "-Wextra",
    "-Wno-unused-variable",
    "-Wno-unused-label",
    "-fPIE",
    "-pie",
    "-I$PSScriptRoot",
    "-I$generated",
    $harness
) + $sources + @("-o", $binary)
& $compiler @arguments
if ($LASTEXITCODE -ne 0) {
    throw "Android ARM64 harness compilation failed."
}

& $adb -s $serial shell "mkdir -p $remoteDirectory"
if ($LASTEXITCODE -ne 0) {
    throw "Could not prepare the test directory on device $serial."
}
& $adb -s $serial push $binary $remoteBinary
if ($LASTEXITCODE -ne 0) {
    throw "Could not copy the ARM64 harness to device $serial."
}
& $adb -s $serial shell "chmod 700 $remoteBinary && $remoteBinary" 2>&1 |
    Tee-Object -FilePath $log
if ($LASTEXITCODE -ne 0) {
    throw "ARM64 device harness failed on $deviceModel."
}
Write-Output "Device: $deviceModel ($deviceAbi), physical device"
Write-Output "Full ARM64 device log: $log"
