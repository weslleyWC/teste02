# Spore Android port: route comparison

## Skyrim_Android as the reference architecture

The primary methodological reference is
[ttom795/Skyrim_Android](https://github.com/ttom795/Skyrim_Android), a static
recompilation of the 2011 x86 PC Skyrim executable for ARM64 Android. Its
README explicitly distinguishes recompilation from decompilation: generated C
is produced from the original executable, rather than recreating the original
source.

The common route is:

1. identify and pin one exact executable build;
2. discover functions and lift the executable into generated native code;
3. compare the generated code against the original behavior;
4. compile the generated code as ARM64;
5. provide native replacements for platform boundaries;
6. package the result in an Android application.

The reference project reports a complete generated-code pipeline for its
selected Skyrim build, with separate generated modules, a differential-testing
tool, and an Android runtime. It also uses acquire/release operations for
cross-thread behavior because ARM memory ordering is weaker than x86, and
replaces the Direct3D 9 boundary with a native Vulkan path through patched
DXVK. Those are design references, not evidence that the same solutions work
for Spore.

The Spore project is currently at an earlier feasibility stage: the verified
100-function export has 52 accepted functions, 404/1,538 exported instruction
bytes accepted, and 7/7 plus 2/2 isolated cross-architecture harness cases.
Calls, 32-bit pointer/ABI behavior, TLS, exceptions, indirect dispatch, and
the Windows/DirectX runtime remain unresolved. The Skyrim project's reported
completion must not be used to infer equivalent Spore coverage.

The same reference also documents a two-stage build: generate native code from
the game files, then build the Android APK with Gradle, CMake, and NDK
`29.0.14206865`. This matches the NDK version used by the current Spore
harnesses. Its optional Unicorn-based lifter self-test is not part of the
approved Spore validation boundary; Spore evidence must continue to use
native x86 versus physical ARM64 comparisons.

## Recommendation

Use a clean-room Android runtime as the product architecture. Treat static
translation of `SporeApp.exe` as a time-boxed feasibility experiment, not as the
port plan. The binary can inform behavior, but translating its machine code
does not supply the Windows, CRT, DirectX, input, audio, or loader environment
that the executable expects.

## Evidence boundary

### Verified in the local executable

- The base `SporeApp.exe` is PE32 x86, SHA-256
  `6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`.
- Its static import table contains 495 imported functions across 20 DLLs.
  The complete inventory and per-import rough shim estimates are in
  [IMPORTS_SPOREAPP.md](./IMPORTS_SPOREAPP.md).
- Imports include the MSVC 9 CRT, Win32 UI/system APIs, Direct3D 9,
  D3DX9, DirectInput, DirectSound, COM/OLE, sockets, and Steam API.
- The import table shows only `Direct3DCreate9`; this does **not** bound the
  graphics work. Calls through D3D9 COM interfaces and their vtables are not
  represented as separate imported DLL symbols.
- The executable has dynamic-loading strings and behavior beyond this static
  import table. Therefore 495 is not a complete list of OS/runtime boundaries.

### Inferred / not yet verified

- The complete runtime boot sequence after the initial `App` object setup has
  not been traced.
- Which imports are actually reached in a typical offline session, and which
  APIs are diagnostic, editor-only, or online-only, is not established by the
  import table.
- The binary has not been run under an Android compatibility layer, and no
  static-recompiler output has been produced.

## Route comparison

| Area | Clean-room reconstruction | Static translation + shims |
|---|---|---|
| Executable behavior | Reimplement only the selected, observed behavior | Preserves some x86 instructions, but not their Windows environment |
| Platform work | Android lifecycle, input, storage, renderer and audio are first-class | Still requires Win32/CRT/COM/DirectX compatibility or replacements |
| Graphics | Build a renderer for the chosen Android API and assets | D3D9 device, resources, state, shaders and presentation must map to GLES/Vulkan |
| CPU/ABI | Compile authored portable C++ for `arm64-v8a` | Translate x86 code and preserve 32-bit pointer assumptions, calling conventions, TLS, exceptions and indirect calls |
| Data/assets | Build parsers and loaders around verified package formats | Still needs the game's resource, shader, audio and filesystem semantics |
| Scope control | Stage-by-stage and testable | Large hidden coupling; one missing API can block startup or a later feature |
| Main risk | Long implementation effort and gaps in behavioral knowledge | Translator coverage plus a Windows/D3D9 compatibility runtime; imported-function counts understate the work |

## Concrete route-2 risks

1. **This is translation, not source recompilation.** There is no source tree
   in the supplied installation; a binary lifter must recover and emit
   equivalent native code from x86 machine code.
2. **32-bit state is pervasive.** The PE is x86; pointers, layouts, callbacks,
   calling conventions, TLS and exception/unwind assumptions may not map to
   an ARM64 process without a carefully designed compatibility ABI.
3. **D3D9 is a subsystem, not one import.** `Direct3DCreate9` returns COM
   interfaces whose methods are called indirectly. Device creation, resource
   formats, fixed-function state, shader profiles, render targets, reset/loss
   handling and presentation all need equivalent behavior.
4. **Win32 semantics remain.** `USER32`, `KERNEL32`, `MSVCR90`, COM/OLE,
   GDI, IME, sockets and DirectSound are real integration boundaries. A stub
   that returns success can make startup appear to work while silently
   breaking saves, input, timing, audio or rendering.
5. **Dynamic imports are outside the 495-symbol table.** Runtime DLL loading,
   optional vendor APIs and delay-loaded APIs require a separate inventory.
6. **Static translation does not remove content-format work.** DBPF, RefPack,
   properties, shaders, models, audio and save semantics still need inspection.

**Machine risk:** do not run unknown installers or replace files in the game
installation. The proposed analysis is offline and read-only; the current
reader and reports are outside `SPOREFILES`.

## Suggested feasibility gate

Before any broad shim effort, make a small isolated experiment that answers
all of these with evidence:

1. Can the selected translator translate this exact PE32 image to runnable
   ARM64 while preserving relocations, indirect calls, TLS and exceptions?
2. Can its output start and reach the first application-owned initialization
   code with a minimal, explicit Win32/CRT shim?
3. Can it create one D3D9 device and render a simple frame through the proposed
   GLES/Vulkan backend?
4. Can one representative package resource be opened through the game's
   actual loading path?

If any gate fails for architectural reasons, stop the translation experiment
and continue the clean-room runtime. Do not treat successful translation of
isolated functions as proof that the game is portable.
