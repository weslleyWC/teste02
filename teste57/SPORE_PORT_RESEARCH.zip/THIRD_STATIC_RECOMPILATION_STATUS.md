# Spore Android — terceira função traduzida estaticamente

## Identidade e evidência

- Executável selecionado: `C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe`
- SHA-256 do executável e export Ghidra: `6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`
- Função: `FUN_00404460`, VA `0x00404460`, RVA `0x00004460`, offset do arquivo `0x3860`, seção `.text`
- Tamanho: 30 bytes; SHA-256 dos bytes: `60d6aa4a904ecc5815beae338b005022bb7382d5d2617b813997f366aafeb037`
- Export Ghidra: `C:\SporeAnalysis\spore_function_00404460.json`
- Instruções exportadas: 13/13; bloco básico: 1/1; pseudocódigo completo, sem truncamento.
- O export não registra referências de entrada (0). Isso não prova que não existam chamadas não resolvidas.
- A convenção de chamada no Ghidra está como `unknown`. A sequência usa `ECX` como receiver, lê um argumento de ponteiro da pilha e termina com `ret 4`; o harness usa `__thiscall`, que foi testado contra os bytes originais. A assinatura permanece uma inferência compatível com o corpo, não uma classificação do Ghidra.

## Comportamento observado

A rotina compara o `uint32` em `[receiver + 4]` com o `uint32` em `[argument + 4]`, devolve `1` se forem iguais e `0` caso contrário. O argumento é removido da pilha pela própria função (`ret 4`). Não há instruções `call`, desvios ou leituras de estado global dentro dos 30 bytes.

## Lift e cobertura

`GenerateStaticEqualLift.py` verifica o SHA-256 do executável e export, entrada/tamanho do inventário, limites do corpo e bytes de todas as instruções contra o PE. Gera C++ estático por instrução; não existe interpretação de x86 em runtime.

Arquivo gerado: `spore_00404460_arm64.cpp`; SHA-256 `eee5b296a3f11a1daf88a8c476cad80fd8579edd560815a5d25f7f11236dd3ab`.

- **PASSOU:** 13/13 instruções aceitas.
- **PASSOU:** 30/30 bytes cobertos (100%).
- **PASSOU:** opcodes/bytes alterados e tamanho de limpeza incorreto em `RET` rejeitados nos testes.
- **PASSOU:** o código gerado e o harness compilaram para objetos ELF64 AArch64 com NDK clang; ambos os objetos foram inspecionados como `e_machine=0x00b7` (AArch64). Os objetos temporários foram removidos.
- **BLOQUEADO:** o link do executável PIE Android não foi concluído. O Windows não conseguiu iniciar o `ld.lld.exe` do NDK porque o arquivo estava em uso; copiar o linker e invocá-lo também não resultou em link válido. O script de build não contorna nem oculta esse erro.
- **PENDENTE:** execução do lift no aparelho Android e comparação x86/ARM64.

## Referência x86 nativa

`FirstNativeEqualX86Reference.cpp` verificou os 30 bytes selecionados, colocou-os em memória executável RX e chamou o corpo original num processo x86 nativo. O processo passou em 8/8 vetores: igual/diferente, valores de fronteira com bit alto e casos de valores idênticos ou distintos. Log: `native_equal_x86_reference.log`.

## Status

| Critério | Status | Evidência |
|---|---|---|
| Identidade e bytes originais | **PASSOU** | Hash do PE confirmado; export corresponde à build; 30 bytes conferidos no offset `0x3860`. |
| Export seletivo e análise do corpo | **PASSOU** | 13 instruções, um bloco, pseudocódigo completo. Zero referências de entrada registradas; chamadas indiretas ou não descobertas não são excluídas. |
| Geração estática | **PASSOU** | 13/13 instruções e 30/30 bytes aceitos; SHA do C++ acima. |
| Testes do gerador | **PASSOU** | Testes de geração, bytes alterados, opcode não suportado e `ret` com limpeza errada. |
| Execução do corpo original | **PASSOU** | 8/8 casos em CPU x86 nativa. |
| Compilação de objetos ARM64 | **PASSOU** | Gerador e harness compilados como objetos ELF64 AArch64 (`e_machine=0xb7`). |
| Link ELF/PIE Android | **PASSOU** | Executável ELF64 PIE (`ET_DYN`), máquina AArch64, produzido pelo NDK 29.0.14206865; SHA-256 `b48d3bc6c79485352c7928907fca476d75bcfc909de1e966eae6509d2f854de2`. |
| Execução física ARM64 | **PASSOU** | 8/8 vetores passaram no aparelho físico `2303ERA42L` (`arm64-v8a`), serial `PJMZAEJRX4YLFIDI`. |
| Comparação nativa x86 / ARM64 | **PASSOU** | Oito pares de resultados coincidem. Relatório: `third_static_lift_cross_arch_comparison_v2.json`. |
| Integração no runtime/boot do Spore | **PENDENTE** | Nenhuma integração foi tentada. |

O teste x86 confirma os bytes de referência e os casos fornecidos, não a equivalência universal nem as pré-condições de todos os chamadores. O registro de 0 referências de entrada no export deve ser investigado antes da integração.

### Execução ARM64 concluída (2026-11-02)

O bloqueio anterior de link não se reproduziu nesta execução. O script
`build_third_static_lift.ps1` produziu `spore_00404460_arm64`, confirmado por
`llvm-readelf` como ELF64/AArch64 do tipo `DYN` (PIE). O script
`run_third_static_lift_on_device.ps1` executou esse binário no aparelho físico
e passou os mesmos oito pares de `uint32` registrados no harness x86.

Para preservar o log x86 anterior, `run_third_static_lift_x86_reference.ps1`
compilou uma cópia fresca do harness em
`ThirdStaticEqualX86Reference.exe` e escreveu
`third_static_equal_x86_reference_v2.log`. Os resultados ARM64 estão em
`arm64_equal_device_validation.log`; a comparação por caso está em
`third_static_lift_cross_arch_comparison_v2.json`.

O reporte identifica o SporeApp.exe pelo SHA-256 já confirmado acima. A
análise adicional pelo provedor REA não ficou disponível nesta sessão porque
o Ghidra instalado é 12.2 e o provedor instalado declara suporte a 12.1.x;
isso não altera a verificação de bytes do export local contra o PE, nem os
testes nativos executados. O harness observa retorno `0/1` apenas para os oito
vetores; não compara todos os registradores/flags e não comprova integração
com chamadores reais.

## Reproduzir no Windows

```powershell
$root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
python "$root\GenerateStaticEqualLift.py" `
  --exe 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe' `
  --csv 'C:\SporeAnalysis\spore_functions.csv' `
  --export 'C:\SporeAnalysis\spore_function_00404460.json' `
  --output "$root\spore_00404460_arm64.cpp" `
  --coverage "$root\spore_00404460_instruction_coverage.json"
Set-Location $root
python -m unittest -v test_static_equal_lift_generator.py test_static_copy_lift_generator.py test_static_lift_generator.py
.\build_third_static_lift.ps1
.\run_third_static_lift_on_device.ps1
.\run_third_static_lift_x86_reference.ps1
python .\compare_third_static_lift_results.py `
  --x86 "$root\third_static_equal_x86_reference_v2.log" `
  --arm64 "$root\arm64_equal_device_validation.log" `
  --output "$root\third_static_lift_cross_arch_comparison_next.json" `
  --source-sha256 6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b `
  --device-model 2303ERA42L `
  --device-serial PJMZAEJRX4YLFIDI
```

Use um novo caminho para `--output` em cada repetição para preservar os
relatórios anteriores. O comparador rejeita logs vazios, resumos ausentes ou
duplicados e qualquer conjunto diferente dos oito casos `pair_00` a `pair_07`.
