$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$vcvars = Get-ChildItem `
    "C:\Program Files\Microsoft Visual Studio",
    "C:\Program Files (x86)\Microsoft Visual Studio" `
    -Filter "vcvarsall.bat" -Recurse -ErrorAction SilentlyContinue |
    Select-Object -First 1 -ExpandProperty FullName
$source = Join-Path $root "BatchStaticLiftReachableX86Reference.cpp"
$output = Join-Path $root "reachable_x86_reference.exe"
$exe = "C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe"
$command = "call `"$vcvars`" x86 >nul && cl /nologo /EHsc /std:c++17 /O2 /W4 `"$source`" /Fe:`"$output`""
& $env:ComSpec /c $command
if ($LASTEXITCODE -ne 0) { throw "x86 harness compilation failed." }
& $output $exe
if ($LASTEXITCODE -ne 0) { throw "x86 reference harness failed." }
