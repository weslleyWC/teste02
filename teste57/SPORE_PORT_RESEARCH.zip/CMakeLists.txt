cmake_minimum_required(VERSION 3.16)
project(spore_dbpf_reader LANGUAGES CXX)

add_library(spore_dbpf dbpf_reader.cpp)
target_include_directories(spore_dbpf PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}")
target_compile_features(spore_dbpf PUBLIC cxx_std_17)

add_executable(spore_dbpf_tool dbpf_tool.cpp)
target_link_libraries(spore_dbpf_tool PRIVATE spore_dbpf)

add_library(spore_prop prop_reader.cpp)
target_link_libraries(spore_prop PUBLIC spore_dbpf)
target_compile_features(spore_prop PUBLIC cxx_std_17)

add_executable(prop_dump prop_dump.cpp)
target_link_libraries(prop_dump PRIVATE spore_prop)
target_compile_features(prop_dump PRIVATE cxx_std_17)

if(MSVC)
    target_compile_options(spore_dbpf PRIVATE /W4 /permissive-)
    target_compile_options(spore_dbpf_tool PRIVATE /W4 /permissive-)
    target_compile_options(spore_prop PRIVATE /W4 /permissive-)
    target_compile_options(prop_dump PRIVATE /W4 /permissive-)
else()
    target_compile_options(spore_dbpf PRIVATE -Wall -Wextra -Wpedantic)
    target_compile_options(spore_dbpf_tool PRIVATE -Wall -Wextra -Wpedantic)
    target_compile_options(spore_prop PRIVATE -Wall -Wextra -Wpedantic)
    target_compile_options(prop_dump PRIVATE -Wall -Wextra -Wpedantic)
endif()
