param(
    [string]$LogPath
)

$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
$python = (Get-Command python -ErrorAction Stop).Source
$vswhere = "C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
$source = Join-Path $root "BatchStaticLiftDecSemanticHarness.cpp"
$generator = Join-Path $root "generate_batch_lift_dec_semantic_fixture.py"
$log = if ($LogPath) {
    [System.IO.Path]::GetFullPath($LogPath)
} else {
    Join-Path $root "batch_static_lift_dec_semantic_x86_v1.log"
}
$tempDirectory = Join-Path $env:TEMP ("spore-dec-semantic-" + [Guid]::NewGuid().ToString("N"))
$generatedSource = Join-Path $tempDirectory "BatchStaticLiftDecSemanticLifts.cpp"
$output = Join-Path $tempDirectory "BatchStaticLiftDecSemanticHarness.exe"

if (Test-Path -LiteralPath $log) {
    throw "Semantic test log already exists; preserve it before rerunning: $log"
}
foreach ($required in @($python, $vswhere, $source, $generator)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Required semantic-test input not found: $required"
    }
}
$processor = Get-CimInstance Win32_Processor | Select-Object -First 1
if ($processor.Architecture -ne 9 -and $processor.Architecture -ne 0) {
    throw "DEC reference tests require physical x86/x86-64 hardware."
}
$vsPath = & $vswhere -products "*" -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vsPath) {
    throw "Visual Studio C++ x86/x64 build tools were not found."
}
$vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvarsall.bat"
if (-not (Test-Path -LiteralPath $vcvars)) {
    throw "vcvarsall.bat not found: $vcvars"
}

New-Item -ItemType Directory -Path $tempDirectory | Out-Null
try {
    & $python $generator --output $generatedSource
    if ($LASTEXITCODE -ne 0) {
        throw "Could not generate the statically translated DEC fixtures."
    }

    $command = 'call "' + $vcvars + '" x86 >nul && cd /d "' + $root +
        '" && cl /nologo /EHsc /std:c++17 /O2 /W4 /I "' + $root +
        '" "' + $generatedSource + '" "' + $source + '" /Fe:"' +
        $output + '" && "' + $output + '" > "' + $log + '" 2>&1'
    & $env:ComSpec /d /s /c $command
    if ($LASTEXITCODE -ne 0) {
        if (Test-Path -LiteralPath $log) {
            Get-Content -LiteralPath $log
        }
        throw "Native DEC semantic comparison failed."
    }

    Select-String -LiteralPath $log -Pattern "semantic summary|PASS=0"
    Write-Output "Full DEC semantic test log: $log"
} finally {
    if (Test-Path -LiteralPath $tempDirectory) {
        Remove-Item -LiteralPath $tempDirectory -Recurse -Force
    }
}
