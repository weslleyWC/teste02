# PROP format findings

## Status

`prop_reader` reads DBPF resources with type ID `0x00B1B104`. The format below is evidence-based and still incomplete: a scan of the local
`SPOREFILES` found 30,925 PROP resources. Scalar type `0x0001` remains
unresolved; an initial size hypothesis did not improve whole-resource parsing
and was not retained.

The original eight `.bin` samples were reported by the researcher to parse
exactly to end-of-file. The additional observations below come from scanning
the installed DBPF packages and inspecting extracted examples.

## Observed structure

- The property count is a big-endian `u32`.
- Each property starts with big-endian `u32 id`, `u16 type`, and `u16 flags`.
- For `flags == 0`, observed inline values are `int32`, `uint32`, and `float`
  (4 bytes, big-endian), plus `key` and `vec3` (12 bytes, little-endian,
  followed by four bytes of non-semantic padding).
- Types `0x0012` and `0x0013` with flags `0x000D` are length-prefixed strings.
  Their length is a big-endian `u32`; `0x0012` stores that many bytes and
  `0x0013` stores that many UTF-16LE code units.
- Types `0x0012` and `0x0013` with flags `0x009C` are arrays of strings. The
  header contains a big-endian count and a second 32-bit field whose full
  meaning is not established; each array element then has a big-endian length
  followed by its bytes (`0x0012`) or UTF-16LE code units (`0x0013`). The parser
  consumes the variable-length elements and retains their encoded bytes.
- One extracted `0x0012` scalar string is the 25-byte ASCII string
  `SkeletonPartUnlockColumn1`; the broader character encoding is not yet
  established.
- Other nonzero-flag properties observed so far use a big-endian `u32 count`,
  big-endian `u32 item_size`, and `count * item_size` bytes.
- A key contains `instance`, `type`, and `group`, each little-endian `u32`.
- Unknown inline scalar types, inconsistent lengths, and trailing bytes are
  reported as failures; their sizes/meaning are not inferred.

The four-byte padding is retained only as a boundary observation. Its changing
contents are not treated as part of the parsed value.

## Installed-package scan

The scan found **30,925** resources of type `0x00B1B104`:

| Result | Count |
|---|---:|
| Parsed and consumed exactly | 19,090 |
| Unknown inline scalar type | 11,835 |
| Array exceeds remaining payload | 0 |
| Trailing bytes | 0 |

No package-level read errors or boundary/trailing-byte failures were reported.
The command exits nonzero because unknown scalar types remain, so the scan is
still explicitly incomplete.

Property census for the 19,090 successfully parsed resources:

| Property type | Flags | Kind | Count |
|---|---:|---|---:|
| `0x0001` | `0x009C` | array | 786 |
| `0x0009` | `0x0000` | scalar | 9,711 |
| `0x0009` | `0x009C` | array | 2,516 |
| `0x000A` | `0x0000` | scalar | 5,391 |
| `0x000A` | `0x009C` | array | 3,572 |
| `0x000D` | `0x0000` | scalar | 15,905 |
| `0x000D` | `0x009C` | array | 5,430 |
| `0x0012` | `0x000D` | byte string | 616 |
| `0x0012` | `0x009C` | byte-string array | 23 |
| `0x0013` | `0x000D` | UTF-16LE string | 6,088 |
| `0x0013` | `0x009C` | UTF-16LE string array | 42 |
| `0x0020` | `0x0000` | scalar key | 38,392 |
| `0x0020` | `0x009C` | key array | 10,313 |
| `0x0022` | `0x001C` | array | 8,793 |
| `0x0022` | `0x009C` | array | 4 |
| `0x0030` | `0x009C` | array | 694 |
| `0x0031` | `0x0000` | scalar vec3 | 5,380 |
| `0x0031` | `0x009C` | array | 931 |
| `0x0032` | `0x009C` | array | 1,443 |
| `0x0038` | `0x009C` | array | 2,201 |
| `0x0039` | `0x001C` | array | 3,508 |

### Representative new string evidence

In `PatchData.package`, the PROP at group `0x02E9C426`, instance
`0x57F31D0E`, contains property `0x02E9C159` with type `0x0012`, flags
`0x000D`, length 25, and bytes `SkeletonPartUnlockColumn1`. The next property
begins immediately after those 25 bytes. Treating this as an ordinary array
instead interpreted the first five string bytes as an impossible item size.
The parser now recognizes this observed length-prefixed byte-string form.

### Variable-length string-array example

The PROP in `PatchData.package`, group `0x00000000`, instance `0x334CB9E6`,
contains a type `0x0013`, flags `0x009C` array with eight strings:
`CreatureArchetype`, `Forest`, `Rock`, `Fruit`, `MigrationPoint`,
`InteractiveOrnament`, `TribeSpawnPoint`, and `CitySpawnPoint`. Each element
starts with a big-endian code-unit length followed by UTF-16LE bytes. The
declared second array-header field is `16`, but the actual elements have
variable lengths; its semantics are therefore preserved as metadata, not used
as a fixed stride.

A separate type `0x0012`, flags `0x009C` example contains byte strings such as
`building_x` and `building_z`, each with a big-endian length. Adding both
string-array encodings eliminated the earlier array-bound and trailing-byte
failures in the full scan. This is stronger structural evidence than the
unconfirmed scalar-size experiments; no type-`0x0001` scalar layout was added.

### Remaining scalar evidence

An example in `BoosterPack_01.package` (group `0x40626000`, instance
`0x17A60A7F`) stops at offset `0x74` on property ID `0x317A429D`, scalar type
`0x0001`. Failures are grouped by scalar type:

| Unknown scalar type | Failed resources |
|---|---:|
| `0x0001` | 9,692 |
| `0x0030` | 467 |
| `0x0032` | 955 |
| `0x0033` | 86 |
| `0x0034` | 635 |

A tentative four-byte layout for `0x0001` and an eight-byte layout for
`0x0030` did not improve the number of complete resources; both were removed.
Their inline sizes, padding, and semantic interpretations remain unresolved.
In particular, `0x0001` is not assumed to be a boolean, and the known 8-byte
array element size for type `0x0030` is not sufficient evidence for its scalar
representation.

## Resource-reference observations from the supplied analysis

These are useful leads, not conclusions established by the package-wide scan:

- PROP `0x07758692`, group `0x40637E00`, reportedly points to four keys of type
  `0x00E6BCE5` sharing an instance and using groups ending in `00` through
  `03`. They may represent variants such as levels of detail or maps; that
  interpretation is unverified.
- PROP `0x1B39544B` reportedly references type `0x2F4E681B` with its own
  instance. This is a candidate PROP-to-RW4 model relationship.
- Property ID `0x00B2CCCB` reportedly references another PROP in two examples;
  inheritance/parent semantics remain a hypothesis.

## Build and reproduction

`CMakeLists.txt` defines `spore_prop` and `prop_dump`, linked to the existing
`spore_dbpf` library. The implementation built successfully with MSVC and the
Android NDK for `arm64-v8a` and `x86_64`. These are compile checks; the Android
executables were not run on a device.

From this directory:

```powershell
cmake -S . -B .\build-prop -G "Visual Studio 18 2026" -A x64
cmake --build .\build-prop --config Release --target prop_dump
.\build-prop\Release\prop_dump.exe --scan "C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES"
```

The current scan prints the census and one example for each failure category,
then exits with status 1 because unsupported PROP records remain.
