#!/usr/bin/env python3

import argparse
import sys
from pathlib import Path

import BatchStaticLift as lifter


FIXTURES = (
    (0x00401000, "48", "DEC", ("EAX",)),
    (0x00402000, "6648", "DEC", ("AX",)),
    (0x00403000, "fec8", "DEC", ("AL",)),
)


def build_fixture_source():
    sources = []
    for entry, encoded, mnemonic, operands in FIXTURES:
        instructions = [
            {
                "address": f"0x{entry:08x}",
                "bytes": encoded,
                "length": len(bytes.fromhex(encoded)),
                "mnemonic": mnemonic,
                "operands": list(operands),
                "flow": "FALL_THROUGH",
                "flows_to": [],
                "references": [],
            },
            {
                "address": f"0x{entry + len(bytes.fromhex(encoded)):08x}",
                "bytes": "c3",
                "length": 1,
                "mnemonic": "RET",
                "operands": [],
                "flow": "TERMINAL",
                "flows_to": [],
                "references": [],
            },
        ]
        function = {
            "entry": f"0x{entry:08x}",
            "name": f"FUN_{entry:08x}",
            "body_address_count": sum(item["length"] for item in instructions),
            "instructions": instructions,
            "instruction_count_exported": len(instructions),
            "instructions_truncated": False,
            "references_truncated": False,
        }
        source, diagnostics = lifter.translate_function(function)
        if any(item.get("status") != "translated" for item in diagnostics):
            raise ValueError(f"semantic fixture at 0x{entry:08x} was not fully translated")
        sources.append(source)
    return "\n\n".join(sources) + "\n"


def main():
    parser = argparse.ArgumentParser(
        description="Generate static DEC fixtures from structured x86 instruction records."
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        print(f"output already exists; preserve it before rerunning: {args.output}", file=sys.stderr)
        return 1
    try:
        source = build_fixture_source()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(source, encoding="utf-8")
    except (OSError, ValueError) as error:
        print(f"DEC semantic fixture generation failed: {error}", file=sys.stderr)
        return 1
    print(f"Generated three statically lifted DEC fixtures: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
