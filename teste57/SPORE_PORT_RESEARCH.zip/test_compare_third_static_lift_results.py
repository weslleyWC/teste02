import tempfile
import unittest
from pathlib import Path

import compare_third_static_lift_results as comparison


class ThirdStaticLiftComparisonTests(unittest.TestCase):
    def test_arm64_log_with_status_matches_native_x86_shape(self):
        x86 = "".join(
            f"x86 case=pair_{index:02d} result=1 expected=1 PASS=1\n"
            for index in range(8)
        ) + "x86 summary cases=8 failures=0\n"
        arm64 = "".join(
            f"arm64 case=pair_{index:02d} status=0 result=1 expected=1 PASS=1\r\n"
            for index in range(8)
        ) + "arm64 summary cases=8 failures=0\r\n"
        with tempfile.TemporaryDirectory(prefix="spore_third_compare_") as temporary:
            root = Path(temporary)
            x86_path = root / "x86.log"
            arm64_path = root / "arm64.log"
            x86_path.write_text(x86, encoding="utf-8")
            arm64_path.write_bytes(arm64.encode("utf-16"))

            x86_result = comparison.parse_log(x86_path, "x86")
            arm64_result = comparison.parse_log(arm64_path, "arm64")

        self.assertEqual(len(x86_result), 8)
        self.assertEqual(x86_result, arm64_result)

    def test_empty_logs_are_rejected(self):
        empty = (
            "arm64 summary cases=0 failures=0\n"
            "x86 summary cases=0 failures=0\n"
        )
        with tempfile.TemporaryDirectory(prefix="spore_third_compare_") as temporary:
            log_path = Path(temporary) / "empty.log"
            log_path.write_text(empty, encoding="utf-8")

            for architecture in ("x86", "arm64"):
                with self.subTest(architecture=architecture):
                    with self.assertRaisesRegex(ValueError, "no test cases"):
                        comparison.parse_log(log_path, architecture)

    def test_missing_expected_case_is_rejected(self):
        log = "".join(
            f"x86 case=pair_{index:02d} result=1 expected=1 PASS=1\n"
            for index in range(7)
        ) + "x86 summary cases=7 failures=0\n"
        with tempfile.TemporaryDirectory(prefix="spore_third_compare_") as temporary:
            log_path = Path(temporary) / "partial.log"
            log_path.write_text(log, encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "expected set"):
                comparison.parse_log(log_path, "x86")

    def test_failed_or_incomplete_log_is_rejected(self):
        text = (
            "arm64 case=pair_00 status=0 result=0 expected=1 PASS=0\n"
            "arm64 summary cases=1 failures=1\n"
        )
        with tempfile.TemporaryDirectory(prefix="spore_third_compare_") as temporary:
            log_path = Path(temporary) / "arm64.log"
            log_path.write_text(text, encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "expected-value test failed"):
                comparison.parse_log(log_path, "arm64")


if __name__ == "__main__":
    unittest.main()
