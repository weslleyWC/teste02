# Spore static lifter — 30-function pilot

## Purpose and current state

This pilot replaces one-function-at-a-time experimentation with a bounded,
repeatable export and measurement pipeline. It is not a full-game lift. The
Ghidra export is read-only and uses the existing analysis database; it does not
run whole-program analysis or execute the target.

The pilot contains exactly:

- 10 non-thunk functions with 1–32 Ghidra body bytes, selected by ascending
  body size and then ascending VA;
- 10 non-thunk functions with 33–128 body bytes, using the same ordering;
- 10 remaining non-thunk functions with a conditional jump and at most 512
  body bytes, also using ascending body size and VA.

The export stops with an explicit error if any stratum cannot supply ten
functions. The criteria are based on the currently open Ghidra program and are
repeatable for an unchanged analysis database.

## Measured pilot result (2026-11-02)

The user supplied `C:\SporeAnalysis\spore_batch_pilot_30.json`. The executable
and export both identify the selected Phase 4 build with SHA-256
`6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`. The
offline verifier confirmed each exported instruction byte against that PE and
the Ghidra inventory.

| Metric | Result |
|---|---:|
| Functions in deterministic pilot | 30 (10/10/10 strata) |
| Functions fully translated | 12 |
| Functions rejected | 18 |
| Accepted complete-function instruction bytes | 66 / 454 (14.54%) |
| Overlapping exported instruction bytes | 0 |
| Direct-call graph nodes from Ghidra entry point | 606 |
| Pilot functions marked reachable by that graph | 1 / 30 |
| Generated sources instantiated and compiled as Android ARM64 C++ | 12 / 12 |

The direct-call graph is complete only under its declared Ghidra-reference
model. It starts at the sole Ghidra external entry point `0x011e11a0` and does
not resolve indirect calls, runtime registration, dynamically loaded code, or
other unmodeled roots. Thus 29 pilot functions were **not reached in this
static graph**; that does not prove they cannot execute in the game.

The largest rejection categories were 13 direct/indirect calls, 15 unsupported
operand forms, one unsupported opcode (`DEC`), one branch target outside the
exported function, and one incomplete one-byte `PUSH` function with no
exported fallthrough. The report contains per-instruction addresses,
mnemonics, operands, and precise reasons. `float`/`byte`/`word` operations,
8-bit registers, indirect calls, and incomplete control-flow exports remain
unsupported by design.

The first offline report was preserved as
`batch_static_lift_pilot_report.json`. A signed-frame-displacement parsing
correction was then applied and the pilot reprocessed without overwriting the
initial outputs; the current result is
`batch_static_lift_pilot_report_v2.json` with sources in
`generated_batch_pilot_30_v2`.

**Interpretation:** 12 accepted means only that the complete exported
instruction set fits the implemented static lowering rules and its bytes
match the selected PE. It is not proof of semantic equivalence, runtime use,
or phone execution. All 12 generated sources, including instantiated lift
templates, compile for Android ARM64; they have not yet been linked into an
Android executable or run on device.

## Fail-closed translation subset

`BatchStaticLift.py` verifies the build hash, Ghidra language, source
confirmation, inventory identity, instruction encodings, `.text` placement,
and completeness before generating code. It rejects the *whole function* if
any instruction, operand form, or control-flow edge is outside the implemented
subset. Unknown mnemonics are never skipped.

The initial static backend supported a deliberately small set:

- 32-bit `MOV`;
- 32-bit `ADD`, `SUB`, `CMP`, `TEST`, `AND`, `OR`, and `XOR`;
- `PUSH` and `POP` using 32-bit values;
- `NOP`, direct `JMP`, listed integer `Jcc` conditions, and `RET`/`RETN`;
- 32-bit memory operands only when Ghidra explicitly identifies `dword ptr`
  and the address is a single base register plus a constant displacement.

It rejects calls (direct and indirect), unresolved or out-of-function branch
targets, unexported fallthrough, 8-/16-bit and floating-point operations,
indexed or segmented addressing, and every opcode not listed above. The
generated C++ has fixed labels and operations; it contains no x86 decoder or
instruction-dispatch loop. It is static lowering, not runtime emulation.

The repeated pilot additionally supports partial 8-/16-bit registers,
byte/word/dword integer operations where width is explicit or unambiguous,
`MOVZX`, `MOVSX`, `SETcc`, `INC`, `DEC`, and `NEG`. `BatchStaticLiftRuntime.hpp`
provides a bounded 32-bit guest-memory map for the generated static operations;
it contains no x86 decoder or interpreter.

An accepted source file is a translation candidate, not equivalence proof. It
still requires compilation, native x86 versus physical Android ARM64 test
vectors, and caller/ABI review before being called validated.

## Repeated pilot and cross-architecture execution

The backend improvements were measured against the **same**
`C:\SporeAnalysis\spore_batch_pilot_30.json`; the comparison tool verifies the
same 30 entry addresses, 10/10/10 selection strata, and executable SHA-256
before reporting a delta. The historical v2 result remains unchanged.

| Metric | Baseline v2 | Repeated v4 | Change |
|---|---:|---:|---:|
| Fully accepted functions | 12 / 30 | 15 / 30 | +3 |
| Accepted unique instruction bytes | 66 / 454 (14.54%) | 99 / 454 (21.81%) | +33 bytes; +7.27 percentage points |
| Direct-call graph reachability | 1 / 30 | 1 / 30 | no change |

The newly accepted functions are `0x008de220`, `0x00e82130`, and `0x00ef72c0`.
The machine-readable delta is in
`batch_static_lift_comparison_v2_v4.json`. This remains coverage of exported
pilot instructions, not whole `.text` or gameplay coverage.

All 15 v4 generated sources passed an Android ARM64 syntax/compile check. Three
were linked into one native ARM64 test executable and run on physical device
`2303ERA42L` (`arm64-v8a`, serial `PJMZAEJRX4YLFIDI`). The matching x86 harness
was compiled as a 32-bit process and executed the original bytes extracted from
the selected PE on the physical x86-64 host; it first verifies the exact bytes
for each selected function, while the PowerShell runner verifies the full PE
SHA-256.

| Function | Shared cases | Compared observation |
|---|---:|---|
| `0x00922a80` | 2 | `EAX`, null and non-null pointer |
| `0x00a02bd0` | 3 | `EAX`, including compare-equal and boundary values |
| `0x00ef72c0` | 2 | byte write/skip at `[ECX+0x3f]` |
| **Total** | **7** | **7/7 matched** |

The exact per-case outputs and executable/device identity are preserved in
`batch_static_lift_execution_comparison_v2.json`; raw logs are
`batch_static_lift_x86_reference.log` and
`batch_static_lift_arm64_device.log`. The cross-architecture result is a
bounded function-level **PASS**, not proof of every register/flag for all
inputs, calling-convention integration, callers, dependencies, or the game.
The test objects and valid pointers are controlled by the harness.

On 2026-11-02, the 100-function pilot was rebuilt independently from the
current executable at `SPOREFILES\SporeBin\SporeApp.exe`, the recovered current
inventory, and the recovered Ghidra export. The rebuild produced the same
source hash, 52 accepted functions, 48 rejected functions, 404/1,538 accepted
instruction bytes, and 52 generated C++ sources. The independent report is
kept in the session artifacts as `rebuild_100_report.json`; this confirms
reproducibility of the export/lift stage, not semantic equivalence or game
integration.

The 300-function expansion was then processed on 2026-11-02 using the same
verified PE and current inventory. It accepted 145/300 functions and
1,415/4,980 exported instruction bytes (28.41%), producing 145 C++ sources.
The rejection counts were 137 direct/indirect calls, 57 unsupported operand
forms, 9 unsupported opcodes, 3 control-flow issues, and 24 other validation
issues. All 145 accepted sources passed the Android ARM64 syntax check. The
300-function report and generated sources are kept in the session artifacts;
these results measure static coverage only and do not authorize ordinary call
lowering.

During harness preparation, `0x00485900` was deliberately excluded: its Ghidra
body exports 33 instruction bytes, while the address span in the PE contains
two additional unexported bytes at `0x0048591b`. Per-instruction PE validation
passes, but a contiguous raw-byte check does not. This does not invalidate the
seven tested vectors; it identifies a useful additional audit for future
test-candidate selection: inspect gaps within function address spans instead of
assuming the sum of instruction lengths describes a contiguous code range.

Reproduce the two executions from PowerShell with
`run_native_batch_x86_reference.ps1` and `run_batch_lift_device_tests.ps1`, then
compare their logs using `compare_batch_lift_execution.py`:

```powershell
$root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
& "$root\run_native_batch_x86_reference.ps1"
& "$root\run_batch_lift_device_tests.ps1"
python "$root\compare_batch_lift_execution.py" `
  --x86 "$root\batch_static_lift_x86_reference.log" `
  --arm64 "$root\batch_static_lift_arm64_device.log" `
  --output "$root\batch_static_lift_execution_comparison_next.json" `
  --source-sha256 6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b `
  --device-model 2303ERA42L `
  --device-serial PJMZAEJRX4YLFIDI
```

Choose a new `--output` path for every run; existing evidence files are
preserved rather than overwritten. The comparator rejects empty logs, duplicate
or missing summaries, and any case set other than the seven fixed names above;
update its expected set and tests when deliberately changing the harness.

## Expanding the fixed sample to 100 or 300 functions

The Ghidra exporter now offers three explicit sample sizes:

- **30-function regression pilot:** 10 small, 10 medium, 10 conditional-branch.
  Its output remains `C:\SporeAnalysis\spore_batch_pilot_30.json`.
- **100-function expansion:** 30 small, 30 medium, 40 conditional-branch.
  Its output is `C:\SporeAnalysis\spore_batch_pilot_100.json`.
- **300-function expansion:** 90 small, 90 medium, 120 conditional-branch.
  Its output is `C:\SporeAnalysis\spore_batch_pilot_300.json`.

The 100-function export deliberately selects the original 10/10/10 pilot
first, then adds the extra 20 small, 20 medium, and 30 conditional-branch
functions. Thus the original 30 addresses and strata remain a subset of the
100-function export, allowing a like-for-like regression comparison alongside
the additional coverage. Both sizes use the existing deterministic ordering
(body size, then VA); both reuse existing Ghidra analysis and the same bounded
reachability traversal.

To produce an expansion, run `ExportSporeFunctionBatch` in the existing
Ghidra 12.2 project and enter `100` or `300` when it asks for pilot size. Keep
the exported JSON; the offline lifter validates the selected PE hash,
inventory, bytes, exact pilot size, and corresponding strata before writing
any generated source. The 300-function export increases measurement scale; it
does not relax rejection of calls or unsupported instructions.

## Complete inventory processing

The complete current Ghidra export contains **57,801** internal,
non-thunk functions. The historical CSV count of 57,922 includes entries that
are not part of this export's internal non-thunk set; the complete run is
therefore measured against 57,801 functions and the current executable hash.

The resumable processor completed this inventory on 2026-11-02:

- 57,801 function records processed;
- 3,703 functions accepted by the current fail-closed subset;
- 54,098 functions rejected;
- 3,703 C++ sources generated;
- all 3,703 sources passed the ARM64 syntax check in chunks of 100 files;
- 606 exported functions are marked reachable by the direct-call graph;
- 45 accepted functions are both reachable and statically translated.

The complete report is `C:\SporeAnalysis\spore_static_lift_incremental_report.json`,
the resumable state is `C:\SporeAnalysis\spore_static_lift_state.json`, and
the generated sources are under `C:\SporeAnalysis\generated_all`. These are
coverage and compilation results, not game integration or whole-program
equivalence. The most common blockers remain calls, SSE/x87 operands, shifts,
and multiply instructions.

The physical ARM64 follow-up on the reachable set now uses forty-seven cases:
`0x0117dde0` with null and non-null arguments, and `0x011874d0` with a
controlled pointer field, plus `0x00743b50` and `0x0077f010` for this-pointer
writes and stack-argument consumption. The latest addition covers three
branches of `0x011895f0`: nonzero second field, first field equal to five, and
the zero-result path. All 8/8 ARM64 cases passed on the connected physical
device. The matching native x86 reference also passed all 11/11 cases after
correcting the harness argument representation for `0x0117dde0`. The bounded
cross-architecture comparison is recorded in
`batch_static_lift_reachable_execution_comparison.json`; it compares
normalized behavior rather than process-specific pointer addresses.
The loop candidate `0x0093c710` is also covered by empty, one-element, and
two-element zero-terminated lists; all three cases passed on both
architectures. The three-argument pointer exchange candidate
`0x0119af70` also passed, returning the old target value and storing the new
value on both architectures.
The nullable-store candidate `0x0091e020` also passed its null-pointer and
non-null-pointer cases, including the two stores at offsets `0xC` and `0x10`
and its `RET 0x8` stack cleanup.
The constant object initializer `0x006b5870` also passed, storing
`0x01409b74` and zero at the two controlled object fields.
The alignment and saturation helper `0x009267a0` also passed its aligned-mask,
lower-bound, and upper-bound paths on both architectures.
The flag-dependent pointer helper `0x0119b160` also passed its direct-return
and pointer-addition branches on both architectures.
The separator classifier `0x0088b850` also passed its backslash, slash,
colon, and ordinary-character paths on both architectures.
The object branch helper `0x0092ea70` also passed its direct-field and
adjusted-pointer branches on both architectures.
The vector-search loop `0x005c1cc0` also passed empty-range, first-match,
later-match, and absent-target cases on both architectures.
The conditional flag store `0x0117afe0` also passed its null-argument,
null-field, and set-flag paths on both architectures.
The byte-copy loop `0x011e8b20` also passed empty-string and five-byte copy
cases, including the trailing zero terminator, on both architectures.
The pointer-validation branch `0x0117e310` also passed the low-limit,
two-zero-byte advance, and nonzero-byte rejection paths on both architectures.
The object initializer `0x008db8c0` also passed zero-seed and nonzero-seed
cases, including its pointer return and initialized fields, on both architectures.
The structure-zeroing initializer `0x00a0fdf0` also passed zero-seed and
nonzero-seed cases across all initialized offsets on both architectures.
The three-argument initializer `0x00925f30` also passed two layouts,
including a zero third argument and its `RET 0xC` stack cleanup.
The chained-node lookup `0x00926a30` also passed empty-sentinel,
current-node, and next-node traversal paths on both architectures.
The 16-byte block-copy loop `0x00705250` also passed empty, one-block, and
three-block cases on both architectures. The cases verified the copied block
contents, the advanced destination return value, and the function's
non-cleaning `RET` stack behavior.
Five additional trivial candidates also passed on both architectures:
`0x00c2e4e0` (plain `RET`), `0x00a6ca00` (`RET 0xC`), and the constant
return helpers `0x006bb640`, `0x00b3d220`, and `0x011861a0`.
The fixed-layout initializer `0x0118a790` also passed, including its five
magic constants, zero-initialized trailing fields, and return value.
The PE image validator `0x011e13c0` also passed rejection cases for invalid
MZ and PE signatures and an acceptance case for the controlled PE32 machine
field `0x10b`.
The node-walk helper `0x00921580` also passed direct-node and null-object
head-node cases with controlled links and matching return pointers.
The tree helper `0x009215c0` also passed its header-match, empty-tree, and
root-without-left-child cases with controlled node links.
The reverse 16-byte block-copy helper `0x00edba80` also passed empty,
one-block, and three-block cases, including destination-end-to-start return
behavior and preservation of its saved register.
The fixed structure initializer `0x005d67f0` also passed, verifying both
fixed pointer fields and zeroing of all tested fields through offset `0x44`.
The conditional initializer `0x0119afe0` passed five more cases on both
architectures: null object context, null descriptor record, flag bit `0x2`
clear, a zero computed destination, and successful writes of `0, 0, 1` to a
controlled nonzero destination.

The mode-dependent helper `0x0041e920` passed four cases on both
architectures: mode `1` with mask `0x30` set returned the first object field;
mode `1` with the mask clear and mode `0x10` returned the object pointer; an
other mode returned `0x015d115d`. Its candidate instruction records total 95
bytes, while the verified contiguous PE span is 97 bytes; every recorded
instruction was checked at its own address and the intervening two-byte jump
was retained in the x86 reference. The x86 byte loader now allocates according
to the requested span instead of using a fixed 32-byte buffer.

The neighboring helper `0x0041e990` passed the same four mode/flag paths with
mode `9` and constant `0x015d1160`; its 95 instruction bytes were likewise
verified at their VAs within the 97-byte PE span. The next helper,
`0x0041ea00`, passed the same four paths with mode `0x0a` and constant
`0x015d1164`. The next helper, `0x0041ea70`, passed the same paths with mode
`0x0d` and constant `0x015d1168`.

The backward 16-bit word search `0x00423890` then passed four cases on both
architectures: an empty interval, a match at the cursor, a match at the
preceding word, and no match. The x86 harness helper was moved to namespace
scope after its first compile exposed an accidental nested-function placement.
The block-copy helper `0x00c7ea30` then passed four cases on both architectures:
an empty interval, one- and two-block copies, and a null source. The copied
bytes, return pointer, unchanged destination on the null-source path, and
preservation of `ESI` matched. The updated comparison manifest records
**97/97 passing cases** across 40 of the 45 accepted reachable candidates,
leaving 5 for validation.

The reverse word-set search `0x005728f0` passed five cases on both
architectures: cursor already at the lower bound, an empty search-value list,
matches at the current and preceding words, and no match. The return positions
and preservation of `EBX`, `ESI`, and `EDI` matched. The manifest now records
**102/102 passing cases** across 41 of the 45 accepted reachable candidates,
leaving 4 for validation.

The tree lookup `0x00e5c780` passed five cases on both architectures: empty
tree, exact root match, exact matches through each child, and absent key. The
output node/sentinel, return pointer, stack cleanup, and preserved `ESI`/`EDI`
matched. The manifest now records **107/107 passing cases** across 42 of the
45 accepted reachable candidates, leaving 3 for validation.

The bounded string-append helper `0x011849c0` passed six cases on both
architectures: empty destination, normal append, truncation, full destination,
zero capacity, and empty source. Destination bytes, termination behavior,
combined-length return values, and preserved callee-saved registers matched.
The comparison now records **113/113 passing cases** across 43 of the 45
accepted reachable candidates, leaving 2 for validation.

The 16-bit word-pattern search `0x005e8ff0` passed six cases on both
architectures: empty pattern, empty text, one-word match, a multi-word match at
the start, retry after a partial prefix, and no match. Return positions and
preserved callee-saved registers matched. The comparison now records
**119/119 passing cases** across 44 of the 45 accepted reachable candidates,
leaving one for validation.

The final candidate, red-black tree insertion `0x009216a0`, passed five cases
on both architectures: insertion into an empty tree, left and right insertion
under a black parent, recoloring with a red uncle, and a left-left rotation.
The tests compared the return value, tree header, parent/child links, node
colors, preserved callee-saved registers, and ARM64 stack cleanup. The comparison
manifest now records **124/124 passing cases across all 45/45 accepted
reachable candidates**. These controlled fixtures do not prove behavior for
all inputs, full caller-ABI integration, or integration in the game.

The ARM64 run used physical device `2303ERA42L` (`arm64-v8a`, serial
`PJMZAEJRX4YLFIDI`). These controlled cases do not establish full caller-ABI
or game integration.

## Full incremental export

The same Ghidra exporter accepts `0` as the size for a complete internal
function export. It preserves the same executable identity and fail-closed
instruction records, but marks the result as a complete export rather than a
pilot. Complete export now writes each function incrementally through a
`BufferedWriter` into a temporary file and publishes it only after successful
completion, so the whole JSON is no longer held in the Java heap. A complete
export is allowed up to one hour. Because the resulting JSON can still be
large, split it into numbered batches before lifting:

```powershell
python "$root\SplitSporeFunctionExport.py" `
  --input 'C:\SporeAnalysis\spore_batch_all.json' `
  --output-dir 'C:\SporeAnalysis\spore_batch_all_parts' `
  --batch-size 500
```

Process or resume all parts with:

```powershell
python "$root\ProcessSporeFunctionBatches.py" `
  --exe 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe' `
  --csv 'C:\SporeAnalysis\spore_functions_current.csv' `
  --batch-dir 'C:\SporeAnalysis\spore_batch_all_parts' `
  --output-dir 'C:\SporeAnalysis\generated_all' `
  --state 'C:\SporeAnalysis\spore_static_lift_state.json' `
  --report 'C:\SporeAnalysis\spore_static_lift_incremental_report.json'
```

The state file keys each function by the executable hash, lifter hash, entry,
name, body size, and instruction records. Re-running the command skips
unchanged results and only processes new or invalidated functions. Existing
pilot outputs are preserved; they are not silently mixed into the complete
state because the complete export is the authoritative input set.

Run the 100-function lift into new output paths:

```powershell
$root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
python "$root\BatchStaticLift.py" `
  --exe 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe' `
  --csv 'C:\SporeAnalysis\spore_functions.csv' `
  --batch 'C:\SporeAnalysis\spore_batch_pilot_100.json' `
  --output-dir "$root\generated_batch_pilot_100_v1" `
  --report "$root\batch_static_lift_pilot_report_100_v1.json"
```

The report comparison supports either identical pilot reruns (30 vs. 30 or
100 vs. 100) or the nested 30-to-100 expansion. It separately reports changes
on the shared 30 functions and acceptance among the 70 additions:

```powershell
python "$root\compare_static_lift_reports.py" `
  --baseline "$root\batch_static_lift_pilot_report_v4.json" `
  --candidate "$root\batch_static_lift_pilot_report_100_v1.json" `
  --output "$root\batch_static_lift_comparison_30_to_100_v1.json"
```

The 100-function pilot was rerun against the same verified executable after
adding bounded 32-bit `LEA register, [base + displacement]` support. Results
from the updated run:

| Stratum | Accepted | Rejected |
|---|---:|---:|
| Small | 29/30 | 1/30 |
| Medium | 4/30 | 26/30 |
| Conditional-branch | 20/40 | 20/40 |
| **Total** | **53/100** | **47/100** |

The accepted functions contain 196 instructions and 418 of 1,541 exported
instruction bytes (27.13%); 418 unique bytes were accepted, with no overlapping
instruction bytes in this pilot. Against the previous 100-function run, the
same addresses improved from 51 to 53 accepted and from 393 to 418 accepted
bytes. The original 30-function regression subset improved from 15 to 16
accepted functions and from 99 to 110 bytes. The 70 additions now contain 37
accepted and 33 rejected functions. The comparison report records the shared
pilot change separately from the expanded sample.

The 59 rejection diagnostics are dominated by direct/indirect calls (41);
the remaining categories are other (9), unsupported operand form (7),
unsupported opcode (1), and control flow (1). These are instruction/function
blockers, not independent counts of unique functions. Direct-call lowering
remains deferred until the target is statically available and its calling
convention, argument/return state, and call/return effects can be preserved.
A separate check found 36 call references: 34 target functions outside this
100-function export, and the two in-export targets both have unknown calling
conventions. This is why the current batch cannot safely lower those calls as
ordinary generated function calls.
Ghidra's bounded direct-call graph marks 2/100 pilot functions reachable and
just 1 accepted function reachable. This is static graph evidence, not proof
of gameplay execution.

All 53 generated C++ sources passed the Android ARM64 syntax check. Two newly
accepted conditional-branch functions were individually validated across
architectures:

- `0x01180160` matched 2/2 null/non-null cases between the original PE bytes
  run natively on x86 and generated code on physical Android ARM64. Its
  calling convention is unknown in Ghidra; the harness follows its observed
  stack argument and plain `RET`.
- `0x007f30d0`, newly accepted because of `LEA` support, also matched 2/2
  null/non-null ECX pointer cases between original x86 bytes and generated
  ARM64. The comparison checks return value, defined TEST/XOR flags,
  entry-relative return stack delta, preserved registers, and unchanged
  sentinel memory. Ghidra reports its calling convention as unknown; the test
  follows the observed ECX input and plain `RET`.

Neither function is reported reachable by the bounded graph. These isolated
function tests do not establish full-game equivalence or integration. The
implemented `LEA` subset intentionally rejects indexed/scaled addresses and
non-32-bit destinations rather than approximating their semantics.

### Post-format export with refreshed Ghidra inventory (2026-11-02)

After restoring the Ghidra project, the 100-function batch was re-exported
from the confirmed Phase 4 executable. The recovered historical CSV did not
contain one newly selected function, so `ExportSporeFunctionInventory` was
added to export the current non-external, non-thunk function inventory without
overwriting the recovered CSV. The refreshed inventory contains 57,801
functions and matches every selected batch entry by address, name, and body
size.

The refreshed batch was processed with the unchanged static lifter:

| Metric | Previous retained v2 | Refreshed Ghidra export |
|---|---:|---:|
| Pilot functions accepted | 53 / 100 | 52 / 100 |
| Accepted instruction bytes | 418 / 1,541 | 404 / 1,538 |
| Accepted reachable functions | 1 | 1 |

The refreshed deterministic pilot replaces `0x00c2ebc0` with `0x00416313`.
All 99 shared functions retain the same accept/reject status. Thus the metric
change reflects the updated Ghidra selection, not a lifter change. The new
report is `batch_static_lift_pilot_report_100_recovered_v2.json` and the 52
generated sources are in `generated_batch_pilot_100_recovered_v2`.

The 40 focused backend/comparator tests passed after this run. Android ARM64
syntax validation is still pending: the configured NDK 29.0.14206865 compiler
was not found at its expected path on this restored PC. No new generated
function is considered runtime-validated by this export alone.

The NDK was subsequently installed and the same three-function harness was
recompiled from `generated_batch_pilot_100_recovered_v2`. The x86 reference
executed the original bytes from the verified PE, while the ARM64 harness ran
on physical device `2303ERA42L` (`arm64-v8a`, serial `PJMZAEJRX4YLFIDI`).
All seven shared cases matched:

| Function | Cases | Result |
|---|---:|---|
| `0x00922a80` | 2 | 2/2 |
| `0x00a02bd0` | 3 | 3/3 |
| `0x00ef72c0` | 2 | 2/2 |
| **Total** | **7** | **7/7 PASS** |

The comparison report is `batch_static_lift_execution_comparison_recovered_v2.json`;
the raw logs are `batch_static_lift_x86_reference_recovered_v2_retry2.log` and
`batch_static_lift_arm64_device_recovered_v2.log`. This validates only the
listed isolated vectors and observed return/memory results; it does not prove
ABI integration, dependency behavior, caller coverage, or whole-game
equivalence.

This 100-function measurement is not a reason to jump directly to 300 or 1,000.
The next high-value area is statically resolved direct-call support with
verified callee coverage and explicit calling-convention handling; retain
strict rejection for unresolved or semantically incomplete calls. Keep the
30-function subset fixed to measure changes caused by lifter improvements
separately from sample expansion.

To collect the evidence needed for that work, copy
`ExportSporeCallInventory.java` into the Ghidra Script Manager directory and
run it with the restored `spore_batch_pilot_100.json`. It verifies the same
Phase 4 executable and writes `C:\SporeAnalysis\spore_batch_call_inventory.csv`
without overwriting existing outputs. The CSV records each direct call site,
resolved target, Ghidra calling convention, callee body size, computed-call
status, and whether the callee is in the selected pilot. This is static
metadata only; it does not make indirect calls safe or justify lowering calls
before caller/callee ABI behavior is verified.

The refreshed call inventory contains 37 call sites: 36 direct calls with
resolved internal targets and one computed call with no resolved target. All
36 resolved targets report Ghidra calling convention `unknown`, including the
two targets that are themselves inside the selected 100-function batch:
`0x006237a0` (33 body bytes) and `0x00c2e4e0` (1 body byte). Therefore no call
was promoted to ordinary generated C++ call syntax. The static lifter remains
fail-closed for both direct and computed calls until a caller/callee ABI is
established and validated with a native x86 versus physical ARM64 harness.

One additional edge case is `0x0060ceb0`: Ghidra describes its `JMP` to
`0x00c2e4e0` as `CALL_TERMINATOR`, and the target consists only of `RET`.
This is evidence of a possible tail-call-to-return pattern, not an ordinary
call. It remains rejected because the callee convention is still `unknown`,
the caller is not reachable in the bounded entry-point graph, and no
cross-architecture harness has yet established the required stack and memory
behavior. It is the next narrow candidate for a dedicated tail-call test; it
must not be generalized to all `CALL_TERMINATOR` flows.

The dedicated harness was then run for two cases (`ECX == 0` and
`ECX == 0x20000000`). The x86 side verified the 13 original PE bytes at
`0x0060ceb0`; because the copied relative tail jump cannot retain its absolute
target after relocation, the harness redirected that verified displacement to a
local `RET` stub, matching the separately exported one-byte callee. The ARM64
side implemented only the observed load/test/return behavior. Both cases
passed on native x86 and on physical ARM64 device model `2303ERA42L`
(serial `PJMZAEJRX4YLFIDI`, `arm64-v8a`): **2/2 x86 and 2/2 ARM64**. This is evidence for
this exact pattern only; it is not sufficient to enable generalized
`CALL_TERMINATOR` lowering or to claim caller ABI integration.

Retained results:

- `batch_static_lift_pilot_report_100_v1.json`
- `batch_static_lift_pilot_report_100_v2.json`
- `batch_static_lift_comparison_30_to_100_v1.json`
- `batch_static_lift_comparison_30_to_100_v2.json`
- `batch_static_lift_01180160_x86_v1.log`
- `batch_static_lift_01180160_arm64_v1.log`
- `batch_static_lift_01180160_comparison_v1.json`
- `batch_static_lift_007f30d0_x86_v2.log`
- `batch_static_lift_007f30d0_arm64_v2.log`
- `batch_static_lift_007f30d0_comparison_v1.json`

The `0x01180160` comparison is reproducible with
`run_batch_branch_x86_reference.ps1`, `run_batch_branch_android.ps1`, and
`compare_batch_static_lift_branch_results.py`. The Android runner selects the
single authorized ADB device or accepts `-DeviceSerial` when multiple devices
are connected. The `0x007f30d0` LEA comparison uses
`run_batch_lea_x86_reference.ps1`, `run_batch_lea_android.ps1`, and
`compare_batch_static_lift_lea_results.py`. Use new paths for every run;
evidence files are not overwritten.

## DEC semantic test across x86 and Android ARM64

The generated `DEC EAX`, `DEC AX`, and `DEC AL` fixtures were exercised with
the same 42-case matrix: seven boundary values per width, each with carry-in
clear and set. The x86 run executes native x86 instructions and captures flags
with `PUSHFD`/`POP`; the Android run executes the statically generated ARM64
code on a physical device and checks it against an independent arithmetic/flags
oracle.
Both harnesses also assert preserved registers, stack position, return address,
and (for 8-/16-bit forms) untouched upper EAX bits.

Verified run: 42/42 cases matched between native x86 and a physical
`arm64-v8a` phone (`25078RA3EL`). The comparison covers EAX and CF/PF/AF/ZF/SF/OF.
This is an instruction-level synthetic fixture test, **not** a test of a
SporeApp.exe function, memory-form DEC, or game integration.

To reproduce, use new log/report paths each time; the runners preserve existing
evidence. The Android runner automatically selects the only authorized
connected ADB device, or accepts `-DeviceSerial` when multiple devices are
connected:

```powershell
$root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
& "$root\run_batch_lift_dec_semantic_tests.ps1" `
  -LogPath "$root\batch_static_lift_dec_semantic_x86_next.log"
& "$root\run_batch_lift_dec_semantic_tests_android.ps1" `
  -LogPath "$root\batch_static_lift_dec_semantic_arm64_next.log"
python "$root\compare_batch_lift_dec_semantic_results.py" `
  --x86 "$root\batch_static_lift_dec_semantic_x86_next.log" `
  --arm64 "$root\batch_static_lift_dec_semantic_arm64_next.log" `
  --output "$root\batch_static_lift_dec_semantic_comparison_next.json" `
  --device-model '<reported model>' `
  --device-serial '<reported serial>'
```

The comparator rejects empty/incomplete/duplicate case sets, nonzero failures,
and mismatched results or arithmetic flags. The retained evidence for the
verified run is `batch_static_lift_dec_semantic_x86_v3.log`,
`batch_static_lift_dec_semantic_arm64_v3.log`, and
`batch_static_lift_dec_semantic_comparison_v1.json`.

## Coverage and reachability definitions

The JSON report distinguishes:

- accepted and rejected complete functions;
- accepted instruction count and bytes for functions fully emitted;
- number of instruction records belonging to rejected functions versus the
  number of individual rejection diagnostics (these are not interchangeable);
- unique instruction-byte addresses covered in the pilot, with cross-function
  overlaps reported separately;
- explicit rejected-instruction diagnostics, including mnemonic, address,
  operands, and reason;
- the number of pilot functions reported reachable or unreachable, plus
  unknown reachability when graph traversal is incomplete;
- how many emitted functions are in the reachable subset.

Byte coverage is exact only for the exported pilot instructions verified
against the selected PE. It is not whole-`.text` coverage. The reachability
search starts from Ghidra external entry-point symbols and follows direct call
references only. Indirect calls, dynamic resolution, unmodeled roots, and
Ghidra analysis omissions are not resolved. Traversal is capped at 50,000
functions; if it reaches that cap, unvisited pilot functions are marked
unknown rather than unreachable. Even a complete graph under this definition
does not establish runtime execution on a particular gameplay path.

## Run the Ghidra export

1. Copy `ExportSporeFunctionBatch.java` beside the existing
   `ExportSporeFunction.java` in the Ghidra Script Manager script directory.
2. In Ghidra 12.2, open the existing analysis for the selected base-game
   `SporeApp.exe` and run `ExportSporeFunctionBatch`; choose 30 for the
   regression pilot or 100 for the nested expansion.
3. Select exactly:
   `C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe`
4. Confirm that this is the executable used to create the open Ghidra program.
   The script refuses a different SHA-256 and does not overwrite an existing
   export.
5. The script writes the selected output:
   `C:\SporeAnalysis\spore_batch_pilot_30.json` or
   `C:\SporeAnalysis\spore_batch_pilot_100.json`.

The script has a 10-minute wall-clock limit, a 50,000-function reachability
cap, a 2,048-instruction cap per exported function, and a 4,096-reference cap
per function. Truncation is recorded and causes the offline lifter to reject
that function.

### Refreshing the function inventory

The batch exporter selects functions from the currently open Ghidra analysis,
so its inventory must come from that same analysis. If the recovered
`spore_functions.csv` disagrees with a selected function's name or body size,
preserve the old CSV and refresh the inventory instead of bypassing the
offline verifier:

1. Copy `ExportSporeFunctionInventory.java` into the Ghidra Script Manager
   script directory and run it with the same Spore program still open.
2. Select the exact `SporeApp.exe` used by the open program and confirm that
   source identity. The script verifies the Phase 4 SHA-256 and refuses to
   overwrite an existing output.
3. Use the newly written `C:\SporeAnalysis\spore_functions_current.csv` with
   `BatchStaticLift.py` in place of `spore_functions.csv`.

The inventory exporter reads the existing function manager, includes
non-external non-thunk functions, sorts entries by address, and does not
trigger analysis or execute target code.

## Run the verifier, translator, and report

From PowerShell:

```powershell
$root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
python "$root\BatchStaticLift.py" `
  --exe 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe' `
  --csv 'C:\SporeAnalysis\spore_functions.csv' `
  --batch 'C:\SporeAnalysis\spore_batch_pilot_30.json' `
  --output-dir "$root\generated_batch_pilot_30_v3" `
  --report "$root\batch_static_lift_pilot_report_v3.json"
```

The output directory and report path must be new or empty; existing results are
preserved. The report lists each function's decision and detailed blockers.
Generated C++ is emitted only for functions for which every exported
instruction passed translation.

Run the backend unit tests:

```powershell
Set-Location 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
python -m unittest -v test_static_batch_lift.py
```

## Acceptance gate for the pilot

The pilot export succeeds only with a 10/10/10 stratified selection. It is
considered measured only after the offline report has been generated from that
export. Before treating any generated function as validated:

1. Compile the generated C++ for Android ARM64.
2. Execute it on the physical ARM64 device.
3. Where safe and possible, compare the same vectors to the original bytes on
   native x86 hardware.
4. Report runtime mismatches separately from static backend rejection.

No whole-game feasibility, runtime integration, or equivalence claim follows
from the pilot's acceptance percentage.
