#include "BatchStaticLiftRuntime.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>

#if defined(_M_IX86)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <fstream>

#elif !defined(__aarch64__)
#error Run this harness on native x86 or Android ARM64.
#endif

#if defined(__aarch64__)
BatchLiftStatus spore_lift_01180160(BatchLiftMemory&, BatchLiftState&);
#endif

namespace {

constexpr std::uint32_t kComparedFlags = 0x8c5u;
constexpr std::uint32_t kExpectedValue = 0x87654321u;
constexpr std::uint32_t kArm64TargetAddress = 0x20000000u;
constexpr std::array<std::uint8_t, 12> kExpectedFunctionBytes{{
    0x8b, 0x44, 0x24, 0x04, 0x85, 0xc0, 0x75, 0x01,
    0xc3, 0x8b, 0x00, 0xc3,
}};

std::uint32_t expected_test_flags(std::uint32_t value) {
    std::uint32_t flags = 0x202u;
    std::uint8_t low = static_cast<std::uint8_t>(value);
    low ^= static_cast<std::uint8_t>(low >> 4u);
    low &= 0x0fu;
    if (((0x6996u >> low) & 1u) == 0u) flags |= 0x004u;
    if (value == 0u) flags |= 0x040u;
    if ((value & 0x80000000u) != 0u) flags |= 0x080u;
    return flags & kComparedFlags;
}

#if defined(_M_IX86)

bool read_original_function(const char* executable_path, void** executable_code) {
    std::ifstream input(executable_path, std::ios::binary);
    if (!input) {
        std::fprintf(stderr, "cannot open selected SporeApp.exe\n");
        return false;
    }

    IMAGE_DOS_HEADER dos{};
    input.read(reinterpret_cast<char*>(&dos), sizeof(dos));
    if (!input || dos.e_magic != IMAGE_DOS_SIGNATURE || dos.e_lfanew <= 0) {
        std::fprintf(stderr, "invalid PE DOS header\n");
        return false;
    }

    input.seekg(dos.e_lfanew, std::ios::beg);
    DWORD signature = 0;
    IMAGE_FILE_HEADER file_header{};
    IMAGE_OPTIONAL_HEADER32 optional_header{};
    input.read(reinterpret_cast<char*>(&signature), sizeof(signature));
    input.read(reinterpret_cast<char*>(&file_header), sizeof(file_header));
    input.read(reinterpret_cast<char*>(&optional_header), sizeof(optional_header));
    if (!input || signature != IMAGE_NT_SIGNATURE ||
        file_header.Machine != IMAGE_FILE_MACHINE_I386 ||
        optional_header.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) {
        std::fprintf(stderr, "selected executable is not a PE32 x86 image\n");
        return false;
    }

    const std::uint32_t va = 0x01180160u;
    if (va < optional_header.ImageBase) {
        std::fprintf(stderr, "function VA is below the PE image base\n");
        return false;
    }
    const std::uint32_t rva = va - optional_header.ImageBase;
    input.seekg(
        dos.e_lfanew +
            static_cast<std::streamoff>(sizeof(DWORD) + sizeof(IMAGE_FILE_HEADER)) +
            file_header.SizeOfOptionalHeader,
        std::ios::beg);

    std::uint32_t raw_offset = 0;
    bool found_section = false;
    for (unsigned index = 0; index < file_header.NumberOfSections; ++index) {
        IMAGE_SECTION_HEADER section{};
        input.read(reinterpret_cast<char*>(&section), sizeof(section));
        if (!input) {
            std::fprintf(stderr, "truncated PE section table\n");
            return false;
        }
        const std::uint32_t span =
            section.Misc.VirtualSize > section.SizeOfRawData
                ? section.Misc.VirtualSize
                : section.SizeOfRawData;
        if (section.VirtualAddress <= rva &&
            static_cast<std::uint64_t>(rva - section.VirtualAddress) +
                    kExpectedFunctionBytes.size() <=
                span) {
            const std::uint32_t section_offset = rva - section.VirtualAddress;
            if (section_offset + kExpectedFunctionBytes.size() >
                section.SizeOfRawData) {
                std::fprintf(stderr, "function bytes are not backed by PE raw data\n");
                return false;
            }
            raw_offset = section.PointerToRawData + section_offset;
            found_section = true;
            break;
        }
    }
    if (!found_section) {
        std::fprintf(stderr, "function VA is not in a PE section\n");
        return false;
    }

    std::array<std::uint8_t, kExpectedFunctionBytes.size()> original{};
    input.seekg(raw_offset, std::ios::beg);
    input.read(
        reinterpret_cast<char*>(original.data()),
        static_cast<std::streamsize>(original.size()));
    if (input.gcount() != static_cast<std::streamsize>(original.size()) ||
        original != kExpectedFunctionBytes) {
        std::fprintf(stderr, "PE bytes differ from the verified Ghidra export\n");
        return false;
    }

    void* memory = VirtualAlloc(
        nullptr, original.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == nullptr) {
        std::fprintf(stderr, "VirtualAlloc failed: %lu\n", GetLastError());
        return false;
    }
    std::memcpy(memory, original.data(), original.size());
    DWORD previous_protection = 0;
    if (!VirtualProtect(
            memory, original.size(), PAGE_EXECUTE_READ, &previous_protection) ||
        !FlushInstructionCache(GetCurrentProcess(), memory, original.size())) {
        std::fprintf(stderr, "could not protect original code RX: %lu\n", GetLastError());
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    *executable_code = memory;
    return true;
}

bool run_x86_case(
    const char* label,
    std::uint32_t(__cdecl* function)(std::uint32_t*),
    std::uint32_t* argument,
    std::uint32_t expected_result,
    std::uint32_t expected_flags) {
    std::uint32_t result = 0;
    std::uint32_t flags = 0;
    std::uint32_t esp_before = 0;
    std::uint32_t esp_after_function = 0;
    std::uint32_t esp_after_cleanup = 0;
    std::uint32_t ebx_after = 0;
    std::uint32_t esi_after = 0;
    std::uint32_t edi_after = 0;
    constexpr std::uint32_t kEbx = 0x13572468u;
    constexpr std::uint32_t kEsi = 0x24681357u;
    constexpr std::uint32_t kEdi = 0x55aa33ccu;

    __asm {
        push ebx
        push esi
        push edi
        mov ebx, kEbx
        mov esi, kEsi
        mov edi, kEdi
        mov esp_before, esp
        push argument
        call function
        pushfd
        pop ecx
        mov flags, ecx
        mov result, eax
        mov esp_after_function, esp
        add esp, 4
        mov esp_after_cleanup, esp
        mov ebx_after, ebx
        mov esi_after, esi
        mov edi_after, edi
        pop edi
        pop esi
        pop ebx
    }

    const std::uint32_t entry_esp = esp_before - 8u;
    const std::uint32_t esp_delta = esp_after_function - entry_esp;
    const bool registers_match =
        ebx_after == kEbx && esi_after == kEsi && edi_after == kEdi &&
        esp_after_cleanup == esp_before;
    const bool passed =
        result == expected_result &&
        (flags & kComparedFlags) == expected_flags &&
        esp_delta == 4u &&
        registers_match;
    std::printf(
        "x86 case=%s result=%08x expected=%08x flags=%08x expected_flags=%08x "
        "esp_delta=%08x registers_match=%u memory_unchanged=1 PASS=%u\n",
        label,
        result,
        expected_result,
        flags & kComparedFlags,
        expected_flags,
        esp_delta,
        registers_match ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

int run_x86(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: BatchStaticLiftBranchReference.exe <selected SporeApp.exe>\n");
        return 2;
    }

    void* code = nullptr;
    if (!read_original_function(argv[1], &code)) return 2;
    auto function = reinterpret_cast<std::uint32_t(__cdecl*)(std::uint32_t*)>(code);

    auto* pointed_value = static_cast<std::uint32_t*>(VirtualAlloc(
        nullptr, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE));
    if (pointed_value == nullptr) {
        VirtualFree(code, 0, MEM_RELEASE);
        std::fprintf(stderr, "could not allocate controlled pointer target\n");
        return 2;
    }
    *pointed_value = kExpectedValue;
    if ((reinterpret_cast<std::uintptr_t>(pointed_value) & 0xffu) != 0u ||
        (reinterpret_cast<std::uintptr_t>(pointed_value) & 0x80000000u) != 0u) {
        VirtualFree(pointed_value, 0, MEM_RELEASE);
        VirtualFree(code, 0, MEM_RELEASE);
        std::fprintf(stderr, "pointer target does not match ARM64 test address semantics\n");
        return 2;
    }

    std::size_t failures = 0;
    failures += !run_x86_case("null", function, nullptr, 0u, expected_test_flags(0u));
    failures += !run_x86_case(
        "nonnull",
        function,
        pointed_value,
        kExpectedValue,
        expected_test_flags(static_cast<std::uint32_t>(
            reinterpret_cast<std::uintptr_t>(pointed_value))));
    const bool memory_unchanged = *pointed_value == kExpectedValue;
    std::printf(
        "x86 summary cases=2 failures=%zu memory_unchanged=%u\n",
        failures + !memory_unchanged,
        memory_unchanged ? 1u : 0u);

    VirtualFree(pointed_value, 0, MEM_RELEASE);
    VirtualFree(code, 0, MEM_RELEASE);
    return failures == 0 && memory_unchanged ? 0 : 1;
}

#else

bool run_arm64_case(
    const char* label,
    std::uint32_t argument,
    std::uint32_t expected_result,
    std::uint32_t expected_flags) {
    alignas(4) std::array<std::uint8_t, 4> pointed_bytes{{
        static_cast<std::uint8_t>(kExpectedValue),
        static_cast<std::uint8_t>(kExpectedValue >> 8u),
        static_cast<std::uint8_t>(kExpectedValue >> 16u),
        static_cast<std::uint8_t>(kExpectedValue >> 24u),
    }};
    BatchLiftMemory memory;
    if (argument != 0u &&
        !memory.map_region(
            kArm64TargetAddress,
            pointed_bytes.data(),
            pointed_bytes.size(),
            false)) {
        std::fprintf(stderr, "case=%s could not map controlled read-only target\n", label);
        return false;
    }
    if (!memory.store32(BatchLiftMemory::kEntryEsp + 4u, argument)) {
        std::fprintf(stderr, "case=%s could not set the function argument\n", label);
        return false;
    }

    BatchLiftState state{};
    state.regs[0] = 0xaaaaaaaa;
    state.regs[1] = 0x11111111;
    state.regs[2] = 0x22222222;
    state.regs[3] = 0x33333333;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[5] = 0x55555555;
    state.regs[6] = 0x66666666;
    state.regs[7] = 0x77777777;
    state.eflags = 0x202u;

    const BatchLiftStatus status = spore_lift_01180160(memory, state);
    const std::uint32_t esp_delta =
        state.regs[4] - BatchLiftMemory::kEntryEsp;
    const bool registers_match =
        state.regs[1] == 0x11111111 &&
        state.regs[2] == 0x22222222 &&
        state.regs[3] == 0x33333333 &&
        state.regs[5] == 0x55555555 &&
        state.regs[6] == 0x66666666 &&
        state.regs[7] == 0x77777777 &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        esp_delta == 4u;
    const std::uint32_t pointed_value =
        static_cast<std::uint32_t>(pointed_bytes[0]) |
        (static_cast<std::uint32_t>(pointed_bytes[1]) << 8u) |
        (static_cast<std::uint32_t>(pointed_bytes[2]) << 16u) |
        (static_cast<std::uint32_t>(pointed_bytes[3]) << 24u);
    const bool memory_unchanged =
        argument == 0u || pointed_value == kExpectedValue;
    const std::uint32_t actual_flags = state.eflags & kComparedFlags;
    const bool passed =
        status == BatchLiftStatus::returned &&
        state.regs[0] == expected_result &&
        actual_flags == expected_flags &&
        registers_match &&
        memory_unchanged;
    std::printf(
        "arm64 case=%s result=%08x expected=%08x flags=%08x expected_flags=%08x "
        "esp_delta=%08x registers_match=%u memory_unchanged=%u PASS=%u\n",
        label,
        state.regs[0],
        expected_result,
        actual_flags,
        expected_flags,
        esp_delta,
        registers_match ? 1u : 0u,
        memory_unchanged ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

int run_arm64() {
    std::size_t failures = 0;
    failures += !run_arm64_case("null", 0u, 0u, expected_test_flags(0u));
    failures += !run_arm64_case(
        "nonnull",
        kArm64TargetAddress,
        kExpectedValue,
        expected_test_flags(kArm64TargetAddress));
    std::printf("arm64 summary cases=2 failures=%zu\n", failures);
    return failures == 0 ? 0 : 1;
}

#endif

} // namespace

int main(int argc, char** argv) {
#if defined(_M_IX86)
    return run_x86(argc, argv);
#else
    (void)argc;
    (void)argv;
    return run_arm64();
#endif
}
