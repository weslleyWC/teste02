#!/usr/bin/env python3
"""Read-only inventory of DBPF TGI types, groups, package overlap and one focus type."""

import argparse
import hashlib
import os
import re
import struct
from collections import Counter, defaultdict
from dataclasses import dataclass, field


HEADER_SIZE = 0x60
REFPACK_LABEL = 0xFFFF
UNCOMPRESSED_LABEL = 0
MAX_FOCUS_OUTPUT = 64 * 1024 * 1024


def u16(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def u64(data, offset):
    return struct.unpack_from("<Q", data, offset)[0]


def read_byte(data, cursor):
    if cursor >= len(data):
        raise ValueError("truncated RefPack command stream")
    return data[cursor], cursor + 1


def decompress_refpack(data, expected_size):
    if expected_size > MAX_FOCUS_OUTPUT:
        raise ValueError(
            f"focus resource exceeds {MAX_FOCUS_OUTPUT} byte analysis limit"
        )
    if len(data) < 5 or data[1] != 0xFB:
        raise ValueError("invalid or truncated RefPack header")

    cursor = 2
    if data[0] in (0x10, 0x50):
        if cursor + 3 > len(data):
            raise ValueError("truncated RefPack 24-bit size")
        declared_size = int.from_bytes(data[cursor:cursor + 3], "big")
        cursor += 3
    elif data[0] == 0x90:
        if cursor + 4 > len(data):
            raise ValueError("truncated RefPack 32-bit size")
        declared_size = int.from_bytes(data[cursor:cursor + 4], "big")
        cursor += 4
    else:
        raise ValueError(f"unsupported RefPack header mode 0x{data[0]:02X}")

    if declared_size != expected_size:
        raise ValueError(
            f"RefPack size {declared_size} differs from index {expected_size}"
        )

    output = bytearray()
    command_count = 0
    while len(output) < expected_size:
        command_count += 1
        if command_count > len(data):
            raise ValueError("RefPack command-count limit exceeded")
        control, cursor = read_byte(data, cursor)

        if control >= 0xFC:
            literal_count = control & 0x03
            copy_length = copy_offset = 0
        elif control >= 0xE0:
            literal_count = ((control & 0x1F) << 2) + 4
            copy_length = copy_offset = 0
        elif control >= 0xC0:
            first, cursor = read_byte(data, cursor)
            second, cursor = read_byte(data, cursor)
            third, cursor = read_byte(data, cursor)
            literal_count = control & 0x03
            copy_length = ((control & 0x0C) << 6) + third + 5
            copy_offset = (
                ((control & 0x10) << 12) + (first << 8) + second + 1
            )
        elif control >= 0x80:
            first, cursor = read_byte(data, cursor)
            second, cursor = read_byte(data, cursor)
            literal_count = (first & 0xC0) >> 6
            copy_length = (control & 0x3F) + 4
            copy_offset = ((first & 0x3F) << 8) + second + 1
        else:
            next_byte, cursor = read_byte(data, cursor)
            literal_count = control & 0x03
            copy_length = ((control & 0x1C) >> 2) + 3
            copy_offset = ((control & 0x60) << 3) + next_byte + 1

        if literal_count > len(data) - cursor:
            raise ValueError("RefPack literal run exceeds input")
        if literal_count > expected_size - len(output):
            raise ValueError("RefPack literal run exceeds expected output")
        output.extend(data[cursor:cursor + literal_count])
        cursor += literal_count

        if copy_length > expected_size - len(output):
            raise ValueError("RefPack back-reference exceeds expected output")
        if copy_length:
            if copy_offset == 0 or copy_offset > len(output):
                raise ValueError("invalid RefPack back-reference offset")
            for _ in range(copy_length):
                output.append(output[-copy_offset])

    return bytes(output)


@dataclass
class PackageStats:
    entries: int = 0
    compressed: int = 0
    output_bytes: int = 0
    types: set = field(default_factory=set)
    groups: set = field(default_factory=set)


def parse_package(path, root, state, focus_type):
    package_name = os.path.relpath(path, root).replace("\\", "/")
    file_size = os.path.getsize(path)
    with open(path, "rb") as package:
        header = package.read(HEADER_SIZE)
        if len(header) != HEADER_SIZE or header[:4] != b"DBPF":
            raise ValueError(f"{package_name}: invalid or truncated DBPF header")
        if u32(header, 4) != 3 or u32(header, 8) != 0:
            raise ValueError(f"{package_name}: unsupported DBPF version")

        entry_count = u32(header, 0x24)
        index_size = u32(header, 0x2C)
        index_offset = u64(header, 0x40)
        if index_offset < HEADER_SIZE or index_offset > file_size:
            raise ValueError(f"{package_name}: invalid index offset")
        if index_size > file_size - index_offset:
            raise ValueError(f"{package_name}: index exceeds file bounds")
        package.seek(index_offset)
        index = package.read(index_size)
        if len(index) != index_size or len(index) < 4:
            raise ValueError(f"{package_name}: truncated index")

        flags = u32(index, 0)
        if flags & ~0x7:
            raise ValueError(
                f"{package_name}: unsupported index flags 0x{flags:X}"
            )
        cursor = 4
        shared_type = u32(index, cursor) if flags & 0x1 else None
        cursor += 4 if flags & 0x1 else 0
        shared_group = u32(index, cursor) if flags & 0x2 else None
        cursor += 4 if flags & 0x2 else 0
        if flags & 0x4:
            if cursor + 4 > len(index):
                raise ValueError(f"{package_name}: truncated optional index word")
            cursor += 4

        package_stats = PackageStats()
        focus_payloads = {}
        for entry_index in range(entry_count):
            type_id = shared_type
            if type_id is None:
                type_id = u32(index, cursor)
                cursor += 4
            group_id = shared_group
            if group_id is None:
                group_id = u32(index, cursor)
                cursor += 4
            if cursor + 16 > len(index):
                raise ValueError(
                    f"{package_name}: truncated TGI/resource record {entry_index}"
                )
            instance_id, offset, stored_with_flag, memory_size = (
                struct.unpack_from("<IIII", index, cursor)
            )
            cursor += 16
            compression = u16(index, cursor)
            saved = index[cursor + 2]
            cursor += 4
            stored_size = stored_with_flag & 0x7FFFFFFF

            if saved > 1:
                raise ValueError(
                    f"{package_name}: invalid saved flag at entry {entry_index}"
                )
            if compression not in (UNCOMPRESSED_LABEL, REFPACK_LABEL):
                raise ValueError(
                    f"{package_name}: unsupported compression 0x{compression:04X}"
                )
            if offset < HEADER_SIZE or offset > index_offset:
                raise ValueError(
                    f"{package_name}: invalid resource offset at entry {entry_index}"
                )
            if stored_size > index_offset - offset:
                raise ValueError(
                    f"{package_name}: resource exceeds data area at entry {entry_index}"
                )
            if compression == UNCOMPRESSED_LABEL and stored_size != memory_size:
                raise ValueError(
                    f"{package_name}: raw resource has inconsistent sizes at "
                    f"entry {entry_index}"
                )

            key = (type_id, group_id, instance_id)
            package_stats.entries += 1
            package_stats.compressed += compression == REFPACK_LABEL
            package_stats.output_bytes += memory_size
            package_stats.types.add(type_id)
            package_stats.groups.add(group_id)
            state["types"][type_id] += 1
            state["groups"][group_id] += 1
            state["pairs"][(type_id, group_id)] += 1
            state["type_groups"][type_id].add(group_id)
            state["type_packages"][type_id].add(package_name)
            state["group_packages"][group_id].add(package_name)
            state["type_output_bytes"][type_id] += memory_size
            state["type_compressed"][type_id] += compression == REFPACK_LABEL
            state["tgi_packages"][key].add(package_name)
            state["package_stats"][package_name] = package_stats

            if type_id == focus_type:
                package.seek(offset)
                payload = package.read(stored_size)
                if len(payload) != stored_size:
                    raise ValueError(
                        f"{package_name}: short read at focus entry {entry_index}"
                    )
                decoded = (
                    decompress_refpack(payload, memory_size)
                    if compression == REFPACK_LABEL
                    else payload
                )
                state["focus"][package_name][key] = {
                    "entry_index": entry_index,
                    "stored_size": stored_size,
                    "memory_size": memory_size,
                    "compression": compression,
                    "decoded_sha256": hashlib.sha256(decoded).hexdigest(),
                    "decoded": decoded,
                }

        if cursor != len(index):
            raise ValueError(
                f"{package_name}: index consumed {cursor} of {len(index)} bytes"
            )

    state["package_count"] += 1


def package_role(package_name):
    if package_name.startswith("DataEP1/"):
        return "EP1"
    if package_name.startswith("bp1content/"):
        return "BoosterPack"
    if package_name.startswith("Data/Locale/"):
        return "Locale"
    if package_name.startswith("Data/"):
        return "Base"
    return "Other"


def canonical_focus_records(focus):
    preference = (
        "Data/PatchData.package",
        "Data/Spore_Game.package",
        "DataEP1/Spore_EP1_Data.package",
    )
    records = {}
    for package_name in preference:
        for key, item in focus.get(package_name, {}).items():
            records.setdefault(key, item["decoded"])
    for package_name in sorted(focus, key=str.casefold):
        for key, item in focus[package_name].items():
            records.setdefault(key, item["decoded"])
    return records


def zero_byte_runs(records):
    if not records:
        return []
    runs = []
    start = None
    for offset in range(len(next(iter(records.values())))):
        is_zero = all(payload[offset] == 0 for payload in records.values())
        if is_zero and start is None:
            start = offset
        elif not is_zero and start is not None:
            if offset - start >= 8:
                runs.append((start, offset))
            start = None
    if start is not None:
        end = len(next(iter(records.values())))
        if end - start >= 8:
            runs.append((start, end))
    return runs


def render_report(root, focus_type, state, output_path):
    package_stats = state["package_stats"]
    duplicate_distribution = Counter(
        len(packages)
        for packages in state["tgi_packages"].values()
        if len(packages) > 1
    )
    duplicate_keys = sum(duplicate_distribution.values())
    duplicate_extra_refs = sum(
        (package_count - 1) * count
        for package_count, count in duplicate_distribution.items()
    )
    total_entries = sum(state["types"].values())
    focus = state["focus"]
    canonical_records = canonical_focus_records(focus)
    focus_variants = {
        (key, item["decoded_sha256"]): item["decoded"]
        for entries in focus.values()
        for key, item in entries.items()
    }
    focus_label_counts = Counter()
    focus_label_offsets = Counter()
    focus_payloads_with_labels = 0
    for payload in focus_variants.values():
        text = payload.decode("utf-16le", errors="ignore")
        matches = list(re.finditer(
            r"PLACEHOLDER_[A-Za-z0-9][A-Za-z0-9 _-]{2,}",
            text,
        ))
        focus_payloads_with_labels += bool(matches)
        for match in matches:
            focus_label_counts[match.group().strip()] += 1
            focus_label_offsets[match.start() * 2] += 1
    lines = [
        "# Catálogo estrutural dos recursos DBPF",
        "",
        f"- Raiz analisada: `{os.path.abspath(root)}`",
        f"- Packages: **{state['package_count']}**",
        f"- Entradas indexadas: **{total_entries:,}**",
        f"- Tipos TGI distintos: **{len(state['types'])}**",
        f"- Grupos TGI distintos: **{len(state['groups'])}**",
        f"- Combinações tipo/grupo: **{len(state['pairs'])}**",
        f"- Chaves TGI presentes em mais de um package: **{duplicate_keys:,}** "
        f"({duplicate_extra_refs:,} ocorrências além da primeira)",
        "",
        "## Método e limites",
        "",
        "O script lê somente cabeçalhos e índices DBPF, mais os payloads do tipo "
        f"focal `0x{focus_type:08X}` para contar textos UTF-16LE e comparar "
        "duplicatas decodificadas. Nenhum package é alterado. As contagens de "
        "tipo/grupo são observações estruturais; não são nomes semânticos "
        "confirmados. A amostra focal foi escolhida porque `0xDFAD9F51` coincide "
        "com FNV-1 de `cell` em ASCII minúsculo. Correlações independentes entre "
        "nomes no executável e IDs dos índices apoiam essa convenção; os pares "
        "e limites estão documentados em `BOOT_AND_HASH_FINDINGS.md` e podem "
        "ser reproduzidos com `validate_dbpf_name_hash.py`.",
        "",
        "## Por package",
        "",
        "| Package | Papel | Entradas | Tipos | Grupos | RefPack | Saída descomprimida (bytes) |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for package_name in sorted(package_stats, key=str.casefold):
        stats = package_stats[package_name]
        lines.append(
            f"| `{package_name}` | {package_role(package_name)} | "
            f"{stats.entries:,} | {len(stats.types)} | {len(stats.groups)} | "
            f"{stats.compressed:,} | {stats.output_bytes:,} |"
        )

    lines.extend([
        "",
        "## Todos os tipos TGI",
        "",
        "Ordenados por número de entradas; IDs são apresentados em hexadecimal.",
        "",
        "| Type ID | Entradas | Grupos | Packages | RefPack | Saída descomprimida (bytes) |",
        "|---|---:|---:|---:|---:|---:|",
    ])
    for type_id, count in state["types"].most_common():
        lines.append(
            f"| `0x{type_id:08X}` | {count:,} | "
            f"{len(state['type_groups'][type_id])} | "
            f"{len(state['type_packages'][type_id])} | "
            f"{state['type_compressed'][type_id]:,} | "
            f"{state['type_output_bytes'][type_id]:,} |"
        )

    lines.extend([
        "",
        "## Grupos mais frequentes",
        "",
        "| Group ID | Entradas | Tipos | Packages |",
        "|---|---:|---:|---:|",
    ])
    for group_id, count in state["groups"].most_common(40):
        type_ids = {
            type_id for type_id, known_group in state["pairs"]
            if known_group == group_id
        }
        lines.append(
            f"| `0x{group_id:08X}` | {count:,} | {len(type_ids)} | "
            f"{len(state['group_packages'][group_id])} |"
        )

    lines.extend([
        "",
        "## Combinações tipo/grupo mais frequentes",
        "",
        "| Type ID | Group ID | Entradas |",
        "|---|---|---:|",
    ])
    for (type_id, group_id), count in state["pairs"].most_common(40):
        lines.append(
            f"| `0x{type_id:08X}` | `0x{group_id:08X}` | {count:,} |"
        )

    focus_keys = set().union(*(set(entries) for entries in focus.values()))
    lines.extend([
        "",
        f"## Tipo focal `0x{focus_type:08X}`",
        "",
        f"- Ocorrências no índice: **{sum(map(len, focus.values()))}**.",
        f"- TGIs distintos: **{len(focus_keys)}**.",
        f"- Versões distintas de payload (TGI + SHA-256): "
        f"**{len(focus_variants)}**.",
        "- Os payloads decodificados têm estes tamanhos: "
        + ", ".join(
            f"`{size}` bytes"
            for size in sorted({
                item["memory_size"]
                for entries in focus.values()
                for item in entries.values()
            })
        ) + ".",
        f"- Entre as versões distintas, **{focus_payloads_with_labels}** "
        f"contêm uma ou mais strings `PLACEHOLDER_...` UTF-16LE "
        f"({len(focus_label_counts)} rótulos distintos).",
        "- Rótulos mais frequentes: "
        + (
            ", ".join(
                f"`{name}` ({count})"
                for name, count in focus_label_counts.most_common(12)
            )
            if focus_label_counts
            else "nenhum encontrado"
        )
        + ".",
        "- Inícios dessas strings no payload: "
        + (
            ", ".join(
                f"offset `{offset}` ({count})"
                for offset, count in sorted(focus_label_offsets.items())
            )
            if focus_label_offsets
            else "nenhum observado"
        )
        + ". O tamanho fixo e os offsets são observações; limites/campos "
        "do formato ainda não foram identificados.",
        "",
        "| Package | Entradas | TGI distintos |",
        "|---|---:|---:|",
    ])
    for package_name in sorted(focus, key=str.casefold):
        lines.append(
            f"| `{package_name}` | {len(focus[package_name])} | "
            f"{len(focus[package_name])} |"
        )

    membership_counts = Counter()
    for key in focus_keys:
        membership = tuple(sorted(
            name for name, entries in focus.items() if key in entries
        ))
        membership_counts[membership] += 1
    lines.extend([
        "",
        "### Sobreposição por TGI do tipo focal",
        "",
        "| Presente em | TGIs |",
        "|---|---:|",
    ])
    for membership, count in membership_counts.most_common():
        lines.append(
            f"| {', '.join(f'`{name}`' for name in membership)} | {count} |"
        )

    base = focus.get("Data/Spore_Game.package", {})
    patch = focus.get("Data/PatchData.package", {})
    ep1 = focus.get("DataEP1/Spore_EP1_Data.package", {})
    shared_base_patch = base.keys() & patch.keys()
    base_patch_same = sum(
        base[key]["decoded_sha256"] == patch[key]["decoded_sha256"]
        for key in shared_base_patch
    )
    patch_ep1_common = patch.keys() & ep1.keys()
    patch_ep1_same = sum(
        patch[key]["decoded_sha256"] == ep1[key]["decoded_sha256"]
        for key in patch_ep1_common
    )
    changed = [
        key for key in shared_base_patch
        if base[key]["decoded_sha256"] != patch[key]["decoded_sha256"]
    ]
    lines.extend([
        "",
        f"- Jogo base vs. patch: **{len(shared_base_patch)}** TGIs em comum; "
        f"**{base_patch_same}** payloads descomprimidos idênticos.",
        f"- Patch vs. EP1: **{len(patch_ep1_common)}** TGIs em comum; "
        f"**{patch_ep1_same}** payloads descomprimidos idênticos.",
    ])
    if changed:
        lines.extend([
            "- Diferenças observadas entre base e patch:",
            "",
            "| TGI | SHA-256 base | SHA-256 patch |",
            "|---|---|---|",
        ])
        for type_id, group_id, instance_id in sorted(changed):
            lines.append(
                f"| `0x{type_id:08X}:0x{group_id:08X}:0x{instance_id:08X}` | "
                f"`{base[(type_id, group_id, instance_id)]['decoded_sha256']}` | "
                f"`{patch[(type_id, group_id, instance_id)]['decoded_sha256']}` |"
            )

    lines.extend([
        "",
        "### Perfil estrutural dos payloads (sem atribuir campos)",
        "",
        f"- Amostra: um payload por TGI, **{len(canonical_records)}** no total; "
        "quando há versões sobrepostas, a escolha é patch, jogo base e depois "
        "EP1. Todos os offsets abaixo são relativos ao início do payload "
        "descomprimido.",
        "- Sequências de pelo menos 8 bytes zerados em todos os payloads: "
        + (
            ", ".join(
                f"`0x{start:03X}–0x{end - 1:03X}` ({end - start} bytes)"
                for start, end in zero_byte_runs(canonical_records)
            )
            or "nenhuma"
        )
        + ".",
        "- O primeiro word de 32 bits tem "
        f"{len({u32(payload, 0) for payload in canonical_records.values()})} "
        "valores distintos; é apresentado somente como dado bruto, sem "
        "interpretá-lo como hash ou campo de versão.",
        "- Os words nos offsets `0x0E4`, `0x0EC`, `0x0F8`, `0x0FC`, `0x100`, "
        "`0x120`, `0x134`, `0x15C`, `0x180`, `0x188`, `0x304` e `0x308` "
        "produzem valores numéricos finitos plausíveis quando lidos como "
        "IEEE-754 little-endian. São **candidatos a float**, não tipos "
        "confirmados. Em `0x304` os valores vão de `0.085` a `5.0`; em "
        "`0x308`, de `0.1` a `5.0`.",
        "- Rótulos UTF-16LE `PLACEHOLDER_...` no prefixo: "
        + (
            ", ".join(
                f"offset `0x{offset:03X}`: {count} payloads"
                for offset, count in sorted(
                    Counter(
                        match.start() * 2
                        for payload in canonical_records.values()
                        for match in re.finditer(
                            r"PLACEHOLDER_[A-Za-z0-9][A-Za-z0-9 _-]{2,}",
                            payload.decode("utf-16le", errors="ignore"),
                        )
                    ).items()
                )
            )
            or "nenhum encontrado"
        )
        + ".",
        "",
        "| Offset u32 | Valores distintos | Zero | Valores não zero mais frequentes (hex: contagem) |",
        "|---:|---:|---:|---|",
    ])
    word_count = len(canonical_records)
    if canonical_records:
        payload_size = len(next(iter(canonical_records.values())))
        for offset in range(0, payload_size - 3, 4):
            values = [
                u32(payload, offset)
                for payload in canonical_records.values()
            ]
            unique_count = len(set(values))
            zero_count = values.count(0)
            if unique_count <= 1 or zero_count == word_count:
                continue
            nonzero_values = Counter(value for value in values if value)
            common_values = ", ".join(
                f"`0x{value:08X}`: {count}"
                for value, count in nonzero_values.most_common(3)
            )
            lines.append(
                f"| `0x{offset:03X}` | {unique_count} | "
                f"{zero_count}/{word_count} | {common_values} |"
            )

    lines.extend([
        "",
        "## Sobreposição entre packages",
        "",
        "| Número de packages com o mesmo TGI | TGIs |",
        "|---:|---:|",
    ])
    for package_count, count in sorted(duplicate_distribution.items()):
        lines.append(f"| {package_count} | {count:,} |")

    lines.extend([
        "",
        "## Leitura dos resultados",
        "",
        "- `Spore_Audio1.package` e `Spore_Audio2.package` concentram o tipo "
        "`0x01A527DB` e o grupo `0x021407EE`; a associação a áudio é **inferida "
        "pelo nome do package e pela distribuição**, não provada só pelo ID.",
        "- O tipo focal `0xDFAD9F51` é fortemente associado a nomes `cell` "
        "pelas correlações FNV-1 com strings do executável, pelos IDs de "
        "instância e pelos rótulos de payload. Isso apoia a interpretação como "
        "dados relacionados à etapa celular; a estrutura do formato e a "
        "classificação exata ainda não foram confirmadas.",
        "- TGIs repetidos mostram que há conteúdo compartilhado ou versões "
        "sobrepostas; não estabelecem sozinhos a ordem de montagem nem qual "
        "package prevalece em runtime.",
        "",
        "## Reprodução",
        "",
        "```powershell",
        "python .\\catalog_dbpf_resources.py "
        "--root ..\\SPOREFILES "
        "--output .\\DBPF_RESOURCE_CATALOG.md",
        "```",
        "",
    ])
    with open(output_path, "w", encoding="utf-8", newline="\n") as report:
        report.write("\n".join(lines))
    print(
        f"wrote {output_path}: {state['package_count']} packages, "
        f"{total_entries} entries, {len(state['types'])} types"
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="SPOREFILES root")
    parser.add_argument("--output", required=True, help="Markdown report path")
    parser.add_argument(
        "--focus-type",
        default="0xDFAD9F51",
        help="TGI type to inspect and compare (default: candidate cell type)",
    )
    args = parser.parse_args()
    root = os.path.abspath(args.root)
    focus_type = int(args.focus_type, 0)
    if not os.path.isdir(root):
        raise SystemExit(f"package root does not exist: {root}")

    state = {
        "package_count": 0,
        "types": Counter(),
        "groups": Counter(),
        "pairs": Counter(),
        "type_groups": defaultdict(set),
        "type_packages": defaultdict(set),
        "group_packages": defaultdict(set),
        "type_output_bytes": Counter(),
        "type_compressed": Counter(),
        "tgi_packages": defaultdict(set),
        "package_stats": {},
        "focus": defaultdict(dict),
    }

    paths = []
    for directory, _, filenames in os.walk(root):
        for filename in filenames:
            if filename.lower().endswith(".package"):
                paths.append(os.path.join(directory, filename))
    paths.sort(key=str.casefold)
    if not paths:
        raise SystemExit(f"no .package files found under {root}")

    for path in paths:
        parse_package(path, root, state, focus_type)
    render_report(root, focus_type, state, os.path.abspath(args.output))


if __name__ == "__main__":
    main()
