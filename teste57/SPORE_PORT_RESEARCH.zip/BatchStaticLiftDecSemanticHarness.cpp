#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "BatchStaticLiftRuntime.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>

#if !defined(_M_IX86) && !defined(__aarch64__)
#error Run this semantic harness on native x86 or physical Android ARM64.
#endif

BatchLiftStatus spore_lift_00401000(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00402000(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00403000(BatchLiftMemory&, BatchLiftState&);

namespace {

constexpr std::uint32_t kComparedFlags = 0x8d5u;

struct NativeResult {
    std::uint32_t eax;
    std::uint32_t eflags;
};

NativeResult oracle_dec(
    std::uint32_t input,
    unsigned width,
    bool initial_carry) {
    const std::uint32_t mask = width == 32u
        ? 0xffffffffu
        : ((std::uint32_t{1} << width) - 1u);
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    const std::uint32_t old_value = input & mask;
    const std::uint32_t new_value = (old_value - 1u) & mask;
    NativeResult result{};
    result.eax = (input & ~mask) | new_value;
    result.eflags = initial_carry ? 0x203u : 0x202u;
    std::uint8_t parity = static_cast<std::uint8_t>(new_value);
    parity ^= static_cast<std::uint8_t>(parity >> 4u);
    parity &= 0x0fu;
    if (((0x6996u >> parity) & 1u) == 0u) result.eflags |= 0x004u;
    if ((old_value & 0x0fu) == 0u) result.eflags |= 0x010u;
    if (new_value == 0u) result.eflags |= 0x040u;
    if ((new_value & sign) != 0u) result.eflags |= 0x080u;
    if (old_value == sign) result.eflags |= 0x800u;
    return result;
}

#if defined(_M_IX86)
NativeResult native_dec32(std::uint32_t input_value, bool initial_carry) {
    NativeResult result{};
    const std::uint32_t carry = initial_carry ? 1u : 0u;
    __asm {
        mov eax, input_value
        mov ecx, carry
        test ecx, ecx
        jz clear_carry
        stc
        jmp do_dec
    clear_carry:
        clc
    do_dec:
        dec eax
        pushfd
        pop ecx
        lea edx, result
        mov [edx], eax
        mov [edx+4], ecx
    }
    return result;
}

NativeResult native_dec16(std::uint32_t input_value, bool initial_carry) {
    NativeResult result{};
    const std::uint32_t carry = initial_carry ? 1u : 0u;
    __asm {
        mov eax, input_value
        mov ecx, carry
        test ecx, ecx
        jz clear_carry
        stc
        jmp do_dec
    clear_carry:
        clc
    do_dec:
        dec ax
        pushfd
        pop ecx
        lea edx, result
        mov [edx], eax
        mov [edx+4], ecx
    }
    return result;
}

NativeResult native_dec8(std::uint32_t input_value, bool initial_carry) {
    NativeResult result{};
    const std::uint32_t carry = initial_carry ? 1u : 0u;
    __asm {
        mov eax, input_value
        mov ecx, carry
        test ecx, ecx
        jz clear_carry
        stc
        jmp do_dec
    clear_carry:
        clc
    do_dec:
        dec al
        pushfd
        pop ecx
        lea edx, result
        mov [edx], eax
        mov [edx+4], ecx
    }
    return result;
}
#else
NativeResult native_dec32(std::uint32_t input_value, bool initial_carry) {
    return oracle_dec(input_value, 32u, initial_carry);
}

NativeResult native_dec16(std::uint32_t input_value, bool initial_carry) {
    return oracle_dec(input_value, 16u, initial_carry);
}

NativeResult native_dec8(std::uint32_t input_value, bool initial_carry) {
    return oracle_dec(input_value, 8u, initial_carry);
}
#endif

using LiftFunction = BatchLiftStatus (*)(BatchLiftMemory&, BatchLiftState&);

bool run_case(
    LiftFunction lift,
    NativeResult (*native)(std::uint32_t, bool),
    const char* label,
    std::uint32_t initial_eax,
    bool initial_carry) {
    BatchLiftMemory memory;
    BatchLiftState state{};
    state.regs[0] = initial_eax;
    state.regs[1] = 0x11111111u;
    state.regs[2] = 0x22222222u;
    state.regs[3] = 0x33333333u;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.regs[5] = 0x55555555u;
    state.regs[6] = 0x66666666u;
    state.regs[7] = 0x77777777u;
    state.eflags = initial_carry ? 0x203u : 0x202u;

    const NativeResult expected = native(initial_eax, initial_carry);
    const BatchLiftStatus status = lift(memory, state);
    const bool flags_match =
        (state.eflags & kComparedFlags) == (expected.eflags & kComparedFlags);
    const bool registers_match =
        state.regs[0] == expected.eax &&
        state.regs[1] == 0x11111111u &&
        state.regs[2] == 0x22222222u &&
        state.regs[3] == 0x33333333u &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u &&
        state.regs[5] == 0x55555555u &&
        state.regs[6] == 0x66666666u &&
        state.regs[7] == 0x77777777u;
    const bool passed =
        status == BatchLiftStatus::returned &&
        flags_match &&
        registers_match &&
        state.eip == BatchLiftMemory::kReturnSentinel;
    std::printf(
        "%s case=%s initial_eax=%08x carry_in=%u result=%08x expected=%08x "
        "flags=%08x expected_flags=%08x flags_match=%u registers_match=%u PASS=%u\n",
#if defined(_M_IX86)
        "x86",
#else
        "arm64",
#endif
        label,
        initial_eax,
        initial_carry ? 1u : 0u,
        state.regs[0],
        expected.eax,
        state.eflags,
        expected.eflags,
        flags_match ? 1u : 0u,
        registers_match ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

template <typename Function>
std::size_t test_width(
    LiftFunction lift,
    NativeResult (*native)(std::uint32_t, bool),
    const char* width_name,
    std::uint32_t preserved_upper_bits,
    Function values,
    std::size_t value_count) {
    std::size_t failures = 0;
    for (std::size_t index = 0; index < value_count; ++index) {
        const std::uint32_t low = values[index];
        const std::uint32_t initial = preserved_upper_bits | low;
        for (unsigned carry = 0; carry <= 1; ++carry) {
            char label[32]{};
            std::snprintf(
                label,
                sizeof(label),
                "dec%s_%02zu_cf%u",
                width_name,
                index,
                carry);
            failures += !run_case(
                lift, native, label, initial, carry != 0);
        }
    }
    return failures;
}

} // namespace

int main() {
    constexpr std::array<std::uint32_t, 7> values8{{
        0x00u, 0x01u, 0x02u, 0x7fu, 0x80u, 0xfeu, 0xffu,
    }};
    constexpr std::array<std::uint32_t, 7> values16{{
        0x0000u, 0x0001u, 0x0002u, 0x7fffu, 0x8000u, 0xfffeu, 0xffffu,
    }};
    constexpr std::array<std::uint32_t, 7> values32{{
        0x00000000u, 0x00000001u, 0x00000002u, 0x7fffffffu,
        0x80000000u, 0xfffffffeu, 0xffffffffu,
    }};
    std::size_t failures = 0;
    failures += test_width(
        spore_lift_00401000, native_dec32, "32", 0, values32, values32.size());
    failures += test_width(
        spore_lift_00402000, native_dec16, "16", 0xa5c30000u, values16, values16.size());
    failures += test_width(
        spore_lift_00403000, native_dec8, "8", 0xa5c35a00u, values8, values8.size());
#if defined(_M_IX86)
    std::printf("x86 semantic summary cases=42 failures=%zu\n", failures);
#else
    std::printf("arm64 semantic summary cases=42 failures=%zu\n", failures);
#endif
    return failures == 0 ? 0 : 1;
}
