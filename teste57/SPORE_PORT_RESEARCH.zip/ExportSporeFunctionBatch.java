// Ghidra 12.2 Script Manager export for deterministic pilots and full exports.
// The script reads existing Ghidra analysis and does not trigger re-analysis.
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressIterator;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.symbol.Reference;

public class ExportSporeFunctionBatch extends GhidraScript {
    private static final String EXPECTED_SHA256 =
        "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b";
    private static final String OUTPUT_DIRECTORY = "C:\\SporeAnalysis";
    private static final String OUTPUT_NAME_30 = "spore_batch_pilot_30.json";
    private static final String OUTPUT_NAME_100 = "spore_batch_pilot_100.json";
    private static final String OUTPUT_NAME_300 = "spore_batch_pilot_300.json";
    private static final int BASELINE_FUNCTIONS_PER_STRATUM = 10;
    private static final int MAX_INSTRUCTIONS_PER_FUNCTION = 2_048;
    private static final int MAX_REFERENCES_PER_FUNCTION = 4_096;
    private static final int MAX_REACHABLE_FUNCTIONS = 50_000;
    private static final long MAX_INPUT_BYTES = 256L * 1024L * 1024L;
    private static final long MAX_RUNTIME_MILLIS = 600_000L;
    private static final long MAX_FULL_EXPORT_RUNTIME_MILLIS = 3_600_000L;

    private long deadline;

    @Override
    protected void run() throws Exception {
        if (currentProgram == null) {
            throw new IllegalStateException("Open the selected Spore program in Ghidra first.");
        }
        File source = askFile(
            "Select the exact SporeApp.exe imported into the open Ghidra program",
            "Select"
        );
        if (source == null || !source.isFile() || source.length() > MAX_INPUT_BYTES) {
            throw new IllegalArgumentException("Select a regular SporeApp.exe under 256 MiB.");
        }
        boolean confirmed = askYesNo(
            "Confirm source identity",
            "Is this the exact original SporeApp.exe used to create the currently open Ghidra program?"
        );
        if (!confirmed) {
            throw new IllegalStateException("Source identity was not confirmed; no batch was exported.");
        }
        SelectionPlan plan = SelectionPlan.forSize(
            askInt("Pilot size", "Choose 30, 100, 300, or 0 for all functions.")
        );
        long runtimeMillis = plan.all ? MAX_FULL_EXPORT_RUNTIME_MILLIS : MAX_RUNTIME_MILLIS;
        deadline = System.currentTimeMillis() + runtimeMillis;
        monitor.initialize(runtimeMillis);
        String sourceHash = sha256(source);
        if (!EXPECTED_SHA256.equalsIgnoreCase(sourceHash)) {
            throw new IllegalArgumentException(
                "Selected SporeApp.exe SHA-256 does not match the approved Phase 4 build: "
                    + sourceHash
            );
        }

        File outputDirectory = new File(OUTPUT_DIRECTORY);
        File output = new File(outputDirectory, plan.outputName);
        if (!outputDirectory.isDirectory()) {
            throw new IllegalStateException("Output directory does not exist: " + OUTPUT_DIRECTORY);
        }
        if (output.exists()) {
            throw new IllegalStateException(
                "Output already exists; preserve it and move it before rerunning: "
                    + output.getCanonicalPath()
            );
        }

        Map<Long, Function> functionsByEntry = collectFunctions();
        List<Candidate> selected = plan.all
            ? selectAll(functionsByEntry)
            : selectPilot(functionsByEntry, plan);
        Reachability reachability = findReachableFunctions(functionsByEntry);
        Path temporaryPath = Files.createTempFile(
            outputDirectory.toPath(), output.getName() + ".", ".tmp"
        );
        boolean published = false;
        try {
            writeManifest(
                temporaryPath.toFile(), source, sourceHash, confirmed,
                selected, reachability, plan
            );
            checkDeadline();
            Files.move(temporaryPath, output.toPath());
            published = true;
        } finally {
            if (!published) {
                Files.deleteIfExists(temporaryPath);
            }
        }
        println("Exported exactly " + selected.size() + " functions to "
            + output.getCanonicalPath());
        if (!plan.all) {
            println("Selection: " + plan.smallCount + " small (1-32 body bytes), "
                + plan.mediumCount + " medium (33-128), " + plan.branchCount
                + " conditional-branch functions (at most 512 body bytes).");
        }
        println("Static reachability: " + reachability.visited.size()
            + " functions visited; complete=" + reachability.complete
            + "; roots=" + reachability.roots.size());
        println("Selected executable SHA-256: " + sourceHash);
        println("No target code was executed and no whole-program analysis was triggered.");
    }

    private Map<Long, Function> collectFunctions() throws Exception {
        Map<Long, Function> result = new HashMap<>();
        FunctionIterator iterator = currentProgram.getFunctionManager().getFunctions(true);
        while (iterator.hasNext()) {
            checkDeadline();
            Function function = iterator.next();
            if (!function.isExternal() && !function.isThunk()) {
                result.put(function.getEntryPoint().getOffset(), function);
            }
        }
        return result;
    }

    private List<Candidate> selectPilot(
        Map<Long, Function> all,
        SelectionPlan plan) throws Exception {
        List<Candidate> small = new ArrayList<>();
        List<Candidate> medium = new ArrayList<>();
        List<Candidate> possibleBranches = new ArrayList<>();
        for (Function function : all.values()) {
            checkDeadline();
            long size = function.getBody().getNumAddresses();
            Candidate candidate = new Candidate(function, size);
            if (size >= 1 && size <= 32) {
                small.add(candidate);
            } else if (size >= 33 && size <= 128) {
                medium.add(candidate);
            }
            if (size >= 1 && size <= 512) {
                possibleBranches.add(candidate);
            }
        }
        Comparator<Candidate> order = Comparator
            .comparingLong((Candidate candidate) -> candidate.size)
            .thenComparingLong(candidate -> candidate.function.getEntryPoint().getOffset());
        small.sort(order);
        medium.sort(order);
        possibleBranches.sort(order);

        List<Candidate> smallSelected = new ArrayList<>();
        List<Candidate> mediumSelected = new ArrayList<>();
        List<Candidate> branchSelected = new ArrayList<>();
        Set<Long> selectedAddresses = new HashSet<>();
        addStratum(
            smallSelected, selectedAddresses, small, "small",
            BASELINE_FUNCTIONS_PER_STRATUM
        );
        addStratum(
            mediumSelected, selectedAddresses, medium, "medium",
            BASELINE_FUNCTIONS_PER_STRATUM
        );
        addConditionalStratum(
            branchSelected, selectedAddresses, possibleBranches,
            BASELINE_FUNCTIONS_PER_STRATUM
        );

        addStratum(smallSelected, selectedAddresses, small, "small", plan.smallCount);
        addStratum(mediumSelected, selectedAddresses, medium, "medium", plan.mediumCount);
        addConditionalStratum(
            branchSelected, selectedAddresses, possibleBranches, plan.branchCount
        );
        if (smallSelected.size() != plan.smallCount
                || mediumSelected.size() != plan.mediumCount
                || branchSelected.size() != plan.branchCount) {
            throw new IllegalStateException(
                "Could not satisfy deterministic pilot strata "
                    + plan.smallCount + "/" + plan.mediumCount + "/" + plan.branchCount
                    + " from current Ghidra data."
            );
        }
        List<Candidate> selected = new ArrayList<>(plan.totalCount);
        selected.addAll(smallSelected);
        selected.addAll(mediumSelected);
        selected.addAll(branchSelected);
        return selected;
    }

    private List<Candidate> selectAll(Map<Long, Function> all) {
        List<Candidate> selected = new ArrayList<>();
        List<Long> addresses = new ArrayList<>(all.keySet());
        addresses.sort(Long::compareTo);
        for (Long address : addresses) {
            Candidate candidate = new Candidate(all.get(address),
                all.get(address).getBody().getNumAddresses());
            candidate.stratum = "all";
            selected.add(candidate);
        }
        return selected;
    }

    private void addStratum(
        List<Candidate> stratumSelected,
        Set<Long> selectedAddresses,
        List<Candidate> candidates,
        String stratum,
        int targetCount) {
        for (Candidate candidate : candidates) {
            if (stratumSelected.size() >= targetCount) {
                break;
            }
            long address = candidate.function.getEntryPoint().getOffset();
            if (selectedAddresses.add(address)) {
                candidate.stratum = stratum;
                stratumSelected.add(candidate);
            }
        }
    }

    private void addConditionalStratum(
        List<Candidate> stratumSelected,
        Set<Long> selectedAddresses,
        List<Candidate> candidates,
        int targetCount) throws Exception {
        for (Candidate candidate : candidates) {
            checkDeadline();
            if (stratumSelected.size() >= targetCount) {
                break;
            }
            long entry = candidate.function.getEntryPoint().getOffset();
            if (selectedAddresses.contains(entry) || !hasConditionalBranch(candidate.function)) {
                continue;
            }
            candidate.stratum = "conditional_branch";
            stratumSelected.add(candidate);
            selectedAddresses.add(entry);
        }
    }

    private boolean hasConditionalBranch(Function function) throws Exception {
        InstructionIterator instructions = currentProgram.getListing()
            .getInstructions(function.getBody(), true);
        while (instructions.hasNext()) {
            checkDeadline();
            ghidra.program.model.symbol.FlowType flow = instructions.next().getFlowType();
            if (flow.isJump() && flow.isConditional()) {
                return true;
            }
        }
        return false;
    }

    private Reachability findReachableFunctions(Map<Long, Function> all) throws Exception {
        Reachability result = new Reachability();
        ArrayDeque<Function> pending = new ArrayDeque<>();
        TreeMap<Long, Function> roots = new TreeMap<>();
        AddressIterator entries = currentProgram.getSymbolTable().getExternalEntryPointIterator();
        while (entries.hasNext()) {
            checkDeadline();
            Address address = entries.next();
            Function root = currentProgram.getFunctionManager().getFunctionContaining(address);
            if (root != null && !root.isExternal() && !root.isThunk()) {
                long offset = root.getEntryPoint().getOffset();
                roots.put(offset, root);
                if (roots.size() >= MAX_REACHABLE_FUNCTIONS) {
                    result.complete = false;
                    break;
                }
            }
        }
        for (Map.Entry<Long, Function> root : roots.entrySet()) {
            result.roots.add(root.getKey());
            result.visited.add(root.getKey());
            pending.addLast(root.getValue());
        }
        if (roots.isEmpty()) {
            result.complete = false;
            return result;
        }
        while (!pending.isEmpty()) {
            checkDeadline();
            if (result.visited.size() >= MAX_REACHABLE_FUNCTIONS) {
                result.complete = false;
                break;
            }
            Function caller = pending.removeFirst();
            TreeMap<Long, Function> callees = new TreeMap<>();
            InstructionIterator instructions = currentProgram.getListing()
                .getInstructions(caller.getBody(), true);
            while (instructions.hasNext()) {
                checkDeadline();
                Instruction instruction = instructions.next();
                Reference[] refs = currentProgram.getReferenceManager()
                    .getReferencesFrom(instruction.getAddress());
                for (Reference reference : refs) {
                    if (!reference.getReferenceType().isCall()
                            || reference.getReferenceType().isComputed()) {
                        continue;
                    }
                    Function callee = currentProgram.getFunctionManager()
                        .getFunctionContaining(reference.getToAddress());
                    if (callee == null || callee.isExternal() || callee.isThunk()) {
                        continue;
                    }
                    long target = callee.getEntryPoint().getOffset();
                    Function indexedCallee = all.get(target);
                    if (indexedCallee != null) {
                        callees.put(target, indexedCallee);
                    }
                }
            }
            for (Map.Entry<Long, Function> callee : callees.entrySet()) {
                if (result.visited.add(callee.getKey())) {
                    pending.addLast(callee.getValue());
                }
            }
        }
        result.complete = pending.isEmpty();
        return result;
    }

    private void writeManifest(
        File output,
        File source,
        String sourceHash,
        boolean confirmed,
        List<Candidate> selected,
        Reachability reachability,
        SelectionPlan plan) throws Exception {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(output), StandardCharsets.UTF_8))) {
            writer.write("{\n");
            field(writer, "schema", "spore-ghidra-function-batch-v1", true);
            field(writer, "program_name", currentProgram.getName(), true);
            field(writer, "project_file", currentProgram.getDomainFile().getName(), true);
            field(writer, "language_id", currentProgram.getLanguageID().toString(), true);
            field(writer, "compiler_spec_id",
            currentProgram.getCompilerSpec().getCompilerSpecID().toString(), true);
            field(writer, "image_base", address(currentProgram.getImageBase()), true);
            field(writer, "selected_source_path", source.getCanonicalPath(), true);
            field(writer, "selected_source_sha256", sourceHash, true);
            boolField(writer, "selected_source_is_phase4_build", true);
            boolField(writer, "user_confirmed_source_for_open_program", confirmed);
            writer.write("  \"pilot_size\": " + selected.size() + ",\n");
            if (plan.all) {
                writer.write("  \"export_mode\": \"all\",\n");
                writer.write("  \"selection_counts\": {\"all\": " + selected.size() + "},\n");
            } else {
                writer.write("  \"selection_counts\": {\"small\": " + plan.smallCount
                    + ", \"medium\": " + plan.mediumCount
                    + ", \"conditional_branch\": " + plan.branchCount + "},\n");
            }
            field(writer, "reachability_basis",
            "Transitive direct call references from Ghidra external entry-point symbols.", true);
            writer.write("  \"reachability_complete\": " + reachability.complete + ",\n");
            writer.write("  \"reachability_visited_function_count\": "
                + reachability.visited.size() + ",\n");
            writer.write("  \"reachability_root_addresses\": ");
            addressArray(writer, reachability.roots);
            writer.write(",\n  \"reachability_limitations\": [");
            writer.write(quote("Indirect calls, dynamically resolved targets and unmodeled roots are not traversed."));
            if (reachability.roots.isEmpty()) {
                writer.write(", ");
                writer.write(quote("Ghidra had no defined function at an external entry point."));
            }
            if (!reachability.complete) {
                writer.write(", ");
                writer.write(quote("Traversal stopped at the 50,000-function cap."));
            }
            writer.write("],\n  \"functions_truncated\": false,\n  \"functions\": [\n");
            for (int i = 0; i < selected.size(); i++) {
                checkDeadline();
                Candidate candidate = selected.get(i);
                if (i > 0) {
                    writer.write(",\n");
                }
                writer.write("    {\"selection_stratum\": ");
                writer.write(quote(candidate.stratum));
                writer.write(", \"reachable_from_program_entry\": ");
                if (reachability.visited.contains(candidate.function.getEntryPoint().getOffset())) {
                    writer.write("true");
                } else if (reachability.complete) {
                    writer.write("false");
                } else {
                    writer.write("null");
                }
                writer.write(", \"reachability_kind\": ");
                writer.write(quote("direct-call graph from Ghidra external entry points"));
                writer.write(", \"function\": ");
                StringBuilder functionJson = new StringBuilder(16 * 1024);
                appendFunction(functionJson, candidate.function);
                writer.write(functionJson.toString());
                writer.write("}");
            }
            writer.write("\n  ]\n}\n");
        }
    }

    private void appendFunction(StringBuilder json, Function function) throws Exception {
        json.append("{");
        property(json, "entry", address(function.getEntryPoint()), true);
        property(json, "name", function.getName(), true);
        property(json, "calling_convention", function.getCallingConventionName(), true);
        property(json, "body_min", address(function.getBody().getMinAddress()), true);
        property(json, "body_max", address(function.getBody().getMaxAddress()), true);
        json.append("\"body_address_count\": ")
            .append(function.getBody().getNumAddresses()).append(", ");
        json.append("\"instructions\": [");
        InstructionIterator iterator = currentProgram.getListing()
            .getInstructions(function.getBody(), true);
        int count = 0;
        int references = 0;
        boolean instructionsTruncated = false;
        boolean referencesTruncated = false;
        StringBuilder instructionJson = new StringBuilder();
        while (iterator.hasNext()) {
            checkDeadline();
            if (count >= MAX_INSTRUCTIONS_PER_FUNCTION) {
                instructionsTruncated = true;
                break;
            }
            Instruction instruction = iterator.next();
            if (count++ > 0) {
                instructionJson.append(", ");
            }
            instructionJson.append("{\"address\": ").append(quote(address(instruction.getAddress())));
            instructionJson.append(", \"bytes\": ").append(quote(bytesHex(instruction.getBytes())));
            instructionJson.append(", \"length\": ").append(instruction.getLength());
            instructionJson.append(", \"mnemonic\": ").append(quote(instruction.getMnemonicString()));
            instructionJson.append(", \"operands\": [");
            for (int operand = 0; operand < instruction.getNumOperands(); operand++) {
                if (operand > 0) {
                    instructionJson.append(", ");
                }
                instructionJson.append(quote(instruction.getDefaultOperandRepresentation(operand)));
            }
            instructionJson.append("], \"flow\": ").append(quote(instruction.getFlowType().toString()));
            instructionJson.append(", \"flows_to\": [");
            Address[] flows = instruction.getFlows();
            for (int flow = 0; flow < flows.length; flow++) {
                if (flow > 0) {
                    instructionJson.append(", ");
                }
                instructionJson.append(quote(address(flows[flow])));
            }
            instructionJson.append("], \"references\": [");
            Reference[] instructionRefs = currentProgram.getReferenceManager()
                .getReferencesFrom(instruction.getAddress());
            int emittedRefs = 0;
            for (Reference reference : instructionRefs) {
                if (references >= MAX_REFERENCES_PER_FUNCTION) {
                    referencesTruncated = true;
                    break;
                }
                if (emittedRefs++ > 0) {
                    instructionJson.append(", ");
                }
                instructionJson.append("{\"to\": ").append(quote(address(reference.getToAddress())));
                instructionJson.append(", \"type\": ")
                    .append(quote(reference.getReferenceType().toString()));
                instructionJson.append(", \"is_call\": ")
                    .append(reference.getReferenceType().isCall()).append("}");
                references++;
            }
            instructionJson.append("]}");
        }
        json.append(instructionJson);
        json.append("], \"instruction_count_exported\": ").append(count);
        json.append(", \"instructions_truncated\": ").append(instructionsTruncated);
        json.append(", \"references_truncated\": ").append(referencesTruncated).append("}");
    }

    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        try (InputStream input = new BufferedInputStream(new FileInputStream(file))) {
            int read;
            while ((read = input.read(buffer)) != -1) {
                checkDeadline();
                total += read;
                if (total > MAX_INPUT_BYTES) {
                    throw new IllegalArgumentException("Input exceeds the configured size limit.");
                }
                digest.update(buffer, 0, read);
            }
        }
        StringBuilder value = new StringBuilder(64);
        for (byte item : digest.digest()) {
            value.append(String.format("%02x", item & 0xff));
        }
        return value.toString();
    }

    private void checkDeadline() throws Exception {
        monitor.checkCancelled();
        if (System.currentTimeMillis() > deadline) {
            throw new IllegalStateException("Batch export exceeded its configured time limit.");
        }
    }

    private void field(BufferedWriter writer, String key, String value, boolean comma)
        throws Exception {
        writer.write("  ");
        writer.write(quote(key));
        writer.write(": ");
        writer.write(quote(value));
        writer.write(comma ? ",\n" : "\n");
    }

    private void boolField(BufferedWriter writer, String key, boolean value) throws Exception {
        writer.write("  ");
        writer.write(quote(key));
        writer.write(": ");
        writer.write(Boolean.toString(value));
        writer.write(",\n");
    }

    private void property(StringBuilder json, String key, String value, boolean comma) {
        json.append(quote(key)).append(": ").append(quote(value));
        json.append(comma ? ", " : " ");
    }

    private void addressArray(BufferedWriter writer, Set<Long> addresses) throws Exception {
        writer.write("[");
        int count = 0;
        for (Long offset : addresses) {
            if (count++ > 0) {
                writer.write(", ");
            }
            writer.write(quote(String.format("0x%08x", offset)));
        }
        writer.write("]");
    }

    private String address(Address value) {
        return value == null ? null : "0x" + value.toString();
    }

    private String bytesHex(byte[] bytes) {
        StringBuilder value = new StringBuilder(bytes.length * 2);
        for (byte item : bytes) {
            value.append(String.format("%02x", item & 0xff));
        }
        return value.toString();
    }

    private String quote(String value) {
        if (value == null) {
            return "null";
        }
        StringBuilder result = new StringBuilder(value.length() + 2);
        result.append('"');
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '"': result.append("\\\""); break;
                case '\\': result.append("\\\\"); break;
                case '\b': result.append("\\b"); break;
                case '\f': result.append("\\f"); break;
                case '\n': result.append("\\n"); break;
                case '\r': result.append("\\r"); break;
                case '\t': result.append("\\t"); break;
                default:
                    if (character < 0x20) {
                        result.append(String.format("\\u%04x", (int) character));
                    } else {
                        result.append(character);
                    }
            }
        }
        return result.append('"').toString();
    }

    private static final class SelectionPlan {
        private final int smallCount;
        private final int mediumCount;
        private final int branchCount;
        private final int totalCount;
        private final String outputName;
        private final boolean all;

        private SelectionPlan(
            int smallCount,
            int mediumCount,
            int branchCount,
            String outputName) {
            this.smallCount = smallCount;
            this.mediumCount = mediumCount;
            this.branchCount = branchCount;
            this.totalCount = smallCount + mediumCount + branchCount;
            this.outputName = outputName;
            this.all = false;
        }

        private SelectionPlan(String outputName) {
            this.smallCount = 0;
            this.mediumCount = 0;
            this.branchCount = 0;
            this.totalCount = 0;
            this.outputName = outputName;
            this.all = true;
        }

        private static SelectionPlan forSize(int size) {
            if (size == 0) {
                return new SelectionPlan("spore_batch_all.json");
            }
            if (size == 30) {
                return new SelectionPlan(10, 10, 10, OUTPUT_NAME_30);
            }
            if (size == 100) {
                return new SelectionPlan(30, 30, 40, OUTPUT_NAME_100);
            }
            if (size == 300) {
                return new SelectionPlan(90, 90, 120, OUTPUT_NAME_300);
            }
            throw new IllegalArgumentException("Pilot size must be 30, 100, 300, or 0 for all.");
        }
    }

    private static final class Candidate {
        private final Function function;
        private final long size;
        private String stratum;

        private Candidate(Function function, long size) {
            this.function = function;
            this.size = size;
        }
    }

    private static final class Reachability {
        private final Set<Long> visited = new HashSet<>();
        private final Set<Long> roots = new TreeSet<>();
        private boolean complete = true;
    }

}
