#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <limits>
#include <string>
#include <vector>

#if !defined(_M_IX86)
#error This reference harness must be compiled as a native 32-bit x86 process.
#endif

namespace {

constexpr std::size_t kFunctionOffset = 0x21830;
constexpr std::size_t kFunctionSize = 122;
constexpr char kExpectedBytes[] =
    "558bec83ec108b450c2b450899b90c000000f7f98945fc837dfc007e56"
    "8b55088955f88b45fcd1f88945f48b4df46bc90c034df8894df88b55f8"
    "8b45108b0a3b081bd2f7da0fb6c285c0741f8b4df883c10c894df88b55"
    "f88955088b45f483c0018b4dfc2bc8894dfceb068b55f48955fceba48b"
    "45088be55dc3";

struct Record {
    std::uint32_t key;
    std::uint32_t payload_a;
    std::uint32_t payload_b;
};

static_assert(sizeof(Record) == 12, "Spore record layout must be 12 bytes.");

using OriginalFunction =
    std::uint32_t* (__cdecl*)(std::uint32_t*, std::int32_t, const std::uint32_t*);

int hex_digit(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    return -1;
}

bool load_original_function(const char* executable_path, void** code) {
    if (std::strlen(kExpectedBytes) != kFunctionSize * 2u) {
        std::fprintf(stderr, "internal expected-byte string has an invalid size\n");
        return false;
    }

    std::ifstream input(executable_path, std::ios::binary);
    if (!input) {
        std::fprintf(stderr, "cannot open selected SporeApp.exe\n");
        return false;
    }
    input.seekg(static_cast<std::streamoff>(kFunctionOffset), std::ios::beg);
    std::array<std::uint8_t, kFunctionSize> original_bytes{};
    input.read(reinterpret_cast<char*>(original_bytes.data()), original_bytes.size());
    if (input.gcount() != static_cast<std::streamsize>(original_bytes.size())) {
        std::fprintf(stderr, "failed to read the complete function byte range\n");
        return false;
    }

    for (std::size_t i = 0; i < original_bytes.size(); ++i) {
        const int high = hex_digit(kExpectedBytes[i * 2u]);
        const int low = hex_digit(kExpectedBytes[i * 2u + 1u]);
        if (high < 0 || low < 0 ||
            original_bytes[i] != static_cast<std::uint8_t>((high << 4) | low)) {
            std::fprintf(stderr, "function bytes differ from the verified export at +0x%zx\n", i);
            return false;
        }
    }

    void* memory = VirtualAlloc(
        nullptr, original_bytes.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == nullptr) {
        std::fprintf(stderr, "VirtualAlloc failed: %lu\n", GetLastError());
        return false;
    }
    std::memcpy(memory, original_bytes.data(), original_bytes.size());

    DWORD old_protection = 0;
    if (!VirtualProtect(memory, original_bytes.size(), PAGE_EXECUTE_READ, &old_protection)) {
        std::fprintf(stderr, "VirtualProtect failed: %lu\n", GetLastError());
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    if (!FlushInstructionCache(GetCurrentProcess(), memory, original_bytes.size())) {
        std::fprintf(stderr, "FlushInstructionCache failed: %lu\n", GetLastError());
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    *code = memory;
    return true;
}

std::size_t oracle(const Record* records, std::size_t count, std::uint32_t key) {
    std::size_t low = 0;
    std::size_t high = count;
    while (low < high) {
        const std::size_t middle = low + ((high - low) >> 1u);
        if (records[middle].key < key) {
            low = middle + 1u;
        } else {
            high = middle;
        }
    }
    return low;
}

bool run_case(OriginalFunction function, Record* records, std::size_t count,
              std::uint32_t key, const char* label) {
    const std::vector<Record> before(records, records + count);
    const auto end_address = reinterpret_cast<std::uintptr_t>(records) + count * sizeof(Record);
    const auto* result = function(
        reinterpret_cast<std::uint32_t*>(records),
        static_cast<std::int32_t>(end_address),
        &key);

    const auto begin_address = reinterpret_cast<std::uintptr_t>(records);
    const auto result_address = reinterpret_cast<std::uintptr_t>(result);
    bool valid_pointer = result_address >= begin_address;
    std::size_t actual = std::numeric_limits<std::size_t>::max();
    if (valid_pointer) {
        const std::uintptr_t byte_offset = result_address - begin_address;
        valid_pointer = byte_offset % sizeof(Record) == 0 &&
            byte_offset / sizeof(Record) <= count;
        if (valid_pointer) {
            actual = static_cast<std::size_t>(byte_offset / sizeof(Record));
        }
    }

    const std::size_t expected = oracle(records, count, key);
    const bool memory_unchanged =
        count == 0 || std::memcmp(before.data(), records, count * sizeof(Record)) == 0;
    const bool passed = valid_pointer && actual == expected && memory_unchanged;
    std::printf(
        "x86 %-18s key=0x%08x actual=%zu expected=%zu memory=%s %s\n",
        label,
        key,
        actual,
        expected,
        memory_unchanged ? "unchanged" : "changed",
        passed ? "PASS" : "FAIL");
    return passed;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: FirstNativeX86Reference.exe <selected SporeApp.exe>\n");
        return 2;
    }

    SYSTEM_INFO system_info{};
    GetNativeSystemInfo(&system_info);
    if (system_info.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_AMD64 &&
        system_info.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_INTEL) {
        std::fprintf(stderr, "host processor is not x86/x86-64\n");
        return 2;
    }

    void* code = nullptr;
    if (!load_original_function(argv[1], &code)) {
        return 2;
    }
    const auto function = reinterpret_cast<OriginalFunction>(code);

    std::array<Record, 8> records{{
        {0x00000000u, 10u, 20u},
        {0x00000008u, 11u, 21u},
        {0x00000008u, 12u, 22u},
        {0x00000010u, 13u, 23u},
        {0x00000020u, 14u, 24u},
        {0x7fffffffu, 15u, 25u},
        {0x80000000u, 16u, 26u},
        {0xffffffffu, 17u, 27u},
    }};
    constexpr std::array<std::uint32_t, 12> keys{{
        0x00000000u, 0x00000001u, 0x00000007u, 0x00000008u,
        0x00000009u, 0x00000010u, 0x00000018u, 0x00000020u,
        0x7fffffffu, 0x80000000u, 0xfffffffeu, 0xffffffffu,
    }};

    std::size_t failures = 0;
    for (std::uint32_t key : keys) {
        failures += !run_case(function, records.data(), records.size(), key, "populated");
    }
    Record empty_sentinel{};
    failures += !run_case(function, &empty_sentinel, 0, 0u, "empty");

    Record singleton{0x80000000u, 1u, 2u};
    failures += !run_case(function, &singleton, 1, 0x7fffffffu, "singleton-before");
    failures += !run_case(function, &singleton, 1, 0x80000000u, "singleton-equal");
    failures += !run_case(function, &singleton, 1, 0xffffffffu, "singleton-after");

    std::vector<Record> stress_records;
    stress_records.reserve(256);
    std::uint32_t value = 0;
    for (std::size_t i = 0; i < 256; ++i) {
        value += static_cast<std::uint32_t>((i % 7u) + 1u);
        stress_records.push_back({value, static_cast<std::uint32_t>(i), ~static_cast<std::uint32_t>(i)});
    }
    for (std::uint32_t key = 0; key < 0x00000400u; key += 3u) {
        failures += !run_case(
            function, stress_records.data(), stress_records.size(), key, "stress");
    }

    std::printf("x86 summary failures=%zu\n", failures);
    VirtualFree(code, 0, MEM_RELEASE);
    return failures == 0 ? 0 : 1;
}
