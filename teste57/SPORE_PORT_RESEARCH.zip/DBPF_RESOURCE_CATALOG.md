# Catálogo estrutural dos recursos DBPF

- Raiz analisada: `C:\Program Files (x86)\steam\steamapps\common\Spore\SPOREFILES`
- Packages: **23**
- Entradas indexadas: **154,576**
- Tipos TGI distintos: **90**
- Grupos TGI distintos: **605**
- Combinações tipo/grupo: **769**
- Chaves TGI presentes em mais de um package: **29,769** (30,821 ocorrências além da primeira)

## Método e limites

O script lê somente cabeçalhos e índices DBPF, mais os payloads do tipo focal `0xDFAD9F51` para contar textos UTF-16LE e comparar duplicatas decodificadas. Nenhum package é alterado. As contagens de tipo/grupo são observações estruturais; não são nomes semânticos confirmados. A amostra focal foi escolhida porque `0xDFAD9F51` coincide com FNV-1 de `cell` em ASCII minúsculo. Correlações independentes entre nomes no executável e IDs dos índices apoiam essa convenção; os pares e limites estão documentados em `BOOT_AND_HASH_FINDINGS.md` e podem ser reproduzidos com `validate_dbpf_name_hash.py`.

## Por package

| Package | Papel | Entradas | Tipos | Grupos | RefPack | Saída descomprimida (bytes) |
|---|---|---:|---:|---:|---:|---:|
| `bp1content/BoosterPack_01.package` | BoosterPack | 6,002 | 13 | 34 | 1,268 | 136,144,905 |
| `Data/BP2_Data.package` | Base | 184 | 7 | 17 | 129 | 9,185,575 |
| `Data/Locale/en-gb/NameGeneration.package` | Locale | 14 | 2 | 1 | 14 | 87,955 |
| `Data/Locale/en-gb/Text.package` | Locale | 194 | 1 | 1 | 185 | 1,697,180 |
| `Data/Locale/en-gb/UI.package` | Locale | 3 | 2 | 1 | 3 | 3,948 |
| `Data/Locale/en-us/NameGeneration.package` | Locale | 14 | 2 | 1 | 14 | 87,955 |
| `Data/Locale/en-us/Text.package` | Locale | 200 | 1 | 1 | 189 | 1,720,447 |
| `Data/Locale/en-us/UI.package` | Locale | 1 | 1 | 1 | 1 | 370 |
| `Data/Locale/ru-ru/NameGeneration.package` | Locale | 14 | 2 | 1 | 14 | 252,049 |
| `Data/Locale/ru-ru/Text.package` | Locale | 196 | 1 | 1 | 185 | 2,550,430 |
| `Data/Locale/ru-ru/UI.package` | Locale | 3 | 2 | 1 | 3 | 4,283 |
| `Data/PatchData.package` | Base | 25,535 | 58 | 442 | 21,823 | 236,698,257 |
| `Data/Spore_Audio1.package` | Base | 17,651 | 12 | 1 | 1,921 | 1,054,758,897 |
| `Data/Spore_Audio2.package` | Base | 12,111 | 11 | 3 | 6,183 | 1,069,703,451 |
| `Data/Spore_Content.package` | Base | 17,119 | 10 | 57 | 15,459 | 2,330,984,360 |
| `Data/Spore_Game.package` | Base | 11,529 | 39 | 365 | 9,314 | 201,360,477 |
| `Data/Spore_Graphics.package` | Base | 24,707 | 25 | 152 | 15,211 | 1,741,799,004 |
| `Data/Spore_Pack_03.package` | Base | 266 | 5 | 15 | 238 | 14,252,925 |
| `DataEP1/Spore_EP1_Content_01.package` | EP1 | 5,807 | 10 | 30 | 5,416 | 848,443,356 |
| `DataEP1/Spore_EP1_Content_02.package` | EP1 | 10,801 | 8 | 12 | 10,286 | 1,907,247,948 |
| `DataEP1/Spore_EP1_Data.package` | EP1 | 22,204 | 54 | 211 | 9,527 | 830,875,599 |
| `DataEP1/Spore_EP1_Locale_01.package` | EP1 | 17 | 1 | 1 | 11 | 3,931,604 |
| `DataEP1/Spore_EP1_Locale_02.package` | EP1 | 4 | 1 | 1 | 4 | 901,311 |

## Todos os tipos TGI

Ordenados por número de entradas; IDs são apresentados em hexadecimal.

| Type ID | Entradas | Grupos | Packages | RefPack | Saída descomprimida (bytes) |
|---|---:|---:|---:|---:|---:|
| `0x01A527DB` | 33,781 | 1 | 5 | 3,148 | 2,567,221,741 |
| `0x00B1B104` | 30,925 | 442 | 15 | 26,741 | 34,277,174 |
| `0x02B9F662` | 19,631 | 2 | 4 | 15,154 | 2,032,504 |
| `0x2F7D0004` | 14,711 | 91 | 10 | 107 | 256,395,958 |
| `0x2F4E681B` | 13,572 | 36 | 9 | 13,389 | 1,675,074,648 |
| `0x00E6BCE5` | 11,041 | 33 | 4 | 11,041 | 2,136,985,290 |
| `0x2F4E681C` | 5,931 | 21 | 3 | 5,931 | 2,805,006,364 |
| `0xEE17C6AD` | 5,022 | 1 | 4 | 5,022 | 300,983,784 |
| `0x5CAA5E28` | 3,282 | 6 | 5 | 566 | 1,026,108 |
| `0x01C135DA` | 2,756 | 3 | 5 | 2,756 | 153,484,110 |
| `0x1A99B06B` | 2,625 | 7 | 5 | 2,625 | 11,782,959 |
| `0x030BDEE3` | 2,598 | 7 | 4 | 2,598 | 381,070 |
| `0x02D5C9AF` | 2,590 | 7 | 4 | 2,590 | 1,369,344 |
| `0x0F43029A` | 1,365 | 4 | 2 | 1,365 | 7,740,489 |
| `0x250FE9A2` | 748 | 3 | 3 | 748 | 16,512,622 |
| `0x02FAC0B6` | 590 | 1 | 3 | 559 | 5,968,057 |
| `0xDFAD9F51` | 489 | 1 | 3 | 489 | 389,244 |
| `0x4B9EF6DC` | 376 | 1 | 3 | 376 | 26,728 |
| `0x617715D9` | 318 | 1 | 4 | 315 | 3,173,879 |
| `0x024A0E52` | 160 | 9 | 8 | 159 | 5,718,783 |
| `0x02393756` | 153 | 1 | 3 | 153 | 842,386 |
| `0x497767B9` | 126 | 2 | 4 | 125 | 501,678 |
| `0x055ADA24` | 124 | 2 | 3 | 124 | 6,223,638 |
| `0xD92AF091` | 115 | 1 | 3 | 109 | 12,792 |
| `0x0472329B` | 97 | 2 | 3 | 97 | 335,540 |
| `0x022D2C83` | 97 | 1 | 4 | 95 | 4,103,480 |
| `0x03E421ED` | 96 | 1 | 3 | 91 | 7,890,048 |
| `0x03F51892` | 95 | 1 | 4 | 41 | 9,045 |
| `0x2B978C46` | 94 | 1 | 2 | 94 | 657,830 |
| `0x3C7E0F63` | 86 | 1 | 2 | 86 | 75,112 |
| `0x03055F61` | 81 | 1 | 3 | 81 | 90,036 |
| `0x366A930D` | 69 | 1 | 1 | 69 | 1,272,329 |
| `0x06EFC6AA` | 68 | 1 | 5 | 17 | 17,602,592 |
| `0xDA141C1B` | 64 | 1 | 3 | 55 | 86,828 |
| `0x0497925E` | 63 | 1 | 3 | 31 | 3,472 |
| `0xF2B924B3` | 52 | 1 | 2 | 40 | 11,870 |
| `0xEA5118B0` | 42 | 9 | 4 | 42 | 59,603,621 |
| `0x01EEF63A` | 42 | 1 | 3 | 1 | 142,023,680 |
| `0x25DF0112` | 39 | 1 | 3 | 39 | 880,272 |
| `0x9B8E862F` | 37 | 1 | 3 | 20 | 3,376 |
| `0x02D5C9B0` | 37 | 1 | 3 | 0 | 296 |
| `0x02C9EFF2` | 36 | 1 | 2 | 31 | 4,170 |
| `0x0469A3F7` | 36 | 3 | 3 | 36 | 65,407,679 |
| `0x047B8300` | 32 | 1 | 2 | 32 | 683,552 |
| `0x3D97A8E4` | 26 | 1 | 2 | 26 | 110,394 |
| `0xF9C3D770` | 22 | 1 | 3 | 3 | 1,044 |
| `0x8C042499` | 20 | 1 | 2 | 2 | 592 |
| `0x448AE7E2` | 18 | 1 | 2 | 18 | 157,280 |
| `0x04805684` | 16 | 1 | 2 | 16 | 3,145,728 |
| `0xFD60F0C1` | 16 | 1 | 1 | 0 | 448 |
| `0xCF6C21B8` | 14 | 1 | 2 | 14 | 330,682 |
| `0x5C74D18B` | 10 | 1 | 2 | 10 | 655,360 |
| `0x0330A65E` | 10 | 1 | 1 | 10 | 1,277,904 |
| `0x03E421E9` | 10 | 1 | 1 | 10 | 2,490,608 |
| `0x027C5CEF` | 10 | 1 | 2 | 8 | 47,340,040 |
| `0x0248F226` | 9 | 3 | 6 | 9 | 71,271 |
| `0x029E333B` | 9 | 1 | 2 | 8 | 3,261 |
| `0x24682294` | 8 | 1 | 2 | 8 | 168,724 |
| `0x042C9CBB` | 6 | 1 | 1 | 5 | 272,430 |
| `0x12952634` | 4 | 1 | 4 | 0 | 1,032 |
| `0x4AEB6BC6` | 4 | 4 | 4 | 4 | 755,039 |
| `0x617715C4` | 4 | 2 | 3 | 4 | 13,358 |
| `0x02CB4F2F` | 4 | 1 | 2 | 4 | 32,736 |
| `0x476A98C7` | 4 | 1 | 2 | 4 | 89,724 |
| `0x376840D7` | 4 | 1 | 2 | 0 | 39,040,460 |
| `0x2F7D0006` | 4 | 1 | 1 | 4 | 33,716 |
| `0x2B6CAB5F` | 3 | 1 | 3 | 3 | 1,110 |
| `0x00000000` | 3 | 1 | 3 | 2 | 198,444 |
| `0x2A3CE5B7` | 3 | 1 | 3 | 3 | 816 |
| `0x7C19AA7A` | 3 | 3 | 3 | 3 | 13,397 |
| `0x05BAD11C` | 3 | 1 | 3 | 3 | 398,752 |
| `0x2B7DF427` | 3 | 1 | 1 | 0 | 45 |
| `0x03E421EC` | 3 | 1 | 1 | 1 | 1,118,268 |
| `0x37979F71` | 3 | 1 | 2 | 3 | 9,538 |
| `0x03E421EF` | 3 | 1 | 1 | 3 | 884,796 |
| `0x1F639D98` | 2 | 1 | 2 | 2 | 59,392 |
| `0x433FB70C` | 2 | 1 | 2 | 2 | 1,360 |
| `0x612B3191` | 2 | 1 | 2 | 2 | 400 |
| `0x2399BE55` | 2 | 1 | 2 | 2 | 23,138 |
| `0x438F6347` | 2 | 1 | 2 | 2 | 5,334 |
| `0xDBA35AE2` | 2 | 1 | 2 | 2 | 856 |
| `0x02523258` | 2 | 1 | 2 | 2 | 2,342 |
| `0x754BE343` | 2 | 1 | 2 | 0 | 16 |
| `0x3C77532E` | 2 | 2 | 2 | 2 | 72,391 |
| `0x065266B7` | 2 | 1 | 2 | 2 | 553 |
| `0x2081B4F5` | 1 | 1 | 1 | 1 | 421 |
| `0x1E99B626` | 1 | 1 | 1 | 0 | 44 |
| `0x3F9C28B5` | 1 | 1 | 1 | 1 | 16,446 |
| `0x191C3C61` | 1 | 1 | 1 | 1 | 12,132 |
| `0x14885D1C` | 1 | 1 | 1 | 1 | 4,286 |

## Grupos mais frequentes

| Group ID | Entradas | Tipos | Packages |
|---|---:|---:|---:|
| `0x021407EE` | 54,179 | 17 | 5 |
| `0x00000000` | 13,225 | 30 | 8 |
| `0x40636200` | 5,488 | 8 | 6 |
| `0x40626200` | 5,157 | 7 | 5 |
| `0x40606000` | 4,285 | 3 | 7 |
| `0x40646200` | 2,498 | 8 | 6 |
| `0x40626000` | 2,328 | 2 | 6 |
| `0x40646000` | 2,160 | 2 | 3 |
| `0x406A2100` | 2,095 | 1 | 6 |
| `0x40666200` | 2,059 | 7 | 5 |
| `0x406A0200` | 1,881 | 1 | 4 |
| `0x40637100` | 1,547 | 3 | 3 |
| `0x40637E00` | 1,522 | 2 | 3 |
| `0x40606100` | 1,398 | 2 | 5 |
| `0x061AD433` | 1,165 | 1 | 3 |
| `0x40464200` | 1,045 | 2 | 3 |
| `0x8A7BE0C0` | 966 | 3 | 2 |
| `0x65928944` | 965 | 1 | 2 |
| `0xD87454E6` | 940 | 1 | 1 |
| `0x40636000` | 900 | 2 | 4 |
| `0xCA14DE92` | 899 | 1 | 3 |
| `0x31A44893` | 796 | 1 | 3 |
| `0x30608F0B` | 741 | 1 | 3 |
| `0x40656200` | 734 | 8 | 5 |
| `0x40632900` | 679 | 1 | 2 |
| `0x40632901` | 679 | 1 | 2 |
| `0x40632902` | 679 | 1 | 2 |
| `0x40636201` | 679 | 1 | 2 |
| `0x40636203` | 679 | 1 | 2 |
| `0x40636202` | 679 | 1 | 2 |
| `0x40637E01` | 679 | 1 | 2 |
| `0x40637E03` | 679 | 1 | 2 |
| `0x40637E02` | 679 | 1 | 2 |
| `0x02E9C426` | 672 | 1 | 3 |
| `0x9430ADD7` | 657 | 1 | 3 |
| `0x011C0BDE` | 646 | 2 | 4 |
| `0x40686000` | 638 | 2 | 4 |
| `0x40667100` | 636 | 3 | 5 |
| `0x41606100` | 595 | 1 | 2 |
| `0x02FABF01` | 590 | 1 | 3 |

## Combinações tipo/grupo mais frequentes

| Type ID | Group ID | Entradas |
|---|---|---:|
| `0x01A527DB` | `0x021407EE` | 33,781 |
| `0x02B9F662` | `0x021407EE` | 19,630 |
| `0x2F4E681B` | `0x00000000` | 5,727 |
| `0xEE17C6AD` | `0x00000000` | 5,022 |
| `0x2F4E681B` | `0x40606000` | 2,104 |
| `0x2F4E681B` | `0x406A2100` | 2,095 |
| `0x01C135DA` | `0x40606000` | 2,057 |
| `0x00B1B104` | `0x406A0200` | 1,881 |
| `0x00B1B104` | `0x40626000` | 1,223 |
| `0x00B1B104` | `0x061AD433` | 1,165 |
| `0x5CAA5E28` | `0x40626000` | 1,105 |
| `0x00B1B104` | `0x40646000` | 1,080 |
| `0x5CAA5E28` | `0x40646000` | 1,080 |
| `0x00B1B104` | `0x00000000` | 1,044 |
| `0x2F7D0004` | `0x65928944` | 965 |
| `0x2F7D0004` | `0x8A7BE0C0` | 961 |
| `0x00B1B104` | `0xD87454E6` | 940 |
| `0x030BDEE3` | `0x40626200` | 938 |
| `0x1A99B06B` | `0x40626200` | 938 |
| `0x2F7D0004` | `0x40626200` | 938 |
| `0x02D5C9AF` | `0x40626200` | 937 |
| `0x0F43029A` | `0x40626200` | 937 |
| `0x2F7D0004` | `0xCA14DE92` | 899 |
| `0x00B1B104` | `0x40636200` | 846 |
| `0x00B1B104` | `0x40637E00` | 843 |
| `0x030BDEE3` | `0x40636200` | 825 |
| `0x1A99B06B` | `0x40636200` | 825 |
| `0x2F7D0004` | `0x40636200` | 825 |
| `0x02D5C9AF` | `0x40636200` | 821 |
| `0x2F7D0004` | `0x31A44893` | 796 |
| `0x00B1B104` | `0x30608F0B` | 741 |
| `0x2F4E681B` | `0x40606100` | 702 |
| `0x01C135DA` | `0x40606100` | 696 |
| `0x2F4E681C` | `0x40632900` | 679 |
| `0x2F4E681C` | `0x40632901` | 679 |
| `0x2F4E681C` | `0x40632902` | 679 |
| `0x00E6BCE5` | `0x40636201` | 679 |
| `0x00E6BCE5` | `0x40636200` | 679 |
| `0x00E6BCE5` | `0x40636203` | 679 |
| `0x00E6BCE5` | `0x40636202` | 679 |

## Tipo focal `0xDFAD9F51`

- Ocorrências no índice: **489**.
- TGIs distintos: **224**.
- Versões distintas de payload (TGI + SHA-256): **225**.
- Os payloads decodificados têm estes tamanhos: `796` bytes.
- Entre as versões distintas, **70** contêm uma ou mais strings `PLACEHOLDER_...` UTF-16LE (27 rótulos distintos).
- Rótulos mais frequentes: `PLACEHOLDER_Goldy` (7), `PLACEHOLDER_Jawhead` (4), `PLACEHOLDER_Ducky` (4), `PLACEHOLDER_Chomper` (4), `PLACEHOLDER_Minno` (4), `PLACEHOLDER_Squiggly` (3), `PLACEHOLDER_Booster` (3), `PLACEHOLDER_Megamouth` (3), `PLACEHOLDER_Nosey` (3), `PLACEHOLDER_Stabber` (3), `PLACEHOLDER_Pokey` (3), `PLACEHOLDER_Puffish` (3).
- Inícios dessas strings no payload: offset `2` (4), offset `4` (66). O tamanho fixo e os offsets são observações; limites/campos do formato ainda não foram identificados.

| Package | Entradas | TGI distintos |
|---|---:|---:|
| `Data/PatchData.package` | 223 | 223 |
| `Data/Spore_Game.package` | 223 | 223 |
| `DataEP1/Spore_EP1_Data.package` | 43 | 43 |

### Sobreposição por TGI do tipo focal

| Presente em | TGIs |
|---|---:|
| `Data/PatchData.package`, `Data/Spore_Game.package` | 181 |
| `Data/PatchData.package`, `Data/Spore_Game.package`, `DataEP1/Spore_EP1_Data.package` | 42 |
| `DataEP1/Spore_EP1_Data.package` | 1 |

- Jogo base vs. patch: **223** TGIs em comum; **222** payloads descomprimidos idênticos.
- Patch vs. EP1: **42** TGIs em comum; **42** payloads descomprimidos idênticos.
- Diferenças observadas entre base e patch:

| TGI | SHA-256 base | SHA-256 patch |
|---|---|---|
| `0xDFAD9F51:0x00000000:0xCBCD1287` | `4494cb02b16c2b4df63686e0779e3e4275ec31f3d0c9a6b62a8c1b7ddcce60c6` | `f12d98c0f59af6d4d58174016f1e04d709647480310103341193df9b0fa76542` |

### Perfil estrutural dos payloads (sem atribuir campos)

- Amostra: um payload por TGI, **224** no total; quando há versões sobrepostas, a escolha é patch, jogo base e depois EP1. Todos os offsets abaixo são relativos ao início do payload descomprimido.
- Sequências de pelo menos 8 bytes zerados em todos os payloads: `0x037–0x0A3` (109 bytes), `0x118–0x11F` (8 bytes), `0x1A5–0x1AD` (9 bytes), `0x1BC–0x1D3` (24 bytes), `0x227–0x22F` (9 bytes), `0x250–0x261` (18 bytes), `0x270–0x289` (26 bytes), `0x28C–0x29D` (18 bytes), `0x2A5–0x2AF` (11 bytes), `0x2B1–0x2BD` (13 bytes), `0x2DA–0x2E3` (10 bytes).
- O primeiro word de 32 bits tem 166 valores distintos; é apresentado somente como dado bruto, sem interpretá-lo como hash ou campo de versão.
- Os words nos offsets `0x0E4`, `0x0EC`, `0x0F8`, `0x0FC`, `0x100`, `0x120`, `0x134`, `0x15C`, `0x180`, `0x188`, `0x304` e `0x308` produzem valores numéricos finitos plausíveis quando lidos como IEEE-754 little-endian. São **candidatos a float**, não tipos confirmados. Em `0x304` os valores vão de `0.085` a `5.0`; em `0x308`, de `0.1` a `5.0`.
- Rótulos UTF-16LE `PLACEHOLDER_...` no prefixo: offset `0x002`: 4 payloads, offset `0x004`: 66 payloads.

| Offset u32 | Valores distintos | Zero | Valores não zero mais frequentes (hex: contagem) |
|---:|---:|---:|---|
| `0x000` | 166 | 1/224 | `0x1386506B`: 7, `0x5D699F3B`: 5, `0x56507D07`: 5 |
| `0x004` | 2 | 154/224 | `0x004C0050`: 70 |
| `0x008` | 2 | 154/224 | `0x00430041`: 70 |
| `0x00C` | 2 | 154/224 | `0x00480045`: 70 |
| `0x010` | 2 | 154/224 | `0x004C004F`: 70 |
| `0x014` | 2 | 154/224 | `0x00450044`: 70 |
| `0x018` | 2 | 154/224 | `0x005F0052`: 70 |
| `0x01C` | 25 | 154/224 | `0x006F0047`: 7, `0x00710053`: 5, `0x00740053`: 5 |
| `0x020` | 25 | 154/224 | `0x0064006C`: 7, `0x00690075`: 5, `0x00620061`: 5 |
| `0x024` | 18 | 158/224 | `0x00000079`: 21, `0x00650074`: 7, `0x00650062`: 5 |
| `0x028` | 10 | 191/224 | `0x00000072`: 14, `0x00000064`: 4, `0x0079006C`: 3 |
| `0x02C` | 5 | 217/224 | `0x00000068`: 3, `0x00000061`: 2, `0x00790068`: 1 |
| `0x030` | 3 | 222/224 | `0x00740073`: 1, `0x0079007A`: 1 |
| `0x034` | 2 | 223/224 | `0x00720065`: 1 |
| `0x0A4` | 32 | 154/224 | `0x018C558C`: 4, `0x1C9B5041`: 4, `0x58250C7D`: 4 |
| `0x0A8` | 2 | 0/224 | `0x00000002`: 223, `0x00000003`: 1 |
| `0x0AC` | 2 | 209/224 | `0x00000001`: 15 |
| `0x0B0` | 3 | 209/224 | `0x00000002`: 12, `0x00000001`: 3 |
| `0x0B4` | 8 | 16/224 | `0x00000002`: 104, `0x00000001`: 32, `0x00000003`: 29 |
| `0x0B8` | 8 | 209/224 | `0x00000007`: 3, `0x00000004`: 2, `0x00000005`: 2 |
| `0x0BC` | 4 | 110/224 | `0x00000003`: 89, `0x00000004`: 16, `0x00000001`: 9 |
| `0x0C4` | 2 | 192/224 | `0xF1690A08`: 32 |
| `0x0C8` | 2 | 191/224 | `0x21B779B4`: 33 |
| `0x0CC` | 2 | 216/224 | `0xDE81E5E0`: 8 |
| `0x0D0` | 2 | 216/224 | `0xFD24574B`: 8 |
| `0x0D4` | 40 | 138/224 | `0xAF06E149`: 7, `0x161DCD8B`: 5, `0x292C93D2`: 4 |
| `0x0D8` | 3 | 216/224 | `0x90E48B5A`: 4, `0x7CC79D94`: 4 |
| `0x0DC` | 3 | 218/224 | `0x00500257`: 5, `0x4EB70DF1`: 1 |
| `0x0E0` | 12 | 100/224 | `0x00001006`: 71, `0x00001001`: 22, `0x00001008`: 16 |
| `0x0E4` | 15 | 98/224 | `0x41200000`: 63, `0x41000000`: 13, `0x40800000`: 11 |
| `0x0EC` | 14 | 173/224 | `0x41000000`: 10, `0x40800000`: 7, `0x40200000`: 6 |
| `0x0F0` | 5 | 215/224 | `0x00000008`: 3, `0x00000001`: 3, `0x00000002`: 2 |
| `0x0F8` | 9 | 99/224 | `0x3F800000`: 112, `0x40A00000`: 5, `0x40000000`: 2 |
| `0x0FC` | 31 | 161/224 | `0x41000000`: 8, `0x41200000`: 7, `0x40A00000`: 5 |
| `0x100` | 18 | 162/224 | `0x40400000`: 12, `0x41200000`: 10, `0x40800000`: 6 |
| `0x104` | 27 | 164/224 | `0x41200000`: 9, `0x41400000`: 6, `0x41000000`: 5 |
| `0x108` | 2 | 223/224 | `0x40800000`: 1 |
| `0x10C` | 2 | 223/224 | `0x40800000`: 1 |
| `0x110` | 2 | 223/224 | `0x40400000`: 1 |
| `0x114` | 2 | 223/224 | `0x40400000`: 1 |
| `0x120` | 11 | 99/224 | `0x3F800000`: 88, `0x40000000`: 9, `0x41200000`: 9 |
| `0x128` | 2 | 222/224 | `0x40C00000`: 2 |
| `0x12C` | 2 | 222/224 | `0x40400000`: 2 |
| `0x130` | 3 | 222/224 | `0xE418FDA1`: 1, `0xCA7621F9`: 1 |
| `0x134` | 3 | 98/224 | `0x40400000`: 124, `0x40200000`: 2 |
| `0x13C` | 4 | 98/224 | `0x00000003`: 123, `0x00000001`: 2, `0x00000002`: 1 |
| `0x140` | 10 | 214/224 | `0x7ADE24E1`: 2, `0x56507D07`: 1, `0x293AF179`: 1 |
| `0x148` | 2 | 98/224 | `0x00000003`: 126 |
| `0x150` | 2 | 222/224 | `0x00000001`: 2 |
| `0x154` | 7 | 159/224 | `0x3F800000`: 21, `0x40800000`: 15, `0x40000000`: 12 |
| `0x158` | 3 | 222/224 | `0x56507D07`: 1, `0x65F06D91`: 1 |
| `0x15C` | 10 | 98/224 | `0x40A00000`: 74, `0x41200000`: 20, `0x40400000`: 11 |
| `0x160` | 7 | 189/224 | `0x40000000`: 16, `0x40400000`: 8, `0x3F800000`: 8 |
| `0x164` | 15 | 106/224 | `0x461C4000`: 57, `0x41200000`: 15, `0x40C00000`: 11 |
| `0x168` | 7 | 177/224 | `0x40000000`: 15, `0x3F800000`: 12, `0x40400000`: 12 |
| `0x16C` | 4 | 98/224 | `0x01010101`: 71, `0x01000001`: 39, `0x01000101`: 16 |
| `0x170` | 5 | 104/224 | `0x00000101`: 93, `0x00000001`: 22, `0x00000100`: 3 |
| `0x174` | 3 | 222/224 | `0x40400000`: 1, `0x3F800000`: 1 |
| `0x178` | 3 | 222/224 | `0x40400000`: 1, `0x40A00000`: 1 |
| `0x17C` | 2 | 101/224 | `0x00000001`: 123 |
| `0x180` | 8 | 98/224 | `0x41200000`: 112, `0x40A00000`: 5, `0x40C00000`: 3 |
| `0x184` | 3 | 219/224 | `0x40800000`: 3, `0x40C00000`: 2 |
| `0x188` | 4 | 98/224 | `0xBF800000`: 123, `0x41700000`: 2, `0x41200000`: 1 |
| `0x18C` | 2 | 98/224 | `0xBF800000`: 126 |
| `0x194` | 3 | 0/224 | `0xFFFFFFFF`: 187, `0x00001006`: 35, `0x00001008`: 2 |
| `0x198` | 14 | 187/224 | `0x40200000`: 8, `0x40800000`: 6, `0x40C00000`: 4 |
| `0x1A0` | 10 | 196/224 | `0x40800000`: 5, `0x40200000`: 5, `0x40A00000`: 4 |
| `0x1A4` | 4 | 220/224 | `0x00000001`: 2, `0x00000002`: 1, `0x00000008`: 1 |
| `0x1AC` | 3 | 187/224 | `0x3F800000`: 36, `0x40400000`: 1 |
| `0x1B0` | 23 | 189/224 | `0x40C00000`: 4, `0x41200000`: 3, `0x40A00000`: 3 |
| `0x1B4` | 12 | 192/224 | `0x40800000`: 6, `0x40400000`: 6, `0x41200000`: 5 |
| `0x1B8` | 17 | 197/224 | `0x41200000`: 4, `0x41400000`: 4, `0x41000000`: 2 |
| `0x1D4` | 7 | 187/224 | `0x3F800000`: 20, `0x3F4CCCCD`: 6, `0x40000000`: 4 |
| `0x1DC` | 2 | 222/224 | `0x40C00000`: 2 |
| `0x1E0` | 2 | 222/224 | `0x40400000`: 2 |
| `0x1E4` | 3 | 222/224 | `0xE418FDA1`: 1, `0xCA7621F9`: 1 |
| `0x1E8` | 2 | 187/224 | `0x40400000`: 37 |
| `0x1F0` | 3 | 187/224 | `0x00000003`: 36, `0x00000002`: 1 |
| `0x1F4` | 3 | 222/224 | `0xB5064646`: 1, `0x7ADE24E1`: 1 |
| `0x1FC` | 2 | 187/224 | `0x00000003`: 37 |
| `0x204` | 2 | 223/224 | `0x00000001`: 1 |
| `0x208` | 3 | 219/224 | `0x3F800000`: 3, `0x40400000`: 2 |
| `0x20C` | 2 | 223/224 | `0x65F06D91`: 1 |
| `0x210` | 6 | 187/224 | `0x40A00000`: 16, `0x40400000`: 9, `0x41200000`: 7 |
| `0x214` | 4 | 204/224 | `0x40000000`: 11, `0x40400000`: 8, `0x40A00000`: 1 |
| `0x218` | 14 | 187/224 | `0x41200000`: 10, `0x40C00000`: 4, `0x43340000`: 3 |
| `0x21C` | 7 | 191/224 | `0x40400000`: 10, `0x3F800000`: 8, `0x40000000`: 8 |
| `0x220` | 4 | 187/224 | `0x01000001`: 28, `0x01000101`: 5, `0x01010101`: 4 |
| `0x224` | 5 | 196/224 | `0x00000001`: 19, `0x00000101`: 7, `0x00010001`: 1 |
| `0x230` | 2 | 189/224 | `0x00000001`: 35 |
| `0x234` | 3 | 187/224 | `0x41200000`: 35, `0x40200000`: 2 |
| `0x238` | 2 | 222/224 | `0x40C00000`: 2 |
| `0x23C` | 3 | 187/224 | `0xBF800000`: 36, `0x41200000`: 1 |
| `0x240` | 2 | 187/224 | `0xBF800000`: 37 |
| `0x248` | 2 | 0/224 | `0xFFFFFFFF`: 222, `0x00001006`: 2 |
| `0x24C` | 2 | 222/224 | `0x40200000`: 2 |
| `0x260` | 2 | 222/224 | `0x3F800000`: 2 |
| `0x264` | 3 | 222/224 | `0x41200000`: 1, `0x40C00000`: 1 |
| `0x268` | 3 | 222/224 | `0x40A00000`: 1, `0x40400000`: 1 |
| `0x26C` | 3 | 222/224 | `0x41200000`: 1, `0x40C00000`: 1 |
| `0x288` | 3 | 222/224 | `0x40000000`: 1, `0x3F800000`: 1 |
| `0x29C` | 2 | 222/224 | `0x40400000`: 2 |
| `0x2A4` | 2 | 222/224 | `0x00000003`: 2 |
| `0x2B0` | 2 | 222/224 | `0x00000003`: 2 |
| `0x2BC` | 2 | 222/224 | `0x3F800000`: 2 |
| `0x2C4` | 2 | 222/224 | `0x40A00000`: 2 |
| `0x2C8` | 2 | 222/224 | `0x40000000`: 2 |
| `0x2CC` | 2 | 222/224 | `0x41200000`: 2 |
| `0x2D0` | 2 | 222/224 | `0x3F800000`: 2 |
| `0x2D4` | 2 | 222/224 | `0x01010101`: 2 |
| `0x2D8` | 2 | 222/224 | `0x00000101`: 2 |
| `0x2E4` | 2 | 222/224 | `0x00000001`: 2 |
| `0x2E8` | 2 | 222/224 | `0x41200000`: 2 |
| `0x2F0` | 2 | 222/224 | `0xBF800000`: 2 |
| `0x2F4` | 2 | 222/224 | `0xBF800000`: 2 |
| `0x2FC` | 14 | 156/224 | `0x00000029`: 12, `0x00000015`: 10, `0x00000033`: 9 |
| `0x300` | 2 | 190/224 | `0x00000100`: 34 |
| `0x304` | 29 | 0/224 | `0x3ECCCCCD`: 82, `0x3E99999A`: 32, `0x3E800000`: 28 |
| `0x308` | 24 | 0/224 | `0x3ECCCCCD`: 82, `0x3E99999A`: 47, `0x3F000000`: 32 |
| `0x30C` | 7 | 1/224 | `0x0000000A`: 141, `0x00000006`: 55, `0x0000000F`: 16 |
| `0x314` | 3 | 222/224 | `0x00000001`: 1, `0x00000100`: 1 |
| `0x318` | 2 | 204/224 | `0x00000001`: 20 |

## Sobreposição entre packages

| Número de packages com o mesmo TGI | TGIs |
|---:|---:|
| 2 | 28,720 |
| 3 | 1,047 |
| 4 | 1 |
| 5 | 1 |

## Leitura dos resultados

- `Spore_Audio1.package` e `Spore_Audio2.package` concentram o tipo `0x01A527DB` e o grupo `0x021407EE`; a associação a áudio é **inferida pelo nome do package e pela distribuição**, não provada só pelo ID.
- O tipo focal `0xDFAD9F51` é fortemente associado a nomes `cell` pelas correlações FNV-1 com strings do executável, pelos IDs de instância e pelos rótulos de payload. Isso apoia a interpretação como dados relacionados à etapa celular; a estrutura do formato e a classificação exata ainda não foram confirmadas.
- TGIs repetidos mostram que há conteúdo compartilhado ou versões sobrepostas; não estabelecem sozinhos a ordem de montagem nem qual package prevalece em runtime.

## Reprodução

```powershell
python .\catalog_dbpf_resources.py --root ..\SPOREFILES --output .\DBPF_RESOURCE_CATALOG.md
```
