// Generated from the verified Ghidra instruction export; do not hand-edit.
// Source: SporeApp.exe!0x00404460; static lowering, no x86 interpreter.
#include "SporeCopyLiftRuntime.hpp"

enum class EqualLiftStatus { ok, invalid_memory, invalid_control_flow };

EqualLiftStatus spore_lift_00404460(
    CopyLiftMemory& memory,
    std::uint32_t receiver,
    std::uint32_t argument,
    std::uint32_t* result) {
    if (result == nullptr) return EqualLiftStatus::invalid_memory;
    std::uint32_t eax = 0, ecx = receiver, edx = 0, ebx = 0;
    std::uint32_t esp = CopyLiftMemory::kEntryEsp, ebp = 0, esi = 0, edi = 0;
    std::uint32_t operand_value = 0, left_value = 0, right_value = 0;
    std::uint32_t result_value = 0, return_address = 0;
    bool zero_flag = false;
    const std::uint32_t expected_return_esp = esp + 8u;
    if (!memory.initialize_thiscall_frame(argument))
        return EqualLiftStatus::invalid_memory;

L_00404460: // 55 PUSH EBP
    operand_value = ebp;
    esp = static_cast<std::uint32_t>(esp - 4u);
    if (!memory.store32(esp, operand_value)) return EqualLiftStatus::invalid_memory;
L_00404461: // 8bec MOV EBP ESP
    operand_value = esp;
    ebp = operand_value;
L_00404463: // 51 PUSH ECX
    operand_value = ecx;
    esp = static_cast<std::uint32_t>(esp - 4u);
    if (!memory.store32(esp, operand_value)) return EqualLiftStatus::invalid_memory;
L_00404464: // 894dfc MOV dword ptr [EBP + -0x4] ECX
    operand_value = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), operand_value)) return EqualLiftStatus::invalid_memory;
L_00404467: // 8b4508 MOV EAX dword ptr [EBP + 0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000008u), operand_value)) return EqualLiftStatus::invalid_memory;
    eax = operand_value;
L_0040446a: // 8b4dfc MOV ECX dword ptr [EBP + -0x4]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), operand_value)) return EqualLiftStatus::invalid_memory;
    ecx = operand_value;
L_0040446d: // 8b5004 MOV EDX dword ptr [EAX + 0x4]
    if (!memory.load32(static_cast<std::uint32_t>(eax + 0x00000004u), operand_value)) return EqualLiftStatus::invalid_memory;
    edx = operand_value;
L_00404470: // 33c0 XOR EAX EAX
    operand_value = eax;
    left_value = operand_value;
    operand_value = eax;
    right_value = operand_value;
    result_value = left_value ^ right_value;
    zero_flag = result_value == 0;
    eax = result_value;
L_00404472: // 3b5104 CMP EDX dword ptr [ECX + 0x4]
    operand_value = edx;
    left_value = operand_value;
    if (!memory.load32(static_cast<std::uint32_t>(ecx + 0x00000004u), operand_value)) return EqualLiftStatus::invalid_memory;
    right_value = operand_value;
    zero_flag = left_value == right_value;
L_00404475: // 0f94c0 SETZ AL
    eax = (eax & 0xffffff00u) | (zero_flag ? 1u : 0u & 0xffu);
L_00404478: // 8be5 MOV ESP EBP
    operand_value = ebp;
    esp = operand_value;
L_0040447a: // 5d POP EBP
    if (!memory.load32(esp, operand_value)) return EqualLiftStatus::invalid_memory;
    ebp = operand_value;
    esp = static_cast<std::uint32_t>(esp + 4u);
L_0040447b: // c20400 RET 0x4
    if (!memory.load32(esp, return_address) || return_address != CopyLiftMemory::kReturnSentinel)
        return EqualLiftStatus::invalid_control_flow;
    esp = static_cast<std::uint32_t>(esp + 4u + 4u);
    if (esp != expected_return_esp) return EqualLiftStatus::invalid_control_flow;
    *result = eax & 0xffu;
    return EqualLiftStatus::ok;
    return EqualLiftStatus::invalid_control_flow;
}
