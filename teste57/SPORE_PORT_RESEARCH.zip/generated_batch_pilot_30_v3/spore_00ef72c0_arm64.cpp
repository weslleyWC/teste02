#include <cstdint>

enum class BatchLiftStatus { returned, invalid_memory, invalid_control_flow };
struct BatchLiftState { std::uint32_t regs[8]{}; std::uint32_t eflags = 0; std::uint32_t eip = 0; };
inline bool batch_even_parity(std::uint8_t value) {
    value ^= static_cast<std::uint8_t>(value >> 4u);
    value &= 0x0fu;
    return ((0x6996u >> value) & 1u) == 0u;
}
inline std::uint32_t batch_mask(unsigned width) {
    return width == 32u ? 0xffffffffu : ((std::uint32_t{1} << width) - 1u);
}
inline void batch_set_add_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t b, std::uint32_t r, unsigned width) {
    const std::uint64_t mask = (std::uint64_t{1} << width) - 1u;
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    a &= static_cast<std::uint32_t>(mask); b &= static_cast<std::uint32_t>(mask); r &= static_cast<std::uint32_t>(mask);
    s.eflags &= ~0x8d5u;
    if (static_cast<std::uint64_t>(a) + b > mask) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ b ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & sign) != 0u) s.eflags |= 0x080u;
    if (((~(a ^ b) & (a ^ r)) & sign) != 0u) s.eflags |= 0x800u;
}
inline void batch_set_sub_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t b, std::uint32_t r, unsigned width) {
    const std::uint32_t mask = batch_mask(width);
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    a &= mask; b &= mask; r &= mask;
    s.eflags &= ~0x8d5u;
    if (a < b) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ b ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & sign) != 0u) s.eflags |= 0x080u;
    if ((((a ^ b) & (a ^ r)) & sign) != 0u) s.eflags |= 0x800u;
}
inline void batch_set_logic_flags(BatchLiftState& s, std::uint32_t r, unsigned width) {
    const std::uint32_t mask = batch_mask(width);
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    r &= mask;
    s.eflags &= ~0x8d5u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & sign) != 0u) s.eflags |= 0x080u;
}
inline void batch_set_inc_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t r, unsigned width) {
    const std::uint32_t mask = batch_mask(width);
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    a &= mask; r &= mask; s.eflags &= ~0x8d4u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ 1u ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & sign) != 0u) s.eflags |= 0x080u;
    if ((a == sign - 1u)) s.eflags |= 0x800u;
}
inline void batch_set_dec_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t r, unsigned width) {
    const std::uint32_t mask = batch_mask(width);
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    a &= mask; r &= mask; s.eflags &= ~0x8d4u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ 1u ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & sign) != 0u) s.eflags |= 0x080u;
    if (a == sign) s.eflags |= 0x800u;
}
inline void batch_set_neg_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t r, unsigned width) {
    const std::uint32_t mask = batch_mask(width);
    const std::uint32_t sign = std::uint32_t{1} << (width - 1u);
    a &= mask; r &= mask; s.eflags &= ~0x8d5u;
    if (a != 0u) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & sign) != 0u) s.eflags |= 0x080u;
    if (a == sign) s.eflags |= 0x800u;
}

template <typename Memory>
BatchLiftStatus spore_lift_00ef72c0(Memory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;

    L_00ef72c0: // 837930ff CMP
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000030u), t0a)) return BatchLiftStatus::invalid_memory;
        t0b = 0xffffffffu;
        t0r = static_cast<std::uint32_t>(t0a - t0b) & 0xffffffffu;
        batch_set_sub_flags(state, t0a, t0b, t0r, 32u);
    L_00ef72c4: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_00ef72ca;
    L_00ef72c6: // c6413f01 MOV
        t2 = 0x00000001u;
        if (!memory.store8(static_cast<std::uint32_t>(state.regs[1] + 0x0000003fu), t2)) return BatchLiftStatus::invalid_memory;
    L_00ef72ca: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
