#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

#if !defined(_M_IX86)
#error This reference harness must be compiled as a native 32-bit x86 process.
#endif

namespace {

constexpr std::size_t kFunctionOffset = 0x79000;
constexpr std::size_t kFunctionSize = 128;
constexpr char kExpectedBytes[] =
    "558bec83ec148b45148945fceb128b4d0c83c108894d0c8b55fc83c2088955fc"
    "8b450c33c93b45100f95c10fb6d185d2743f8b45fc8945f48b4df4894df8837df8"
    "0074248b550c8955f08b45f88b4df0d901d9188b55f88b45f0d94004d95a04"
    "8b4df8894deceb07c745ec00000000eb9d8b55088b45fc89028b45088be55dc3";

struct FloatPairBits {
    std::uint32_t first;
    std::uint32_t second;
};

static_assert(sizeof(FloatPairBits) == 8, "Function advances by two 32-bit values.");

using OriginalFunction = std::uint32_t* (__cdecl*)(
    std::uint32_t**,
    const std::uint32_t*,
    const std::uint32_t*,
    std::uint32_t*);

int hex_digit(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    return -1;
}

bool load_original_function(const char* executable_path, void** code) {
    if (std::strlen(kExpectedBytes) != kFunctionSize * 2u) {
        std::fprintf(stderr, "internal expected-byte string has an invalid size\n");
        return false;
    }
    std::ifstream input(executable_path, std::ios::binary);
    if (!input) {
        std::fprintf(stderr, "cannot open selected SporeApp.exe\n");
        return false;
    }
    input.seekg(static_cast<std::streamoff>(kFunctionOffset), std::ios::beg);
    std::array<std::uint8_t, kFunctionSize> original_bytes{};
    input.read(reinterpret_cast<char*>(original_bytes.data()), original_bytes.size());
    if (input.gcount() != static_cast<std::streamsize>(original_bytes.size())) {
        std::fprintf(stderr, "failed to read the complete function byte range\n");
        return false;
    }
    for (std::size_t i = 0; i < original_bytes.size(); ++i) {
        const int high = hex_digit(kExpectedBytes[i * 2u]);
        const int low = hex_digit(kExpectedBytes[i * 2u + 1u]);
        if (high < 0 || low < 0 ||
            original_bytes[i] != static_cast<std::uint8_t>((high << 4) | low)) {
            std::fprintf(stderr, "function bytes differ from the Ghidra export at +0x%zx\n", i);
            return false;
        }
    }

    void* memory = VirtualAlloc(
        nullptr, original_bytes.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == nullptr) {
        std::fprintf(stderr, "VirtualAlloc failed: %lu\n", GetLastError());
        return false;
    }
    std::memcpy(memory, original_bytes.data(), original_bytes.size());
    DWORD old_protection = 0;
    if (!VirtualProtect(memory, original_bytes.size(), PAGE_EXECUTE_READ, &old_protection) ||
        !FlushInstructionCache(GetCurrentProcess(), memory, original_bytes.size())) {
        std::fprintf(stderr, "failed to make the verified function executable: %lu\n", GetLastError());
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    *code = memory;
    return true;
}

std::uint32_t fnv1a(const std::uint8_t* bytes, std::size_t size) {
    std::uint32_t hash = 2166136261u;
    for (std::size_t i = 0; i < size; ++i) {
        hash = (hash ^ bytes[i]) * 16777619u;
    }
    return hash;
}

std::uint32_t expected_x87_roundtrip(std::uint32_t bits) {
    if ((bits & 0x7f800000u) == 0x7f800000u && (bits & 0x007fffffu) != 0u) {
        bits |= 0x00400000u;
    }
    return bits;
}

std::vector<FloatPairBits> make_stress_records() {
    std::vector<FloatPairBits> records;
    records.reserve(256);
    std::uint32_t state = 0x9e3779b9u;
    for (std::size_t i = 0; i < 256; ++i) {
        state ^= state << 13u;
        state ^= state >> 17u;
        state ^= state << 5u;
        const std::uint32_t first = state;
        state ^= state << 13u;
        state ^= state >> 17u;
        state ^= state << 5u;
        records.push_back({first, state});
    }
    records[0] = {0x7f800001u, 0xff800123u};
    return records;
}

bool run_case(
    OriginalFunction function,
    const char* label,
    const std::vector<FloatPairBits>& source,
    bool null_destination) {
    const std::size_t bytes = source.size() * sizeof(FloatPairBits);
    FloatPairBits empty_sentinel{};
    std::vector<FloatPairBits> destination(source.size() + 2u);
    std::memset(destination.data(), 0xa5, destination.size() * sizeof(FloatPairBits));
    const auto* source_begin = source.empty()
        ? reinterpret_cast<const std::uint32_t*>(&empty_sentinel)
        : reinterpret_cast<const std::uint32_t*>(source.data());
    const auto* source_end = source_begin + source.size() * 2u;
    std::uint32_t* destination_begin =
        null_destination ? nullptr : reinterpret_cast<std::uint32_t*>(destination.data());
    std::uint32_t* output_slot = nullptr;
    std::uint32_t* returned = function(
        &output_slot, source_begin, source_end, destination_begin);
    const std::uintptr_t destination_address =
        reinterpret_cast<std::uintptr_t>(destination_begin);
    const std::uintptr_t end_address = reinterpret_cast<std::uintptr_t>(output_slot);
    const std::uint32_t end_offset =
        static_cast<std::uint32_t>(end_address - destination_address);
    bool copied = true;
    if (!null_destination && bytes != 0) {
        const auto* source_words = reinterpret_cast<const std::uint32_t*>(source.data());
        const auto* destination_words =
            reinterpret_cast<const std::uint32_t*>(destination.data());
        for (std::size_t i = 0; i < source.size() * 2u; ++i) {
            copied = copied &&
                destination_words[i] == expected_x87_roundtrip(source_words[i]);
        }
    }
    const std::uint8_t* guard_start =
        reinterpret_cast<const std::uint8_t*>(destination.data()) + bytes;
    const std::size_t guard_size =
        destination.size() * sizeof(FloatPairBits) - bytes;
    const bool guard_unchanged = std::all_of(
        guard_start, guard_start + guard_size,
        [](std::uint8_t value) { return value == 0xa5; });
    if (!copied && !null_destination) {
        const auto* source_words = reinterpret_cast<const std::uint32_t*>(source.data());
        const auto* destination_words =
            reinterpret_cast<const std::uint32_t*>(destination.data());
        for (std::size_t i = 0; i < source.size() * 2u; ++i) {
            if (source_words[i] != destination_words[i]) {
                std::fprintf(
                    stderr,
                    "%s changed word %zu: source=%08x destination=%08x\n",
                    label,
                    i,
                    source_words[i],
                    destination_words[i]);
            }
        }
    }
    const bool passed =
        returned == reinterpret_cast<std::uint32_t*>(&output_slot) &&
        end_offset == bytes &&
        copied &&
        guard_unchanged;
    const std::uint32_t output_hash = null_destination
        ? 2166136261u
        : fnv1a(reinterpret_cast<const std::uint8_t*>(destination.data()), bytes);
    std::printf(
        "x86 case=%s end_offset=0x%08x copy_hash=%08x copied=%u guard=%u PASS=%u\n",
        label,
        end_offset,
        output_hash,
        copied ? 1u : 0u,
        guard_unchanged ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: FirstNativeCopyX86Reference.exe <selected SporeApp.exe>\n");
        return 2;
    }
    SYSTEM_INFO system_info{};
    GetNativeSystemInfo(&system_info);
    if (system_info.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_AMD64 &&
        system_info.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_INTEL) {
        std::fprintf(stderr, "host processor is not x86/x86-64\n");
        return 2;
    }

    void* code = nullptr;
    if (!load_original_function(argv[1], &code)) return 2;
    const auto function = reinterpret_cast<OriginalFunction>(code);
    const std::vector<FloatPairBits> empty;
    const std::vector<FloatPairBits> one{{{0x3f800000u, 0xc0200000u}}};
    const std::vector<FloatPairBits> varied{{
        {0x00000000u, 0x80000000u},
        {0x00000001u, 0x007fffffu},
        {0x3f800000u, 0xbf800000u},
        {0x7f7fffffu, 0xff7fffffu},
        {0x7f800000u, 0xff800000u},
        {0x7fc12345u, 0xffc54321u},
        {0x7f800001u, 0xff800123u},
    }};
    const std::vector<FloatPairBits> stress = make_stress_records();
    std::size_t failures = 0;
    std::size_t cases = 0;
    failures += !run_case(function, "empty", empty, false); ++cases;
    failures += !run_case(function, "single", one, false); ++cases;
    failures += !run_case(function, "varied", varied, false); ++cases;
    failures += !run_case(function, "stress_256", stress, false); ++cases;
    failures += !run_case(function, "null_destination", one, true); ++cases;
    std::printf("x86 summary cases=%zu failures=%zu\n", cases, failures);
    VirtualFree(code, 0, MEM_RELEASE);
    return failures == 0 ? 0 : 1;
}
