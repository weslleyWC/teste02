#!/usr/bin/env python3
"""Generate a read-only import inventory and rough shim-effort report for a PE32 file."""

import argparse
import hashlib
import os
import struct
from collections import Counter


def u16(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def rva_to_offset(rva, sections):
    for va, span, raw_offset in sections:
        if va <= rva < va + span:
            return raw_offset + (rva - va)
    raise ValueError(f"unmapped RVA 0x{rva:X}")


def read_c_string(data, offset):
    end = data.find(b"\0", offset)
    if end < 0:
        raise ValueError("unterminated PE string")
    return data[offset:end].decode("ascii", "replace")


def export_ordinals(path):
    if not path or not os.path.isfile(path):
        return {}
    data = open(path, "rb").read()
    pe = u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0":
        return {}
    coff = pe + 4
    section_count = u16(data, coff + 2)
    optional_size = u16(data, coff + 16)
    optional = coff + 20
    magic = u16(data, optional)
    if magic not in (0x10B, 0x20B):
        return {}
    directory = optional + (96 if magic == 0x10B else 112)
    export_rva = u32(data, directory)
    if not export_rva:
        return {}
    section_table = optional + optional_size
    sections = []
    for index in range(section_count):
        offset = section_table + index * 40
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", data, offset + 8
        )
        sections.append(
            (virtual_address, max(virtual_size, raw_size), raw_offset)
        )
    export = rva_to_offset(export_rva, sections)
    ordinal_base, _, name_count, _, names_rva, ordinals_rva = struct.unpack_from(
        "<IIIIII", data, export + 16
    )
    names = rva_to_offset(names_rva, sections)
    ordinals = rva_to_offset(ordinals_rva, sections)
    result = {}
    for index in range(name_count):
        name_rva = u32(data, names + index * 4)
        name = read_c_string(data, rva_to_offset(name_rva, sections))
        ordinal_index = u16(data, ordinals + index * 2)
        result[ordinal_base + ordinal_index] = name
    return result


def parse_imports(path, syswow64):
    data = open(path, "rb").read()
    if data[:2] != b"MZ":
        raise ValueError("input has no DOS MZ header")
    pe = u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0":
        raise ValueError("input has no PE signature")
    coff = pe + 4
    machine = u16(data, coff)
    section_count = u16(data, coff + 2)
    optional_size = u16(data, coff + 16)
    optional = coff + 20
    magic = u16(data, optional)
    if machine != 0x14C or magic != 0x10B:
        raise ValueError("report generator currently requires PE32 x86")
    image_base = u32(data, optional + 28)
    directory = optional + 96
    import_rva = u32(data, directory + 8)
    section_table = optional + optional_size
    sections = []
    for index in range(section_count):
        offset = section_table + index * 40
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", data, offset + 8
        )
        sections.append(
            (virtual_address, max(virtual_size, raw_size), raw_offset)
        )

    imports = []
    descriptor = rva_to_offset(import_rva, sections)
    while True:
        original_thunk, _, _, name_rva, first_thunk = struct.unpack_from(
            "<IIIII", data, descriptor
        )
        descriptor += 20
        if not any((original_thunk, name_rva, first_thunk)):
            break
        dll = read_c_string(data, rva_to_offset(name_rva, sections))
        ordinal_map = export_ordinals(
            os.path.join(syswow64, dll) if syswow64 else None
        )
        lookup = rva_to_offset(original_thunk or first_thunk, sections)
        index = 0
        while True:
            thunk = u32(data, lookup + index * 4)
            if thunk == 0:
                break
            if thunk & 0x80000000:
                ordinal = thunk & 0xFFFF
                symbol = ordinal_map.get(ordinal, f"ordinal #{ordinal}")
            else:
                ordinal = None
                hint_name = rva_to_offset(thunk, sections)
                symbol = read_c_string(data, hint_name + 2)
            imports.append((dll, symbol, ordinal))
            index += 1
    return data, image_base, imports


def effort(dll, symbol):
    name = symbol.lower()
    base = dll.lower()

    if name.startswith("ordinal #"):
        return ("unknown", "unestimated", "Ordinal not resolved in local system DLL")
    if base == "msvcr90.dll":
        if any(token in name for token in (
            "cxx", "except_handler", "xcptfilter", "invoke_watson",
            "terminate", "longjmp", "setjmp", "onexit", "initterm",
            "amsg_exit", "purecall", "dllonexit",
        )):
            return ("high", "8-32 h", "C++ ABI, exception or CRT startup semantics")
        if any(token in name for token in ("locale", "mbcp", "tow", "isw")):
            return ("medium", "2-8 h", "Locale and multibyte behavior differs by platform")
        if any(token in name for token in ("fopen", "fread", "fwrite", "fseek",
                                           "ftell", "fclose", "tmpfile", "stat")):
            return ("low-medium", "1-4 h", "CRT file/stdio wrapper")
        return ("low", "0.5-2 h", "Standard CRT routine; ABI and edge cases still need tests")
    if base == "kernel32.dll":
        if any(token in name for token in ("virtual", "tls", "thread", "apc",
                                           "raiseexception", "unhandledexception",
                                           "loadlibrary", "getprocaddress",
                                           "modulehandle", "terminateprocess",
                                           "deviceiocontrol", "openprocess")):
            return ("high", "8-24 h", "Process, loader, exception, VM or thread semantics")
        if any(token in name for token in ("createfile", "readfile", "writefile",
                                           "filepointer", "filesize", "findfirst",
                                           "findnext", "changeNotification".lower(),
                                           "directory", "deletefile", "movefile",
                                           "copyfile", "volume")):
            return ("medium", "3-12 h", "Windows handles, paths and async/error semantics")
        if any(token in name for token in ("criticalsection", "mutex", "semaphore",
                                           "waitforsingle", "waitformultiple",
                                           "createevent", "setevent", "release")):
            return ("medium-high", "4-16 h", "Synchronization primitive and wait semantics")
        if any(token in name for token in ("interlocked", "sleep", "tickcount",
                                           "performancecounter", "systemtime",
                                           "multibytetowide", "widechartomulti",
                                           "getlast", "setlast", "globalmemory",
                                           "getsysteminfo", "getversion", "getlocale")):
            return ("low-medium", "1-4 h", "Direct Bionic/POSIX or small compatibility wrapper")
        return ("medium", "2-8 h", "Win32 environment, path, process or system API")
    if base == "user32.dll":
        if any(token in name for token in ("hook", "clipboard", "paint", "monitor",
                                           "window", "message", "cursor", "keyboard",
                                           "mouse", "focus", "display", "class")):
            return ("high", "6-24 h", "Window-system/input behavior needs Android mapping")
        return ("medium", "2-10 h", "UI state or platform behavior needs adaptation")
    if base in ("d3d9.dll", "d3dx9_27.dll"):
        if "vec3transform" in name:
            return ("low-medium", "1-4 h", "Math routine; verify matrix convention")
        if "matrix" in name:
            return ("low-medium", "1-4 h", "Math routine; verify matrix convention")
        if name == "d3dxcheckversion":
            return ("low", "0.5-2 h", "Version compatibility check")
        if name.endswith("shaderprofile"):
            return ("medium", "2-8 h", "Return supported profile based on selected backend capabilities")
        if "compile" in name or "shader" in name:
            return ("very high", "16-80 h", "D3D9 shader compiler/profile to GLES/Vulkan")
        return ("very high", "16-80 h", "D3D9 device/resource/format semantics")
    if base == "dinput8.dll":
        return ("high", "8-32 h", "DirectInput device enumeration, state and event mapping")
    if base == "dsound.dll":
        return ("high", "8-32 h", "DirectSound buffers, mixing, timing and device semantics")
    if base == "steam_api.dll":
        return ("low-medium", "1-6 h", "Offline stub is easy; real Steam semantics are not")
    if base == "wsock32.dll" or base == "ws2_32.dll":
        return ("medium-high", "4-16 h", "Socket ABI, errors, nonblocking I/O and network policy")
    if base == "ole32.dll":
        return ("high", "8-32 h", "COM/OLE lifetime, drag-drop and storage-medium semantics")
    if base == "gdi32.dll":
        if name == "extescape":
            return ("high", "8-24 h", "Driver escape has no direct Android equivalent")
        return ("medium-high", "4-16 h", "GDI device contexts/objects need a renderer adapter")
    if base == "imm32.dll":
        return ("medium-high", "4-16 h", "IME composition and candidate UI need Android input connection")
    if base == "usp10.dll":
        return ("high", "8-24 h", "Uniscribe shaping/layout must be replaced with Android text stack")
    if base == "advapi32.dll":
        if "event" in name:
            return ("medium", "3-10 h", "Windows Event Log has no direct Android equivalent")
        return ("low-medium", "1-6 h", "Registry/user identity persistence adapter")
    if base == "shell32.dll":
        return ("medium-high", "4-16 h", "Special folders, drag/drop and external intents")
    if base == "psapi.dll":
        return ("low-medium", "1-4 h", "Module metadata/process API adapter")
    if base == "version.dll":
        return ("low", "1-3 h", "Version-resource query or packaged metadata adapter")
    if base == "dbghelp.dll":
        return ("low-medium", "1-6 h", "Debug symbol stack; likely diagnostic-only")
    if base == "winmm.dll":
        return ("low-medium", "1-5 h", "Timer resolution/monotonic clock adapter")
    return ("unknown", "unestimated", "Review symbol semantics individually")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pe", required=True, help="Local PE32 x86 executable")
    parser.add_argument("--output", required=True, help="Markdown report path")
    parser.add_argument(
        "--syswow64",
        default=os.environ.get("WINDIR", r"C:\Windows") + r"\SysWOW64",
        help="Directory used only to resolve imported ordinals",
    )
    args = parser.parse_args()
    data, image_base, imports = parse_imports(args.pe, args.syswow64)
    grouped = {}
    for dll, symbol, ordinal in imports:
        grouped.setdefault(dll, []).append((symbol, ordinal))
    digest = hashlib.sha256(data).hexdigest()
    ordinal_imports = [
        (symbol, ordinal)
        for _, symbol, ordinal in imports
        if ordinal is not None
    ]
    unresolved_ordinals = sum(
        symbol.startswith("ordinal #") for symbol, _ in ordinal_imports
    )

    lines = [
        "# Import report: SporeApp.exe",
        "",
        f"- Input: `{args.pe}`",
        f"- SHA-256: `{digest}`",
        f"- PE image base: `0x{image_base:08X}`",
        f"- Imported functions/ordinals: **{len(imports)}**",
        f"- Imported DLLs: **{len(grouped)}**",
        f"- Ordinal imports: **{len(ordinal_imports)}** "
        f"({len(ordinal_imports) - unresolved_ordinals} resolved by local export name; "
        f"{unresolved_ordinals} unresolved)",
        "- Scope: static PE import table only; delay-loaded/dynamically resolved APIs are not included.",
        "- Effort values are rough person-hours for a compatibility layer, not a sum of independent tasks.",
        "- An API shim does not imply the complete subsystem can be implemented in that time.",
        "",
        "## Summary by DLL",
        "",
        "| DLL | Imports |",
        "|---|---:|",
    ]
    for dll in sorted(grouped, key=str.lower):
        lines.append(f"| `{dll}` | {len(grouped[dll])} |")

    lines.extend(["", "## Function-by-function inventory", ""])
    for dll in sorted(grouped, key=str.lower):
        lines.extend([
            f"### `{dll}` ({len(grouped[dll])})",
            "",
            "| Imported symbol | Effort | Estimate | Shim notes |",
            "|---|---|---:|---|",
        ])
        for symbol, ordinal in grouped[dll]:
            level, hours, note = effort(dll, symbol)
            display_symbol = symbol
            if ordinal is not None and not symbol.startswith("ordinal #"):
                display_symbol += f" (ordinal #{ordinal})"
            lines.append(
                f"| `{display_symbol}` | {level} | {hours} | {note} |"
            )
        lines.append("")

    lines.extend([
        "## Interpretation",
        "",
        "The estimates are not additive: many imported functions share one underlying "
        "adapter (for example file handles, UI message dispatch, COM, D3D9, or CRT "
        "startup). The largest architectural risks are not the number of imports but "
        "pointer-width/ABI translation, exception and TLS behavior, dynamic loading, "
        "window/message semantics, and D3D9-to-GLES/Vulkan resource and shader mapping.",
        "",
        "Ordinals are resolved against the local Windows `SysWOW64` export tables where "
        "available. That is a local OS mapping, not proof the game was built against "
        "that exact DLL revision; unresolved ordinals remain explicitly named.",
        "",
    ])
    with open(args.output, "w", encoding="utf-8", newline="\n") as report:
        report.write("\n".join(lines))
    print(f"wrote {args.output}: {len(imports)} imports across {len(grouped)} DLLs")


if __name__ == "__main__":
    main()
