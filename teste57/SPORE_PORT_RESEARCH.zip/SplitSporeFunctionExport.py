#!/usr/bin/env python3

import argparse
import json
from pathlib import Path


def iter_function_objects(stream, initial_buffer):
    decoder = json.JSONDecoder()
    buffer = initial_buffer
    while True:
        buffer = buffer.lstrip(" \t\r\n,")
        if not buffer:
            buffer = stream.read(1024 * 1024)
            if not buffer:
                return
            continue
        if buffer[0] == "]":
            return
        if buffer[0] != "{":
            raise ValueError("expected function object in functions array")
        try:
            value, consumed = decoder.raw_decode(buffer)
        except json.JSONDecodeError:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                raise ValueError("unterminated function object")
            buffer += chunk
            continue
        yield json.dumps(value, separators=(",", ":")).encode("utf-8")
        buffer = buffer[consumed:]


def main():
    parser = argparse.ArgumentParser(description="Split a complete Ghidra export into resumable batches.")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=500)
    args = parser.parse_args()
    if args.batch_size < 1:
        raise ValueError("--batch-size must be positive")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with args.input.open("r", encoding="utf-8") as stream:
        prefix = stream.read(1024 * 1024)
        marker = '"functions": ['
        marker_position = prefix.find(marker)
        while marker_position < 0 and len(prefix) < 16 * 1024 * 1024:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            prefix += chunk
            marker_position = prefix.find(marker)
        if marker_position < 0:
            raise ValueError("complete export has no functions array")
        function_start = marker_position + len(marker)
        initial_buffer = prefix[function_start:]
        batch_index = 0
        function_count = 0
        batch_objects = []

        output_prefix = prefix[:function_start]

        def publish(objects, index):
            target = args.output_dir / f"spore_batch_all_{index:04d}.json"
            if target.exists():
                raise FileExistsError(f"refusing to overwrite {target}")
            target.write_text(
                output_prefix + "\n" + ",\n".join(
                    item.decode("utf-8") for item in objects
                ) + "\n  ]\n}\n",
                encoding="utf-8",
            )

        for function in iter_function_objects(stream, initial_buffer):
            batch_objects.append(function)
            function_count += 1
            if len(batch_objects) == args.batch_size:
                batch_index += 1
                publish(batch_objects, batch_index)
                batch_objects = []
        if batch_objects:
            batch_index += 1
            publish(batch_objects, batch_index)
    if function_count == 0:
        raise ValueError("complete export has no functions")
    print(f"Created {batch_index} batches containing {function_count} functions.")


if __name__ == "__main__":
    main()
