#!/usr/bin/env python3

import argparse
import json
import re
import sys
from pathlib import Path


LINE = re.compile(
    r"^(x86|arm64) case=(\S+)(?: status=\d+)? "
    r"result=(\d+) expected=(\d+) PASS=([01])$"
)
EXPECTED_CASES = {f"pair_{index:02d}" for index in range(8)}


def parse_log(path, architecture):
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16")
    elif raw.count(b"\x00") > max(2, len(raw) // 8):
        text = raw.decode("utf-16-le")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    text = text.replace("\r", "")

    cases = {}
    summary = re.search(
        rf"^{architecture} summary cases=(\d+) failures=(\d+)$",
        text,
        re.MULTILINE,
    )
    if summary is None:
        raise ValueError(f"{architecture} completion summary missing from {path}")
    if len(re.findall(
        rf"^{architecture} summary cases=\d+ failures=\d+$",
        text,
        re.MULTILINE,
    )) != 1:
        raise ValueError(f"expected exactly one {architecture} completion summary in {path}")
    for line in text.splitlines():
        match = LINE.fullmatch(line.strip())
        if match is None:
            continue
        arch, name, actual, expected, passed = match.groups()
        if arch != architecture:
            continue
        if name in cases:
            raise ValueError(f"duplicate {architecture} result for {name}")
        if passed != "1" or actual != expected:
            raise ValueError(f"{architecture} expected-value test failed for {name}")
        cases[name] = int(actual)
    if len(cases) != int(summary.group(1)):
        raise ValueError(
            f"{architecture} summary says {summary.group(1)} cases, "
            f"but {len(cases)} passing records were found"
        )
    if int(summary.group(2)) != 0:
        raise ValueError(f"{architecture} reports {summary.group(2)} failures")
    if not cases:
        raise ValueError(f"{architecture} log contains no test cases")
    if set(cases) != EXPECTED_CASES:
        raise ValueError(
            f"{architecture} cases differ from the expected set; "
            f"missing={sorted(EXPECTED_CASES - set(cases))}, "
            f"unexpected={sorted(set(cases) - EXPECTED_CASES)}"
        )
    return cases


def main():
    parser = argparse.ArgumentParser(
        description="Compare original x86 and statically lifted ARM64 results."
    )
    parser.add_argument("--x86", type=Path, required=True)
    parser.add_argument("--arm64", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--device-model", required=True)
    parser.add_argument("--device-serial", required=True)
    args = parser.parse_args()
    if args.output.exists():
        print(
            f"output already exists; preserve it before rerunning: {args.output}",
            file=sys.stderr,
        )
        return 1
    if not re.fullmatch(r"[0-9a-fA-F]{64}", args.source_sha256):
        print("source SHA-256 must contain exactly 64 hexadecimal characters", file=sys.stderr)
        return 1

    try:
        x86 = parse_log(args.x86, "x86")
        arm64 = parse_log(args.arm64, "arm64")
        if set(x86) != set(arm64):
            raise ValueError(
                f"test cases differ; x86-only={sorted(set(x86) - set(arm64))}, "
                f"ARM64-only={sorted(set(arm64) - set(x86))}"
            )
        differences = {
            name: {
                "x86_result": x86[name],
                "arm64_result": arm64[name],
            }
            for name in sorted(x86)
            if x86[name] != arm64[name]
        }
        result = {
            "schema": "spore-third-static-lift-comparison-v1",
            "function_entry": "0x00404460",
            "source_binary_sha256": args.source_sha256.lower(),
            "x86_reference_log": str(args.x86),
            "arm64_device_log": str(args.arm64),
            "arm64_device": {
                "model": args.device_model,
                "serial": args.device_serial,
                "abi": "arm64-v8a",
            },
            "x86_hardware_execution": True,
            "arm64_physical_device_execution": True,
            "x86_case_count": len(x86),
            "arm64_case_count": len(arm64),
            "shared_case_count": len(set(x86) & set(arm64)),
            "outputs_match": not differences,
            "differences": differences,
            "cases": [
                {
                    "case": name,
                    "x86_result": x86[name],
                    "arm64_result": arm64[name],
                }
                for name in sorted(x86)
            ],
            "scope": (
                "Isolated return-value comparison for eight uint32 input pairs; "
                "does not establish complete register/flag equivalence, caller "
                "integration, or whole-game behavior."
            ),
        }
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError) as error:
        print(f"cross-architecture comparison failed: {error}", file=sys.stderr)
        return 1

    print(
        f"Cross-architecture results: {result['shared_case_count']} shared cases; "
        f"match={result['outputs_match']}."
    )
    print(f"Comparison report: {args.output}")
    return 0 if result["outputs_match"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
