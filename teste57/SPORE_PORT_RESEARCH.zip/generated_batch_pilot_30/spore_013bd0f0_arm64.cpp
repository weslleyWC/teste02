#include <cstdint>

enum class BatchLiftStatus { returned, invalid_memory, invalid_control_flow };
struct BatchLiftState { std::uint32_t regs[8]{}; std::uint32_t eflags = 0; std::uint32_t eip = 0; };
inline bool batch_even_parity(std::uint8_t value) {
    value ^= static_cast<std::uint8_t>(value >> 4u);
    value &= 0x0fu;
    return ((0x6996u >> value) & 1u) == 0u;
}
inline void batch_set_add_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t b, std::uint32_t r) {
    constexpr std::uint32_t mask = 0x8d5u;
    s.eflags &= ~mask;
    if (r < a) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ b ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & 0x80000000u) != 0u) s.eflags |= 0x080u;
    if (((~(a ^ b) & (a ^ r)) & 0x80000000u) != 0u) s.eflags |= 0x800u;
}
inline void batch_set_sub_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t b, std::uint32_t r) {
    constexpr std::uint32_t mask = 0x8d5u;
    s.eflags &= ~mask;
    if (a < b) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ b ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & 0x80000000u) != 0u) s.eflags |= 0x080u;
    if ((((a ^ b) & (a ^ r)) & 0x80000000u) != 0u) s.eflags |= 0x800u;
}
inline void batch_set_logic_flags(BatchLiftState& s, std::uint32_t r) {
    constexpr std::uint32_t mask = 0x8d5u;
    s.eflags &= ~mask;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & 0x80000000u) != 0u) s.eflags |= 0x080u;
}

template <typename Memory>
BatchLiftStatus spore_lift_013bd0f0(Memory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;

    L_013bd0f0: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
