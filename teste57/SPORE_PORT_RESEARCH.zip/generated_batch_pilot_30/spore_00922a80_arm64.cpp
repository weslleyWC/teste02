#include <cstdint>

enum class BatchLiftStatus { returned, invalid_memory, invalid_control_flow };
struct BatchLiftState { std::uint32_t regs[8]{}; std::uint32_t eflags = 0; std::uint32_t eip = 0; };
inline bool batch_even_parity(std::uint8_t value) {
    value ^= static_cast<std::uint8_t>(value >> 4u);
    value &= 0x0fu;
    return ((0x6996u >> value) & 1u) == 0u;
}
inline void batch_set_add_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t b, std::uint32_t r) {
    constexpr std::uint32_t mask = 0x8d5u;
    s.eflags &= ~mask;
    if (r < a) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ b ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & 0x80000000u) != 0u) s.eflags |= 0x080u;
    if (((~(a ^ b) & (a ^ r)) & 0x80000000u) != 0u) s.eflags |= 0x800u;
}
inline void batch_set_sub_flags(BatchLiftState& s, std::uint32_t a, std::uint32_t b, std::uint32_t r) {
    constexpr std::uint32_t mask = 0x8d5u;
    s.eflags &= ~mask;
    if (a < b) s.eflags |= 0x001u;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (((a ^ b ^ r) & 0x010u) != 0u) s.eflags |= 0x010u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & 0x80000000u) != 0u) s.eflags |= 0x080u;
    if ((((a ^ b) & (a ^ r)) & 0x80000000u) != 0u) s.eflags |= 0x800u;
}
inline void batch_set_logic_flags(BatchLiftState& s, std::uint32_t r) {
    constexpr std::uint32_t mask = 0x8d5u;
    s.eflags &= ~mask;
    if (batch_even_parity(static_cast<std::uint8_t>(r))) s.eflags |= 0x004u;
    if (r == 0u) s.eflags |= 0x040u;
    if ((r & 0x80000000u) != 0u) s.eflags |= 0x080u;
}

template <typename Memory>
BatchLiftStatus spore_lift_00922a80(Memory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;

    L_00922a80: // 8b01 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000000u), t0)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t0;
    L_00922a82: // 85c0 TEST
        t1a = state.regs[0];
        t1b = state.regs[0];
        t1r = t1a & t1b;
        batch_set_logic_flags(state, t1r);
    L_00922a84: // 7403 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_00922a89;
    L_00922a86: // 8b00 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x00000000u), t3)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t3;
    L_00922a88: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    L_00922a89: // 33c0 XOR
        t5a = state.regs[0];
        t5b = state.regs[0];
        t5r = t5a ^ t5b;
        batch_set_logic_flags(state, t5r);
        state.regs[0] = t5r;
    L_00922a8b: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
