# Spore Android — Fase 4: status da primeira recompilação estática

## Escopo e identidade

O alvo definido pelo usuário é exclusivamente:

`C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe`

SHA-256 lido diretamente desse arquivo: `6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`.

Esse hash difere do hash-base histórico `290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74`. A escolha explícita do usuário fixa o caminho e o arquivo atual para esta fase; não altera nem reescreve os resultados históricos do hash anterior.

O CSV do Ghidra contém `00422430,FUN_00422430,122`. Como o CSV não registra o SHA-256, sua identidade isolada não é criptograficamente vinculada à build. Para esta função, porém, o export seletivo do programa aberto no Ghidra confirmou o SHA-256 do executável selecionado e exportou o corpo correspondente.

## Evidência estática disponível

Sem executar o executável, o arquivo selecionado foi mapeado como PE32 x86. VA `0x00422430` corresponde a RVA `0x00022430`, offset de arquivo `0x00021830`, dentro de `.text`. Foram lidos e desmontados 122 bytes, o mesmo tamanho informado pela linha do inventário.

Bytes da função, na ordem:

```text
558bec83ec108b450c2b450899b90c000000f7f98945fc837dfc007e568b55088955f88b45fcd1f88945f48b4df46bc90c034df8894df88b55f88b45108b0a3b081bd2f7da0fb6c285c0741f8b4df883c10c894df88b55f88955088b45f483c0018b4dfc2bc8894dfceb068b55f48955fceba48b45088be55dc3
```

Desmontagem Capstone da cópia selecionada:

```asm
00422430  push ebp
00422431  mov ebp, esp
00422433  sub esp, 0x10
00422436  mov eax, dword ptr [ebp + 0xc]
00422439  sub eax, dword ptr [ebp + 8]
0042243c  cdq
0042243d  mov ecx, 0xc
00422442  idiv ecx
00422444  mov dword ptr [ebp - 4], eax
00422447  cmp dword ptr [ebp - 4], 0
0042244b  jle 0x4224a3
0042244d  mov edx, dword ptr [ebp + 8]
00422450  mov dword ptr [ebp - 8], edx
00422453  mov eax, dword ptr [ebp - 4]
00422456  sar eax, 1
00422458  mov dword ptr [ebp - 0xc], eax
0042245b  mov ecx, dword ptr [ebp - 0xc]
0042245e  imul ecx, ecx, 0xc
00422461  add ecx, dword ptr [ebp - 8]
00422464  mov dword ptr [ebp - 8], ecx
00422467  mov edx, dword ptr [ebp - 8]
0042246a  mov eax, dword ptr [ebp + 0x10]
0042246d  mov ecx, dword ptr [edx]
0042246f  cmp ecx, dword ptr [eax]
00422471  sbb edx, edx
00422473  neg edx
00422475  movzx eax, dl
00422478  test eax, eax
0042247a  je 0x42249b
0042247c  mov ecx, dword ptr [ebp - 8]
0042247f  add ecx, 0xc
00422482  mov dword ptr [ebp - 8], ecx
00422485  mov edx, dword ptr [ebp - 8]
00422488  mov dword ptr [ebp + 8], edx
0042248b  mov eax, dword ptr [ebp - 0xc]
0042248e  add eax, 1
00422491  mov ecx, dword ptr [ebp - 4]
00422494  sub ecx, eax
00422496  mov dword ptr [ebp - 4], ecx
00422499  jmp 0x4224a1
0042249b  mov edx, dword ptr [ebp - 0xc]
0042249e  mov dword ptr [ebp - 4], edx
004224a1  jmp 0x422447
004224a3  mov eax, dword ptr [ebp + 8]
004224a6  mov esp, ebp
004224a8  pop ebp
004224a9  ret
```

### Semântica recuperada e limites remanescentes

- O frame acessa três valores na pilha em `[ebp+8]`, `[ebp+0xc]` e `[ebp+0x10]`; o retorno fica em `EAX`. O decompilador inferiu `uint * FUN_00422430(uint *param_1, int param_2, uint *param_3)`. A convenção segue `unknown`; o `ret` comum é compatível com caller-cleanup, mas não prova sozinho `cdecl`.
- O código calcula `(arg2 - arg1) / 12` com divisão inteira assinada; cada passo intermediário avança 12 bytes. Ele lê um `uint32` em `[mid]` e outro em `[*arg3]`. O par `cmp`/`sbb`/`neg` obtém a condição de menor que sem sinal.
- O fluxo observado contém `jle 0x4224a3`, `je 0x42249b`, `jmp 0x4224a1` e o salto de repetição `jmp 0x422447`. Não há instrução `call` no corpo de 122 bytes.
- A estrutura é consistente com busca lower-bound em registros de 12 bytes, mas isso não prova identidade semântica nem equivalência. Em particular, `idiv` e o tamanho de elemento fazem parte do comportamento original e não podem ser descartados por semelhança com o lift manual.
- O export seletivo confirma três callers de entrada e nenhum `call` no corpo. As pré-condições reais dos callers e o comportamento em ponteiros/ranges inválidos continuam sem comprovação; os testes ficam limitados a arrays válidos e ordenados.

## Resultados da Fase 4 — 2026-11-02

| Critério | Status | Evidência |
|---|---|---|
| Identificar a build selecionada | **PASSOU** | O export do Ghidra registra `SporeApp.exe`, confirma a origem do programa aberto e o SHA-256 `6aec99cb…e59b`, igual ao executável escolhido nesta fase. |
| Encontrar a função no inventário | **PASSOU** | `FUN_00422430`, 122 bytes, no CSV; export confirma início exato em `0x00422430`. |
| Exportar bytes, instruções e limites | **PASSOU** | 47 instruções cobrem os 122 bytes; corpo `0x00422430–0x004224a9`; sete blocos básicos, sem truncamento. |
| Exportar pseudocódigo e referências | **PASSOU** | Decompilação concluída; três referências de chamada de entrada. Nenhuma chamada dentro do corpo da função. |
| Determinar a assinatura e convenção de chamada | **PARCIAL** | Decompilador infere `uint * FUN_00422430(uint *param_1, int param_2, uint *param_3)`. Ghidra marca a convenção como `unknown`; o `ret` comum é compatível com caller-cleanup, não prova sozinho `cdecl`. |
| Gerar C++ a partir das instruções exportadas | **PASSOU** | `GenerateStaticLift.py` verifica SHA-256, bytes PE, CSV, limites, CFG e subset de instruções; gera lowering estático para todas as 47 instruções. Não copia `lifted_lower_bound.cpp`. |
| Cobertura do primeiro lifter | **PASSOU** | 47/47 instruções, 122/122 bytes, 100%; zero instruções rejeitadas. Isso é cobertura desta função, não do executável todo. |
| Rejeição explícita de entrada não suportada | **PASSOU** | Quatro testes Python passam, incluindo opcode não suportado, bytes adulterados e desvio para endereço fora da função. |
| Compilar binário ARM64 | **PASSOU** | Android NDK gera ELF64 `AArch64`, PIE. SHA-256: `c6aea4e8c35a5fe838eeaca972e96afa06539cc044ab1a33b894f2665f2095cf`. |
| Executar em Android físico | **PASSOU** | Redmi 2303ERA42L, ABI `arm64-v8a`, Android 15; 16 vetores, zero falhas. O runner rejeita serial/modelo de emulador e exige um aparelho físico autorizado. |
| Executar referência original x86 nativa | **PASSOU** | 358 chamadas, zero falhas em Ryzen 5 2600 físico. Harness x86 copia os 122 bytes verificados para memória RW, muda a proteção para RX e chama a função sem imports ou chamadas externas no corpo. |
| Comparar resultados nos mesmos vetores | **PASSOU** | 16 casos compartilhados (populado, vazio e singleton): resultados de índice x86 e ARM64 idênticos; comparação reproduzível gravada em `cross_arch_comparison.json`. |
| Equivalência irrestrita para qualquer entrada | **BLOQUEADO** | Evidência cobre vetores válidos e definidos; ponteiros inválidos, range/subtração fora de pré-condição e efeitos de falha/exception do processo original não são cobertos. Não reivindicar equivalência fora do escopo de teste. |

Após a inclusão de `static_assert` para garantir o stride de 12 bytes nos dois harnesses, os testes foram repetidos: 4/4 testes do gerador passaram; referência x86, 358/358 casos; aparelho ARM64 físico, 16/16 casos; comparação compartilhada, 16/16 resultados idênticos. Os hashes SHA-256 do executável de origem, código gerado e binário ARM64 foram conferidos novamente.

### Fluxo de execução e artefatos

1. `ExportSporeFunction.java` exportou a função do Ghidra para `C:\SporeAnalysis\spore_function_00422430.json`; o export confirmou o hash da build.
2. Gerar novamente, se necessário:

   ```powershell
   $root = 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
   python "$root\GenerateStaticLift.py" `
     --exe 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe' `
     --csv 'C:\SporeAnalysis\spore_functions.csv' `
     --export 'C:\SporeAnalysis\spore_function_00422430.json' `
     --output "$root\spore_00422430_arm64.cpp" `
     --coverage "$root\spore_00422430_instruction_coverage.json"
   ```
3. Executar testes do gerador:

   ```powershell
   Set-Location 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
   python -m unittest -v test_static_lift_generator.py
   ```
4. Compilar e executar no aparelho ARM64 físico:

   ```powershell
   .\build_first_static_lift.ps1
   .\run_first_static_lift_on_device.ps1
   ```
5. Compilar/executar a referência nativa x86 e comparar os logs:

   ```powershell
   .\run_native_x86_reference.ps1
   python .\compare_static_lift_results.py
   ```

### Limitações semânticas

- O lowering usa registradores e flags de 32 bits e baixa as instruções estaticamente em código C++ com labels/gotos; não há fetch/decode de instruções x86 em runtime, nem tradutor dinâmico.
- A camada `FirstStaticLiftRuntime.hpp` mapeia registros, chave e stack para memória controlada do harness. Isso permite executar o corpo recompilado em ARM64 sem tentar usar ponteiros host de 64 bits como endereços x86.
- Os testes cobrem arrays de registros de 12 bytes ordenados, valores duplicados, chaves abaixo/acima e transição `0x7fffffff/0x80000000`, arrays vazios e singleton. O x86 também executou 342 casos de stress com array de 256 elementos.
- O harness compara os bytes da função no executável com os bytes esperados e o runner confere o hash integral antes da execução.
- A implementação não foi integrada ao boot do jogo. CRT/Win32/D3D9, runtime global, chamadas indiretas e as outras funções do jogo continuam fora desta fase.

## Segunda função traduzida

O inventário registra `FUN_00479c00` com 128 bytes. Seu export seletivo foi confirmado contra o mesmo SHA-256 do executável escolhido. O lifter gerou código para 47/47 instruções e o corpo recompilado foi comparado com a referência x86 nativa em cinco casos no aparelho ARM64 físico. O relatório específico, limitações, hashes e comandos estão em `SECOND_STATIC_RECOMPILATION_STATUS.md`.
