#!/usr/bin/env python3
"""Classify sampled DBPF resources by decoded content signatures."""

import argparse
import os
import re
import struct
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass

from catalog_dbpf_resources import (
    HEADER_SIZE,
    MAX_FOCUS_OUTPUT,
    REFPACK_LABEL,
    UNCOMPRESSED_LABEL,
    decompress_refpack,
    u16,
    u32,
    u64,
)


DEFAULT_SAMPLE_COUNT = 20
DEFAULT_MAX_SAMPLE_BYTES = MAX_FOCUS_OUTPUT
DEFAULT_MAX_TOTAL_BYTES = 512 * 1024 * 1024
RANDOM_MULTIPLIER = 25_214_903_917
RANDOM_INCREMENT = 11
RANDOM_MASK = (1 << 48) - 1
RW4_MAGIC = bytes.fromhex(
    "89 52 57 34 77 33 32 00 0D 0A 1A 0A 00 20 04 00 "
    "34 35 34 00 30 30 30 00 00 00 00 00"
)


@dataclass(frozen=True)
class ResourceSample:
    package: str
    type_id: int
    group_id: int
    instance_id: int
    entry_index: int
    offset: int
    stored_size: int
    memory_size: int
    compression: int


@dataclass
class TypeSamples:
    entry_count: int = 0
    samples: list = None

    def __post_init__(self):
        if self.samples is None:
            self.samples = []


def decode_entry(package_path, sample):
    with open(package_path, "rb") as package:
        package.seek(sample.offset)
        payload = package.read(sample.stored_size)
    if len(payload) != sample.stored_size:
        raise ValueError("short read of resource payload")
    if sample.compression == REFPACK_LABEL:
        return decompress_refpack(payload, sample.memory_size)
    if sample.compression != UNCOMPRESSED_LABEL:
        raise ValueError(f"unsupported compression 0x{sample.compression:04X}")
    if len(payload) != sample.memory_size:
        raise ValueError("uncompressed payload size differs from DBPF index")
    return payload


def iter_package_entries(path, root):
    package_name = os.path.relpath(path, root).replace("\\", "/")
    file_size = os.path.getsize(path)
    with open(path, "rb") as package:
        header = package.read(HEADER_SIZE)
        if len(header) != HEADER_SIZE or header[:4] != b"DBPF":
            raise ValueError(f"{package_name}: invalid or truncated DBPF header")
        if u32(header, 4) != 3 or u32(header, 8) != 0:
            raise ValueError(f"{package_name}: unsupported DBPF version")

        entry_count = u32(header, 0x24)
        index_size = u32(header, 0x2C)
        index_offset = u64(header, 0x40)
        if index_offset < HEADER_SIZE or index_offset > file_size:
            raise ValueError(f"{package_name}: invalid index offset")
        if index_size > file_size - index_offset:
            raise ValueError(f"{package_name}: index exceeds file bounds")
        package.seek(index_offset)
        index = package.read(index_size)
        if len(index) != index_size or len(index) < 4:
            raise ValueError(f"{package_name}: truncated index")

    flags = u32(index, 0)
    if flags & ~0x7:
        raise ValueError(f"{package_name}: unsupported index flags 0x{flags:X}")
    cursor = 4
    shared_type = u32(index, cursor) if flags & 0x1 else None
    cursor += 4 if flags & 0x1 else 0
    shared_group = u32(index, cursor) if flags & 0x2 else None
    cursor += 4 if flags & 0x2 else 0
    if flags & 0x4:
        if cursor + 4 > len(index):
            raise ValueError(f"{package_name}: truncated optional index word")
        cursor += 4

    for entry_index in range(entry_count):
        type_id = shared_type
        if type_id is None:
            if cursor + 4 > len(index):
                raise ValueError(f"{package_name}: truncated type at entry {entry_index}")
            type_id = u32(index, cursor)
            cursor += 4
        group_id = shared_group
        if group_id is None:
            if cursor + 4 > len(index):
                raise ValueError(f"{package_name}: truncated group at entry {entry_index}")
            group_id = u32(index, cursor)
            cursor += 4
        if cursor + 20 > len(index):
            raise ValueError(
                f"{package_name}: truncated resource record at entry {entry_index}"
            )
        instance_id, offset, stored_with_flag, memory_size = struct.unpack_from(
            "<IIII", index, cursor
        )
        cursor += 16
        compression = u16(index, cursor)
        saved = index[cursor + 2]
        cursor += 4
        stored_size = stored_with_flag & 0x7FFFFFFF

        if saved > 1:
            raise ValueError(f"{package_name}: invalid saved flag at entry {entry_index}")
        if compression not in (UNCOMPRESSED_LABEL, REFPACK_LABEL):
            raise ValueError(
                f"{package_name}: unsupported compression 0x{compression:04X}"
            )
        if offset < HEADER_SIZE or offset > index_offset:
            raise ValueError(f"{package_name}: invalid resource offset at entry {entry_index}")
        if stored_size > index_offset - offset:
            raise ValueError(
                f"{package_name}: resource exceeds data area at entry {entry_index}"
            )
        if compression == UNCOMPRESSED_LABEL and stored_size != memory_size:
            raise ValueError(
                f"{package_name}: raw resource has inconsistent sizes at entry {entry_index}"
            )

        yield ResourceSample(
            package_name,
            type_id,
            group_id,
            instance_id,
            entry_index,
            offset,
            stored_size,
            memory_size,
            compression,
        )

    if cursor != len(index):
        raise ValueError(
            f"{package_name}: index consumed {cursor} of {len(index)} bytes"
        )


def sample_resources(paths, root, sample_count):
    by_type = defaultdict(TypeSamples)
    random_state = 0x5EED
    for path in paths:
        for sample in iter_package_entries(path, root):
            stats = by_type[sample.type_id]
            stats.entry_count += 1
            if len(stats.samples) < sample_count:
                stats.samples.append(sample)
                continue
            random_state = (
                random_state * RANDOM_MULTIPLIER + RANDOM_INCREMENT
            ) & RANDOM_MASK
            position = random_state % stats.entry_count
            if position < sample_count:
                stats.samples[position] = sample
    return by_type


def looks_like_text(data, endian):
    if len(data) < 4:
        return False
    sample = data[: min(len(data), 4096)]
    even = sample[0::2]
    odd = sample[1::2]
    zero_ratio = (odd if endian == "le" else even).count(0) / max(
        1, len(odd if endian == "le" else even)
    )
    text_bytes = even if endian == "le" else odd
    printable_ratio = sum(
        byte in (9, 10, 13) or 32 <= byte <= 126 for byte in text_bytes
    ) / max(1, len(text_bytes))
    return zero_ratio >= 0.55 and printable_ratio >= 0.7


def classify_payload(data):
    matches = []
    prefix = data[:16]
    if prefix.startswith(b"DDS "):
        matches.append("DDS")
    if prefix.startswith(b"\x89PNG\r\n\x1a\n"):
        matches.append("PNG")
    if prefix.startswith(b"OggS"):
        matches.append("Ogg")
    if prefix.startswith(b"RIFF") and len(prefix) >= 12:
        riff_kind = prefix[8:12]
        if riff_kind == b"WAVE":
            matches.append("RIFF/WAVE")
        elif riff_kind == b"AVI ":
            matches.append("RIFF/AVI")
        else:
            matches.append("RIFF")
    if prefix.startswith(b"BM"):
        matches.append("BMP")
    if prefix.startswith(b"\xFF\xD8\xFF"):
        matches.append("JPEG")
    if prefix.startswith((b"PK\x03\x04", b"PK\x05\x06")):
        matches.append("ZIP")

    ascii_window = data[: min(len(data), 256 * 1024)]
    stripped = ascii_window.lstrip(b"\xef\xbb\xbf\x00\t\r\n ")
    if stripped.startswith((b"<?xml", b"<!DOCTYPE", b"<root", b"<Root")):
        matches.append("XML/ASCII")
    if stripped.startswith((b"float", b"sampler", b"technique", b"//")):
        matches.append("text/ASCII")
    if data.startswith(RW4_MAGIC) and len(data) >= 32:
        rw4_type = struct.unpack_from("<I", data, 28)[0]
        rw4_types = {
            1: "RW4-model",
            0x04000000: "RW4-texture",
            0xCAFED00D: "RW4-special",
        }
        matches.append(rw4_types.get(rw4_type, "RW4-unknown-type"))
    if data.startswith(b"\xFF\xFE") and looks_like_text(data[2:], "le"):
        matches.append("UTF-16LE-text")
    elif data.startswith(b"\xFE\xFF") and looks_like_text(data[2:], "be"):
        matches.append("UTF-16BE-text")
    elif looks_like_text(data, "le"):
        matches.append("UTF-16LE-text")

    lowered = ascii_window.lower()
    strong_hlsl_patterns = (
        rb"\bfloat[1-4]x[1-4]\s+[a-z_]\w*",
        rb"\btex2d\s*\(",
        rb"\btechnique\s+[a-z_]\w*\s*\{[^}]{0,512}\bpass\b",
        rb"\bsampler\w*\s+[a-z_]\w*\s*:\s*register\s*\(",
    )
    if any(re.search(pattern, lowered) for pattern in strong_hlsl_patterns):
        matches.append("HLSL-source-candidate")

    if not matches:
        matches.append("unknown/binary")
    return matches


def format_tgi(sample):
    return (
        f"0x{sample.type_id:08X}:0x{sample.group_id:08X}:"
        f"0x{sample.instance_id:08X}"
    )


def run_self_test():
    cases = [
        (b"DDS " + bytes(8), "DDS"),
        (b"\x89PNG\r\n\x1a\n" + bytes(8), "PNG"),
        (b"OggS" + bytes(8), "Ogg"),
        (b"RIFF" + bytes(4) + b"WAVE" + bytes(4), "RIFF/WAVE"),
        (b"<?xml version='1.0'?>", "XML/ASCII"),
        ("<root/>".encode("utf-16le"), "UTF-16LE-text"),
        (b"float4x4 transform; tex2D(diffuse, uv);", "HLSL-source-candidate"),
        (b"ordinary prose about the technique used by this author", None),
        (RW4_MAGIC + struct.pack("<I", 1), "RW4-model"),
    ]
    for payload, expected in cases:
        matches = classify_payload(payload)
        if expected is None and matches != ["unknown/binary"]:
            raise AssertionError(
                f"unexpected classification for negative case: {matches}"
            )
        if expected is not None and expected not in matches:
            raise AssertionError(f"{expected} missing from classification {matches}")
    if classify_payload(cases[-2][0]) != ["unknown/binary"]:
        raise AssertionError("ordinary prose was misclassified as shader source")
    print(f"self-test: PASS ({len(cases)} signature/text cases)")


def render_report(root, by_type, sample_count, max_sample_bytes, max_total_bytes):
    lines = [
        "# Classificação amostral dos tipos DBPF",
        "",
        f"- Raiz: `{os.path.abspath(root)}`",
        f"- Tipos encontrados: **{len(by_type)}**",
        f"- Amostras máximas por tipo: **{sample_count}**",
        f"- Limite por payload: **{max_sample_bytes:,} bytes**",
        f"- Orçamento total de payloads decodificados: **{max_total_bytes:,} bytes**",
        "- Método: amostragem determinística de índices; classificação por assinaturas "
        "do conteúdo descomprimido.",
        "",
        "## Resumo por tipo",
        "",
        "| Type ID | Entradas | Amostras | Decodificadas | Ignoradas por tamanho | Erros | Classificações |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]

    total_decoded = 0
    total_errors = 0
    details_by_type = {}
    for type_id in sorted(by_type, key=lambda item: (-by_type[item].entry_count, item)):
        stats = by_type[type_id]
        counts = Counter()
        details = []
        decoded_count = 0
        skipped_count = 0
        error_count = 0
        for sample in stats.samples:
            if sample.memory_size > max_sample_bytes:
                skipped_count += 1
                details.append((sample, "skipped-size", [], "exceeds per-sample limit"))
                continue
            if total_decoded + sample.memory_size > max_total_bytes:
                skipped_count += 1
                details.append((sample, "skipped-budget", [], "exceeds total decode budget"))
                continue

            package_path = os.path.join(root, *sample.package.split("/"))
            try:
                payload = decode_entry(package_path, sample)
            except (OSError, ValueError, struct.error) as error:
                error_count += 1
                total_errors += 1
                details.append((sample, "decode-error", [], str(error)))
                continue

            total_decoded += len(payload)
            decoded_count += 1
            matches = classify_payload(payload)
            counts.update(matches)
            details.append((sample, "decoded", matches, f"{len(payload):,} bytes"))

        total_type_samples = len(stats.samples)
        classification_text = ", ".join(
            f"{name}: {count}"
            for name, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        ) or "nenhuma amostra decodificada"
        lines.append(
            f"| `0x{type_id:08X}` | {stats.entry_count:,} | "
            f"{total_type_samples} | {decoded_count} | {skipped_count} | "
            f"{error_count} | {classification_text} |"
        )
        details_by_type[type_id] = details

    lines.extend([
        "",
        "## Amostras e evidências",
        "",
        "Uma assinatura indica apenas que os bytes iniciais ou texto do payload "
        "amostrado correspondem ao detector; não prova o papel completo do tipo. "
        "RW4 usa o magic de 28 bytes e códigos de tipo documentados pelo "
        "SporeModder FX; os payloads locais ainda precisam de validação estrutural "
        "do manifesto e das seções. `HLSL-source-candidate` exige marcadores "
        "sintáticos mais fortes que palavras isoladas como `technique`. Recursos "
        "ignorados por tamanho/orçamento e falhas de decode são listados "
        "explicitamente.",
        "",
    ])
    for type_id in sorted(by_type, key=lambda item: (-by_type[item].entry_count, item)):
        lines.extend([
            f"### `0x{type_id:08X}` — {by_type[type_id].entry_count:,} entradas",
            "",
            "| Status | TGI | Package | Payload | Classificação/observação |",
            "|---|---|---|---:|---|",
        ])
        for sample, status, matches, note in details_by_type[type_id]:
            labels = ", ".join(matches) if matches else note
            lines.append(
                f"| {status} | `{format_tgi(sample)}` | `{sample.package}` | "
                f"{sample.memory_size:,} | {labels} — {note if matches else ''} |"
            )
        lines.append("")

    lines.extend([
        "## Limites",
        "",
        "- A amostra é limitada e determinística; conteúdo raro pode não aparecer.",
        "- A amostragem inclui entradas repetidas entre packages como registros "
        "distintos; ela não resolve precedência de montagem.",
        "- Payloads maiores que os limites são contados, mas não decodificados.",
        "- `unknown/binary` significa que os detectores implementados não "
        "reconheceram o conteúdo, não que ele seja opaco ou não documentado.",
        "- A classificação de texto/HLSL é heurística. A confirmação de um formato "
        "exige parser ou validação estrutural própria.",
        "- O magic RW4 segue `RWHeader.java` do SporeModder FX: "
        "https://github.com/Spore-Community/SporeModder-FX/blob/master/"
        "src/sporemodder/file/rw4/RWHeader.java",
        f"- Payloads efetivamente decodificados: **{total_decoded:,} bytes**; "
        f"erros de decode: **{total_errors}**.",
        "",
    ])
    return "\n".join(lines), total_errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", help="SPOREFILES root")
    parser.add_argument("--output", help="Markdown report path")
    parser.add_argument(
        "--samples-per-type",
        type=int,
        default=DEFAULT_SAMPLE_COUNT,
        help=f"maximum decoded samples per type (default: {DEFAULT_SAMPLE_COUNT})",
    )
    parser.add_argument(
        "--max-sample-bytes",
        type=int,
        default=DEFAULT_MAX_SAMPLE_BYTES,
        help="skip individual payloads larger than this",
    )
    parser.add_argument(
        "--max-total-bytes",
        type=int,
        default=DEFAULT_MAX_TOTAL_BYTES,
        help="maximum total decoded bytes across selected samples",
    )
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return 0
    if not args.root or not args.output:
        parser.error("--root and --output are required unless --self-test is used")
    if args.samples_per_type <= 0 or args.max_sample_bytes <= 0 or args.max_total_bytes <= 0:
        parser.error("sample count and byte limits must be positive")
    if args.max_sample_bytes > MAX_FOCUS_OUTPUT:
        parser.error(
            f"--max-sample-bytes cannot exceed the decoder limit {MAX_FOCUS_OUTPUT}"
        )
    root = os.path.abspath(args.root)
    if not os.path.isdir(root):
        parser.error(f"package root does not exist: {root}")

    paths = []
    for directory, _, filenames in os.walk(root):
        for filename in filenames:
            if filename.lower().endswith(".package"):
                paths.append(os.path.join(directory, filename))
    paths.sort(key=str.casefold)
    if not paths:
        parser.error(f"no .package files found under {root}")

    by_type = sample_resources(paths, root, args.samples_per_type)
    report, error_count = render_report(
        root,
        by_type,
        args.samples_per_type,
        args.max_sample_bytes,
        args.max_total_bytes,
    )
    output_path = os.path.abspath(args.output)
    with open(output_path, "w", encoding="utf-8", newline="\n") as output:
        output.write(report)
    sampled = sum(len(item.samples) for item in by_type.values())
    print(
        f"wrote {output_path}: {len(by_type)} types, {sampled} selected samples, "
        f"{error_count} decode errors"
    )
    return 1 if error_count else 0


if __name__ == "__main__":
    sys.exit(main())
