#include "dbpf_reader.hpp"

#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

std::uint32_t parse_u32(const std::string& value) {
    std::size_t consumed = 0;
    const auto parsed = std::stoull(value, &consumed, 0);
    if (consumed != value.size() || parsed > 0xFFFFFFFFULL) {
        throw std::invalid_argument("invalid 32-bit integer: " + value);
    }
    return static_cast<std::uint32_t>(parsed);
}

void write_file(const std::string& path,
                const std::vector<std::uint8_t>& data) {
    std::ofstream output(path, std::ios::binary);
    if (!output) {
        throw std::runtime_error("cannot create output file: " + path);
    }
    if (!data.empty()) {
        output.write(reinterpret_cast<const char*>(data.data()),
                     static_cast<std::streamsize>(data.size()));
    }
    if (!output) {
        throw std::runtime_error("failed writing output file: " + path);
    }
}

int self_test() {
    const std::vector<std::uint8_t> copy_stream{
        0x10, 0xFB, 0x00, 0x00, 0x04, 0x01, 0x00, 'a'
    };
    const auto repeated = spore::decompress_refpack(copy_stream, 4);
    if (repeated != std::vector<std::uint8_t>{'a', 'a', 'a', 'a'}) {
        throw std::runtime_error("RefPack overlapping-copy self-test failed");
    }

    const std::vector<std::uint8_t> literal_stream{
        0x50, 0xFB, 0x00, 0x00, 0x03, 0xFF, 'S', 'p', 'r'
    };
    const auto literal = spore::decompress_refpack(literal_stream, 3);
    if (literal != std::vector<std::uint8_t>{'S', 'p', 'r'}) {
        throw std::runtime_error("RefPack literal self-test failed");
    }

    const std::vector<std::uint8_t> extended_size_stream{
        0x90, 0xFB, 0x00, 0x00, 0x00, 0x03, 0xFF, 'S', 'p', 'r'
    };
    const auto extended_size =
        spore::decompress_refpack(extended_size_stream, 3);
    if (extended_size != std::vector<std::uint8_t>{'S', 'p', 'r'}) {
        throw std::runtime_error("RefPack extended-size self-test failed");
    }

    if (spore::fnv1_ascii_lower("cell") != 0xDFAD9F51) {
        throw std::runtime_error("FNV-1 candidate self-test failed");
    }
    if (spore::fnv1a_ascii_lower("cell") != 0x68DC9CB5) {
        throw std::runtime_error("FNV-1a candidate self-test failed");
    }

    bool malformed_stream_rejected = false;
    try {
        (void)spore::decompress_refpack(
            std::vector<std::uint8_t>{0x10, 0xFB, 0x00, 0x00, 0x04, 0x01, 0x00},
            4);
    } catch (const std::runtime_error&) {
        malformed_stream_rejected = true;
    }
    if (!malformed_stream_rejected) {
        throw std::runtime_error("RefPack malformed-stream self-test failed");
    }
    std::cout << "self-test: PASS (RefPack literal/copy/extended-size/error, "
                 "candidate FNV vectors)\n";
    return 0;
}

void print_info(spore::DbpfPackage& package) {
    const auto& header = package.header();
    std::size_t compressed = 0;
    for (const auto& entry : package.entries()) {
        compressed += entry.is_compressed() ? 1 : 0;
    }
    std::cout << "format=DBPF " << header.major_version << '.'
              << header.minor_version << '\n'
              << "entries=" << header.entry_count << '\n'
              << "compressed_entries=" << compressed << '\n'
              << "index_offset=0x" << std::hex << header.index_offset
              << std::dec << '\n'
              << "index_size=" << header.index_size << '\n'
              << "index_minor_version=" << header.index_minor_version << '\n';
}

int run(int argc, char** argv) {
    if (argc == 2 && std::string(argv[1]) == "--self-test") {
        return self_test();
    }
    if (argc < 3) {
        std::cerr << "usage:\n"
                  << "  spore_dbpf info <package>\n"
                  << "  spore_dbpf list <package>\n"
                  << "  spore_dbpf verify <package>\n"
                  << "  spore_dbpf extract <package> <type> <group> <instance> <output>\n"
                  << "  spore_dbpf hash <name>\n"
                  << "  spore_dbpf --self-test\n";
        return 2;
    }

    const std::string command = argv[1];
    if (command == "hash") {
        if (argc != 3) throw std::invalid_argument("hash expects one name");
        std::cout << "FNV-1(lower ASCII)  " << spore::hex32(spore::fnv1_ascii_lower(argv[2])) << '\n'
                  << "FNV-1a(lower ASCII) " << spore::hex32(spore::fnv1a_ascii_lower(argv[2])) << '\n';
        return 0;
    }

    spore::DbpfPackage package(argv[2]);
    if (command == "info") {
        if (argc != 3) throw std::invalid_argument("info expects one package");
        print_info(package);
        return 0;
    }
    if (command == "list") {
        if (argc != 3) throw std::invalid_argument("list expects one package");
        print_info(package);
        for (std::size_t i = 0; i < package.entries().size(); ++i) {
            const auto& entry = package.entries()[i];
            std::cout << i << '\t' << spore::hex32(entry.key.type) << '\t'
                      << spore::hex32(entry.key.group) << '\t'
                      << spore::hex32(entry.key.instance) << '\t'
                      << "offset=0x" << std::hex << entry.offset << std::dec << '\t'
                      << "stored=" << entry.stored_size << '\t'
                      << "memory=" << entry.memory_size << '\t'
                      << (entry.is_compressed() ? "RefPack" : "none") << '\n';
        }
        return 0;
    }
    if (command == "verify") {
        if (argc != 3) throw std::invalid_argument("verify expects one package");
        std::uint64_t total_memory = 0;
        for (std::size_t i = 0; i < package.entries().size(); ++i) {
            const auto bytes = package.read_entry(i);
            total_memory += bytes.size();
        }
        std::cout << "verify=PASS\nentries=" << package.entries().size()
                  << "\ndecoded_bytes=" << total_memory << '\n';
        return 0;
    }
    if (command == "extract") {
        if (argc != 7) throw std::invalid_argument("extract expects package, TGI and output");
        const spore::Tgi key{parse_u32(argv[3]), parse_u32(argv[4]),
                             parse_u32(argv[5])};
        const auto index = package.find(key);
        if (index == package.entries().size()) {
            throw std::runtime_error("TGI not found in package");
        }
        const auto bytes = package.read_entry(index);
        write_file(argv[6], bytes);
        std::cout << "extracted_entry=" << index << "\nbytes=" << bytes.size() << '\n';
        return 0;
    }
    throw std::invalid_argument("unknown command: " + command);
}

}  // namespace

int main(int argc, char** argv) {
    try {
        return run(argc, argv);
    } catch (const std::exception& error) {
        std::cerr << "error: " << error.what() << '\n';
        return 1;
    }
}
