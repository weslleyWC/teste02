# Classificação amostral dos tipos DBPF

- Raiz: `C:\Program Files (x86)\steam\steamapps\common\Spore\SPOREFILES`
- Tipos encontrados: **90**
- Amostras máximas por tipo: **20**
- Limite por payload: **67,108,864 bytes**
- Orçamento total de payloads decodificados: **536,870,912 bytes**
- Método: amostragem determinística de índices; classificação por assinaturas do conteúdo descomprimido.

## Resumo por tipo

| Type ID | Entradas | Amostras | Decodificadas | Ignoradas por tamanho | Erros | Classificações |
|---|---:|---:|---:|---:|---:|---|
| `0x01A527DB` | 33,781 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x00B1B104` | 30,925 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x02B9F662` | 19,631 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x2F7D0004` | 14,711 | 20 | 20 | 0 | 0 | PNG: 20 |
| `0x2F4E681B` | 13,572 | 20 | 20 | 0 | 0 | RW4-texture: 8, RW4-model: 7, RW4-special: 5 |
| `0x00E6BCE5` | 11,041 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x2F4E681C` | 5,931 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0xEE17C6AD` | 5,022 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x5CAA5E28` | 3,282 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x01C135DA` | 2,756 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x1A99B06B` | 2,625 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x030BDEE3` | 2,598 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x02D5C9AF` | 2,590 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x0F43029A` | 1,365 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x250FE9A2` | 748 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x02FAC0B6` | 590 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0xDFAD9F51` | 489 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x4B9EF6DC` | 376 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x617715D9` | 318 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x024A0E52` | 160 | 20 | 20 | 0 | 0 | unknown/binary: 19, text/ASCII: 1 |
| `0x02393756` | 153 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x497767B9` | 126 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x055ADA24` | 124 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0xD92AF091` | 115 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x022D2C83` | 97 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x0472329B` | 97 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x03E421ED` | 96 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x03F51892` | 95 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x2B978C46` | 94 | 20 | 20 | 0 | 0 | XML/ASCII: 20 |
| `0x3C7E0F63` | 86 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x03055F61` | 81 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x366A930D` | 69 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x06EFC6AA` | 68 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0xDA141C1B` | 64 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x0497925E` | 63 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0xF2B924B3` | 52 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x01EEF63A` | 42 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0xEA5118B0` | 42 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x25DF0112` | 39 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x02D5C9B0` | 37 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x9B8E862F` | 37 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x02C9EFF2` | 36 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x0469A3F7` | 36 | 20 | 20 | 0 | 0 | unknown/binary: 12, HLSL-source-candidate: 8 |
| `0x047B8300` | 32 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x3D97A8E4` | 26 | 20 | 20 | 0 | 0 | XML/ASCII: 20 |
| `0xF9C3D770` | 22 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x8C042499` | 20 | 20 | 20 | 0 | 0 | unknown/binary: 20 |
| `0x448AE7E2` | 18 | 18 | 18 | 0 | 0 | unknown/binary: 18 |
| `0x04805684` | 16 | 16 | 16 | 0 | 0 | unknown/binary: 16 |
| `0xFD60F0C1` | 16 | 16 | 16 | 0 | 0 | unknown/binary: 16 |
| `0xCF6C21B8` | 14 | 14 | 14 | 0 | 0 | XML/ASCII: 14 |
| `0x027C5CEF` | 10 | 10 | 10 | 0 | 0 | unknown/binary: 10 |
| `0x0330A65E` | 10 | 10 | 10 | 0 | 0 | XML/ASCII: 10 |
| `0x03E421E9` | 10 | 10 | 10 | 0 | 0 | unknown/binary: 10 |
| `0x5C74D18B` | 10 | 10 | 10 | 0 | 0 | unknown/binary: 10 |
| `0x0248F226` | 9 | 9 | 9 | 0 | 0 | text/ASCII: 5, unknown/binary: 4 |
| `0x029E333B` | 9 | 9 | 9 | 0 | 0 | unknown/binary: 9 |
| `0x24682294` | 8 | 8 | 8 | 0 | 0 | XML/ASCII: 8 |
| `0x042C9CBB` | 6 | 6 | 6 | 0 | 0 | unknown/binary: 6 |
| `0x02CB4F2F` | 4 | 4 | 4 | 0 | 0 | unknown/binary: 4 |
| `0x12952634` | 4 | 4 | 4 | 0 | 0 | unknown/binary: 4 |
| `0x2F7D0006` | 4 | 4 | 4 | 0 | 0 | unknown/binary: 4 |
| `0x376840D7` | 4 | 4 | 4 | 0 | 0 | unknown/binary: 4 |
| `0x476A98C7` | 4 | 4 | 4 | 0 | 0 | XML/ASCII: 4 |
| `0x4AEB6BC6` | 4 | 4 | 4 | 0 | 0 | unknown/binary: 4 |
| `0x617715C4` | 4 | 4 | 4 | 0 | 0 | unknown/binary: 4 |
| `0x00000000` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x03E421EC` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x03E421EF` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x05BAD11C` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x2A3CE5B7` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x2B6CAB5F` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x2B7DF427` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x37979F71` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x7C19AA7A` | 3 | 3 | 3 | 0 | 0 | unknown/binary: 3 |
| `0x02523258` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0x065266B7` | 2 | 2 | 2 | 0 | 0 | XML/ASCII: 2 |
| `0x1F639D98` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0x2399BE55` | 2 | 2 | 2 | 0 | 0 | XML/ASCII: 2 |
| `0x3C77532E` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0x433FB70C` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0x438F6347` | 2 | 2 | 2 | 0 | 0 | XML/ASCII: 2 |
| `0x612B3191` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0x754BE343` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0xDBA35AE2` | 2 | 2 | 2 | 0 | 0 | unknown/binary: 2 |
| `0x14885D1C` | 1 | 1 | 1 | 0 | 0 | unknown/binary: 1 |
| `0x191C3C61` | 1 | 1 | 1 | 0 | 0 | unknown/binary: 1 |
| `0x1E99B626` | 1 | 1 | 1 | 0 | 0 | unknown/binary: 1 |
| `0x2081B4F5` | 1 | 1 | 1 | 0 | 0 | unknown/binary: 1 |
| `0x3F9C28B5` | 1 | 1 | 1 | 0 | 0 | RIFF: 1 |

## Amostras e evidências

Uma assinatura indica apenas que os bytes iniciais ou texto do payload amostrado correspondem ao detector; não prova o papel completo do tipo. RW4 usa o magic de 28 bytes e códigos de tipo documentados pelo SporeModder FX; os payloads locais ainda precisam de validação estrutural do manifesto e das seções. `HLSL-source-candidate` exige marcadores sintáticos mais fortes que palavras isoladas como `technique`. Recursos ignorados por tamanho/orçamento e falhas de decode são listados explicitamente.

### `0x01A527DB` — 33,781 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x01A527DB:0x021407EE:0x48F137D1` | `DataEP1/Spore_EP1_Data.package` | 5,395 | unknown/binary — 5,395 bytes |
| decoded | `0x01A527DB:0x021407EE:0x4627169C` | `Data/Spore_Audio1.package` | 22,512 | unknown/binary — 22,512 bytes |
| decoded | `0x01A527DB:0x021407EE:0x331B2405` | `Data/Spore_Audio1.package` | 60,417 | unknown/binary — 60,417 bytes |
| decoded | `0x01A527DB:0x021407EE:0x8D9FFCCB` | `Data/Spore_Audio1.package` | 45,754 | unknown/binary — 45,754 bytes |
| decoded | `0x01A527DB:0x021407EE:0xDE5E8987` | `Data/Spore_Audio1.package` | 505,112 | unknown/binary — 505,112 bytes |
| decoded | `0x01A527DB:0x021407EE:0x85F38BBE` | `Data/Spore_Audio1.package` | 21,552 | unknown/binary — 21,552 bytes |
| decoded | `0x01A527DB:0x021407EE:0xFF20A35D` | `Data/Spore_Audio1.package` | 15,832 | unknown/binary — 15,832 bytes |
| decoded | `0x01A527DB:0x021407EE:0x1BFBEEFB` | `bp1content/BoosterPack_01.package` | 4,192 | unknown/binary — 4,192 bytes |
| decoded | `0x01A527DB:0x021407EE:0x1A5625BE` | `DataEP1/Spore_EP1_Data.package` | 28,996 | unknown/binary — 28,996 bytes |
| decoded | `0x01A527DB:0x021407EE:0xAED91A0B` | `bp1content/BoosterPack_01.package` | 12,195 | unknown/binary — 12,195 bytes |
| decoded | `0x01A527DB:0x021407EE:0x1C92A995` | `Data/Spore_Audio1.package` | 28,879 | unknown/binary — 28,879 bytes |
| decoded | `0x01A527DB:0x021407EE:0xB5F88991` | `Data/Spore_Audio1.package` | 12,133 | unknown/binary — 12,133 bytes |
| decoded | `0x01A527DB:0x021407EE:0x0C3BA73D` | `Data/Spore_Audio1.package` | 92,232 | unknown/binary — 92,232 bytes |
| decoded | `0x01A527DB:0x021407EE:0x169D72D7` | `DataEP1/Spore_EP1_Data.package` | 12,723 | unknown/binary — 12,723 bytes |
| decoded | `0x01A527DB:0x021407EE:0xE1BCE410` | `bp1content/BoosterPack_01.package` | 7,770 | unknown/binary — 7,770 bytes |
| decoded | `0x01A527DB:0x021407EE:0x189C9D9A` | `Data/Spore_Audio1.package` | 17,724 | unknown/binary — 17,724 bytes |
| decoded | `0x01A527DB:0x021407EE:0x90188B8F` | `Data/Spore_Audio1.package` | 54,128 | unknown/binary — 54,128 bytes |
| decoded | `0x01A527DB:0x021407EE:0x5B8BEE66` | `DataEP1/Spore_EP1_Data.package` | 46,162 | unknown/binary — 46,162 bytes |
| decoded | `0x01A527DB:0x021407EE:0x157F9CD0` | `bp1content/BoosterPack_01.package` | 5,856 | unknown/binary — 5,856 bytes |
| decoded | `0x01A527DB:0x021407EE:0x5CC4C907` | `Data/Spore_Audio1.package` | 50,587 | unknown/binary — 50,587 bytes |

### `0x00B1B104` — 30,925 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x00B1B104:0x4E5892EB:0x4468C6BA` | `Data/Spore_Graphics.package` | 592 | unknown/binary — 592 bytes |
| decoded | `0x00B1B104:0x40646000:0x2B0C1257` | `Data/PatchData.package` | 116 | unknown/binary — 116 bytes |
| decoded | `0x00B1B104:0x406A0200:0x5F66811E` | `Data/PatchData.package` | 184 | unknown/binary — 184 bytes |
| decoded | `0x00B1B104:0x00000000:0x8A255677` | `Data/PatchData.package` | 52 | unknown/binary — 52 bytes |
| decoded | `0x00B1B104:0x40636000:0x276B0D4E` | `Data/Spore_Graphics.package` | 748 | unknown/binary — 748 bytes |
| decoded | `0x00B1B104:0x02E9C426:0x39C5CF5C` | `Data/PatchData.package` | 96 | unknown/binary — 96 bytes |
| decoded | `0x00B1B104:0x406A0200:0xB0E951A4` | `Data/PatchData.package` | 738 | unknown/binary — 738 bytes |
| decoded | `0x00B1B104:0x9430ADD7:0x65A78789` | `DataEP1/Spore_EP1_Data.package` | 124 | unknown/binary — 124 bytes |
| decoded | `0x00B1B104:0x40470102:0x046170A7` | `DataEP1/Spore_EP1_Data.package` | 130 | unknown/binary — 130 bytes |
| decoded | `0x00B1B104:0x40646000:0x94CFEA82` | `Data/PatchData.package` | 834 | unknown/binary — 834 bytes |
| decoded | `0x00B1B104:0x40646200:0x067B506F` | `Data/PatchData.package` | 958 | unknown/binary — 958 bytes |
| decoded | `0x00B1B104:0xD87454E6:0xC82DAF75` | `DataEP1/Spore_EP1_Data.package` | 621 | unknown/binary — 621 bytes |
| decoded | `0x00B1B104:0xD87454E6:0x0C836597` | `DataEP1/Spore_EP1_Data.package` | 621 | unknown/binary — 621 bytes |
| decoded | `0x00B1B104:0x40646200:0xD4E3888E` | `Data/PatchData.package` | 798 | unknown/binary — 798 bytes |
| decoded | `0x00B1B104:0x30608F0B:0x1E180798` | `Data/Spore_Game.package` | 2,653 | unknown/binary — 2,653 bytes |
| decoded | `0x00B1B104:0x5267DE50:0xDCDF2F2F` | `Data/PatchData.package` | 1,648 | unknown/binary — 1,648 bytes |
| decoded | `0x00B1B104:0x01B68DB4:0xCE0EC3BD` | `Data/Spore_Game.package` | 1,103 | unknown/binary — 1,103 bytes |
| decoded | `0x00B1B104:0x40636200:0x07E832FF` | `DataEP1/Spore_EP1_Content_02.package` | 435 | unknown/binary — 435 bytes |
| decoded | `0x00B1B104:0x40666200:0xBEAE5501` | `Data/Spore_Content.package` | 338 | unknown/binary — 338 bytes |
| decoded | `0x00B1B104:0x02E9C426:0x77DEBD98` | `Data/PatchData.package` | 94 | unknown/binary — 94 bytes |

### `0x02B9F662` — 19,631 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02B9F662:0x021407EE:0x850C4CCB` | `DataEP1/Spore_EP1_Data.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x02B9F662:0x021407EE:0x81CC263B` | `DataEP1/Spore_EP1_Data.package` | 80 | unknown/binary — 80 bytes |
| decoded | `0x02B9F662:0x021407EE:0x5FEB5FFF` | `Data/Spore_Audio2.package` | 101 | unknown/binary — 101 bytes |
| decoded | `0x02B9F662:0x021407EE:0xA0A98CEA` | `Data/Spore_Audio2.package` | 221 | unknown/binary — 221 bytes |
| decoded | `0x02B9F662:0x021407EE:0xE5A3C0EA` | `Data/PatchData.package` | 188 | unknown/binary — 188 bytes |
| decoded | `0x02B9F662:0x021407EE:0xF083A995` | `Data/PatchData.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x02B9F662:0x021407EE:0x9CCE68B5` | `Data/PatchData.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x02B9F662:0x021407EE:0x954D63A4` | `Data/PatchData.package` | 140 | unknown/binary — 140 bytes |
| decoded | `0x02B9F662:0x021407EE:0xEA2363E1` | `Data/Spore_Audio2.package` | 80 | unknown/binary — 80 bytes |
| decoded | `0x02B9F662:0x021407EE:0x41D8BBB5` | `Data/Spore_Audio2.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x02B9F662:0x021407EE:0x51D62AAB` | `Data/PatchData.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0x02B9F662:0x021407EE:0xDAEF010E` | `Data/Spore_Audio2.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x02B9F662:0x021407EE:0x60794ECA` | `Data/Spore_Audio2.package` | 80 | unknown/binary — 80 bytes |
| decoded | `0x02B9F662:0x021407EE:0x47C2159F` | `Data/Spore_Audio2.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x02B9F662:0x021407EE:0x2F65E4BC` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x02B9F662:0x021407EE:0xC8192981` | `Data/PatchData.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x02B9F662:0x021407EE:0xEEDD9580` | `Data/PatchData.package` | 200 | unknown/binary — 200 bytes |
| decoded | `0x02B9F662:0x021407EE:0x455DFC9A` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x02B9F662:0x021407EE:0xFC0408CA` | `Data/Spore_Audio2.package` | 176 | unknown/binary — 176 bytes |
| decoded | `0x02B9F662:0x021407EE:0xDAF51C57` | `Data/Spore_Audio2.package` | 56 | unknown/binary — 56 bytes |

### `0x2F7D0004` — 14,711 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2F7D0004:0x100D977C:0xA978118A` | `Data/Spore_Graphics.package` | 3,300 | PNG — 3,300 bytes |
| decoded | `0x2F7D0004:0x65928944:0xBA83D58F` | `DataEP1/Spore_EP1_Data.package` | 6,565 | PNG — 6,565 bytes |
| decoded | `0x2F7D0004:0x8A7BE0C0:0x439F9849` | `DataEP1/Spore_EP1_Data.package` | 3,625 | PNG — 3,625 bytes |
| decoded | `0x2F7D0004:0x02289318:0xF0EDEE09` | `Data/Spore_Graphics.package` | 5,979 | PNG — 5,979 bytes |
| decoded | `0x2F7D0004:0x99C7F284:0x327DFAB8` | `Data/Spore_Graphics.package` | 22,296 | PNG — 22,296 bytes |
| decoded | `0x2F7D0004:0x40636200:0x077981C6` | `DataEP1/Spore_EP1_Content_02.package` | 24,783 | PNG — 24,783 bytes |
| decoded | `0x2F7D0004:0x011C0C08:0x75AA0FF3` | `Data/Spore_Graphics.package` | 2,834 | PNG — 2,834 bytes |
| decoded | `0x2F7D0004:0x40666200:0x1044D695` | `Data/Spore_Content.package` | 27,131 | PNG — 27,131 bytes |
| decoded | `0x2F7D0004:0xF13D3D23:0xE8DE5F4B` | `Data/Spore_Graphics.package` | 9,931 | PNG — 9,931 bytes |
| decoded | `0x2F7D0004:0x91B125E5:0x66DE5D51` | `Data/Spore_Graphics.package` | 10,518 | PNG — 10,518 bytes |
| decoded | `0x2F7D0004:0x710F2470:0x7DA7E228` | `Data/PatchData.package` | 20,201 | PNG — 20,201 bytes |
| decoded | `0x2F7D0004:0x710F2470:0x12E5C4D5` | `Data/Spore_Graphics.package` | 21,209 | PNG — 21,209 bytes |
| decoded | `0x2F7D0004:0xD509FFBF:0x16705BD2` | `Data/Spore_Graphics.package` | 2,760 | PNG — 2,760 bytes |
| decoded | `0x2F7D0004:0x40636200:0x0679F5DE` | `Data/Spore_Content.package` | 30,295 | PNG — 30,295 bytes |
| decoded | `0x2F7D0004:0x65928944:0xE5CD0FBC` | `DataEP1/Spore_EP1_Data.package` | 11,949 | PNG — 11,949 bytes |
| decoded | `0x2F7D0004:0x31A44893:0x108D800D` | `Data/Spore_Graphics.package` | 9,814 | PNG — 9,814 bytes |
| decoded | `0x2F7D0004:0x02E9A2CA:0x9F1DE296` | `Data/Spore_Graphics.package` | 2,878 | PNG — 2,878 bytes |
| decoded | `0x2F7D0004:0x31A44893:0xFCB7F8F5` | `Data/PatchData.package` | 184,866 | PNG — 184,866 bytes |
| decoded | `0x2F7D0004:0x100D977C:0xD2C8B176` | `Data/Spore_Graphics.package` | 5,228 | PNG — 5,228 bytes |
| decoded | `0x2F7D0004:0x8A7BE0C0:0xA6B05D09` | `DataEP1/Spore_EP1_Data.package` | 3,489 | PNG — 3,489 bytes |

### `0x2F4E681B` — 13,572 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2F4E681B:0x00000000:0x39F1B4A2` | `Data/Spore_Graphics.package` | 22,244 | RW4-texture — 22,244 bytes |
| decoded | `0x2F4E681B:0x40636200:0x06725717` | `Data/Spore_Content.package` | 66,600 | RW4-special — 66,600 bytes |
| decoded | `0x2F4E681B:0x00000000:0xA86669A1` | `Data/Spore_Graphics.package` | 44,076 | RW4-texture — 44,076 bytes |
| decoded | `0x2F4E681B:0x40606000:0x44B1EDE6` | `Data/Spore_Graphics.package` | 590,352 | RW4-model — 590,352 bytes |
| decoded | `0x2F4E681B:0x00000000:0xEA7D97CB` | `Data/Spore_Graphics.package` | 22,244 | RW4-texture — 22,244 bytes |
| decoded | `0x2F4E681B:0x41606100:0x3B9D9564` | `Data/Spore_Content.package` | 9,192 | RW4-special — 9,192 bytes |
| decoded | `0x2F4E681B:0x441BBD49:0x593A20B4` | `DataEP1/Spore_EP1_Data.package` | 371,276 | RW4-model — 371,276 bytes |
| decoded | `0x2F4E681B:0x40636200:0x07C8A001` | `DataEP1/Spore_EP1_Content_02.package` | 57,272 | RW4-special — 57,272 bytes |
| decoded | `0x2F4E681B:0x406A2100:0xA049E52D` | `Data/Spore_Graphics.package` | 22,244 | RW4-texture — 22,244 bytes |
| decoded | `0x2F4E681B:0x40636200:0x078FEAE8` | `DataEP1/Spore_EP1_Content_02.package` | 15,784 | RW4-special — 15,784 bytes |
| decoded | `0x2F4E681B:0x40656200:0x066DD807` | `Data/Spore_Content.package` | 112,680 | RW4-special — 112,680 bytes |
| decoded | `0x2F4E681B:0x00000000:0xD192A66D` | `Data/Spore_Graphics.package` | 57,972 | RW4-model — 57,972 bytes |
| decoded | `0x2F4E681B:0x406A2100:0xF5D3D4A2` | `Data/PatchData.package` | 22,244 | RW4-texture — 22,244 bytes |
| decoded | `0x2F4E681B:0x00000000:0xA9EC7D6B` | `Data/Spore_Graphics.package` | 1,398,472 | RW4-texture — 1,398,472 bytes |
| decoded | `0x2F4E681B:0x441BBD49:0x1340A384` | `DataEP1/Spore_EP1_Data.package` | 2,012 | RW4-model — 2,012 bytes |
| decoded | `0x2F4E681B:0x00000000:0x714C7978` | `Data/Spore_Graphics.package` | 87,752 | RW4-texture — 87,752 bytes |
| decoded | `0x2F4E681B:0x406A2100:0x9A6729EB` | `Data/Spore_Graphics.package` | 22,244 | RW4-texture — 22,244 bytes |
| decoded | `0x2F4E681B:0x40606100:0x363C86DD` | `Data/Spore_Graphics.package` | 53,284 | RW4-model — 53,284 bytes |
| decoded | `0x2F4E681B:0x00000000:0x3D5E64AC` | `Data/Spore_Graphics.package` | 7,604 | RW4-model — 7,604 bytes |
| decoded | `0x2F4E681B:0x40606100:0x17A60A7F` | `bp1content/BoosterPack_01.package` | 294,944 | RW4-model — 294,944 bytes |

### `0x00E6BCE5` — 11,041 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x00E6BCE5:0x40637E00:0x07E83301` | `DataEP1/Spore_EP1_Content_02.package` | 124,548 | unknown/binary — 124,548 bytes |
| decoded | `0x00E6BCE5:0x40637E03:0x077ADC8E` | `DataEP1/Spore_EP1_Content_02.package` | 11,174 | unknown/binary — 11,174 bytes |
| decoded | `0x00E6BCE5:0x40666202:0x07730CE8` | `DataEP1/Spore_EP1_Content_01.package` | 36,194 | unknown/binary — 36,194 bytes |
| decoded | `0x00E6BCE5:0x40627100:0x8D230A9B` | `Data/Spore_Content.package` | 614,336 | unknown/binary — 614,336 bytes |
| decoded | `0x00E6BCE5:0x40637E03:0x067CEDFB` | `Data/Spore_Content.package` | 6,934 | unknown/binary — 6,934 bytes |
| decoded | `0x00E6BCE5:0x40627101:0x065CBFF4` | `Data/Spore_Content.package` | 467,176 | unknown/binary — 467,176 bytes |
| decoded | `0x00E6BCE5:0x40627101:0x065CBF48` | `Data/Spore_Content.package` | 152,096 | unknown/binary — 152,096 bytes |
| decoded | `0x00E6BCE5:0x40637100:0x07EC688B` | `DataEP1/Spore_EP1_Content_02.package` | 207,664 | unknown/binary — 207,664 bytes |
| decoded | `0x00E6BCE5:0x40636200:0x0771F2CF` | `DataEP1/Spore_EP1_Content_02.package` | 587,548 | unknown/binary — 587,548 bytes |
| decoded | `0x00E6BCE5:0x40646203:0x0679C27B` | `Data/Spore_Content.package` | 29,208 | unknown/binary — 29,208 bytes |
| decoded | `0x00E6BCE5:0x40637E03:0x07DF06C8` | `DataEP1/Spore_EP1_Content_02.package` | 4,208 | unknown/binary — 4,208 bytes |
| decoded | `0x00E6BCE5:0x40626202:0x07E35ABB` | `DataEP1/Spore_EP1_Content_01.package` | 49,532 | unknown/binary — 49,532 bytes |
| decoded | `0x00E6BCE5:0x40656202:0xE7569FD7` | `Data/Spore_Content.package` | 89,356 | unknown/binary — 89,356 bytes |
| decoded | `0x00E6BCE5:0x40637E03:0x0768A055` | `DataEP1/Spore_EP1_Content_02.package` | 18,980 | unknown/binary — 18,980 bytes |
| decoded | `0x00E6BCE5:0x40637100:0x0798026F` | `DataEP1/Spore_EP1_Content_02.package` | 419,536 | unknown/binary — 419,536 bytes |
| decoded | `0x00E6BCE5:0x40637E02:0x074E5538` | `DataEP1/Spore_EP1_Content_02.package` | 71,396 | unknown/binary — 71,396 bytes |
| decoded | `0x00E6BCE5:0x40637E03:0x0680503A` | `Data/Spore_Content.package` | 8,344 | unknown/binary — 8,344 bytes |
| decoded | `0x00E6BCE5:0x40646200:0xD201FFDA` | `Data/Spore_Content.package` | 669,512 | unknown/binary — 669,512 bytes |
| decoded | `0x00E6BCE5:0x40646200:0x067A0164` | `Data/Spore_Content.package` | 295,652 | unknown/binary — 295,652 bytes |
| decoded | `0x00E6BCE5:0x40636200:0x07C65508` | `DataEP1/Spore_EP1_Content_02.package` | 138,108 | unknown/binary — 138,108 bytes |

### `0x2F4E681C` — 5,931 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2F4E681C:0x40642901:0xA3ADD9A0` | `Data/Spore_Content.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40632902:0x078ECC3F` | `DataEP1/Spore_EP1_Content_02.package` | 1,398,164 | unknown/binary — 1,398,164 bytes |
| decoded | `0x2F4E681C:0x40662801:0xF4F55AC7` | `Data/Spore_Content.package` | 87,468 | unknown/binary — 87,468 bytes |
| decoded | `0x2F4E681C:0x40622901:0x065CBDB2` | `Data/Spore_Content.package` | 349,584 | unknown/binary — 349,584 bytes |
| decoded | `0x2F4E681C:0x40632902:0x067C4C2F` | `Data/Spore_Content.package` | 1,398,164 | unknown/binary — 1,398,164 bytes |
| decoded | `0x2F4E681C:0x40642902:0x067717B9` | `Data/Spore_Content.package` | 1,398,164 | unknown/binary — 1,398,164 bytes |
| decoded | `0x2F4E681C:0x40632900:0x067CEDE8` | `Data/Spore_Content.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40632901:0x0779AFF6` | `DataEP1/Spore_EP1_Content_02.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40662C01:0xBEAE5501` | `Data/Spore_Content.package` | 43,764 | unknown/binary — 43,764 bytes |
| decoded | `0x2F4E681C:0x40622901:0x07BFA133` | `DataEP1/Spore_EP1_Content_01.package` | 349,584 | unknown/binary — 349,584 bytes |
| decoded | `0x2F4E681C:0x40642902:0x07B687FA` | `DataEP1/Spore_EP1_Content_01.package` | 1,398,164 | unknown/binary — 1,398,164 bytes |
| decoded | `0x2F4E681C:0x40642902:0x06785BBE` | `Data/Spore_Content.package` | 1,398,164 | unknown/binary — 1,398,164 bytes |
| decoded | `0x2F4E681C:0x40622901:0x065CBF75` | `Data/Spore_Content.package` | 349,584 | unknown/binary — 349,584 bytes |
| decoded | `0x2F4E681C:0x40632900:0x068081AE` | `Data/Spore_Content.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40632900:0x0768CEB1` | `DataEP1/Spore_EP1_Content_02.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40632902:0x074F591F` | `DataEP1/Spore_EP1_Content_02.package` | 1,398,164 | unknown/binary — 1,398,164 bytes |
| decoded | `0x2F4E681C:0x40662900:0x07798A20` | `DataEP1/Spore_EP1_Content_01.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40642901:0x06785BB8` | `Data/Spore_Content.package` | 349,616 | unknown/binary — 349,616 bytes |
| decoded | `0x2F4E681C:0x40662C00:0x17665FDE` | `Data/Spore_Content.package` | 43,764 | unknown/binary — 43,764 bytes |
| decoded | `0x2F4E681C:0x40662C01:0x35744F38` | `Data/Spore_Content.package` | 43,764 | unknown/binary — 43,764 bytes |

### `0xEE17C6AD` — 5,022 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xEE17C6AD:0x00000000:0x412F9431` | `Data/Spore_Game.package` | 64,076 | unknown/binary — 64,076 bytes |
| decoded | `0xEE17C6AD:0x00000000:0xE2E88A40` | `Data/PatchData.package` | 17,932 | unknown/binary — 17,932 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x987F2DF4` | `Data/PatchData.package` | 39,024 | unknown/binary — 39,024 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x37440E75` | `Data/Spore_Game.package` | 25,656 | unknown/binary — 25,656 bytes |
| decoded | `0xEE17C6AD:0x00000000:0xED84B775` | `DataEP1/Spore_EP1_Data.package` | 81,324 | unknown/binary — 81,324 bytes |
| decoded | `0xEE17C6AD:0x00000000:0xD73FF623` | `bp1content/BoosterPack_01.package` | 123,720 | unknown/binary — 123,720 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x0B396B30` | `Data/PatchData.package` | 23,080 | unknown/binary — 23,080 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x4C4774C9` | `Data/Spore_Game.package` | 138,788 | unknown/binary — 138,788 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x2069CC69` | `Data/PatchData.package` | 6,476 | unknown/binary — 6,476 bytes |
| decoded | `0xEE17C6AD:0x00000000:0xF3C920B1` | `Data/PatchData.package` | 11,424 | unknown/binary — 11,424 bytes |
| decoded | `0xEE17C6AD:0x00000000:0xEB7D486C` | `DataEP1/Spore_EP1_Data.package` | 6,968 | unknown/binary — 6,968 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x0FF32194` | `Data/Spore_Game.package` | 87,656 | unknown/binary — 87,656 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x654C5412` | `Data/PatchData.package` | 67,640 | unknown/binary — 67,640 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x627334E6` | `Data/Spore_Game.package` | 62,440 | unknown/binary — 62,440 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x7E222F62` | `Data/PatchData.package` | 23,876 | unknown/binary — 23,876 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x04029C28` | `DataEP1/Spore_EP1_Data.package` | 27,268 | unknown/binary — 27,268 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x72213827` | `Data/PatchData.package` | 16,592 | unknown/binary — 16,592 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x2B91B561` | `Data/Spore_Game.package` | 33,988 | unknown/binary — 33,988 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x3E930E5F` | `DataEP1/Spore_EP1_Data.package` | 30,632 | unknown/binary — 30,632 bytes |
| decoded | `0xEE17C6AD:0x00000000:0x4828706D` | `DataEP1/Spore_EP1_Data.package` | 47,264 | unknown/binary — 47,264 bytes |

### `0x5CAA5E28` — 3,282 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x5CAA5E28:0x40626000:0x06ABBE84` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0x5CAA5E28:0x40666000:0xA4885A48` | `Data/PatchData.package` | 804 | unknown/binary — 804 bytes |
| decoded | `0x5CAA5E28:0x40626000:0x580543E2` | `bp1content/BoosterPack_01.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40646000:0x01568CD8` | `Data/PatchData.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40646000:0x2825A8FA` | `Data/Spore_Game.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0x5CAA5E28:0x40626000:0x9343E65D` | `Data/PatchData.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40636000:0x6955A1B7` | `Data/Spore_Game.package` | 3,108 | unknown/binary — 3,108 bytes |
| decoded | `0x5CAA5E28:0x40646000:0x2B25ADB8` | `Data/PatchData.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40626000:0x8DE1493F` | `Data/PatchData.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40636000:0xDD4EAF83` | `Data/Spore_Game.package` | 804 | unknown/binary — 804 bytes |
| decoded | `0x5CAA5E28:0x40686000:0xF2102F52` | `DataEP1/Spore_EP1_Data.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0x5CAA5E28:0x40646000:0x2825A8FC` | `Data/PatchData.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0x5CAA5E28:0x40636000:0x276B0D49` | `Data/Spore_Game.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40626000:0x44B1EDE0` | `Data/PatchData.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40626000:0x807792E7` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0x5CAA5E28:0x40616000:0x2EA86BFA` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0x5CAA5E28:0x40646000:0x9309BDE2` | `Data/Spore_Game.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40666000:0x1A17317A` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0x5CAA5E28:0x40616000:0x2FC35733` | `Data/Spore_Game.package` | 84 | unknown/binary — 84 bytes |
| decoded | `0x5CAA5E28:0x40646000:0x9209BC75` | `Data/Spore_Game.package` | 228 | unknown/binary — 228 bytes |

### `0x01C135DA` — 2,756 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x01C135DA:0x40606000:0xFC5FB08D` | `Data/Spore_Graphics.package` | 49,970 | unknown/binary — 49,970 bytes |
| decoded | `0x01C135DA:0x40606000:0x32ACB871` | `Data/Spore_Graphics.package` | 18,974 | unknown/binary — 18,974 bytes |
| decoded | `0x01C135DA:0x40606000:0x28ECC4BF` | `Data/Spore_Graphics.package` | 2,046 | unknown/binary — 2,046 bytes |
| decoded | `0x01C135DA:0x40606000:0x3573D7C5` | `Data/Spore_Graphics.package` | 43,660 | unknown/binary — 43,660 bytes |
| decoded | `0x01C135DA:0x40606000:0xEA105D18` | `Data/Spore_Graphics.package` | 35,486 | unknown/binary — 35,486 bytes |
| decoded | `0x01C135DA:0x40606100:0x7C830515` | `Data/Spore_Graphics.package` | 49,296 | unknown/binary — 49,296 bytes |
| decoded | `0x01C135DA:0x40606000:0xD82377EA` | `Data/Spore_Graphics.package` | 28,008 | unknown/binary — 28,008 bytes |
| decoded | `0x01C135DA:0x40606000:0xBE5B1774` | `Data/Spore_Graphics.package` | 1,752 | unknown/binary — 1,752 bytes |
| decoded | `0x01C135DA:0x40606100:0xCF98F8B1` | `Data/Spore_Graphics.package` | 50,808 | unknown/binary — 50,808 bytes |
| decoded | `0x01C135DA:0x40606000:0x0F8D9DD8` | `Data/Spore_Graphics.package` | 200,760 | unknown/binary — 200,760 bytes |
| decoded | `0x01C135DA:0x40606100:0x018B1D5E` | `Data/Spore_Graphics.package` | 41,988 | unknown/binary — 41,988 bytes |
| decoded | `0x01C135DA:0x40606000:0x659AD22C` | `Data/Spore_Graphics.package` | 39,472 | unknown/binary — 39,472 bytes |
| decoded | `0x01C135DA:0x40606000:0xC75C9618` | `Data/Spore_Graphics.package` | 52,564 | unknown/binary — 52,564 bytes |
| decoded | `0x01C135DA:0x40606000:0xEFEDEC98` | `Data/Spore_Graphics.package` | 99,294 | unknown/binary — 99,294 bytes |
| decoded | `0x01C135DA:0x40606000:0x78BBEE40` | `bp1content/BoosterPack_01.package` | 56,652 | unknown/binary — 56,652 bytes |
| decoded | `0x01C135DA:0x40606000:0x41A96423` | `Data/Spore_Graphics.package` | 185,602 | unknown/binary — 185,602 bytes |
| decoded | `0x01C135DA:0x40606100:0xD6ADE968` | `Data/Spore_Graphics.package` | 14,736 | unknown/binary — 14,736 bytes |
| decoded | `0x01C135DA:0x40606000:0x6955A1B3` | `Data/Spore_Graphics.package` | 57,750 | unknown/binary — 57,750 bytes |
| decoded | `0x01C135DA:0x40606100:0x80E1C1F8` | `Data/Spore_Graphics.package` | 47,634 | unknown/binary — 47,634 bytes |
| decoded | `0x01C135DA:0x40606000:0x9209BC77` | `Data/Spore_Graphics.package` | 35,186 | unknown/binary — 35,186 bytes |

### `0x1A99B06B` — 2,625 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x1A99B06B:0x40636200:0x07746B02` | `DataEP1/Spore_EP1_Content_02.package` | 2,872 | unknown/binary — 2,872 bytes |
| decoded | `0x1A99B06B:0x40616200:0xF5447AEB` | `Data/Spore_Content.package` | 1,039 | unknown/binary — 1,039 bytes |
| decoded | `0x1A99B06B:0x40636200:0x067C68F4` | `Data/Spore_Content.package` | 4,635 | unknown/binary — 4,635 bytes |
| decoded | `0x1A99B06B:0x40626200:0x065CBAFE` | `Data/Spore_Content.package` | 2,906 | unknown/binary — 2,906 bytes |
| decoded | `0x1A99B06B:0x40636200:0x068044EE` | `Data/Spore_Content.package` | 4,658 | unknown/binary — 4,658 bytes |
| decoded | `0x1A99B06B:0x40626200:0xB4702810` | `Data/Spore_Content.package` | 5,151 | unknown/binary — 5,151 bytes |
| decoded | `0x1A99B06B:0x40636200:0x078FEAEB` | `DataEP1/Spore_EP1_Content_02.package` | 2,497 | unknown/binary — 2,497 bytes |
| decoded | `0x1A99B06B:0x40666200:0x07730CF8` | `DataEP1/Spore_EP1_Content_01.package` | 4,360 | unknown/binary — 4,360 bytes |
| decoded | `0x1A99B06B:0x40626200:0x067257E6` | `Data/Spore_Content.package` | 4,901 | unknown/binary — 4,901 bytes |
| decoded | `0x1A99B06B:0x40626200:0x07BFA13F` | `DataEP1/Spore_EP1_Content_01.package` | 6,343 | unknown/binary — 6,343 bytes |
| decoded | `0x1A99B06B:0x40626200:0x068043A8` | `Data/Spore_Content.package` | 2,356 | unknown/binary — 2,356 bytes |
| decoded | `0x1A99B06B:0x40626200:0x067B4012` | `Data/Spore_Content.package` | 3,953 | unknown/binary — 3,953 bytes |
| decoded | `0x1A99B06B:0x40636200:0x077981CD` | `DataEP1/Spore_EP1_Content_02.package` | 3,442 | unknown/binary — 3,442 bytes |
| decoded | `0x1A99B06B:0x40666200:0x0774E759` | `DataEP1/Spore_EP1_Content_01.package` | 5,168 | unknown/binary — 5,168 bytes |
| decoded | `0x1A99B06B:0x40666200:0xB1E018FA` | `Data/Spore_Content.package` | 1,322 | unknown/binary — 1,322 bytes |
| decoded | `0x1A99B06B:0x40626200:0x067A13D9` | `Data/Spore_Content.package` | 3,661 | unknown/binary — 3,661 bytes |
| decoded | `0x1A99B06B:0x40656200:0x067256EA` | `Data/Spore_Content.package` | 4,434 | unknown/binary — 4,434 bytes |
| decoded | `0x1A99B06B:0x40636200:0x0680B52C` | `Data/Spore_Content.package` | 7,026 | unknown/binary — 7,026 bytes |
| decoded | `0x1A99B06B:0x40636200:0x0775F757` | `DataEP1/Spore_EP1_Content_02.package` | 8,557 | unknown/binary — 8,557 bytes |
| decoded | `0x1A99B06B:0x40626200:0x0658BB13` | `Data/Spore_Content.package` | 5,439 | unknown/binary — 5,439 bytes |

### `0x030BDEE3` — 2,598 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x030BDEE3:0x40666200:0x0770DF8B` | `DataEP1/Spore_EP1_Content_01.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40626200:0x06577404` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40626200:0x75E0266A` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40666200:0xB7DA4CE1` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40626200:0x07E8AAE8` | `DataEP1/Spore_EP1_Content_01.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40646200:0x0672129C` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40656200:0x0665F6B8` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40626200:0x065CB9E6` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40636200:0x067B6E59` | `Data/Spore_Content.package` | 159 | unknown/binary — 159 bytes |
| decoded | `0x030BDEE3:0x40646200:0x0670988F` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40626200:0x06538D5B` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40666200:0x076DE1E4` | `DataEP1/Spore_EP1_Content_01.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40636200:0x077AE254` | `DataEP1/Spore_EP1_Content_02.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40646200:0x06786655` | `Data/Spore_Content.package` | 135 | unknown/binary — 135 bytes |
| decoded | `0x030BDEE3:0x40626200:0x0763474E` | `DataEP1/Spore_EP1_Content_01.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40636200:0x077ADC8E` | `DataEP1/Spore_EP1_Content_02.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40636200:0x074B5D77` | `DataEP1/Spore_EP1_Content_02.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40636200:0x06725705` | `Data/Spore_Content.package` | 157 | unknown/binary — 157 bytes |
| decoded | `0x030BDEE3:0x40636200:0x0772EC70` | `DataEP1/Spore_EP1_Content_02.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x030BDEE3:0x40636200:0x07B27E64` | `DataEP1/Spore_EP1_Content_02.package` | 163 | unknown/binary — 163 bytes |

### `0x02D5C9AF` — 2,590 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02D5C9AF:0x40666200:0x0772D72F` | `DataEP1/Spore_EP1_Content_01.package` | 144 | unknown/binary — 144 bytes |
| decoded | `0x02D5C9AF:0x40666200:0xB689B784` | `Data/Spore_Content.package` | 132 | unknown/binary — 132 bytes |
| decoded | `0x02D5C9AF:0x40636200:0x07B673C4` | `DataEP1/Spore_EP1_Content_02.package` | 468 | unknown/binary — 468 bytes |
| decoded | `0x02D5C9AF:0x40666200:0x07762D1E` | `DataEP1/Spore_EP1_Content_01.package` | 144 | unknown/binary — 144 bytes |
| decoded | `0x02D5C9AF:0x40636200:0x068042E1` | `Data/Spore_Content.package` | 420 | unknown/binary — 420 bytes |
| decoded | `0x02D5C9AF:0x40626200:0x06538FCD` | `Data/Spore_Content.package` | 876 | unknown/binary — 876 bytes |
| decoded | `0x02D5C9AF:0x40666200:0x0775929E` | `DataEP1/Spore_EP1_Content_01.package` | 144 | unknown/binary — 144 bytes |
| decoded | `0x02D5C9AF:0x40646200:0xFB106D1F` | `Data/Spore_Content.package` | 540 | unknown/binary — 540 bytes |
| decoded | `0x02D5C9AF:0x40666200:0x0775854B` | `DataEP1/Spore_EP1_Content_01.package` | 144 | unknown/binary — 144 bytes |
| decoded | `0x02D5C9AF:0x40626200:0x067DAB86` | `Data/Spore_Content.package` | 708 | unknown/binary — 708 bytes |
| decoded | `0x02D5C9AF:0x40636200:0x07C4D758` | `DataEP1/Spore_EP1_Content_02.package` | 276 | unknown/binary — 276 bytes |
| decoded | `0x02D5C9AF:0x40626200:0x067C7CF4` | `Data/Spore_Content.package` | 852 | unknown/binary — 852 bytes |
| decoded | `0x02D5C9AF:0x40626200:0x078EA024` | `DataEP1/Spore_EP1_Content_01.package` | 732 | unknown/binary — 732 bytes |
| decoded | `0x02D5C9AF:0x40656200:0x0665F6DA` | `Data/Spore_Content.package` | 396 | unknown/binary — 396 bytes |
| decoded | `0x02D5C9AF:0x40646200:0xEF50CCD5` | `Data/Spore_Content.package` | 564 | unknown/binary — 564 bytes |
| decoded | `0x02D5C9AF:0x40626200:0x0652765D` | `Data/Spore_Content.package` | 804 | unknown/binary — 804 bytes |
| decoded | `0x02D5C9AF:0x40636200:0x077AE252` | `DataEP1/Spore_EP1_Content_02.package` | 456 | unknown/binary — 456 bytes |
| decoded | `0x02D5C9AF:0x40636200:0x0771F2C3` | `DataEP1/Spore_EP1_Content_02.package` | 408 | unknown/binary — 408 bytes |
| decoded | `0x02D5C9AF:0x40616200:0x0D64F036` | `Data/Spore_Content.package` | 132 | unknown/binary — 132 bytes |
| decoded | `0x02D5C9AF:0x40636200:0x0675F7B9` | `Data/Spore_Content.package` | 528 | unknown/binary — 528 bytes |

### `0x0F43029A` — 1,365 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x0F43029A:0x40616200:0x4DA56CA5` | `Data/Spore_Content.package` | 1,889 | unknown/binary — 1,889 bytes |
| decoded | `0x0F43029A:0x40626200:0x065CF65B` | `Data/Spore_Content.package` | 4,353 | unknown/binary — 4,353 bytes |
| decoded | `0x0F43029A:0x40626200:0x067A06C5` | `Data/Spore_Content.package` | 6,438 | unknown/binary — 6,438 bytes |
| decoded | `0x0F43029A:0x40626200:0x067DDC6F` | `Data/Spore_Content.package` | 5,141 | unknown/binary — 5,141 bytes |
| decoded | `0x0F43029A:0x40626200:0x0680578D` | `Data/Spore_Content.package` | 9,589 | unknown/binary — 9,589 bytes |
| decoded | `0x0F43029A:0x40626200:0x065392AD` | `Data/Spore_Content.package` | 7,583 | unknown/binary — 7,583 bytes |
| decoded | `0x0F43029A:0x40626200:0x07DF5FAB` | `DataEP1/Spore_EP1_Content_01.package` | 9,684 | unknown/binary — 9,684 bytes |
| decoded | `0x0F43029A:0x40626200:0x077B00A1` | `DataEP1/Spore_EP1_Content_01.package` | 13,323 | unknown/binary — 13,323 bytes |
| decoded | `0x0F43029A:0x40626200:0x0678611D` | `Data/Spore_Content.package` | 7,282 | unknown/binary — 7,282 bytes |
| decoded | `0x0F43029A:0x40626200:0x065392F7` | `Data/Spore_Content.package` | 5,320 | unknown/binary — 5,320 bytes |
| decoded | `0x0F43029A:0x40626200:0x0654E016` | `Data/Spore_Content.package` | 6,590 | unknown/binary — 6,590 bytes |
| decoded | `0x0F43029A:0x40666200:0xB059CD3C` | `Data/Spore_Content.package` | 4,415 | unknown/binary — 4,415 bytes |
| decoded | `0x0F43029A:0x40626200:0x067B6EED` | `Data/Spore_Content.package` | 5,023 | unknown/binary — 5,023 bytes |
| decoded | `0x0F43029A:0x40626200:0x065CBA69` | `Data/Spore_Content.package` | 5,270 | unknown/binary — 5,270 bytes |
| decoded | `0x0F43029A:0x40666200:0x0772D72D` | `DataEP1/Spore_EP1_Content_01.package` | 1,882 | unknown/binary — 1,882 bytes |
| decoded | `0x0F43029A:0x40626200:0x06538B1C` | `Data/Spore_Content.package` | 5,931 | unknown/binary — 5,931 bytes |
| decoded | `0x0F43029A:0x40626200:0x07EC6883` | `DataEP1/Spore_EP1_Content_01.package` | 6,773 | unknown/binary — 6,773 bytes |
| decoded | `0x0F43029A:0x40626200:0x06538E11` | `Data/Spore_Content.package` | 9,976 | unknown/binary — 9,976 bytes |
| decoded | `0x0F43029A:0x40626200:0x067C684A` | `Data/Spore_Content.package` | 6,978 | unknown/binary — 6,978 bytes |
| decoded | `0x0F43029A:0x40626200:0x07BFA133` | `DataEP1/Spore_EP1_Content_01.package` | 8,392 | unknown/binary — 8,392 bytes |

### `0x250FE9A2` — 748 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x250FE9A2:0x40464200:0x8A4B2306` | `Data/PatchData.package` | 9,460 | unknown/binary — 9,460 bytes |
| decoded | `0x250FE9A2:0x42464200:0x4258C8DF` | `Data/Spore_Graphics.package` | 2,670 | unknown/binary — 2,670 bytes |
| decoded | `0x250FE9A2:0x40464200:0xE9BCF182` | `Data/PatchData.package` | 24,939 | unknown/binary — 24,939 bytes |
| decoded | `0x250FE9A2:0x42464200:0x166158E8` | `Data/Spore_Graphics.package` | 2,689 | unknown/binary — 2,689 bytes |
| decoded | `0x250FE9A2:0x40464200:0x12F13857` | `Data/Spore_Graphics.package` | 1,363 | unknown/binary — 1,363 bytes |
| decoded | `0x250FE9A2:0x40464200:0xB0039D21` | `Data/PatchData.package` | 4,534 | unknown/binary — 4,534 bytes |
| decoded | `0x250FE9A2:0x40464200:0xCB6A4669` | `Data/Spore_Graphics.package` | 17,091 | unknown/binary — 17,091 bytes |
| decoded | `0x250FE9A2:0x40464200:0xA10D844A` | `Data/Spore_Graphics.package` | 1,042 | unknown/binary — 1,042 bytes |
| decoded | `0x250FE9A2:0x40464200:0x5ED10964` | `Data/PatchData.package` | 151,999 | unknown/binary — 151,999 bytes |
| decoded | `0x250FE9A2:0x41464200:0xDECDB609` | `Data/Spore_Graphics.package` | 3,137 | unknown/binary — 3,137 bytes |
| decoded | `0x250FE9A2:0x40464200:0x14880158` | `Data/Spore_Graphics.package` | 1,868 | unknown/binary — 1,868 bytes |
| decoded | `0x250FE9A2:0x41464200:0x2B47985B` | `Data/Spore_Graphics.package` | 12,727 | unknown/binary — 12,727 bytes |
| decoded | `0x250FE9A2:0x40464200:0xC0A3C2D6` | `Data/Spore_Graphics.package` | 5,346 | unknown/binary — 5,346 bytes |
| decoded | `0x250FE9A2:0x40464200:0xAE531FF5` | `DataEP1/Spore_EP1_Data.package` | 52,423 | unknown/binary — 52,423 bytes |
| decoded | `0x250FE9A2:0x40464200:0x4235A1DB` | `Data/Spore_Graphics.package` | 302 | unknown/binary — 302 bytes |
| decoded | `0x250FE9A2:0x40464200:0x930C2B50` | `Data/Spore_Graphics.package` | 7,099 | unknown/binary — 7,099 bytes |
| decoded | `0x250FE9A2:0x40464200:0x5D75CF56` | `Data/PatchData.package` | 18,166 | unknown/binary — 18,166 bytes |
| decoded | `0x250FE9A2:0x40464200:0x0C029EEF` | `Data/PatchData.package` | 5,570 | unknown/binary — 5,570 bytes |
| decoded | `0x250FE9A2:0x40464200:0xF61F431A` | `Data/PatchData.package` | 4,162 | unknown/binary — 4,162 bytes |
| decoded | `0x250FE9A2:0x40464200:0xB74C6B64` | `DataEP1/Spore_EP1_Data.package` | 2,216 | unknown/binary — 2,216 bytes |

### `0x02FAC0B6` — 590 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02FAC0B6:0x02FABF01:0xEB177F74` | `Data/Locale/en-gb/Text.package` | 29,709 | unknown/binary — 29,709 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x1411582D` | `Data/Locale/en-us/Text.package` | 3,635 | unknown/binary — 3,635 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x8462D22A` | `Data/Locale/ru-ru/Text.package` | 3,301 | unknown/binary — 3,301 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x8AC9EBC7` | `Data/Locale/ru-ru/Text.package` | 326 | unknown/binary — 326 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xAECEA11D` | `Data/Locale/en-gb/Text.package` | 161 | unknown/binary — 161 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x496BFB26` | `Data/Locale/en-us/Text.package` | 7,154 | unknown/binary — 7,154 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xF37C24E6` | `Data/Locale/en-us/Text.package` | 1,082 | unknown/binary — 1,082 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x33E7F436` | `Data/Locale/ru-ru/Text.package` | 53,049 | unknown/binary — 53,049 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x974299BE` | `Data/Locale/en-gb/Text.package` | 10,075 | unknown/binary — 10,075 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xAECEA11D` | `Data/Locale/en-us/Text.package` | 157 | unknown/binary — 157 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x5C770DBB` | `Data/Locale/en-us/Text.package` | 903 | unknown/binary — 903 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x5C1E8AD6` | `Data/Locale/ru-ru/Text.package` | 77 | unknown/binary — 77 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x9369A29A` | `Data/Locale/en-gb/Text.package` | 445 | unknown/binary — 445 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x97A78C92` | `Data/Locale/ru-ru/Text.package` | 43,808 | unknown/binary — 43,808 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xCDF005AB` | `Data/Locale/en-us/Text.package` | 1,137 | unknown/binary — 1,137 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x325440A2` | `Data/Locale/ru-ru/Text.package` | 21,586 | unknown/binary — 21,586 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xFB5E0D8C` | `Data/Locale/en-gb/Text.package` | 1,859 | unknown/binary — 1,859 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xDBFED2EF` | `Data/Locale/en-gb/Text.package` | 120 | unknown/binary — 120 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0x7153BBB1` | `Data/Locale/ru-ru/Text.package` | 32,352 | unknown/binary — 32,352 bytes |
| decoded | `0x02FAC0B6:0x02FABF01:0xA249DE71` | `Data/Locale/en-us/Text.package` | 3,771 | unknown/binary — 3,771 bytes |

### `0xDFAD9F51` — 489 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xDFAD9F51:0x00000000:0x4BC9336F` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x1658BCAE` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x7D00E384` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x0BC1FF72` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x1D32AA42` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x1D32AA42` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x0FEB4D84` | `DataEP1/Spore_EP1_Data.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x0322CF0F` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0xAB4E230F` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x9FA0EDCB` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0xEFE530A1` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0xCBCD1287` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0xA559D562` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x201C2477` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x61411153` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0xB20BA910` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x63166099` | `DataEP1/Spore_EP1_Data.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x2DFC83CF` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x34AA6561` | `Data/PatchData.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0xDFAD9F51:0x00000000:0x8685B7FC` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |

### `0x4B9EF6DC` — 376 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x4B9EF6DC:0x00000000:0xFD24574F` | `Data/Spore_Game.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0xFD24574A` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x54FF6057` | `Data/Spore_Game.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0xDD97371A` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x4EB70DF1` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x8F5EA990` | `Data/Spore_Game.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x7BF0B6F5` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x246D3B89` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x9B754EC5` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x00500257` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x611DB7BF` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x304CB8B9` | `Data/Spore_Game.package` | 108 | unknown/binary — 108 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0xCBCD1287` | `Data/Spore_Game.package` | 108 | unknown/binary — 108 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x8628690A` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0xCBDB0A9A` | `Data/Spore_Game.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x5260117C` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x246D3B8A` | `Data/Spore_Game.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x1B941948` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x3B9A0FF2` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x4B9EF6DC:0x00000000:0x320C330C` | `Data/PatchData.package` | 68 | unknown/binary — 68 bytes |

### `0x617715D9` — 318 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x617715D9:0x021407EE:0x924E2237` | `Data/Spore_Audio2.package` | 362 | unknown/binary — 362 bytes |
| decoded | `0x617715D9:0x021407EE:0xE9002484` | `Data/Spore_Audio2.package` | 4,622 | unknown/binary — 4,622 bytes |
| decoded | `0x617715D9:0x021407EE:0x7797C0B1` | `Data/Spore_Audio2.package` | 27,206 | unknown/binary — 27,206 bytes |
| decoded | `0x617715D9:0x021407EE:0x6CEAD618` | `Data/Spore_Audio2.package` | 1,479 | unknown/binary — 1,479 bytes |
| decoded | `0x617715D9:0x021407EE:0xD4754C0E` | `Data/Spore_Audio2.package` | 2,856 | unknown/binary — 2,856 bytes |
| decoded | `0x617715D9:0x021407EE:0xB96B734B` | `Data/Spore_Audio2.package` | 2,072 | unknown/binary — 2,072 bytes |
| decoded | `0x617715D9:0x021407EE:0x842DC614` | `Data/Spore_Audio2.package` | 2,256 | unknown/binary — 2,256 bytes |
| decoded | `0x617715D9:0x021407EE:0x5B97468B` | `Data/Spore_Audio2.package` | 47,695 | unknown/binary — 47,695 bytes |
| decoded | `0x617715D9:0x021407EE:0xAD0570D6` | `Data/Spore_Audio2.package` | 12,000 | unknown/binary — 12,000 bytes |
| decoded | `0x617715D9:0x021407EE:0x9B7D6501` | `Data/Spore_Audio2.package` | 1,934 | unknown/binary — 1,934 bytes |
| decoded | `0x617715D9:0x021407EE:0xB05A4F0B` | `Data/Spore_Audio2.package` | 31,969 | unknown/binary — 31,969 bytes |
| decoded | `0x617715D9:0x021407EE:0x7CB81A35` | `Data/Spore_Audio2.package` | 10,290 | unknown/binary — 10,290 bytes |
| decoded | `0x617715D9:0x021407EE:0x248754F0` | `Data/Spore_Audio2.package` | 1,204 | unknown/binary — 1,204 bytes |
| decoded | `0x617715D9:0x021407EE:0x1D8F5A44` | `Data/Spore_Audio2.package` | 3,812 | unknown/binary — 3,812 bytes |
| decoded | `0x617715D9:0x021407EE:0xBE3C2358` | `Data/Spore_Audio2.package` | 3,008 | unknown/binary — 3,008 bytes |
| decoded | `0x617715D9:0x021407EE:0xE109E879` | `Data/Spore_Audio2.package` | 721 | unknown/binary — 721 bytes |
| decoded | `0x617715D9:0x021407EE:0x1C1B19E0` | `Data/Spore_Audio2.package` | 2,000 | unknown/binary — 2,000 bytes |
| decoded | `0x617715D9:0x021407EE:0xBC8B7982` | `Data/Spore_Audio2.package` | 31,370 | unknown/binary — 31,370 bytes |
| decoded | `0x617715D9:0x021407EE:0xFB86348B` | `Data/Spore_Audio2.package` | 9,666 | unknown/binary — 9,666 bytes |
| decoded | `0x617715D9:0x021407EE:0x7B2A0D20` | `Data/Spore_Audio2.package` | 32,888 | unknown/binary — 32,888 bytes |

### `0x024A0E52` — 160 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x024A0E52:0x024A4F5A:0xC0EF4F0E` | `Data/Spore_Game.package` | 5,084 | unknown/binary — 5,084 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0x71D93685` | `Data/PatchData.package` | 609 | unknown/binary — 609 bytes |
| decoded | `0x024A0E52:0x40890200:0xDFAD9F51` | `Data/Spore_Game.package` | 890 | unknown/binary — 890 bytes |
| decoded | `0x024A0E52:0x0461227D:0x39DE2A45` | `Data/Locale/en-gb/NameGeneration.package` | 169 | unknown/binary — 169 bytes |
| decoded | `0x024A0E52:0x00000000:0x68D2F62B` | `Data/BP2_Data.package` | 23,339 | unknown/binary — 23,339 bytes |
| decoded | `0x024A0E52:0x40890200:0x4297B011` | `Data/PatchData.package` | 17,841 | unknown/binary — 17,841 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0xC0EF4F0E` | `Data/PatchData.package` | 5,084 | unknown/binary — 5,084 bytes |
| decoded | `0x024A0E52:0x00000000:0x2CB7250D` | `Data/BP2_Data.package` | 5,856 | unknown/binary — 5,856 bytes |
| decoded | `0x024A0E52:0x00000000:0x68D2F62B` | `Data/PatchData.package` | 23,130 | unknown/binary — 23,130 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0x8C69B52D` | `DataEP1/Spore_EP1_Data.package` | 11,784 | unknown/binary — 11,784 bytes |
| decoded | `0x024A0E52:0x00000000:0x96D01090` | `Data/Spore_Game.package` | 15,269 | unknown/binary — 15,269 bytes |
| decoded | `0x024A0E52:0x0461227D:0x0B243DC0` | `Data/Locale/en-us/NameGeneration.package` | 4,207 | unknown/binary — 4,207 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0xD086337F` | `Data/Spore_Game.package` | 5,248 | unknown/binary — 5,248 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0x71146A91` | `Data/PatchData.package` | 1,045 | text/ASCII — 1,045 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0xC26FBBFA` | `Data/Spore_Game.package` | 1,633 | unknown/binary — 1,633 bytes |
| decoded | `0x024A0E52:0x40890200:0xF4A9480E` | `Data/Spore_Game.package` | 2,200 | unknown/binary — 2,200 bytes |
| decoded | `0x024A0E52:0x024A4F5A:0xEE02F7D5` | `Data/PatchData.package` | 5,183 | unknown/binary — 5,183 bytes |
| decoded | `0x024A0E52:0x00000000:0x9EFE877A` | `Data/Spore_Game.package` | 1,148 | unknown/binary — 1,148 bytes |
| decoded | `0x024A0E52:0x40890200:0x3D4F6726` | `Data/PatchData.package` | 727 | unknown/binary — 727 bytes |
| decoded | `0x024A0E52:0x00000000:0x8C47952D` | `Data/Spore_Game.package` | 42,853 | unknown/binary — 42,853 bytes |

### `0x02393756` — 153 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02393756:0x02393C07:0x24BED16E` | `Data/PatchData.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0xAFB1145C` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0xD40ABF71` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x0BCB8F86` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x46C65FC2` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x8629A043` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x5264A757` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x03C32077` | `DataEP1/Spore_EP1_Data.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x5003E8E0` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x086C375D` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0xB450DFB5` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0xE84563D4` | `DataEP1/Spore_EP1_Data.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x5BAB8FCE` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x5003E8EB` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x790E693C` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x3BF27091` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x24C6D844` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0xF4AFEC95` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x5003E8E4` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |
| decoded | `0x02393756:0x02393C07:0x17880A2F` | `Data/Spore_Graphics.package` | 4,286 | unknown/binary — 4,286 bytes |

### `0x497767B9` — 126 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x497767B9:0xEA5118B1:0xC42B891F` | `Data/Spore_Graphics.package` | 2,302 | unknown/binary — 2,302 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x0156AC06` | `Data/Spore_Graphics.package` | 1,610 | unknown/binary — 1,610 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x471B9250` | `Data/PatchData.package` | 27,089 | unknown/binary — 27,089 bytes |
| decoded | `0x497767B9:0xEA5118B1:0xEED1E21B` | `Data/Spore_Graphics.package` | 3,125 | unknown/binary — 3,125 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x203219F6` | `Data/Spore_Graphics.package` | 2,302 | unknown/binary — 2,302 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x8E3B61BA` | `Data/Spore_Graphics.package` | 1,988 | unknown/binary — 1,988 bytes |
| decoded | `0x497767B9:0xEA5118B1:0xB80F36C3` | `Data/Spore_Graphics.package` | 1,613 | unknown/binary — 1,613 bytes |
| decoded | `0x497767B9:0xEA5118B1:0xC2C7E62B` | `Data/Spore_Graphics.package` | 2,812 | unknown/binary — 2,812 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x47D7EF44` | `Data/Spore_Graphics.package` | 1,474 | unknown/binary — 1,474 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x32FE45F6` | `Data/Spore_Graphics.package` | 6,544 | unknown/binary — 6,544 bytes |
| decoded | `0x497767B9:0xEA5118B1:0xA9BB0919` | `Data/Spore_Graphics.package` | 1,666 | unknown/binary — 1,666 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x25238AE2` | `Data/Spore_Graphics.package` | 2,438 | unknown/binary — 2,438 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x8EB01DDE` | `Data/Spore_Graphics.package` | 2,539 | unknown/binary — 2,539 bytes |
| decoded | `0x497767B9:0xEA5118B1:0xBD65935D` | `Data/Spore_Graphics.package` | 1,082 | unknown/binary — 1,082 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x8C7AA8C3` | `Data/Spore_Graphics.package` | 1,928 | unknown/binary — 1,928 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x2FC1E149` | `Data/Spore_Graphics.package` | 2,140 | unknown/binary — 2,140 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x89E3653F` | `Data/Spore_Graphics.package` | 272 | unknown/binary — 272 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x641CAAB1` | `Data/Spore_Graphics.package` | 1,574 | unknown/binary — 1,574 bytes |
| decoded | `0x497767B9:0xEA5118B1:0xBDC690BB` | `Data/Spore_Graphics.package` | 3,363 | unknown/binary — 3,363 bytes |
| decoded | `0x497767B9:0xEA5118B1:0x9C359D13` | `Data/Spore_Graphics.package` | 3,778 | unknown/binary — 3,778 bytes |

### `0x055ADA24` — 124 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x055ADA24:0x055ADA23:0x0DAC76F6` | `Data/Spore_Game.package` | 22,611 | unknown/binary — 22,611 bytes |
| decoded | `0x055ADA24:0x055ADA23:0xF0B62B43` | `Data/PatchData.package` | 12,600 | unknown/binary — 12,600 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x14FCB04C` | `Data/PatchData.package` | 78,911 | unknown/binary — 78,911 bytes |
| decoded | `0x055ADA24:0x02AE1A8E:0x06B5005E` | `Data/PatchData.package` | 216 | unknown/binary — 216 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x2E27078E` | `Data/PatchData.package` | 4,550 | unknown/binary — 4,550 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x5D44A586` | `Data/Spore_Game.package` | 22,611 | unknown/binary — 22,611 bytes |
| decoded | `0x055ADA24:0x055ADA23:0xA50123B0` | `Data/PatchData.package` | 22,611 | unknown/binary — 22,611 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x0DAC76F6` | `Data/PatchData.package` | 22,611 | unknown/binary — 22,611 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x95BBBBFC` | `Data/Spore_Game.package` | 79,551 | unknown/binary — 79,551 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x98622544` | `Data/PatchData.package` | 7,466 | unknown/binary — 7,466 bytes |
| decoded | `0x055ADA24:0x055ADA23:0xA5423D2B` | `Data/Spore_Game.package` | 12,448 | unknown/binary — 12,448 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x2F119813` | `Data/PatchData.package` | 26,749 | unknown/binary — 26,749 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x9D9FA70E` | `Data/PatchData.package` | 93,604 | unknown/binary — 93,604 bytes |
| decoded | `0x055ADA24:0x02AE1A8E:0xA07F6FD6` | `Data/Spore_Game.package` | 380 | unknown/binary — 380 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x789B1C41` | `Data/Spore_Game.package` | 43,679 | unknown/binary — 43,679 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x97A78C92` | `Data/Spore_Game.package` | 87,991 | unknown/binary — 87,991 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x59649908` | `DataEP1/Spore_EP1_Data.package` | 38,005 | unknown/binary — 38,005 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x1FD54648` | `Data/Spore_Game.package` | 81,919 | unknown/binary — 81,919 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x944BC29A` | `Data/Spore_Game.package` | 94,044 | unknown/binary — 94,044 bytes |
| decoded | `0x055ADA24:0x055ADA23:0x71F6D030` | `Data/PatchData.package` | 100,136 | unknown/binary — 100,136 bytes |

### `0xD92AF091` — 115 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xD92AF091:0x00000000:0x30E0DF41` | `Data/PatchData.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0xE7724657` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0x2A5469B3` | `Data/PatchData.package` | 288 | unknown/binary — 288 bytes |
| decoded | `0xD92AF091:0x00000000:0x0D7FF9E2` | `Data/PatchData.package` | 120 | unknown/binary — 120 bytes |
| decoded | `0xD92AF091:0x00000000:0x292C93D2` | `Data/Spore_Game.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0xDFD2ADEE` | `Data/Spore_Game.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0x292C93D2` | `Data/PatchData.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0xE7724657` | `Data/Spore_Game.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0x6DD68E6E` | `Data/Spore_Game.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0x6DD68E6E` | `Data/PatchData.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0x413097D7` | `Data/PatchData.package` | 232 | unknown/binary — 232 bytes |
| decoded | `0xD92AF091:0x00000000:0xCE5DE260` | `Data/Spore_Game.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0x7CC79D94` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0x65F06D91` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0x413097C2` | `Data/Spore_Game.package` | 204 | unknown/binary — 204 bytes |
| decoded | `0xD92AF091:0x00000000:0x2A5469B3` | `Data/Spore_Game.package` | 288 | unknown/binary — 288 bytes |
| decoded | `0xD92AF091:0x00000000:0x7CC79D94` | `DataEP1/Spore_EP1_Data.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0x21B779B4` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0xD92AF091:0x00000000:0xFDCF2605` | `Data/Spore_Game.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xD92AF091:0x00000000:0x9C3778A2` | `Data/Spore_Game.package` | 92 | unknown/binary — 92 bytes |

### `0x022D2C83` — 97 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x022D2C83:0x021407EE:0x3759D899` | `Data/Spore_Audio2.package` | 77,475 | unknown/binary — 77,475 bytes |
| decoded | `0x022D2C83:0x021407EE:0x405C332D` | `Data/Spore_Audio2.package` | 13,349 | unknown/binary — 13,349 bytes |
| decoded | `0x022D2C83:0x021407EE:0x6B4E19B4` | `Data/Spore_Audio2.package` | 1,214 | unknown/binary — 1,214 bytes |
| decoded | `0x022D2C83:0x021407EE:0xB18378FD` | `Data/Spore_Audio2.package` | 2,884 | unknown/binary — 2,884 bytes |
| decoded | `0x022D2C83:0x021407EE:0xB18378FE` | `Data/Spore_Audio2.package` | 3,019 | unknown/binary — 3,019 bytes |
| decoded | `0x022D2C83:0x021407EE:0x2C8646EB` | `Data/Spore_Audio2.package` | 972 | unknown/binary — 972 bytes |
| decoded | `0x022D2C83:0x021407EE:0xD9953A6F` | `Data/Spore_Audio2.package` | 921 | unknown/binary — 921 bytes |
| decoded | `0x022D2C83:0x021407EE:0x7797C0B1` | `Data/Spore_Audio2.package` | 29,848 | unknown/binary — 29,848 bytes |
| decoded | `0x022D2C83:0x021407EE:0x8BA68280` | `Data/Spore_Audio1.package` | 2,704 | unknown/binary — 2,704 bytes |
| decoded | `0x022D2C83:0x021407EE:0x9A5A556F` | `Data/Spore_Audio2.package` | 126,556 | unknown/binary — 126,556 bytes |
| decoded | `0x022D2C83:0x021407EE:0x7F699A4B` | `DataEP1/Spore_EP1_Data.package` | 8,405 | unknown/binary — 8,405 bytes |
| decoded | `0x022D2C83:0x021407EE:0x2E218A49` | `Data/Spore_Audio2.package` | 39,750 | unknown/binary — 39,750 bytes |
| decoded | `0x022D2C83:0x021407EE:0xBE3C2358` | `Data/Spore_Audio2.package` | 3,343 | unknown/binary — 3,343 bytes |
| decoded | `0x022D2C83:0x021407EE:0x7F5ADDE6` | `Data/Spore_Audio2.package` | 959 | unknown/binary — 959 bytes |
| decoded | `0x022D2C83:0x021407EE:0xEF7C622D` | `Data/Spore_Audio2.package` | 96,567 | unknown/binary — 96,567 bytes |
| decoded | `0x022D2C83:0x021407EE:0x39668EFC` | `Data/Spore_Audio2.package` | 158,507 | unknown/binary — 158,507 bytes |
| decoded | `0x022D2C83:0x021407EE:0xB90DF32E` | `Data/Spore_Audio2.package` | 15,591 | unknown/binary — 15,591 bytes |
| decoded | `0x022D2C83:0x021407EE:0x896ED613` | `Data/Spore_Audio2.package` | 4,804 | unknown/binary — 4,804 bytes |
| decoded | `0x022D2C83:0x021407EE:0x2C6B91EB` | `Data/Spore_Audio2.package` | 2,984 | unknown/binary — 2,984 bytes |
| decoded | `0x022D2C83:0x021407EE:0x4235F8B7` | `Data/Spore_Audio2.package` | 2,467 | unknown/binary — 2,467 bytes |

### `0x0472329B` — 97 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x0472329B:0x024A4F5A:0x18657795` | `Data/PatchData.package` | 1,132 | unknown/binary — 1,132 bytes |
| decoded | `0x0472329B:0x024B4A2F:0x51813982` | `Data/Spore_Game.package` | 2,064 | unknown/binary — 2,064 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x5B2DD8B4` | `Data/Spore_Game.package` | 7,892 | unknown/binary — 7,892 bytes |
| decoded | `0x0472329B:0x024A4F5A:0xDB334A60` | `Data/PatchData.package` | 3,136 | unknown/binary — 3,136 bytes |
| decoded | `0x0472329B:0x024A4F5A:0xA1ED6E3C` | `Data/Spore_Game.package` | 888 | unknown/binary — 888 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x027B0C3C` | `Data/PatchData.package` | 840 | unknown/binary — 840 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x2278CC41` | `Data/Spore_Game.package` | 796 | unknown/binary — 796 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x5C1C6351` | `Data/Spore_Game.package` | 12,724 | unknown/binary — 12,724 bytes |
| decoded | `0x0472329B:0x024A4F5A:0xB3A05C62` | `Data/Spore_Game.package` | 1,996 | unknown/binary — 1,996 bytes |
| decoded | `0x0472329B:0x024B4A2F:0x3492D768` | `Data/Spore_Game.package` | 2,064 | unknown/binary — 2,064 bytes |
| decoded | `0x0472329B:0x024B4A2F:0x300E868E` | `Data/Spore_Game.package` | 2,008 | unknown/binary — 2,008 bytes |
| decoded | `0x0472329B:0x024A4F5A:0xF184141B` | `Data/PatchData.package` | 2,208 | unknown/binary — 2,208 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x9B5C194F` | `Data/Spore_Game.package` | 236 | unknown/binary — 236 bytes |
| decoded | `0x0472329B:0x024B4A2F:0x4B69E14A` | `Data/Spore_Game.package` | 1,444 | unknown/binary — 1,444 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x225D13AD` | `Data/Spore_Game.package` | 8,836 | unknown/binary — 8,836 bytes |
| decoded | `0x0472329B:0x024A4F5A:0xE0FC6DF9` | `Data/Spore_Game.package` | 1,416 | unknown/binary — 1,416 bytes |
| decoded | `0x0472329B:0x024B4A2F:0x47C32C9B` | `Data/Spore_Game.package` | 1,828 | unknown/binary — 1,828 bytes |
| decoded | `0x0472329B:0x024A4F5A:0x09DD95C4` | `Data/PatchData.package` | 604 | unknown/binary — 604 bytes |
| decoded | `0x0472329B:0x024B4A2F:0x47C32C9B` | `Data/PatchData.package` | 1,828 | unknown/binary — 1,828 bytes |
| decoded | `0x0472329B:0x024A4F5A:0xE86722A6` | `Data/PatchData.package` | 468 | unknown/binary — 468 bytes |

### `0x03E421ED` — 96 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x03E421ED:0x00000000:0x0536DD5E` | `Data/Spore_Graphics.package` | 276 | unknown/binary — 276 bytes |
| decoded | `0x03E421ED:0x00000000:0x0536DD51` | `Data/PatchData.package` | 276 | unknown/binary — 276 bytes |
| decoded | `0x03E421ED:0x00000000:0x6904D29F` | `Data/Spore_Graphics.package` | 65,556 | unknown/binary — 65,556 bytes |
| decoded | `0x03E421ED:0x00000000:0xE531F8B0` | `Data/Spore_Graphics.package` | 262,164 | unknown/binary — 262,164 bytes |
| decoded | `0x03E421ED:0x00000000:0xE2E599A0` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x702F03E0` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x9C751F5E` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x88566056` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x4D272BC5` | `Data/Spore_Graphics.package` | 262,164 | unknown/binary — 262,164 bytes |
| decoded | `0x03E421ED:0x00000000:0x83AF2D67` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x0536DD58` | `Data/Spore_Graphics.package` | 276 | unknown/binary — 276 bytes |
| decoded | `0x03E421ED:0x00000000:0x0536DD5B` | `Data/PatchData.package` | 276 | unknown/binary — 276 bytes |
| decoded | `0x03E421ED:0x00000000:0xC71EF96A` | `Data/Spore_Graphics.package` | 196,628 | unknown/binary — 196,628 bytes |
| decoded | `0x03E421ED:0x00000000:0x05359C50` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x05359C59` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x7848B7AA` | `Data/Spore_Graphics.package` | 262,164 | unknown/binary — 262,164 bytes |
| decoded | `0x03E421ED:0x00000000:0x05359C51` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x05359C57` | `Data/Spore_Graphics.package` | 16,404 | unknown/binary — 16,404 bytes |
| decoded | `0x03E421ED:0x00000000:0x3BF31899` | `Data/Spore_Graphics.package` | 196,628 | unknown/binary — 196,628 bytes |
| decoded | `0x03E421ED:0x00000000:0x0536DD50` | `Data/Spore_Graphics.package` | 276 | unknown/binary — 276 bytes |

### `0x03F51892` — 95 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x03F51892:0x021407EE:0xEF7C622D` | `Data/PatchData.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0x03F51892:0x021407EE:0xCA454791` | `Data/PatchData.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0x03F51892:0x021407EE:0x7A621F4A` | `Data/PatchData.package` | 94 | unknown/binary — 94 bytes |
| decoded | `0x03F51892:0x021407EE:0x39668EFC` | `Data/Spore_Audio2.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x03F51892:0x021407EE:0xBC8B7982` | `Data/PatchData.package` | 77 | unknown/binary — 77 bytes |
| decoded | `0x03F51892:0x021407EE:0x8B3ECA7A` | `Data/Spore_Audio1.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0x03F51892:0x021407EE:0x7A621F4A` | `Data/Spore_Audio2.package` | 94 | unknown/binary — 94 bytes |
| decoded | `0x03F51892:0x021407EE:0xF37ADB02` | `Data/PatchData.package` | 105 | unknown/binary — 105 bytes |
| decoded | `0x03F51892:0x021407EE:0x5293D931` | `Data/Spore_Audio2.package` | 351 | unknown/binary — 351 bytes |
| decoded | `0x03F51892:0x021407EE:0x40DCB1AC` | `Data/Spore_Audio2.package` | 174 | unknown/binary — 174 bytes |
| decoded | `0x03F51892:0x021407EE:0xA92A6E63` | `Data/Spore_Audio2.package` | 149 | unknown/binary — 149 bytes |
| decoded | `0x03F51892:0x021407EE:0x3366F9B5` | `Data/Spore_Audio2.package` | 70 | unknown/binary — 70 bytes |
| decoded | `0x03F51892:0x021407EE:0x2873C7EE` | `Data/PatchData.package` | 286 | unknown/binary — 286 bytes |
| decoded | `0x03F51892:0x021407EE:0x405C332D` | `Data/Spore_Audio2.package` | 65 | unknown/binary — 65 bytes |
| decoded | `0x03F51892:0x021407EE:0x966871FB` | `Data/Spore_Audio2.package` | 65 | unknown/binary — 65 bytes |
| decoded | `0x03F51892:0x021407EE:0xD6C4FC3B` | `Data/PatchData.package` | 79 | unknown/binary — 79 bytes |
| decoded | `0x03F51892:0x021407EE:0x1D8F5A44` | `Data/Spore_Audio2.package` | 86 | unknown/binary — 86 bytes |
| decoded | `0x03F51892:0x021407EE:0x23E4B8F9` | `Data/Spore_Audio2.package` | 40 | unknown/binary — 40 bytes |
| decoded | `0x03F51892:0x021407EE:0x5293D931` | `Data/PatchData.package` | 351 | unknown/binary — 351 bytes |
| decoded | `0x03F51892:0x021407EE:0x3366F9B5` | `Data/PatchData.package` | 70 | unknown/binary — 70 bytes |

### `0x2B978C46` — 94 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2B978C46:0x40626200:0x9BD7A03B` | `Data/Spore_Game.package` | 7,966 | XML/ASCII — 7,966 bytes |
| decoded | `0x2B978C46:0x40626200:0x9BD7A036` | `Data/PatchData.package` | 7,919 | XML/ASCII — 7,919 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CD9` | `Data/PatchData.package` | 6,139 | XML/ASCII — 6,139 bytes |
| decoded | `0x2B978C46:0x40626200:0x9BD7A03D` | `Data/PatchData.package` | 11,577 | XML/ASCII — 11,577 bytes |
| decoded | `0x2B978C46:0x40626200:0x9BD7A037` | `Data/PatchData.package` | 10,399 | XML/ASCII — 10,399 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CDA` | `Data/PatchData.package` | 4,919 | XML/ASCII — 4,919 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CDA` | `Data/Spore_Game.package` | 4,919 | XML/ASCII — 4,919 bytes |
| decoded | `0x2B978C46:0x40626200:0x145FF20F` | `Data/PatchData.package` | 7,302 | XML/ASCII — 7,302 bytes |
| decoded | `0x2B978C46:0x40626200:0x9AD79E4D` | `Data/PatchData.package` | 6,119 | XML/ASCII — 6,119 bytes |
| decoded | `0x2B978C46:0x40626200:0x9BD7A038` | `Data/PatchData.package` | 8,538 | XML/ASCII — 8,538 bytes |
| decoded | `0x2B978C46:0x40626200:0x135FF09A` | `Data/PatchData.package` | 7,903 | XML/ASCII — 7,903 bytes |
| decoded | `0x2B978C46:0x40626200:0x9BD7A03E` | `Data/Spore_Game.package` | 8,554 | XML/ASCII — 8,554 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CDC` | `Data/Spore_Game.package` | 6,129 | XML/ASCII — 6,129 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CDD` | `Data/PatchData.package` | 6,736 | XML/ASCII — 6,736 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CDF` | `Data/Spore_Game.package` | 6,722 | XML/ASCII — 6,722 bytes |
| decoded | `0x2B978C46:0x40626200:0x9AD79E42` | `Data/PatchData.package` | 6,696 | XML/ASCII — 6,696 bytes |
| decoded | `0x2B978C46:0x40626200:0x9AD79E43` | `Data/PatchData.package` | 7,900 | XML/ASCII — 7,900 bytes |
| decoded | `0x2B978C46:0x40626200:0x99D79CD0` | `Data/PatchData.package` | 5,495 | XML/ASCII — 5,495 bytes |
| decoded | `0x2B978C46:0x40626200:0x9AD79E49` | `Data/PatchData.package` | 10,966 | XML/ASCII — 10,966 bytes |
| decoded | `0x2B978C46:0x40626200:0x9AD79E4A` | `Data/PatchData.package` | 9,756 | XML/ASCII — 9,756 bytes |

### `0x3C7E0F63` — 86 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x3C7E0F63:0x40606600:0xAEA4B90F` | `Data/PatchData.package` | 2,992 | unknown/binary — 2,992 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xEB7392E9` | `Data/PatchData.package` | 826 | unknown/binary — 826 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x34F03585` | `Data/PatchData.package` | 375 | unknown/binary — 375 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x486730E7` | `Data/Spore_Game.package` | 420 | unknown/binary — 420 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x30F02FFA` | `Data/PatchData.package` | 470 | unknown/binary — 470 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xB894E6B6` | `Data/PatchData.package` | 421 | unknown/binary — 421 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x4E7DC1F7` | `Data/Spore_Game.package` | 507 | unknown/binary — 507 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xDF9D470C` | `Data/Spore_Game.package` | 696 | unknown/binary — 696 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xB894E6B6` | `Data/Spore_Game.package` | 421 | unknown/binary — 421 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xF1DD153A` | `Data/PatchData.package` | 830 | unknown/binary — 830 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x86F857B0` | `Data/PatchData.package` | 508 | unknown/binary — 508 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x33F03433` | `Data/PatchData.package` | 155 | unknown/binary — 155 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xD13300CC` | `Data/Spore_Game.package` | 703 | unknown/binary — 703 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x972B64B7` | `Data/PatchData.package` | 827 | unknown/binary — 827 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x35F03716` | `Data/Spore_Game.package` | 892 | unknown/binary — 892 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x212BFF90` | `Data/Spore_Game.package` | 471 | unknown/binary — 471 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xF805D326` | `Data/PatchData.package` | 831 | unknown/binary — 831 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xF805D327` | `Data/PatchData.package` | 777 | unknown/binary — 777 bytes |
| decoded | `0x3C7E0F63:0x40606600:0xF805D370` | `Data/PatchData.package` | 334 | unknown/binary — 334 bytes |
| decoded | `0x3C7E0F63:0x40606600:0x35F03715` | `Data/Spore_Game.package` | 897 | unknown/binary — 897 bytes |

### `0x03055F61` — 81 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x03055F61:0x021407EE:0xE0EEF51F` | `DataEP1/Spore_EP1_Data.package` | 190 | unknown/binary — 190 bytes |
| decoded | `0x03055F61:0x021407EE:0xAC972E81` | `Data/Spore_Audio2.package` | 1,425 | unknown/binary — 1,425 bytes |
| decoded | `0x03055F61:0x021407EE:0xC47E4178` | `Data/Spore_Audio2.package` | 1,995 | unknown/binary — 1,995 bytes |
| decoded | `0x03055F61:0x021407EE:0x5F8365CE` | `Data/Spore_Audio2.package` | 760 | unknown/binary — 760 bytes |
| decoded | `0x03055F61:0x021407EE:0x034BF3D9` | `Data/Spore_Audio2.package` | 1,343 | unknown/binary — 1,343 bytes |
| decoded | `0x03055F61:0x021407EE:0xC0EBF928` | `DataEP1/Spore_EP1_Data.package` | 1,710 | unknown/binary — 1,710 bytes |
| decoded | `0x03055F61:0x021407EE:0x2954E735` | `Data/Spore_Audio2.package` | 190 | unknown/binary — 190 bytes |
| decoded | `0x03055F61:0x021407EE:0x078BF0BF` | `Data/Spore_Audio2.package` | 1,995 | unknown/binary — 1,995 bytes |
| decoded | `0x03055F61:0x021407EE:0x5371C012` | `DataEP1/Spore_EP1_Data.package` | 189 | unknown/binary — 189 bytes |
| decoded | `0x03055F61:0x021407EE:0x667BBF23` | `Data/Spore_Audio2.package` | 190 | unknown/binary — 190 bytes |
| decoded | `0x03055F61:0x021407EE:0x078BF0B8` | `Data/Spore_Audio2.package` | 1,995 | unknown/binary — 1,995 bytes |
| decoded | `0x03055F61:0x021407EE:0x01218B5D` | `Data/Spore_Audio2.package` | 190 | unknown/binary — 190 bytes |
| decoded | `0x03055F61:0x021407EE:0xC0538A42` | `Data/Spore_Audio2.package` | 285 | unknown/binary — 285 bytes |
| decoded | `0x03055F61:0x021407EE:0x1411C076` | `Data/Spore_Audio2.package` | 190 | unknown/binary — 190 bytes |
| decoded | `0x03055F61:0x021407EE:0xEF58D1DD` | `Data/Spore_Audio1.package` | 2,111 | unknown/binary — 2,111 bytes |
| decoded | `0x03055F61:0x021407EE:0x9C9C283B` | `DataEP1/Spore_EP1_Data.package` | 189 | unknown/binary — 189 bytes |
| decoded | `0x03055F61:0x021407EE:0x850C4CCB` | `DataEP1/Spore_EP1_Data.package` | 189 | unknown/binary — 189 bytes |
| decoded | `0x03055F61:0x021407EE:0x8F7A5F9D` | `Data/Spore_Audio2.package` | 190 | unknown/binary — 190 bytes |
| decoded | `0x03055F61:0x021407EE:0x44AC4A2C` | `Data/Spore_Audio2.package` | 4,275 | unknown/binary — 4,275 bytes |
| decoded | `0x03055F61:0x021407EE:0xD799188C` | `Data/Spore_Audio2.package` | 1,995 | unknown/binary — 1,995 bytes |

### `0x366A930D` — 69 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x366A930D:0x408A0000:0xF63B6851` | `DataEP1/Spore_EP1_Data.package` | 47,672 | unknown/binary — 47,672 bytes |
| decoded | `0x366A930D:0x408A0000:0xE0798796` | `DataEP1/Spore_EP1_Data.package` | 2,163 | unknown/binary — 2,163 bytes |
| decoded | `0x366A930D:0x408A0000:0x58102924` | `DataEP1/Spore_EP1_Data.package` | 18,179 | unknown/binary — 18,179 bytes |
| decoded | `0x366A930D:0x408A0000:0xFC4C1D97` | `DataEP1/Spore_EP1_Data.package` | 9,591 | unknown/binary — 9,591 bytes |
| decoded | `0x366A930D:0x408A0000:0x62B84F6C` | `DataEP1/Spore_EP1_Data.package` | 8,687 | unknown/binary — 8,687 bytes |
| decoded | `0x366A930D:0x408A0000:0xE8CA06B0` | `DataEP1/Spore_EP1_Data.package` | 40,994 | unknown/binary — 40,994 bytes |
| decoded | `0x366A930D:0x408A0000:0xCC5699A9` | `DataEP1/Spore_EP1_Data.package` | 1,963 | unknown/binary — 1,963 bytes |
| decoded | `0x366A930D:0x408A0000:0xC01A1240` | `DataEP1/Spore_EP1_Data.package` | 5,159 | unknown/binary — 5,159 bytes |
| decoded | `0x366A930D:0x408A0000:0x3C367AB4` | `DataEP1/Spore_EP1_Data.package` | 3,295 | unknown/binary — 3,295 bytes |
| decoded | `0x366A930D:0x408A0000:0xCC5699AB` | `DataEP1/Spore_EP1_Data.package` | 2,755 | unknown/binary — 2,755 bytes |
| decoded | `0x366A930D:0x408A0000:0xCC5699A4` | `DataEP1/Spore_EP1_Data.package` | 1,843 | unknown/binary — 1,843 bytes |
| decoded | `0x366A930D:0x408A0000:0xBB6A4472` | `DataEP1/Spore_EP1_Data.package` | 6,907 | unknown/binary — 6,907 bytes |
| decoded | `0x366A930D:0x408A0000:0x1E4563B9` | `DataEP1/Spore_EP1_Data.package` | 9,779 | unknown/binary — 9,779 bytes |
| decoded | `0x366A930D:0x408A0000:0xE6F78525` | `DataEP1/Spore_EP1_Data.package` | 52,780 | unknown/binary — 52,780 bytes |
| decoded | `0x366A930D:0x408A0000:0xC2C7B154` | `DataEP1/Spore_EP1_Data.package` | 30,380 | unknown/binary — 30,380 bytes |
| decoded | `0x366A930D:0x408A0000:0x288BE48A` | `DataEP1/Spore_EP1_Data.package` | 29,851 | unknown/binary — 29,851 bytes |
| decoded | `0x366A930D:0x408A0000:0x0462D47F` | `DataEP1/Spore_EP1_Data.package` | 6,755 | unknown/binary — 6,755 bytes |
| decoded | `0x366A930D:0x408A0000:0xB3CA6438` | `DataEP1/Spore_EP1_Data.package` | 8,131 | unknown/binary — 8,131 bytes |
| decoded | `0x366A930D:0x408A0000:0x6E008979` | `DataEP1/Spore_EP1_Data.package` | 30,821 | unknown/binary — 30,821 bytes |
| decoded | `0x366A930D:0x408A0000:0x0462D47E` | `DataEP1/Spore_EP1_Data.package` | 6,083 | unknown/binary — 6,083 bytes |

### `0x06EFC6AA` — 68 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x06EFC6AA:0x00000000:0x2E6BC2B7` | `bp1content/BoosterPack_01.package` | 2,100 | unknown/binary — 2,100 bytes |
| decoded | `0x06EFC6AA:0x00000000:0xA4595492` | `Data/PatchData.package` | 547,341 | unknown/binary — 547,341 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x7080DB55` | `DataEP1/Spore_EP1_Locale_01.package` | 202,113 | unknown/binary — 202,113 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x195B5F2C` | `bp1content/BoosterPack_01.package` | 1,973 | unknown/binary — 1,973 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x5CB9F1B6` | `bp1content/BoosterPack_01.package` | 1,977 | unknown/binary — 1,977 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x3DB57750` | `DataEP1/Spore_EP1_Locale_01.package` | 239,457 | unknown/binary — 239,457 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x6286DF0E` | `Data/PatchData.package` | 424,242 | unknown/binary — 424,242 bytes |
| decoded | `0x06EFC6AA:0x00000000:0xA4595492` | `bp1content/BoosterPack_01.package` | 2,037 | unknown/binary — 2,037 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x6286DF0E` | `bp1content/BoosterPack_01.package` | 1,964 | unknown/binary — 1,964 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x8A5745E2` | `Data/PatchData.package` | 414,076 | unknown/binary — 414,076 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x05292CDF` | `bp1content/BoosterPack_01.package` | 1,921 | unknown/binary — 1,921 bytes |
| decoded | `0x06EFC6AA:0x00000000:0xF15488F8` | `Data/PatchData.package` | 665,074 | unknown/binary — 665,074 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x58D931D0` | `Data/PatchData.package` | 525,161 | unknown/binary — 525,161 bytes |
| decoded | `0x06EFC6AA:0x00000000:0xE7297D92` | `DataEP1/Spore_EP1_Locale_01.package` | 235,635 | unknown/binary — 235,635 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x6286DF0E` | `DataEP1/Spore_EP1_Locale_01.package` | 231,800 | unknown/binary — 231,800 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x1725D5AD` | `bp1content/BoosterPack_01.package` | 2,087 | unknown/binary — 2,087 bytes |
| decoded | `0x06EFC6AA:0x00000000:0xF15488F8` | `bp1content/BoosterPack_01.package` | 1,981 | unknown/binary — 1,981 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x5CB9F1B6` | `DataEP1/Spore_EP1_Locale_01.package` | 227,978 | unknown/binary — 227,978 bytes |
| decoded | `0x06EFC6AA:0x00000000:0x7E80F152` | `Data/PatchData.package` | 353,416 | unknown/binary — 353,416 bytes |
| decoded | `0x06EFC6AA:0x00000000:0xA4595492` | `DataEP1/Spore_EP1_Locale_01.package` | 233,032 | unknown/binary — 233,032 bytes |

### `0xDA141C1B` — 64 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xDA141C1B:0x00000000:0x36B24FC6` | `DataEP1/Spore_EP1_Data.package` | 168 | unknown/binary — 168 bytes |
| decoded | `0xDA141C1B:0x00000000:0x9DA02F3E` | `Data/PatchData.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0xDA141C1B:0x00000000:0xE0E55402` | `DataEP1/Spore_EP1_Data.package` | 2,980 | unknown/binary — 2,980 bytes |
| decoded | `0xDA141C1B:0x00000000:0xC6F8CE6D` | `DataEP1/Spore_EP1_Data.package` | 92 | unknown/binary — 92 bytes |
| decoded | `0xDA141C1B:0x00000000:0x1D9BE503` | `DataEP1/Spore_EP1_Data.package` | 244 | unknown/binary — 244 bytes |
| decoded | `0xDA141C1B:0x00000000:0xBFA6BDDA` | `Data/PatchData.package` | 1,840 | unknown/binary — 1,840 bytes |
| decoded | `0xDA141C1B:0x00000000:0x9DA02F3E` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0xDA141C1B:0x00000000:0xBE3F2ED5` | `Data/PatchData.package` | 2,752 | unknown/binary — 2,752 bytes |
| decoded | `0xDA141C1B:0x00000000:0x7E3CE2B9` | `Data/PatchData.package` | 3,436 | unknown/binary — 3,436 bytes |
| decoded | `0xDA141C1B:0x00000000:0xBFA6BDDA` | `DataEP1/Spore_EP1_Data.package` | 1,840 | unknown/binary — 1,840 bytes |
| decoded | `0xDA141C1B:0x00000000:0xBE3F2ED5` | `DataEP1/Spore_EP1_Data.package` | 2,752 | unknown/binary — 2,752 bytes |
| decoded | `0xDA141C1B:0x00000000:0x584913E0` | `Data/PatchData.package` | 2,752 | unknown/binary — 2,752 bytes |
| decoded | `0xDA141C1B:0x00000000:0xE132069D` | `Data/PatchData.package` | 1,460 | unknown/binary — 1,460 bytes |
| decoded | `0xDA141C1B:0x00000000:0xD91AA320` | `Data/PatchData.package` | 168 | unknown/binary — 168 bytes |
| decoded | `0xDA141C1B:0x00000000:0x8F3A4C9D` | `DataEP1/Spore_EP1_Data.package` | 1,156 | unknown/binary — 1,156 bytes |
| decoded | `0xDA141C1B:0x00000000:0x095710C7` | `Data/PatchData.package` | 3,132 | unknown/binary — 3,132 bytes |
| decoded | `0xDA141C1B:0x00000000:0xE7538543` | `Data/Spore_Game.package` | 2,524 | unknown/binary — 2,524 bytes |
| decoded | `0xDA141C1B:0x00000000:0x2F77685E` | `Data/Spore_Game.package` | 2,372 | unknown/binary — 2,372 bytes |
| decoded | `0xDA141C1B:0x00000000:0x2A46E9EA` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0xDA141C1B:0x00000000:0x3D7C6059` | `DataEP1/Spore_EP1_Data.package` | 16 | unknown/binary — 16 bytes |

### `0x0497925E` — 63 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x0497925E:0x021407EE:0x0CBC1C57` | `Data/PatchData.package` | 116 | unknown/binary — 116 bytes |
| decoded | `0x0497925E:0x021407EE:0x52DD00C1` | `DataEP1/Spore_EP1_Data.package` | 32 | unknown/binary — 32 bytes |
| decoded | `0x0497925E:0x021407EE:0xCDDE2D78` | `Data/Spore_Audio1.package` | 4 | unknown/binary — 4 bytes |
| decoded | `0x0497925E:0x021407EE:0xE50BE14B` | `Data/Spore_Audio1.package` | 60 | unknown/binary — 60 bytes |
| decoded | `0x0497925E:0x021407EE:0xDD4D5CD8` | `Data/Spore_Audio1.package` | 180 | unknown/binary — 180 bytes |
| decoded | `0x0497925E:0x021407EE:0x250FC692` | `DataEP1/Spore_EP1_Data.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x0497925E:0x021407EE:0xF3F05329` | `Data/Spore_Audio1.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x0497925E:0x021407EE:0xC3B6E28F` | `Data/Spore_Audio1.package` | 32 | unknown/binary — 32 bytes |
| decoded | `0x0497925E:0x021407EE:0x47395AE5` | `DataEP1/Spore_EP1_Data.package` | 88 | unknown/binary — 88 bytes |
| decoded | `0x0497925E:0x021407EE:0x41601D81` | `Data/Spore_Audio1.package` | 20 | unknown/binary — 20 bytes |
| decoded | `0x0497925E:0x021407EE:0x1FEC7FDF` | `DataEP1/Spore_EP1_Data.package` | 32 | unknown/binary — 32 bytes |
| decoded | `0x0497925E:0x021407EE:0x03ED3BF9` | `Data/Spore_Audio1.package` | 80 | unknown/binary — 80 bytes |
| decoded | `0x0497925E:0x021407EE:0x1A27F146` | `DataEP1/Spore_EP1_Data.package` | 68 | unknown/binary — 68 bytes |
| decoded | `0x0497925E:0x021407EE:0x6FA34923` | `DataEP1/Spore_EP1_Data.package` | 32 | unknown/binary — 32 bytes |
| decoded | `0x0497925E:0x021407EE:0xF8BFA142` | `Data/Spore_Audio1.package` | 32 | unknown/binary — 32 bytes |
| decoded | `0x0497925E:0x021407EE:0x47395AE5` | `Data/Spore_Audio1.package` | 60 | unknown/binary — 60 bytes |
| decoded | `0x0497925E:0x021407EE:0x79E526CB` | `Data/Spore_Audio1.package` | 56 | unknown/binary — 56 bytes |
| decoded | `0x0497925E:0x021407EE:0x1DB6D6CC` | `Data/Spore_Audio1.package` | 60 | unknown/binary — 60 bytes |
| decoded | `0x0497925E:0x021407EE:0x38432C22` | `Data/Spore_Audio1.package` | 72 | unknown/binary — 72 bytes |
| decoded | `0x0497925E:0x021407EE:0xC676CE3E` | `Data/Spore_Audio1.package` | 140 | unknown/binary — 140 bytes |

### `0xF2B924B3` — 52 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xF2B924B3:0x72B924B5:0xD2E36F4B` | `Data/PatchData.package` | 229 | unknown/binary — 229 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xCF5256A8` | `Data/Spore_Game.package` | 115 | unknown/binary — 115 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xEE71DB16` | `Data/PatchData.package` | 229 | unknown/binary — 229 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xB5BC62BF` | `Data/Spore_Game.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x3EDBC51F` | `Data/Spore_Game.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xAED08DD4` | `Data/Spore_Game.package` | 229 | unknown/binary — 229 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x64044207` | `Data/PatchData.package` | 115 | unknown/binary — 115 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x1AA213D2` | `Data/PatchData.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xB60A3F9C` | `Data/PatchData.package` | 194 | unknown/binary — 194 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x64044206` | `Data/Spore_Game.package` | 115 | unknown/binary — 115 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x1AA213D2` | `Data/Spore_Game.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x2F2E15D2` | `Data/PatchData.package` | 229 | unknown/binary — 229 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xB60A3F9C` | `Data/Spore_Game.package` | 194 | unknown/binary — 194 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x9AE5223B` | `Data/PatchData.package` | 227 | unknown/binary — 227 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xEBC1D836` | `Data/Spore_Game.package` | 226 | unknown/binary — 226 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x664EEFC2` | `Data/Spore_Game.package` | 228 | unknown/binary — 228 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x9A3D2CCB` | `Data/Spore_Game.package` | 227 | unknown/binary — 227 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0xEE71DB16` | `Data/Spore_Game.package` | 229 | unknown/binary — 229 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x9A3D2CCB` | `Data/PatchData.package` | 227 | unknown/binary — 227 bytes |
| decoded | `0xF2B924B3:0x72B924B5:0x664EEFC2` | `Data/PatchData.package` | 228 | unknown/binary — 228 bytes |

### `0x01EEF63A` — 42 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x01EEF63A:0x021407EE:0x460FE7C5` | `Data/Spore_Audio2.package` | 1,987,392 | unknown/binary — 1,987,392 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1AA` | `Data/Spore_Audio2.package` | 978,560 | unknown/binary — 978,560 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1A8` | `Data/Spore_Audio2.package` | 1,111,360 | unknown/binary — 1,111,360 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1A7` | `Data/Spore_Audio2.package` | 1,083,136 | unknown/binary — 1,083,136 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xDAEE13FD` | `Data/Spore_Audio1.package` | 1,912,384 | unknown/binary — 1,912,384 bytes |
| decoded | `0x01EEF63A:0x021407EE:0x55AB9EEA` | `Data/Spore_Audio2.package` | 16,544,576 | unknown/binary — 16,544,576 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE7F72BC8` | `Data/Spore_Audio2.package` | 1,256,320 | unknown/binary — 1,256,320 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE7F72BC9` | `Data/Spore_Audio2.package` | 1,213,376 | unknown/binary — 1,213,376 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1A1` | `Data/Spore_Audio2.package` | 1,017,856 | unknown/binary — 1,017,856 bytes |
| decoded | `0x01EEF63A:0x021407EE:0x62F6E1AE` | `Data/Spore_Audio2.package` | 655,872 | unknown/binary — 655,872 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1A3` | `Data/Spore_Audio2.package` | 1,017,408 | unknown/binary — 1,017,408 bytes |
| decoded | `0x01EEF63A:0x021407EE:0x4244D484` | `Data/Spore_Audio2.package` | 6,205,824 | unknown/binary — 6,205,824 bytes |
| decoded | `0x01EEF63A:0x021407EE:0x9C43BBC9` | `Data/Spore_Audio2.package` | 423,744 | unknown/binary — 423,744 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1A6` | `Data/Spore_Audio2.package` | 986,624 | unknown/binary — 986,624 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xE90AB1A0` | `Data/Spore_Audio2.package` | 1,039,680 | unknown/binary — 1,039,680 bytes |
| decoded | `0x01EEF63A:0x021407EE:0x6AB57A69` | `Data/Spore_Audio2.package` | 18,058,496 | unknown/binary — 18,058,496 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xF8BE4230` | `Data/Spore_Audio2.package` | 2,234,624 | unknown/binary — 2,234,624 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xA1D7C001` | `Data/Spore_Audio2.package` | 6,122,432 | unknown/binary — 6,122,432 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xF85A9473` | `Data/Spore_Audio2.package` | 8,369,600 | unknown/binary — 8,369,600 bytes |
| decoded | `0x01EEF63A:0x021407EE:0xF8BE4233` | `Data/Spore_Audio2.package` | 1,274,048 | unknown/binary — 1,274,048 bytes |

### `0xEA5118B0` — 42 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xEA5118B0:0x40604301:0x00000001` | `bp1content/BoosterPack_01.package` | 104,989 | unknown/binary — 104,989 bytes |
| decoded | `0xEA5118B0:0x40450200:0xBAFC5CA1` | `Data/Spore_Graphics.package` | 631,889 | unknown/binary — 631,889 bytes |
| decoded | `0xEA5118B0:0x40604302:0x00000001` | `bp1content/BoosterPack_01.package` | 104,989 | unknown/binary — 104,989 bytes |
| decoded | `0xEA5118B0:0x408A4300:0xC1195706` | `DataEP1/Spore_EP1_Data.package` | 1,448,054 | unknown/binary — 1,448,054 bytes |
| decoded | `0xEA5118B0:0x40450201:0x2C978DA4` | `Data/PatchData.package` | 58,285 | unknown/binary — 58,285 bytes |
| decoded | `0xEA5118B0:0x40450200:0xC1195706` | `Data/Spore_Graphics.package` | 5,068,716 | unknown/binary — 5,068,716 bytes |
| decoded | `0xEA5118B0:0x40450200:0x5F848353` | `Data/Spore_Graphics.package` | 2,433,733 | unknown/binary — 2,433,733 bytes |
| decoded | `0xEA5118B0:0x40450200:0xC1195706` | `Data/PatchData.package` | 5,068,716 | unknown/binary — 5,068,716 bytes |
| decoded | `0xEA5118B0:0x40450201:0xC1195706` | `Data/PatchData.package` | 5,122,674 | unknown/binary — 5,122,674 bytes |
| decoded | `0xEA5118B0:0x40450201:0xBC2C0BE9` | `Data/PatchData.package` | 143,471 | unknown/binary — 143,471 bytes |
| decoded | `0xEA5118B0:0x40450202:0xBC2C0BE9` | `Data/Spore_Graphics.package` | 143,689 | unknown/binary — 143,689 bytes |
| decoded | `0xEA5118B0:0x40450202:0x5F848353` | `Data/Spore_Graphics.package` | 2,544,525 | unknown/binary — 2,544,525 bytes |
| decoded | `0xEA5118B0:0x40450201:0xBAFC5CA1` | `Data/PatchData.package` | 653,317 | unknown/binary — 653,317 bytes |
| decoded | `0xEA5118B0:0x40450201:0xBC2C0BE9` | `Data/Spore_Graphics.package` | 143,471 | unknown/binary — 143,471 bytes |
| decoded | `0xEA5118B0:0x40450201:0x4CF9B596` | `Data/Spore_Graphics.package` | 697,967 | unknown/binary — 697,967 bytes |
| decoded | `0xEA5118B0:0x40450202:0x2C978DA4` | `Data/Spore_Graphics.package` | 58,285 | unknown/binary — 58,285 bytes |
| decoded | `0xEA5118B0:0x408A4302:0xC1195706` | `DataEP1/Spore_EP1_Data.package` | 1,467,031 | unknown/binary — 1,467,031 bytes |
| decoded | `0xEA5118B0:0x40450201:0x4CF9B596` | `Data/PatchData.package` | 697,967 | unknown/binary — 697,967 bytes |
| decoded | `0xEA5118B0:0x40450202:0x5F848353` | `Data/PatchData.package` | 2,545,942 | unknown/binary — 2,545,942 bytes |
| decoded | `0xEA5118B0:0x40450201:0x5F848353` | `Data/PatchData.package` | 2,517,370 | unknown/binary — 2,517,370 bytes |

### `0x25DF0112` — 39 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x25DF0112:0x00000000:0xB00EAF67` | `Data/Spore_Game.package` | 8,984 | unknown/binary — 8,984 bytes |
| decoded | `0x25DF0112:0x00000000:0xB0DA01C0` | `Data/PatchData.package` | 5,288 | unknown/binary — 5,288 bytes |
| decoded | `0x25DF0112:0x00000000:0xB0DA01C3` | `Data/Spore_Game.package` | 2,448 | unknown/binary — 2,448 bytes |
| decoded | `0x25DF0112:0x00000000:0xB0DA01C3` | `Data/PatchData.package` | 2,448 | unknown/binary — 2,448 bytes |
| decoded | `0x25DF0112:0x00000000:0xB0DA01C4` | `Data/Spore_Game.package` | 14,016 | unknown/binary — 14,016 bytes |
| decoded | `0x25DF0112:0x00000000:0xB0DA01C6` | `Data/PatchData.package` | 9,664 | unknown/binary — 9,664 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF64` | `Data/Spore_Game.package` | 23,064 | unknown/binary — 23,064 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF62` | `Data/Spore_Game.package` | 45,432 | unknown/binary — 45,432 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF60` | `Data/PatchData.package` | 48,504 | unknown/binary — 48,504 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF66` | `Data/Spore_Game.package` | 1,208 | unknown/binary — 1,208 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF63` | `Data/PatchData.package` | 40,600 | unknown/binary — 40,600 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF64` | `Data/PatchData.package` | 27,552 | unknown/binary — 27,552 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF63` | `Data/Spore_Game.package` | 40,600 | unknown/binary — 40,600 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF66` | `Data/PatchData.package` | 1,208 | unknown/binary — 1,208 bytes |
| decoded | `0x25DF0112:0x00000000:0xB0DA01C1` | `Data/Spore_Game.package` | 7,056 | unknown/binary — 7,056 bytes |
| decoded | `0x25DF0112:0x00000000:0x01DCD147` | `Data/PatchData.package` | 32,908 | unknown/binary — 32,908 bytes |
| decoded | `0x25DF0112:0x00000000:0x4C3A8738` | `Data/Spore_Game.package` | 38,568 | unknown/binary — 38,568 bytes |
| decoded | `0x25DF0112:0x00000000:0xB6897971` | `Data/Spore_Game.package` | 24,816 | unknown/binary — 24,816 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF63` | `DataEP1/Spore_EP1_Data.package` | 40,600 | unknown/binary — 40,600 bytes |
| decoded | `0x25DF0112:0x00000000:0xB00EAF65` | `DataEP1/Spore_EP1_Data.package` | 24,792 | unknown/binary — 24,792 bytes |

### `0x02D5C9B0` — 37 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02D5C9B0:0x011AC19C:0x02DC95B4` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x0436D641` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x02DC95B4` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x05DE9730` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x052DA273` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x068375D7` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x05833344` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x0227F195` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x0534676F` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x04EBFEBD` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x04F65904` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x052C812A` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x05DE9730` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x052C8CA5` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x0436D641` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x068375D7` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x0428DE45` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x0428DE45` | `Data/Spore_Content.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0x052C8CA5` | `DataEP1/Spore_EP1_Content_01.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x02D5C9B0:0x011AC19C:0xA4E45195` | `DataEP1/Spore_EP1_Data.package` | 8 | unknown/binary — 8 bytes |

### `0x9B8E862F` — 37 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x9B8E862F:0x00000000:0x8393271F` | `Data/PatchData.package` | 544 | unknown/binary — 544 bytes |
| decoded | `0x9B8E862F:0x00000000:0x3AAF1035` | `DataEP1/Spore_EP1_Data.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x6D2FC7B7` | `DataEP1/Spore_EP1_Data.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x9B8E862F:0x00000000:0x5F180E4F` | `Data/PatchData.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0x9B8E862F:0x00000000:0x33BEB73B` | `Data/PatchData.package` | 136 | unknown/binary — 136 bytes |
| decoded | `0x9B8E862F:0x00000000:0x17BE63FB` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x33BEB73B` | `Data/Spore_Game.package` | 136 | unknown/binary — 136 bytes |
| decoded | `0x9B8E862F:0x00000000:0x664987EB` | `Data/PatchData.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0x9B8E862F:0x00000000:0x664987EB` | `Data/Spore_Game.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0x9B8E862F:0x00000000:0x6F95F97B` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x6D2FC7B7` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x9B8E862F:0x00000000:0xDB9066CF` | `DataEP1/Spore_EP1_Data.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0xDB9066CF` | `Data/PatchData.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x8393271F` | `Data/Spore_Game.package` | 544 | unknown/binary — 544 bytes |
| decoded | `0x9B8E862F:0x00000000:0x81A666D9` | `DataEP1/Spore_EP1_Data.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x17BE63FB` | `Data/Spore_Game.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0xDB9066CF` | `Data/Spore_Game.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x6F95F97B` | `Data/Spore_Game.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x3AAF1035` | `Data/Spore_Game.package` | 64 | unknown/binary — 64 bytes |
| decoded | `0x9B8E862F:0x00000000:0x06A14891` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |

### `0x02C9EFF2` — 36 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02C9EFF2:0x021407EE:0xF1CC1687` | `Data/PatchData.package` | 76 | unknown/binary — 76 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x45D02E70` | `Data/Spore_Audio1.package` | 138 | unknown/binary — 138 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0xB3E58FE9` | `Data/Spore_Audio1.package` | 112 | unknown/binary — 112 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x45D02E73` | `Data/PatchData.package` | 138 | unknown/binary — 138 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x45D02E70` | `Data/PatchData.package` | 138 | unknown/binary — 138 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x341D24B7` | `Data/Spore_Audio1.package` | 132 | unknown/binary — 132 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0xADB23A20` | `Data/PatchData.package` | 108 | unknown/binary — 108 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x362087BD` | `Data/PatchData.package` | 102 | unknown/binary — 102 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x14CCC315` | `Data/PatchData.package` | 117 | unknown/binary — 117 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0xADB23A20` | `Data/Spore_Audio1.package` | 108 | unknown/binary — 108 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x724A8EE7` | `Data/Spore_Audio1.package` | 132 | unknown/binary — 132 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x45253DC1` | `Data/PatchData.package` | 106 | unknown/binary — 106 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x724A8EE7` | `Data/PatchData.package` | 132 | unknown/binary — 132 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x0DEEBAF5` | `Data/Spore_Audio1.package` | 106 | unknown/binary — 106 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0xB3E58FE9` | `Data/PatchData.package` | 112 | unknown/binary — 112 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x45D02E73` | `Data/Spore_Audio1.package` | 138 | unknown/binary — 138 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x85901C81` | `Data/PatchData.package` | 104 | unknown/binary — 104 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x341D24B7` | `Data/PatchData.package` | 132 | unknown/binary — 132 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0xF1CC1687` | `Data/Spore_Audio1.package` | 76 | unknown/binary — 76 bytes |
| decoded | `0x02C9EFF2:0x021407EE:0x14CCC315` | `Data/Spore_Audio1.package` | 117 | unknown/binary — 117 bytes |

### `0x0469A3F7` — 36 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x0469A3F7:0x40212000:0x00000001` | `DataEP1/Spore_EP1_Data.package` | 6,710 | unknown/binary — 6,710 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000003` | `DataEP1/Spore_EP1_Data.package` | 351,276 | HLSL-source-candidate — 351,276 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000003` | `Data/PatchData.package` | 351,276 | HLSL-source-candidate — 351,276 bytes |
| decoded | `0x0469A3F7:0x40212000:0x00000001` | `Data/PatchData.package` | 6,710 | unknown/binary — 6,710 bytes |
| decoded | `0x0469A3F7:0x40212000:0x00000002` | `Data/PatchData.package` | 6,710 | unknown/binary — 6,710 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000000` | `Data/PatchData.package` | 337,465 | HLSL-source-candidate — 337,465 bytes |
| decoded | `0x0469A3F7:0x40212000:0x00000003` | `Data/PatchData.package` | 6,726 | unknown/binary — 6,726 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000001` | `Data/PatchData.package` | 340,399 | HLSL-source-candidate — 340,399 bytes |
| decoded | `0x0469A3F7:0x40212004:0x00000003` | `Data/Spore_Graphics.package` | 5,365,997 | unknown/binary — 5,365,997 bytes |
| decoded | `0x0469A3F7:0x40212004:0x00000001` | `Data/PatchData.package` | 4,957,330 | unknown/binary — 4,957,330 bytes |
| decoded | `0x0469A3F7:0x40212004:0x00000001` | `Data/Spore_Graphics.package` | 4,090,938 | unknown/binary — 4,090,938 bytes |
| decoded | `0x0469A3F7:0x40212004:0x00000000` | `DataEP1/Spore_EP1_Data.package` | 4,275,306 | unknown/binary — 4,275,306 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000002` | `Data/Spore_Graphics.package` | 349,723 | HLSL-source-candidate — 349,723 bytes |
| decoded | `0x0469A3F7:0x40212000:0x00000000` | `DataEP1/Spore_EP1_Data.package` | 6,710 | unknown/binary — 6,710 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000000` | `DataEP1/Spore_EP1_Data.package` | 337,465 | HLSL-source-candidate — 337,465 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000001` | `DataEP1/Spore_EP1_Data.package` | 340,399 | HLSL-source-candidate — 340,399 bytes |
| decoded | `0x0469A3F7:0x40212002:0x00000000` | `Data/Spore_Graphics.package` | 337,644 | HLSL-source-candidate — 337,644 bytes |
| decoded | `0x0469A3F7:0x40212000:0x00000002` | `DataEP1/Spore_EP1_Data.package` | 6,710 | unknown/binary — 6,710 bytes |
| decoded | `0x0469A3F7:0x40212000:0x00000003` | `Data/Spore_Graphics.package` | 6,628 | unknown/binary — 6,628 bytes |
| decoded | `0x0469A3F7:0x40212004:0x00000003` | `DataEP1/Spore_EP1_Data.package` | 6,915,641 | unknown/binary — 6,915,641 bytes |

### `0x047B8300` — 32 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x047B8300:0x02412C19:0x1A5337B5` | `Data/Spore_Game.package` | 16,906 | unknown/binary — 16,906 bytes |
| decoded | `0x047B8300:0x02412C19:0xEDF593AB` | `Data/Spore_Game.package` | 17,962 | unknown/binary — 17,962 bytes |
| decoded | `0x047B8300:0x02412C19:0xC49B97A3` | `Data/Spore_Game.package` | 16,378 | unknown/binary — 16,378 bytes |
| decoded | `0x047B8300:0x02412C19:0xC49B97A3` | `Data/PatchData.package` | 16,378 | unknown/binary — 16,378 bytes |
| decoded | `0x047B8300:0x02412C19:0x592DA373` | `Data/PatchData.package` | 18,490 | unknown/binary — 18,490 bytes |
| decoded | `0x047B8300:0x02412C19:0x5E0AC22E` | `Data/Spore_Game.package` | 72,346 | unknown/binary — 72,346 bytes |
| decoded | `0x047B8300:0x02412C19:0xCD482419` | `Data/Spore_Game.package` | 17,962 | unknown/binary — 17,962 bytes |
| decoded | `0x047B8300:0x02412C19:0x4DDB0AF7` | `Data/Spore_Game.package` | 22,010 | unknown/binary — 22,010 bytes |
| decoded | `0x047B8300:0x02412C19:0xF1851946` | `Data/PatchData.package` | 16,730 | unknown/binary — 16,730 bytes |
| decoded | `0x047B8300:0x02412C19:0xC7BEDB5A` | `Data/PatchData.package` | 14,090 | unknown/binary — 14,090 bytes |
| decoded | `0x047B8300:0x02412C19:0xB59BA540` | `Data/PatchData.package` | 22,362 | unknown/binary — 22,362 bytes |
| decoded | `0x047B8300:0x02412C19:0x5E0AC22E` | `Data/PatchData.package` | 72,346 | unknown/binary — 72,346 bytes |
| decoded | `0x047B8300:0x02412C19:0xA36D90EE` | `Data/Spore_Game.package` | 15,850 | unknown/binary — 15,850 bytes |
| decoded | `0x047B8300:0x02412C19:0x73BD8FEB` | `Data/PatchData.package` | 19,194 | unknown/binary — 19,194 bytes |
| decoded | `0x047B8300:0x02412C19:0x73BD8FEB` | `Data/Spore_Game.package` | 19,194 | unknown/binary — 19,194 bytes |
| decoded | `0x047B8300:0x02412C19:0xD7796C1F` | `Data/PatchData.package` | 17,786 | unknown/binary — 17,786 bytes |
| decoded | `0x047B8300:0x02412C19:0xC7BEDB5A` | `Data/Spore_Game.package` | 14,090 | unknown/binary — 14,090 bytes |
| decoded | `0x047B8300:0x02412C19:0x56711DE0` | `Data/Spore_Game.package` | 23,242 | unknown/binary — 23,242 bytes |
| decoded | `0x047B8300:0x02412C19:0xD7796C1F` | `Data/Spore_Game.package` | 17,786 | unknown/binary — 17,786 bytes |
| decoded | `0x047B8300:0x02412C19:0x592DA373` | `Data/Spore_Game.package` | 18,490 | unknown/binary — 18,490 bytes |

### `0x3D97A8E4` — 26 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x3D97A8E4:0x40616200:0x0625A980` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A976` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A978` | `Data/PatchData.package` | 4,215 | XML/ASCII — 4,215 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A97A` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A97C` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A97E` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A980` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A982` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A984` | `Data/PatchData.package` | 4,201 | XML/ASCII — 4,201 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A986` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A988` | `Data/PatchData.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A986` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A988` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0C7963FB` | `Data/Spore_Game.package` | 4,568 | XML/ASCII — 4,568 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A974` | `Data/Spore_Game.package` | 4,215 | XML/ASCII — 4,215 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A976` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A982` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A984` | `Data/Spore_Game.package` | 4,201 | XML/ASCII — 4,201 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A97C` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |
| decoded | `0x3D97A8E4:0x40616200:0x0625A97E` | `Data/Spore_Game.package` | 4,222 | XML/ASCII — 4,222 bytes |

### `0xF9C3D770` — 22 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xF9C3D770:0x00000000:0x4122E50C` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x4122E50F` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x9A391385` | `Data/PatchData.package` | 120 | unknown/binary — 120 bytes |
| decoded | `0xF9C3D770:0x00000000:0xD7E124A4` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xD7E124A7` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xBC092044` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xBC092047` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xB17DEBCC` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xB17DEBCF` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x6BEAB167` | `Data/PatchData.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x6BEAB167` | `DataEP1/Spore_EP1_Data.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xD7E124A7` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x4122E50C` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x4122E50F` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xBC092044` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0xBC092047` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x6BEAB167` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |
| decoded | `0xF9C3D770:0x00000000:0x9A391385` | `Data/Spore_Game.package` | 120 | unknown/binary — 120 bytes |
| decoded | `0xF9C3D770:0x00000000:0x9A391385` | `DataEP1/Spore_EP1_Data.package` | 120 | unknown/binary — 120 bytes |
| decoded | `0xF9C3D770:0x00000000:0xB17DEBCF` | `Data/Spore_Game.package` | 36 | unknown/binary — 36 bytes |

### `0x8C042499` — 20 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x8C042499:0x00000000:0x42FDE1B6` | `Data/PatchData.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0x7188F42F` | `Data/PatchData.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0x93BEC3B3` | `Data/PatchData.package` | 48 | unknown/binary — 48 bytes |
| decoded | `0x8C042499:0x00000000:0xF9E9796C` | `Data/PatchData.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0xD929E413` | `Data/PatchData.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0xFE656169` | `Data/PatchData.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0x626522CF` | `Data/PatchData.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0xEEC00A8F` | `Data/PatchData.package` | 88 | unknown/binary — 88 bytes |
| decoded | `0x8C042499:0x00000000:0xB0953EB5` | `Data/PatchData.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0xE1F69365` | `Data/PatchData.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0x93BEC3B3` | `Data/Spore_Game.package` | 48 | unknown/binary — 48 bytes |
| decoded | `0x8C042499:0x00000000:0x626522CF` | `Data/Spore_Game.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0x42FDE1B6` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0xF9E9796C` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0xB0953EB5` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0xEEC00A8F` | `Data/Spore_Game.package` | 88 | unknown/binary — 88 bytes |
| decoded | `0x8C042499:0x00000000:0x7188F42F` | `Data/Spore_Game.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0xFE656169` | `Data/Spore_Game.package` | 24 | unknown/binary — 24 bytes |
| decoded | `0x8C042499:0x00000000:0xE1F69365` | `Data/Spore_Game.package` | 16 | unknown/binary — 16 bytes |
| decoded | `0x8C042499:0x00000000:0xD929E413` | `Data/Spore_Game.package` | 24 | unknown/binary — 24 bytes |

### `0x448AE7E2` — 18 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x448AE7E2:0x6C0DFB08:0xC45E4C50` | `Data/PatchData.package` | 1,152 | unknown/binary — 1,152 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xE8C6E8DC` | `Data/PatchData.package` | 15,840 | unknown/binary — 15,840 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xBECF22F2` | `Data/PatchData.package` | 7,872 | unknown/binary — 7,872 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x638E8E2D` | `Data/PatchData.package` | 1,616 | unknown/binary — 1,616 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xDF4323F7` | `Data/PatchData.package` | 8,256 | unknown/binary — 8,256 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xBB1C3CBF` | `Data/PatchData.package` | 10,352 | unknown/binary — 10,352 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x5E60FFD2` | `Data/PatchData.package` | 20,128 | unknown/binary — 20,128 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x22D5BCA8` | `Data/PatchData.package` | 3,072 | unknown/binary — 3,072 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x017E2AF6` | `Data/PatchData.package` | 10,352 | unknown/binary — 10,352 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xE8C6E8DC` | `Data/Spore_Game.package` | 15,840 | unknown/binary — 15,840 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x5E60FFD2` | `Data/Spore_Game.package` | 20,128 | unknown/binary — 20,128 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xBB1C3CBF` | `Data/Spore_Game.package` | 10,352 | unknown/binary — 10,352 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xBECF22F2` | `Data/Spore_Game.package` | 7,872 | unknown/binary — 7,872 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x017E2AF6` | `Data/Spore_Game.package` | 10,352 | unknown/binary — 10,352 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x638E8E2D` | `Data/Spore_Game.package` | 1,616 | unknown/binary — 1,616 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xDF4323F7` | `Data/Spore_Game.package` | 8,256 | unknown/binary — 8,256 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0xC45E4C50` | `Data/Spore_Game.package` | 1,152 | unknown/binary — 1,152 bytes |
| decoded | `0x448AE7E2:0x6C0DFB08:0x22D5BCA8` | `Data/Spore_Game.package` | 3,072 | unknown/binary — 3,072 bytes |

### `0x04805684` — 16 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x04805684:0x00000000:0x266BB8B3` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xD144217E` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xB693FBAC` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xC7EE8594` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x0DE60A0B` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x2EA8FB98` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xEEE342EE` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x81758B75` | `Data/PatchData.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x0DE60A0B` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xC7EE8594` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x2EA8FB98` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xD144217E` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x81758B75` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xB693FBAC` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0xEEE342EE` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |
| decoded | `0x04805684:0x00000000:0x266BB8B3` | `Data/Spore_Game.package` | 196,608 | unknown/binary — 196,608 bytes |

### `0xFD60F0C1` — 16 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xFD60F0C1:0x408A0000:0xF63B6851` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xAF1BC5FF` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xE8CA06B0` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xE6F78525` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x1FB0677A` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xEF9DD7F3` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x3C546825` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xECF6B868` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x5292926C` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x6FCBCE96` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xC2C7B154` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x0A91C418` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x6E008979` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xF3AA05AA` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0xBF0CE0D0` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |
| decoded | `0xFD60F0C1:0x408A0000:0x288BE48A` | `DataEP1/Spore_EP1_Data.package` | 28 | unknown/binary — 28 bytes |

### `0xCF6C21B8` — 14 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xCF6C21B8:0x0248E873:0x82580884` | `Data/Spore_Graphics.package` | 285 | XML/ASCII — 285 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x347AC8DD` | `Data/Spore_Graphics.package` | 2,104 | XML/ASCII — 2,104 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x5E120D3F` | `Data/Spore_Graphics.package` | 70,032 | XML/ASCII — 70,032 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x3A080BC4` | `Data/Spore_Graphics.package` | 583 | XML/ASCII — 583 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x033FE3FD` | `Data/Spore_Graphics.package` | 37,425 | XML/ASCII — 37,425 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x892FF8E7` | `DataEP1/Spore_EP1_Data.package` | 70,032 | XML/ASCII — 70,032 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0xE0A52995` | `DataEP1/Spore_EP1_Data.package` | 2,079 | XML/ASCII — 2,079 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x82580884` | `DataEP1/Spore_EP1_Data.package` | 285 | XML/ASCII — 285 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x086F9135` | `DataEP1/Spore_EP1_Data.package` | 37,425 | XML/ASCII — 37,425 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x347AC8DD` | `DataEP1/Spore_EP1_Data.package` | 2,104 | XML/ASCII — 2,104 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x9015991C` | `DataEP1/Spore_EP1_Data.package` | 288 | XML/ASCII — 288 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x5E120D3F` | `DataEP1/Spore_EP1_Data.package` | 70,032 | XML/ASCII — 70,032 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x3A080BC4` | `DataEP1/Spore_EP1_Data.package` | 583 | XML/ASCII — 583 bytes |
| decoded | `0xCF6C21B8:0x0248E873:0x033FE3FD` | `DataEP1/Spore_EP1_Data.package` | 37,425 | XML/ASCII — 37,425 bytes |

### `0x027C5CEF` — 10 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x027C5CEF:0x0248E873:0x511B49CA` | `Data/Spore_Graphics.package` | 117,628 | unknown/binary — 117,628 bytes |
| decoded | `0x027C5CEF:0x0248E873:0xBACAAAA5` | `Data/Spore_Graphics.package` | 23,311,968 | unknown/binary — 23,311,968 bytes |
| decoded | `0x027C5CEF:0x0248E873:0xFFE355DF` | `Data/Spore_Graphics.package` | 8,672 | unknown/binary — 8,672 bytes |
| decoded | `0x027C5CEF:0x0248E873:0x61639DFB` | `Data/Spore_Graphics.package` | 228,016 | unknown/binary — 228,016 bytes |
| decoded | `0x027C5CEF:0x0248E873:0x6BBC4E0E` | `Data/Spore_Graphics.package` | 3,736 | unknown/binary — 3,736 bytes |
| decoded | `0x027C5CEF:0x0248E873:0x511B49CA` | `DataEP1/Spore_EP1_Data.package` | 117,628 | unknown/binary — 117,628 bytes |
| decoded | `0x027C5CEF:0x0248E873:0xBACAAAA5` | `DataEP1/Spore_EP1_Data.package` | 23,311,968 | unknown/binary — 23,311,968 bytes |
| decoded | `0x027C5CEF:0x0248E873:0xFFE355DF` | `DataEP1/Spore_EP1_Data.package` | 8,672 | unknown/binary — 8,672 bytes |
| decoded | `0x027C5CEF:0x0248E873:0x61639DFB` | `DataEP1/Spore_EP1_Data.package` | 228,016 | unknown/binary — 228,016 bytes |
| decoded | `0x027C5CEF:0x0248E873:0x6BBC4E0E` | `DataEP1/Spore_EP1_Data.package` | 3,736 | unknown/binary — 3,736 bytes |

### `0x0330A65E` — 10 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x0330A65E:0x021407EE:0x4CD4312F` | `Data/Spore_Audio2.package` | 13,316 | XML/ASCII — 13,316 bytes |
| decoded | `0x0330A65E:0x021407EE:0xCC15A7AA` | `Data/Spore_Audio2.package` | 713 | XML/ASCII — 713 bytes |
| decoded | `0x0330A65E:0x021407EE:0xF920A66B` | `Data/Spore_Audio2.package` | 338,489 | XML/ASCII — 338,489 bytes |
| decoded | `0x0330A65E:0x021407EE:0x00023F9D` | `Data/Spore_Audio2.package` | 99,706 | XML/ASCII — 99,706 bytes |
| decoded | `0x0330A65E:0x021407EE:0x7EF10F06` | `Data/Spore_Audio2.package` | 333,970 | XML/ASCII — 333,970 bytes |
| decoded | `0x0330A65E:0x021407EE:0x33E62CBF` | `Data/Spore_Audio2.package` | 5,026 | XML/ASCII — 5,026 bytes |
| decoded | `0x0330A65E:0x021407EE:0xB05A4F0B` | `Data/Spore_Audio2.package` | 333,951 | XML/ASCII — 333,951 bytes |
| decoded | `0x0330A65E:0x021407EE:0x2F5049CB` | `Data/Spore_Audio2.package` | 47,351 | XML/ASCII — 47,351 bytes |
| decoded | `0x0330A65E:0x021407EE:0xCF05BF48` | `Data/Spore_Audio2.package` | 104,045 | XML/ASCII — 104,045 bytes |
| decoded | `0x0330A65E:0x021407EE:0xBC8FBE98` | `Data/Spore_Audio2.package` | 1,337 | XML/ASCII — 1,337 bytes |

### `0x03E421E9` — 10 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x03E421E9:0x00000000:0x2D884687` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |
| decoded | `0x03E421E9:0x00000000:0x1A4D48A7` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |
| decoded | `0x03E421E9:0x00000000:0x9A76F5E7` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |
| decoded | `0x03E421E9:0x00000000:0x8E960553` | `Data/Spore_Graphics.package` | 524,312 | unknown/binary — 524,312 bytes |
| decoded | `0x03E421E9:0x00000000:0x59DB37F2` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |
| decoded | `0x03E421E9:0x00000000:0xEED2A658` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |
| decoded | `0x03E421E9:0x00000000:0xDE12103B` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |
| decoded | `0x03E421E9:0x00000000:0x733CC614` | `Data/Spore_Graphics.package` | 524,312 | unknown/binary — 524,312 bytes |
| decoded | `0x03E421E9:0x00000000:0x810E5E7D` | `Data/Spore_Graphics.package` | 524,312 | unknown/binary — 524,312 bytes |
| decoded | `0x03E421E9:0x00000000:0x15FF5CDA` | `Data/Spore_Graphics.package` | 131,096 | unknown/binary — 131,096 bytes |

### `0x5C74D18B` — 10 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x5C74D18B:0x00000000:0x42C623CC` | `Data/PatchData.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x8C3517B5` | `Data/PatchData.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x8C3517B6` | `Data/PatchData.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0xD424EEDC` | `Data/PatchData.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x24C96F9E` | `Data/PatchData.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x24C96F9E` | `Data/Spore_Game.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x8C3517B5` | `Data/Spore_Game.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x8C3517B6` | `Data/Spore_Game.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0x42C623CC` | `Data/Spore_Game.package` | 65,536 | unknown/binary — 65,536 bytes |
| decoded | `0x5C74D18B:0x00000000:0xD424EEDC` | `Data/Spore_Game.package` | 65,536 | unknown/binary — 65,536 bytes |

### `0x0248F226` — 9 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x0248F226:0x05AD83F4:0x3BC56E83` | `Data/Locale/en-gb/UI.package` | 1,263 | unknown/binary — 1,263 bytes |
| decoded | `0x0248F226:0x05AD83F4:0x94DA47E5` | `Data/Locale/en-gb/UI.package` | 2,315 | text/ASCII — 2,315 bytes |
| decoded | `0x0248F226:0x05AD83F4:0x3BC56E83` | `Data/Locale/ru-ru/UI.package` | 1,263 | unknown/binary — 1,263 bytes |
| decoded | `0x0248F226:0x05AD83F4:0x94DA47E5` | `Data/Locale/ru-ru/UI.package` | 2,650 | text/ASCII — 2,650 bytes |
| decoded | `0x0248F226:0x0248E873:0x94DA47E5` | `Data/PatchData.package` | 19,943 | text/ASCII — 19,943 bytes |
| decoded | `0x0248F226:0x041BBEB9:0x3BC56E83` | `Data/PatchData.package` | 1,395 | unknown/binary — 1,395 bytes |
| decoded | `0x0248F226:0x041BBEB9:0x3BC56E83` | `Data/Spore_Game.package` | 1,395 | unknown/binary — 1,395 bytes |
| decoded | `0x0248F226:0x0248E873:0x94DA47E5` | `Data/Spore_Graphics.package` | 19,802 | text/ASCII — 19,802 bytes |
| decoded | `0x0248F226:0x0248E873:0x94DA47E5` | `DataEP1/Spore_EP1_Data.package` | 21,245 | text/ASCII — 21,245 bytes |

### `0x029E333B` — 9 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x029E333B:0x021407EE:0xF1CC1687` | `Data/Spore_Audio1.package` | 26 | unknown/binary — 26 bytes |
| decoded | `0x029E333B:0x021407EE:0x4F669645` | `Data/Spore_Audio1.package` | 162 | unknown/binary — 162 bytes |
| decoded | `0x029E333B:0x021407EE:0x459B46E1` | `Data/Spore_Audio1.package` | 104 | unknown/binary — 104 bytes |
| decoded | `0x029E333B:0x021407EE:0xBF583E6C` | `Data/Spore_Audio1.package` | 453 | unknown/binary — 453 bytes |
| decoded | `0x029E333B:0x021407EE:0x2EA8FB98` | `Data/Spore_Audio1.package` | 590 | unknown/binary — 590 bytes |
| decoded | `0x029E333B:0x021407EE:0x6F394B77` | `Data/Spore_Audio1.package` | 163 | unknown/binary — 163 bytes |
| decoded | `0x029E333B:0x021407EE:0x8CE4C4D7` | `Data/Spore_Audio1.package` | 652 | unknown/binary — 652 bytes |
| decoded | `0x029E333B:0x021407EE:0x0B8AF40E` | `DataEP1/Spore_EP1_Data.package` | 512 | unknown/binary — 512 bytes |
| decoded | `0x029E333B:0x021407EE:0x2EA8FB98` | `DataEP1/Spore_EP1_Data.package` | 599 | unknown/binary — 599 bytes |

### `0x24682294` — 8 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x24682294:0x40646200:0x65D8B119` | `Data/PatchData.package` | 28,525 | XML/ASCII — 28,525 bytes |
| decoded | `0x24682294:0x40646200:0xCD442489` | `Data/PatchData.package` | 19,256 | XML/ASCII — 19,256 bytes |
| decoded | `0x24682294:0x40646200:0x89B047C6` | `Data/PatchData.package` | 20,255 | XML/ASCII — 20,255 bytes |
| decoded | `0x24682294:0x40646200:0x69DD3497` | `Data/PatchData.package` | 16,326 | XML/ASCII — 16,326 bytes |
| decoded | `0x24682294:0x40646200:0xCD442489` | `Data/Spore_Game.package` | 19,256 | XML/ASCII — 19,256 bytes |
| decoded | `0x24682294:0x40646200:0x69DD3497` | `Data/Spore_Game.package` | 16,326 | XML/ASCII — 16,326 bytes |
| decoded | `0x24682294:0x40646200:0x65D8B119` | `Data/Spore_Game.package` | 28,525 | XML/ASCII — 28,525 bytes |
| decoded | `0x24682294:0x40646200:0x89B047C6` | `Data/Spore_Game.package` | 20,255 | XML/ASCII — 20,255 bytes |

### `0x042C9CBB` — 6 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x042C9CBB:0x021407EE:0x6AB57A69` | `Data/Spore_Audio2.package` | 80,846 | unknown/binary — 80,846 bytes |
| decoded | `0x042C9CBB:0x021407EE:0xA1D7C001` | `Data/Spore_Audio2.package` | 28,182 | unknown/binary — 28,182 bytes |
| decoded | `0x042C9CBB:0x021407EE:0x8D357F88` | `Data/Spore_Audio2.package` | 3,252 | unknown/binary — 3,252 bytes |
| decoded | `0x042C9CBB:0x021407EE:0xBE3DA4C6` | `Data/Spore_Audio2.package` | 31,642 | unknown/binary — 31,642 bytes |
| decoded | `0x042C9CBB:0x021407EE:0x72B15D29` | `Data/Spore_Audio2.package` | 57,312 | unknown/binary — 57,312 bytes |
| decoded | `0x042C9CBB:0x021407EE:0x55AB9EEA` | `Data/Spore_Audio2.package` | 71,196 | unknown/binary — 71,196 bytes |

### `0x02CB4F2F` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02CB4F2F:0x00000000:0x5C1900FE` | `Data/PatchData.package` | 8,184 | unknown/binary — 8,184 bytes |
| decoded | `0x02CB4F2F:0x00000000:0x1FA9AB84` | `Data/PatchData.package` | 8,184 | unknown/binary — 8,184 bytes |
| decoded | `0x02CB4F2F:0x00000000:0x5C1900FE` | `Data/Spore_Game.package` | 8,184 | unknown/binary — 8,184 bytes |
| decoded | `0x02CB4F2F:0x00000000:0x1FA9AB84` | `Data/Spore_Game.package` | 8,184 | unknown/binary — 8,184 bytes |

### `0x12952634` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x12952634:0x00000000:0x9C7EAA60` | `bp1content/BoosterPack_01.package` | 258 | unknown/binary — 258 bytes |
| decoded | `0x12952634:0x00000000:0x9C7EAA60` | `Data/PatchData.package` | 258 | unknown/binary — 258 bytes |
| decoded | `0x12952634:0x00000000:0x9C7EAA60` | `Data/Spore_Game.package` | 258 | unknown/binary — 258 bytes |
| decoded | `0x12952634:0x00000000:0x9C7EAA60` | `DataEP1/Spore_EP1_Data.package` | 258 | unknown/binary — 258 bytes |

### `0x2F7D0006` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2F7D0006:0x8A7BE0C0:0x1F2E46B7` | `DataEP1/Spore_EP1_Data.package` | 7,784 | unknown/binary — 7,784 bytes |
| decoded | `0x2F7D0006:0x8A7BE0C0:0xC75F273D` | `DataEP1/Spore_EP1_Data.package` | 7,784 | unknown/binary — 7,784 bytes |
| decoded | `0x2F7D0006:0x8A7BE0C0:0x56185B46` | `DataEP1/Spore_EP1_Data.package` | 10,364 | unknown/binary — 10,364 bytes |
| decoded | `0x2F7D0006:0x8A7BE0C0:0x0C95E756` | `DataEP1/Spore_EP1_Data.package` | 7,784 | unknown/binary — 7,784 bytes |

### `0x376840D7` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x376840D7:0x00000000:0x09EE4B01` | `Data/Spore_Graphics.package` | 7,882,676 | unknown/binary — 7,882,676 bytes |
| decoded | `0x376840D7:0x00000000:0x2D7D6A26` | `Data/Spore_Graphics.package` | 8,539,860 | unknown/binary — 8,539,860 bytes |
| decoded | `0x376840D7:0x00000000:0x62F7C5C4` | `DataEP1/Spore_EP1_Data.package` | 8,539,860 | unknown/binary — 8,539,860 bytes |
| decoded | `0x376840D7:0x00000000:0x7AF7DF4F` | `DataEP1/Spore_EP1_Data.package` | 14,078,064 | unknown/binary — 14,078,064 bytes |

### `0x476A98C7` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x476A98C7:0x40656200:0xB11D3AA9` | `Data/PatchData.package` | 20,337 | XML/ASCII — 20,337 bytes |
| decoded | `0x476A98C7:0x40656200:0x6ABF210B` | `Data/PatchData.package` | 24,525 | XML/ASCII — 24,525 bytes |
| decoded | `0x476A98C7:0x40656200:0x6ABF210B` | `Data/Spore_Game.package` | 24,525 | XML/ASCII — 24,525 bytes |
| decoded | `0x476A98C7:0x40656200:0xB11D3AA9` | `Data/Spore_Game.package` | 20,337 | XML/ASCII — 20,337 bytes |

### `0x4AEB6BC6` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x4AEB6BC6:0x000070C1:0xD5F0E3C8` | `bp1content/BoosterPack_01.package` | 2,442 | unknown/binary — 2,442 bytes |
| decoded | `0x4AEB6BC6:0x000082D0:0x142CBA20` | `Data/PatchData.package` | 342,835 | unknown/binary — 342,835 bytes |
| decoded | `0x4AEB6BC6:0x00006F14:0xF8CC4670` | `Data/Spore_Game.package` | 208,414 | unknown/binary — 208,414 bytes |
| decoded | `0x4AEB6BC6:0x000082EA:0x82BBAA18` | `DataEP1/Spore_EP1_Data.package` | 201,348 | unknown/binary — 201,348 bytes |

### `0x617715C4` — 4 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x617715C4:0x40606600:0xC1807FD3` | `Data/PatchData.package` | 4,552 | unknown/binary — 4,552 bytes |
| decoded | `0x617715C4:0x40606600:0xC1807FD3` | `Data/Spore_Game.package` | 4,552 | unknown/binary — 4,552 bytes |
| decoded | `0x617715C4:0xB94BBB7E:0x5615B763` | `Data/Spore_Graphics.package` | 1,050 | unknown/binary — 1,050 bytes |
| decoded | `0x617715C4:0xB94BBB7E:0x24594AC6` | `Data/Spore_Graphics.package` | 3,204 | unknown/binary — 3,204 bytes |

### `0x00000000` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x00000000:0x0248E873:0xB038BEF1` | `Data/PatchData.package` | 105,940 | unknown/binary — 105,940 bytes |
| decoded | `0x00000000:0x0248E873:0xB038BEF1` | `Data/Spore_Graphics.package` | 92,500 | unknown/binary — 92,500 bytes |
| decoded | `0x00000000:0x0248E873:0xB038BEF1` | `DataEP1/Spore_EP1_Data.package` | 4 | unknown/binary — 4 bytes |

### `0x03E421EC` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x03E421EC:0x00000000:0x8C995802` | `Data/Spore_Graphics.package` | 4,116 | unknown/binary — 4,116 bytes |
| decoded | `0x03E421EC:0x00000000:0xC5D262E4` | `Data/Spore_Graphics.package` | 65,556 | unknown/binary — 65,556 bytes |
| decoded | `0x03E421EC:0x00000000:0x361D1E3F` | `Data/Spore_Graphics.package` | 1,048,596 | unknown/binary — 1,048,596 bytes |

### `0x03E421EF` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x03E421EF:0x00000000:0x60ECA9E0` | `Data/Spore_Graphics.package` | 294,932 | unknown/binary — 294,932 bytes |
| decoded | `0x03E421EF:0x00000000:0x71EBAFF9` | `Data/Spore_Graphics.package` | 294,932 | unknown/binary — 294,932 bytes |
| decoded | `0x03E421EF:0x00000000:0x7D328FDD` | `Data/Spore_Graphics.package` | 294,932 | unknown/binary — 294,932 bytes |

### `0x05BAD11C` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x05BAD11C:0x021407EE:0xA101B2C4` | `Data/PatchData.package` | 163,520 | unknown/binary — 163,520 bytes |
| decoded | `0x05BAD11C:0x021407EE:0xA101B2C4` | `Data/Spore_Audio2.package` | 163,520 | unknown/binary — 163,520 bytes |
| decoded | `0x05BAD11C:0x021407EE:0xA101B2C4` | `DataEP1/Spore_EP1_Data.package` | 71,712 | unknown/binary — 71,712 bytes |

### `0x2A3CE5B7` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2A3CE5B7:0x00000000:0xA426730B` | `Data/PatchData.package` | 276 | unknown/binary — 276 bytes |
| decoded | `0x2A3CE5B7:0x00000000:0xA426730B` | `Data/Spore_Game.package` | 264 | unknown/binary — 264 bytes |
| decoded | `0x2A3CE5B7:0x00000000:0xA426730B` | `DataEP1/Spore_EP1_Data.package` | 276 | unknown/binary — 276 bytes |

### `0x2B6CAB5F` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2B6CAB5F:0x05AD83F4:0xC1D3534F` | `Data/Locale/en-gb/UI.package` | 370 | unknown/binary — 370 bytes |
| decoded | `0x2B6CAB5F:0x05AD83F4:0xC1D3534F` | `Data/Locale/en-us/UI.package` | 370 | unknown/binary — 370 bytes |
| decoded | `0x2B6CAB5F:0x05AD83F4:0xC1D3534F` | `Data/Locale/ru-ru/UI.package` | 370 | unknown/binary — 370 bytes |

### `0x2B7DF427` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2B7DF427:0x021407EE:0x64348B50` | `Data/Spore_Audio1.package` | 15 | unknown/binary — 15 bytes |
| decoded | `0x2B7DF427:0x021407EE:0xC0249D9D` | `Data/Spore_Audio1.package` | 15 | unknown/binary — 15 bytes |
| decoded | `0x2B7DF427:0x021407EE:0xCBFF3F4B` | `Data/Spore_Audio1.package` | 15 | unknown/binary — 15 bytes |

### `0x37979F71` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x37979F71:0x0248E873:0x347AC8DD` | `Data/Spore_Graphics.package` | 2,754 | unknown/binary — 2,754 bytes |
| decoded | `0x37979F71:0x0248E873:0xE0A52995` | `DataEP1/Spore_EP1_Data.package` | 3,392 | unknown/binary — 3,392 bytes |
| decoded | `0x37979F71:0x0248E873:0x347AC8DD` | `DataEP1/Spore_EP1_Data.package` | 3,392 | unknown/binary — 3,392 bytes |

### `0x7C19AA7A` — 3 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x7C19AA7A:0x000082D0:0x142D3338` | `Data/PatchData.package` | 4,961 | unknown/binary — 4,961 bytes |
| decoded | `0x7C19AA7A:0x00006F14:0xF8CCFE08` | `Data/Spore_Game.package` | 3,475 | unknown/binary — 3,475 bytes |
| decoded | `0x7C19AA7A:0x000082EA:0x82BC2330` | `DataEP1/Spore_EP1_Data.package` | 4,961 | unknown/binary — 4,961 bytes |

### `0x02523258` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x02523258:0x0302A1C9:0x726EBAB5` | `Data/PatchData.package` | 1,171 | unknown/binary — 1,171 bytes |
| decoded | `0x02523258:0x0302A1C9:0x726EBAB5` | `Data/Spore_Game.package` | 1,171 | unknown/binary — 1,171 bytes |

### `0x065266B7` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x065266B7:0x40484400:0xE960ADD1` | `Data/Spore_Graphics.package` | 263 | XML/ASCII — 263 bytes |
| decoded | `0x065266B7:0x40484400:0x55FBDE18` | `DataEP1/Spore_EP1_Data.package` | 290 | XML/ASCII — 290 bytes |

### `0x1F639D98` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x1F639D98:0x00000000:0xB7477C11` | `Data/PatchData.package` | 29,696 | unknown/binary — 29,696 bytes |
| decoded | `0x1F639D98:0x00000000:0xB7477C11` | `Data/Spore_Game.package` | 29,696 | unknown/binary — 29,696 bytes |

### `0x2399BE55` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2399BE55:0x40636200:0xCD363887` | `Data/PatchData.package` | 11,569 | XML/ASCII — 11,569 bytes |
| decoded | `0x2399BE55:0x40636200:0xCD363887` | `Data/Spore_Game.package` | 11,569 | XML/ASCII — 11,569 bytes |

### `0x3C77532E` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x3C77532E:0x011C0BDE:0xF614BF94` | `Data/Spore_Graphics.package` | 35,173 | unknown/binary — 35,173 bytes |
| decoded | `0x3C77532E:0x8A7BE0C0:0x0820ABA1` | `DataEP1/Spore_EP1_Data.package` | 37,218 | unknown/binary — 37,218 bytes |

### `0x433FB70C` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x433FB70C:0x00000000:0xAACC3A75` | `Data/PatchData.package` | 680 | unknown/binary — 680 bytes |
| decoded | `0x433FB70C:0x00000000:0xAACC3A75` | `Data/Spore_Game.package` | 680 | unknown/binary — 680 bytes |

### `0x438F6347` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x438F6347:0x40666200:0xDE727FA9` | `Data/PatchData.package` | 2,667 | XML/ASCII — 2,667 bytes |
| decoded | `0x438F6347:0x40666200:0xDE727FA9` | `Data/Spore_Game.package` | 2,667 | XML/ASCII — 2,667 bytes |

### `0x612B3191` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x612B3191:0x00000000:0x1D3FBACC` | `Data/PatchData.package` | 200 | unknown/binary — 200 bytes |
| decoded | `0x612B3191:0x00000000:0x1D3FBACC` | `Data/Spore_Game.package` | 200 | unknown/binary — 200 bytes |

### `0x754BE343` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x754BE343:0x00000000:0xA4A360CE` | `Data/PatchData.package` | 8 | unknown/binary — 8 bytes |
| decoded | `0x754BE343:0x00000000:0xA4A360CE` | `DataEP1/Spore_EP1_Data.package` | 8 | unknown/binary — 8 bytes |

### `0xDBA35AE2` — 2 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0xDBA35AE2:0x00000000:0xE69CBA48` | `Data/PatchData.package` | 428 | unknown/binary — 428 bytes |
| decoded | `0xDBA35AE2:0x00000000:0xE69CBA48` | `Data/Spore_Game.package` | 428 | unknown/binary — 428 bytes |

### `0x14885D1C` — 1 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x14885D1C:0x02393C07:0x667CE009` | `DataEP1/Spore_EP1_Data.package` | 4,286 | unknown/binary — 4,286 bytes |

### `0x191C3C61` — 1 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x191C3C61:0x408A0000:0x07E0AF2A` | `DataEP1/Spore_EP1_Data.package` | 12,132 | unknown/binary — 12,132 bytes |

### `0x1E99B626` — 1 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x1E99B626:0xB94BBB7E:0xBB8F81D0` | `Data/Spore_Graphics.package` | 44 | unknown/binary — 44 bytes |

### `0x2081B4F5` — 1 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x2081B4F5:0x021407EE:0x352AEC80` | `Data/Spore_Audio1.package` | 421 | unknown/binary — 421 bytes |

### `0x3F9C28B5` — 1 entradas

| Status | TGI | Package | Payload | Classificação/observação |
|---|---|---|---:|---|
| decoded | `0x3F9C28B5:0x02393C07:0x08CA27E5` | `Data/Spore_Graphics.package` | 16,446 | RIFF — 16,446 bytes |

## Limites

- A amostra é limitada e determinística; conteúdo raro pode não aparecer.
- A amostragem inclui entradas repetidas entre packages como registros distintos; ela não resolve precedência de montagem.
- Payloads maiores que os limites são contados, mas não decodificados.
- `unknown/binary` significa que os detectores implementados não reconheceram o conteúdo, não que ele seja opaco ou não documentado.
- A classificação de texto/HLSL é heurística. A confirmação de um formato exige parser ou validação estrutural própria.
- O magic RW4 segue `RWHeader.java` do SporeModder FX: https://github.com/Spore-Community/SporeModder-FX/blob/master/src/sporemodder/file/rw4/RWHeader.java
- Payloads efetivamente decodificados: **265,275,559 bytes**; erros de decode: **0**.
