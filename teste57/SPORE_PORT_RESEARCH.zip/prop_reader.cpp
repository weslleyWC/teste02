#include "prop_reader.hpp"

#include <charconv>
#include <cstdio>
#include <cstring>
#include <stdexcept>

namespace spore {
namespace {

std::uint32_t be32(const std::uint8_t* p) {
    return (std::uint32_t{p[0]} << 24) | (std::uint32_t{p[1]} << 16) |
           (std::uint32_t{p[2]} << 8) | std::uint32_t{p[3]};
}

std::uint16_t be16(const std::uint8_t* p) {
    return static_cast<std::uint16_t>((p[0] << 8) | p[1]);
}

std::uint32_t le32(const std::uint8_t* p) {
    return std::uint32_t{p[0]} | (std::uint32_t{p[1]} << 8) |
           (std::uint32_t{p[2]} << 16) | (std::uint32_t{p[3]} << 24);
}

float bits_to_float(std::uint32_t bits) {
    float f;
    static_assert(sizeof(f) == sizeof(bits), "float must be 32-bit");
    std::memcpy(&f, &bits, sizeof(f));
    return f;
}

[[noreturn]] void fail(const char* what, std::size_t offset, std::uint32_t a = 0,
                       std::uint32_t b = 0) {
    char buf[160];
    std::snprintf(buf, sizeof(buf), "PROP: %s (offset 0x%zX, 0x%X, 0x%X)", what,
                  offset, static_cast<unsigned>(a), static_cast<unsigned>(b));
    throw std::runtime_error(buf);
}

class Cursor {
public:
    Cursor(const std::uint8_t* data, std::size_t size) : p_(data), n_(size) {}
    std::size_t pos() const { return pos_; }
    std::size_t remaining() const { return n_ - pos_; }
    const std::uint8_t* take(std::size_t count) {
        if (count > remaining()) fail("truncated data", pos_, static_cast<std::uint32_t>(count));
        const std::uint8_t* out = p_ + pos_;
        pos_ += count;
        return out;
    }
    const std::uint8_t* at(std::size_t offset) const {
        if (offset > n_) fail("invalid data offset", offset);
        return p_ + offset;
    }
    std::uint32_t u32() { return be32(take(4)); }
    std::uint16_t u16() { return be16(take(2)); }

private:
    const std::uint8_t* p_;
    std::size_t n_;
    std::size_t pos_{0};
};

// Size of the inline value for flags == 0, and how many padding bytes follow it.
struct ScalarLayout {
    std::uint32_t item_size;
    std::uint32_t padding;
};

bool scalar_layout(std::uint16_t type, ScalarLayout& out) {
    switch (type) {
        case prop_type::kInt32:
        case prop_type::kUInt32:
        case prop_type::kFloat:
            out = {4, 0};
            return true;
        case prop_type::kKey:
        case prop_type::kVec3:
            out = {12, 4};
            return true;
        default:
            return false;
    }
}

bool is_string_type(std::uint16_t type, std::uint16_t flags) {
    return type == prop_type::kString16 && flags == 0x000D;
}

bool is_byte_string_type(std::uint16_t type, std::uint16_t flags) {
    return type == prop_type::kString8 && flags == 0x000D;
}

bool check(const PropValue& v, std::uint16_t type, std::uint32_t item_size,
           std::size_t index) {
    return v.type == type && v.item_size == item_size && index < v.count &&
           v.bytes.size() >= (index + 1) * item_size;
}

}  // namespace

const PropValue* PropList::find(std::uint32_t id) const noexcept {
    for (const PropValue& v : values) {
        if (v.id == id) return &v;
    }
    return nullptr;
}

PropList parse_prop(const std::uint8_t* data, std::size_t size) {
    Cursor cur(data, size);
    const std::uint32_t count = cur.u32();
    if (count > (size - 4) / 8) fail("property count exceeds data", 0, count);

    PropList list;
    list.values.reserve(count);
    for (std::uint32_t i = 0; i < count; ++i) {
        const std::size_t start = cur.pos();
        PropValue v;
        v.id = cur.u32();
        v.type = cur.u16();
        v.flags = cur.u16();

        if (is_byte_string_type(v.type, v.flags)) {
            const std::uint32_t length = cur.u32();
            if (length > cur.remaining()) fail("byte string exceeds data", start, length);
            v.is_string = true;
            v.count = length;
            v.item_size = 1;
            const std::uint8_t* p = cur.take(length);
            v.bytes.assign(p, p + length);
        } else if (is_string_type(v.type, v.flags)) {
            const std::uint32_t length = cur.u32();
            const std::uint32_t unit = 2;  // UTF-16LE code units
            if (length > cur.remaining() / unit) fail("string exceeds data", start, length);
            v.is_string = true;
            v.count = length;
            v.item_size = unit;
            const std::uint8_t* p = cur.take(static_cast<std::size_t>(length) * unit);
            v.bytes.assign(p, p + static_cast<std::size_t>(length) * unit);
        } else if ((v.type == prop_type::kString8 || v.type == prop_type::kString16) &&
                   v.flags == 0x009C) {
            v.is_array = true;
            v.is_string_array = true;
            v.count = cur.u32();
            v.item_size = cur.u32();
            const std::uint32_t unit =
                v.type == prop_type::kString16 ? 2 : 1;
            if (v.count > cur.remaining() / 4) {
                fail("string array count exceeds data", start, v.count);
            }
            const std::size_t data_start = cur.pos();
            for (std::uint32_t item = 0; item < v.count; ++item) {
                const std::uint32_t length = cur.u32();
                if (length > cur.remaining() / unit) {
                    fail("string array item exceeds data", cur.pos() - 4, length);
                }
                cur.take(static_cast<std::size_t>(length) * unit);
            }
            const std::size_t encoded_size = cur.pos() - data_start;
            const std::uint8_t* p = cur.at(data_start);
            v.bytes.assign(p, p + encoded_size);
        } else if (v.flags == 0) {
            ScalarLayout layout{};
            if (!scalar_layout(v.type, layout)) {
                fail("unknown scalar type", start, v.type, v.id);
            }
            v.count = 1;
            v.item_size = layout.item_size;
            const std::uint8_t* p = cur.take(layout.item_size);
            v.bytes.assign(p, p + layout.item_size);
            cur.take(layout.padding);
        } else {
            v.is_array = true;
            v.count = cur.u32();
            v.item_size = cur.u32();
            const std::uint64_t total = std::uint64_t{v.count} * v.item_size;
            if (total > cur.remaining()) fail("array exceeds data", start, v.count, v.item_size);
            const std::uint8_t* p = cur.take(static_cast<std::size_t>(total));
            v.bytes.assign(p, p + static_cast<std::size_t>(total));
        }
        list.values.push_back(std::move(v));
    }
    if (cur.remaining() != 0) {
        fail("trailing bytes", cur.pos(), static_cast<std::uint32_t>(cur.remaining()));
    }
    return list;
}

bool prop_float(const PropValue& v, std::size_t index, float& out) {
    if (!check(v, prop_type::kFloat, 4, index)) return false;
    out = bits_to_float(be32(v.bytes.data() + index * 4));  // primitives: big-endian
    return true;
}

bool prop_int32(const PropValue& v, std::size_t index, std::int32_t& out) {
    if (!check(v, prop_type::kInt32, 4, index)) return false;
    out = static_cast<std::int32_t>(be32(v.bytes.data() + index * 4));
    return true;
}

bool prop_uint32(const PropValue& v, std::size_t index, std::uint32_t& out) {
    if (!check(v, prop_type::kUInt32, 4, index)) return false;
    out = be32(v.bytes.data() + index * 4);
    return true;
}

bool prop_key(const PropValue& v, std::size_t index, Tgi& out) {
    if (!check(v, prop_type::kKey, 12, index)) return false;
    const std::uint8_t* p = v.bytes.data() + index * 12;  // compounds: little-endian
    out.instance = le32(p);
    out.type = le32(p + 4);
    out.group = le32(p + 8);
    return true;
}

bool prop_vec3(const PropValue& v, std::size_t index, float out[3]) {
    if (!check(v, prop_type::kVec3, 12, index)) return false;
    const std::uint8_t* p = v.bytes.data() + index * 12;
    for (int k = 0; k < 3; ++k) out[k] = bits_to_float(le32(p + 4 * k));
    return true;
}

bool prop_string8(const PropValue& v, std::string& bytes_out) {
    if (v.type != prop_type::kString8 || !v.is_string) return false;
    bytes_out.assign(v.bytes.begin(), v.bytes.end());
    return true;
}

bool prop_string16(const PropValue& v, std::string& utf8_out) {
    if (v.type != prop_type::kString16 || !v.is_string) return false;
    utf8_out.clear();
    const std::size_t units = v.count;
    for (std::size_t i = 0; i < units; ++i) {
        std::uint32_t cp = static_cast<std::uint32_t>(v.bytes[2 * i]) |
                           (static_cast<std::uint32_t>(v.bytes[2 * i + 1]) << 8);
        if (cp >= 0xD800 && cp <= 0xDBFF && i + 1 < units) {
            const std::uint32_t lo = static_cast<std::uint32_t>(v.bytes[2 * i + 2]) |
                                     (static_cast<std::uint32_t>(v.bytes[2 * i + 3]) << 8);
            if (lo >= 0xDC00 && lo <= 0xDFFF) {
                cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                ++i;
            }
        }
        if (cp < 0x80) {
            utf8_out.push_back(static_cast<char>(cp));
        } else if (cp < 0x800) {
            utf8_out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
            utf8_out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else if (cp < 0x10000) {
            utf8_out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
            utf8_out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            utf8_out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        } else {
            utf8_out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
            utf8_out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
            utf8_out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
            utf8_out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
        }
    }
    return true;
}

}  // namespace spore
