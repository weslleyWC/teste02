#!/usr/bin/env python3

import argparse
import json
import re
import sys
from pathlib import Path


LINE = re.compile(
    r"^(x86|arm64) case=(null|nonnull) result=([0-9a-fA-F]{8}) "
    r"expected=([0-9a-fA-F]{8}) flags=([0-9a-fA-F]{8}) "
    r"expected_flags=([0-9a-fA-F]{8}) esp_delta=([0-9a-fA-F]{8}) "
    r"registers_match=([01]) memory_unchanged=([01]) PASS=([01])$"
)
EXPECTED_CASES = {"null", "nonnull"}


def parse_log(path, architecture):
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16")
    elif raw.count(b"\x00") > max(2, len(raw) // 8):
        text = raw.decode("utf-16-le")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    text = text.replace("\r", "")

    summaries = re.findall(
        rf"^{architecture} summary cases=(\d+) failures=(\d+)(?: memory_unchanged=([01]))?$",
        text,
        re.MULTILINE,
    )
    if len(summaries) != 1:
        raise ValueError(f"expected exactly one {architecture} summary in {path}")

    cases = {}
    for line in text.splitlines():
        match = LINE.fullmatch(line.strip())
        if match is None:
            continue
        (
            arch, name, result, expected, flags, expected_flags,
            esp_delta, registers_match, memory_unchanged, passed,
        ) = match.groups()
        if arch != architecture:
            continue
        if name in cases:
            raise ValueError(f"duplicate {architecture} case {name}")
        if (
            result != expected
            or flags != expected_flags
            or esp_delta != "00000004"
            or registers_match != "1"
            or memory_unchanged != "1"
            or passed != "1"
        ):
            raise ValueError(f"{architecture} case failed semantic assertions: {name}")
        cases[name] = {
            "result": int(result, 16),
            "flags": int(flags, 16),
            "esp_delta": int(esp_delta, 16),
            "registers_preserved": registers_match == "1",
            "memory_unchanged": memory_unchanged == "1",
        }

    if len(cases) != int(summaries[0][0]) or int(summaries[0][1]) != 0:
        raise ValueError(
            f"{architecture} summary disagrees with parsed passing cases in {path}"
        )
    if architecture == "x86" and summaries[0][2] != "1":
        raise ValueError("x86 summary does not confirm unchanged memory")
    if set(cases) != EXPECTED_CASES:
        raise ValueError(
            f"{architecture} case set differs from the required null/non-null matrix; "
            f"missing={sorted(EXPECTED_CASES - set(cases))}, "
            f"unexpected={sorted(set(cases) - EXPECTED_CASES)}"
        )
    return cases


def main():
    parser = argparse.ArgumentParser(
        description="Compare original x86 and generated ARM64 behavior for 0x007f30d0."
    )
    parser.add_argument("--x86", type=Path, required=True)
    parser.add_argument("--arm64", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device-model", required=True)
    parser.add_argument("--device-serial", required=True)
    args = parser.parse_args()
    if args.output.exists():
        print(
            f"output already exists; preserve it before rerunning: {args.output}",
            file=sys.stderr,
        )
        return 1

    try:
        x86 = parse_log(args.x86, "x86")
        arm64 = parse_log(args.arm64, "arm64")
        mismatches = {
            name: {"x86": x86[name], "arm64": arm64[name]}
            for name in sorted(EXPECTED_CASES)
            if x86[name] != arm64[name]
        }
        result = {
            "schema": "spore-static-lift-function-comparison-v1",
            "function_va": "0x007f30d0",
            "source_sha256": "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b",
            "x86_reference": "original PE bytes read, verified, and executed natively on x86 hardware",
            "arm64_target": "statically generated C++ from exported Ghidra instructions",
            "device": {
                "model": args.device_model,
                "serial": args.device_serial,
                "abi": "arm64-v8a",
                "physical_device": True,
            },
            "cases": x86,
            "case_count": len(EXPECTED_CASES),
            "matching_case_count": len(EXPECTED_CASES) - len(mismatches),
            "mismatches": mismatches,
            "result": "pass" if not mismatches else "fail",
            "limitations": [
                "Only null and non-null ECX pointer values were tested.",
                "Ghidra reports the calling convention as unknown; the test uses the observed ECX argument and plain RET.",
                "The function is not reported reachable from the bounded direct-call graph.",
                "This does not prove full-game equivalence or integration.",
            ],
        }
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError) as error:
        print(f"Function comparison failed: {error}", file=sys.stderr)
        return 1

    print(
        f"0x007f30d0 comparison: {result['matching_case_count']}/"
        f"{result['case_count']} cases match; {result['result']}."
    )
    print(f"Comparison report: {args.output}")
    return 0 if not mismatches else 1


if __name__ == "__main__":
    raise SystemExit(main())
