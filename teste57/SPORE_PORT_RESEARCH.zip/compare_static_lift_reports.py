#!/usr/bin/env python3

import argparse
import json
import sys
from pathlib import Path


PILOT_SELECTION_COUNTS = {
    30: {"small": 10, "medium": 10, "conditional_branch": 10},
    100: {"small": 30, "medium": 30, "conditional_branch": 40},
}


def load_report(path):
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("schema") != "spore-static-lift-batch-report-v1":
        raise ValueError(f"unsupported report schema in {path}")
    functions = report.get("functions")
    if not isinstance(functions, list):
        raise ValueError(f"function records are missing in {path}")
    by_address = {}
    for function in functions:
        address = function.get("address")
        if not isinstance(address, str) or address in by_address:
            raise ValueError(f"missing or duplicate function address in {path}: {address!r}")
        if function.get("status") not in {"accepted", "rejected"}:
            raise ValueError(f"invalid lift status for {address} in {path}")
        by_address[address] = function
    status_counts = {
        status: sum(function["status"] == status for function in by_address.values())
        for status in ("accepted", "rejected")
    }
    if status_counts.get("accepted") != report.get("accepted_function_count"):
        raise ValueError(f"accepted count does not match function records in {path}")
    if status_counts.get("rejected") != report.get("rejected_function_count"):
        raise ValueError(f"rejected count does not match function records in {path}")
    pilot_size = len(by_address)
    if pilot_size not in PILOT_SELECTION_COUNTS:
        raise ValueError(f"unsupported pilot size {pilot_size} in {path}")
    if report.get("pilot_size") != pilot_size:
        raise ValueError(f"pilot size metadata does not match function records in {path}")
    expected_strata = PILOT_SELECTION_COUNTS[pilot_size]
    actual_strata = {}
    for function in by_address.values():
        stratum = function.get("selection_stratum")
        actual_strata[stratum] = actual_strata.get(stratum, 0) + 1
    if actual_strata != expected_strata:
        raise ValueError(f"invalid selection strata in {path}: {actual_strata}")
    if report.get("selection_counts") != expected_strata:
        raise ValueError(f"selection count metadata differs from function records in {path}")
    return report, by_address


def accepted_bytes_for(functions, addresses):
    covered = set()
    for address in addresses:
        function = functions[address]
        if function["status"] != "accepted":
            continue
        for instruction in function.get("verified_bytes", []):
            start = int(instruction["address"], 16)
            covered.update(range(start, start + instruction["length"]))
    return len(covered)


def compare_reports(baseline_path, candidate_path):
    baseline, old = load_report(baseline_path)
    candidate, new = load_report(candidate_path)
    if baseline.get("source_sha256") != candidate.get("source_sha256"):
        raise ValueError("reports use different executable builds")
    old_addresses = set(old)
    new_addresses = set(new)
    if len(old) == len(new):
        if old_addresses != new_addresses:
            missing = sorted(old_addresses - new_addresses)
            added = sorted(new_addresses - old_addresses)
            raise ValueError(
                f"same-size reports must contain the same pilot addresses; "
                f"missing={missing}, added={added}"
            )
        shared_addresses = old_addresses
        added_addresses = set()
        relationship = "same_pilot"
    elif len(old) == 30 and len(new) == 100 and old_addresses <= new_addresses:
        shared_addresses = old_addresses
        added_addresses = new_addresses - old_addresses
        relationship = "nested_expansion"
    else:
        raise ValueError(
            "reports must be the same pilot size with identical addresses, "
            "or a 30-function pilot nested in the 100-function export"
        )

    transitions = []
    for address in sorted(shared_addresses, key=lambda value: int(value, 16)):
        if old[address].get("selection_stratum") != new[address].get("selection_stratum"):
            raise ValueError(f"selection stratum changed for {address}")
        if old[address]["status"] != new[address]["status"]:
            transitions.append({
                "address": address,
                "name": new[address]["name"],
                "from": old[address]["status"],
                "to": new[address]["status"],
                "old_rejection_reasons": old[address].get("rejection_reasons", []),
                "new_rejection_reasons": new[address].get("rejection_reasons", []),
            })
    old_accepted = baseline["accepted_function_count"]
    new_accepted = candidate["accepted_function_count"]
    old_bytes = baseline["accepted_unique_instruction_bytes"]
    new_bytes = candidate["accepted_unique_instruction_bytes"]
    return {
        "schema": "spore-static-lift-comparison-v1",
        "source_sha256": baseline["source_sha256"],
        "baseline_report": str(baseline_path),
        "candidate_report": str(candidate_path),
        "relationship": relationship,
        "same_pilot_function_count": len(shared_addresses),
        "same_selection_strata": True,
        "added_function_count": len(added_addresses),
        "accepted_functions": {
            "baseline": old_accepted,
            "candidate": new_accepted,
            "delta": new_accepted - old_accepted,
        },
        "shared_function_acceptance": {
            "baseline": sum(old[address]["status"] == "accepted" for address in shared_addresses),
            "candidate": sum(new[address]["status"] == "accepted" for address in shared_addresses),
            "delta": sum(
                new[address]["status"] == "accepted"
                for address in shared_addresses
            ) - sum(
                old[address]["status"] == "accepted"
                for address in shared_addresses
            ),
            "baseline_bytes": accepted_bytes_for(old, shared_addresses),
            "candidate_bytes": accepted_bytes_for(new, shared_addresses),
        },
        "added_functions": {
            "accepted": sum(new[address]["status"] == "accepted" for address in added_addresses),
            "rejected": sum(new[address]["status"] == "rejected" for address in added_addresses),
        },
        "accepted_unique_instruction_bytes": {
            "baseline": old_bytes,
            "candidate": new_bytes,
            "delta": new_bytes - old_bytes,
            "pilot_export_bytes": candidate["exported_unique_instruction_bytes"],
            "baseline_percent": baseline["accepted_bytes_percent_of_pilot_export"],
            "candidate_percent": candidate["accepted_bytes_percent_of_pilot_export"],
            "percentage_point_delta": round(
                candidate["accepted_bytes_percent_of_pilot_export"]
                - baseline["accepted_bytes_percent_of_pilot_export"],
                2,
            ),
        },
        "status_transitions": transitions,
        "candidate_rejection_counts_by_kind": candidate["rejection_counts_by_kind"],
    }


def main():
    parser = argparse.ArgumentParser(
        description="Compare static-lift coverage for exactly the same pilot functions."
    )
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        print(f"output already exists; preserve it before rerunning: {args.output}", file=sys.stderr)
        return 1
    try:
        result = compare_reports(args.baseline, args.candidate)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        print(f"report comparison failed: {error}", file=sys.stderr)
        return 1
    if result["relationship"] == "same_pilot":
        print(
            f"Same {result['same_pilot_function_count']} functions: "
            f"{result['accepted_functions']['baseline']} -> "
            f"{result['accepted_functions']['candidate']} accepted; "
            f"bytes {result['accepted_unique_instruction_bytes']['baseline']} -> "
            f"{result['accepted_unique_instruction_bytes']['candidate']}."
        )
    else:
        shared = result["shared_function_acceptance"]
        added = result["added_functions"]
        print(
            f"Nested expansion: {result['same_pilot_function_count']} shared "
            f"functions ({shared['baseline']} -> {shared['candidate']} accepted); "
            f"{result['added_function_count']} added "
            f"({added['accepted']} accepted, {added['rejected']} rejected)."
        )
    print(f"Comparison report: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
