#include "SporeCopyLiftRuntime.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

CopyLiftStatus spore_lift_00479c00(
    CopyLiftMemory& memory,
    std::uint32_t out_pointer,
    std::uint32_t source_begin,
    std::uint32_t source_end,
    std::uint32_t destination,
    std::uint32_t* returned_out_pointer);

namespace {

constexpr std::uint32_t kSourceBase = 0x10000000u;
constexpr std::uint32_t kDestinationBase = 0x20000000u;
constexpr std::uint32_t kOutParameterBase = 0x30000000u;
constexpr std::uint8_t kGuardByte = 0xa5;
constexpr std::size_t kGuardBytes = 16;

struct FloatPairBits {
    std::uint32_t first;
    std::uint32_t second;
};

static_assert(sizeof(FloatPairBits) == 8, "Function advances by two 32-bit values.");

std::uint32_t fnv1a(const std::uint8_t* bytes, std::size_t size) {
    std::uint32_t hash = 2166136261u;
    for (std::size_t i = 0; i < size; ++i) {
        hash = (hash ^ bytes[i]) * 16777619u;
    }
    return hash;
}

std::uint32_t expected_x87_roundtrip(std::uint32_t bits) {
    if ((bits & 0x7f800000u) == 0x7f800000u && (bits & 0x007fffffu) != 0u) {
        bits |= 0x00400000u;
    }
    return bits;
}

std::vector<FloatPairBits> make_stress_records() {
    std::vector<FloatPairBits> records;
    records.reserve(256);
    std::uint32_t state = 0x9e3779b9u;
    for (std::size_t i = 0; i < 256; ++i) {
        state ^= state << 13u;
        state ^= state >> 17u;
        state ^= state << 5u;
        const std::uint32_t first = state;
        state ^= state << 13u;
        state ^= state >> 17u;
        state ^= state << 5u;
        records.push_back({first, state});
    }
    records[0] = {0x7f800001u, 0xff800123u};
    return records;
}

bool run_case(const char* label, const std::vector<FloatPairBits>& source, bool null_destination) {
    const std::size_t bytes = source.size() * sizeof(FloatPairBits);
    std::vector<std::uint8_t> source_bytes(bytes);
    if (bytes != 0) {
        std::memcpy(source_bytes.data(), source.data(), bytes);
    }
    std::vector<std::uint8_t> destination_bytes(bytes + kGuardBytes, kGuardByte);
    std::uint32_t output_slot = 0xdeadbeefu;
    CopyLiftMemory memory;
    if ((bytes != 0 &&
            !memory.map_region(kSourceBase, source_bytes.data(), bytes, false)) ||
        (!null_destination && !memory.map_region(
            kDestinationBase, destination_bytes.data(), destination_bytes.size(), true)) ||
        !memory.map_region(
            kOutParameterBase,
            reinterpret_cast<std::uint8_t*>(&output_slot),
            sizeof(output_slot),
            true)) {
        std::fprintf(stderr, "failed to configure guest mappings for %s\n", label);
        return false;
    }

    const std::uint32_t source_end =
        kSourceBase + static_cast<std::uint32_t>(bytes);
    const std::uint32_t destination_address = null_destination ? 0u : kDestinationBase;
    std::uint32_t returned = 0;
    const CopyLiftStatus status = spore_lift_00479c00(
        memory,
        kOutParameterBase,
        kSourceBase,
        source_end,
        destination_address,
        &returned);
    const std::uint32_t expected_end =
        destination_address + static_cast<std::uint32_t>(bytes);
    bool copied = true;
    if (!null_destination && bytes != 0) {
        const auto* actual_words =
            reinterpret_cast<const std::uint32_t*>(destination_bytes.data());
        const auto* source_words =
            reinterpret_cast<const std::uint32_t*>(source_bytes.data());
        for (std::size_t i = 0; i < bytes / sizeof(std::uint32_t); ++i) {
            copied = copied &&
                actual_words[i] == expected_x87_roundtrip(source_words[i]);
        }
    }
    const bool guard_unchanged = std::all_of(
        destination_bytes.begin() + static_cast<std::ptrdiff_t>(bytes),
        destination_bytes.end(),
        [](std::uint8_t value) { return value == kGuardByte; });
    const bool passed = status == CopyLiftStatus::ok &&
        returned == kOutParameterBase &&
        output_slot == expected_end &&
        copied &&
        guard_unchanged;
    const std::uint32_t output_hash = null_destination
        ? 2166136261u
        : fnv1a(destination_bytes.data(), bytes);
    std::printf(
        "arm64 case=%s status=%u end_offset=0x%08x copy_hash=%08x "
        "copied=%u guard=%u PASS=%u\n",
        label,
        static_cast<unsigned>(status),
        output_slot - destination_address,
        output_hash,
        copied ? 1u : 0u,
        guard_unchanged ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main() {
    const std::vector<FloatPairBits> empty;
    const std::vector<FloatPairBits> one{{
        {0x3f800000u, 0xc0200000u},
    }};
    const std::vector<FloatPairBits> varied{{
        {0x00000000u, 0x80000000u},
        {0x00000001u, 0x007fffffu},
        {0x3f800000u, 0xbf800000u},
        {0x7f7fffffu, 0xff7fffffu},
        {0x7f800000u, 0xff800000u},
        {0x7fc12345u, 0xffc54321u},
        {0x7f800001u, 0xff800123u},
    }};
    const std::vector<FloatPairBits> stress = make_stress_records();

    std::size_t failures = 0;
    std::size_t cases = 0;
    failures += !run_case("empty", empty, false); ++cases;
    failures += !run_case("single", one, false); ++cases;
    failures += !run_case("varied", varied, false); ++cases;
    failures += !run_case("stress_256", stress, false); ++cases;
    failures += !run_case("null_destination", one, true); ++cases;
    std::printf("arm64 summary cases=%zu failures=%zu\n", cases, failures);
    return failures == 0 ? 0 : 1;
}
