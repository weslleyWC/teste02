# Retomada do port nativo do Spore para Android

Atualizado em 2 de novembro de 2026.

Este arquivo registra onde o trabalho parou para permitir a retomada após a
formatação do PC. O objetivo continua sendo traduzir estaticamente código
x86-32 do Spore para C/C++ e executar o código gerado em ARM64 nativo no
Android. Não usar Wine, Box64, QEMU, Unicorn, emulação x86, tradução dinâmica
ou streaming como substituto desse objetivo.

## Antes de formatar

O projeto e as evidências estão dentro da pasta de instalação do Steam. Faça
uma cópia de segurança de toda a pasta abaixo para outro disco ou local seguro:

`C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH`

Preserve também, se possível:

- `C:\SporeAnalysis` — projeto e exports do Ghidra.
- `C:\SporeAnalysis\spore_batch_pilot_100.json` — export usado no lote de
  100 funções.
- O executável de referência em
  `C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe`.

Depois da formatação, confirme que esses arquivos voltaram aos locais esperados
ou ajuste os caminhos dos comandos e scripts. Reconecte o telefone Android e
confirme o ADB antes de repetir testes no dispositivo.

## Estado confirmado

- O export do lote contém 100 funções, com piloto fixo de 30 e 70 funções
  adicionais. O executável de origem reportado pelo Ghidra tem SHA-256
  `6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`.
- A rodada v2 aceitou 53/100 funções e rejeitou 47. As funções aceitas cobrem
  418 de 1.541 bytes de instrução exportados (27,13%). Os 53 arquivos C++
  gerados passaram pela verificação de sintaxe ARM64.
- Comparando o mesmo piloto fixo de 30 funções: 15 passaram a 16 aceitas
  (99 para 110 bytes). As 70 funções adicionais tiveram 37 aceitas e 33
  rejeitadas.
- A melhoria implementada foi suporte conservador a `LEA` de 32 bits no formato
  base + deslocamento. Formas indexadas/escaladas e destinos não suportados
  continuam sendo rejeitados.
- `0x007f30d0`, recém-aceita devido a `LEA`, correspondeu em 2/2 casos entre
  bytes originais executados em x86 nativo e código gerado executado em um
  telefone Android ARM64. O relatório verifica resultado, flags definidas,
  pilha, registradores preservados e memória sentinela.
- A função `0x01180160` também tem comparação anterior de 2/2 casos entre x86
  nativo e Android ARM64.
- As convenções de chamada dessas duas funções são desconhecidas no Ghidra;
  os harnesses seguem os argumentos observados. Nenhuma delas aparece como
  alcançável no grafo estático limitado. Isso não prova execução no jogo nem
  equivalência do jogo inteiro.
- O relatório v2 registra 41 bloqueios de chamadas. Uma análise separada
  encontrou 36 referências de chamada: 34 alvos estão fora do export de
  100 funções e os outros dois têm convenção de chamada desconhecida. Não
  implementar chamadas como chamadas comuns sem resolver esses requisitos.

## Python e testes

O Python inicialmente selecionado pelo comando `python` era:

`C:\Users\wesll\AppData\Local\Programs\Python\Python311\python.exe`

Também foi tentado o launcher `py` com Python 3.12 e 3.13. As tentativas
falharam com erro do Windows indicando que o executável estava sendo usado por
outro processo. Após reiniciar o VS Code, o erro persistiu. Portanto, a suíte
completa não foi confirmada nessa última sessão. Não trate essa execução como
aprovada.

Depois da formatação e da instalação de Python, abra PowerShell e execute:

```powershell
Set-Location 'C:\Program Files (x86)\Steam\steamapps\common\Spore\SPORE_PORT_RESEARCH'
py -3.11 -m unittest -v `
  test_static_batch_lift `
  test_compare_batch_static_lift_branch_results `
  test_compare_batch_static_lift_lea_results `
  test_compare_batch_lift_dec_semantic_results `
  test_compare_third_static_lift_results `
  test_static_copy_lift_generator `
  test_static_equal_lift_generator `
  test_static_lift_comparisons `
  test_static_lift_generator
```

Use uma versão suportada que realmente consiga iniciar no PC restaurado. Se o
launcher `py` não estiver disponível, invoque o caminho completo para o
`python.exe` instalado. A suíte acima deve terminar com código de saída zero;
se falhar, guarde a saída integral para investigar.

## Programas e componentes para reinstalar

Instale estes componentes para recuperar os fluxos de análise, compilação e
teste que já existem. As versões abaixo são as confirmadas nos arquivos e
scripts deste projeto; quando não há versão exata registrada, use uma versão
atual compatível.

| Programa/componente | Necessidade e versão |
|---|---|
| **Visual Studio Code** | Editor usado neste trabalho. Instale também as extensões **Python** e **Pylance** para manter o fluxo de edição/diagnóstico. |
| **Python** | Reinstale **Python 3.11 x64** e o launcher `py`. Os testes listados usam `unittest` e não há manifesto de dependências externas no diretório do projeto. |
| **Ghidra** | **Ghidra 12.2**, necessário para abrir o projeto de análise e executar `ExportSporeFunctionBatch.java`. Restaure também o diretório `C:\SporeAnalysis`; não refaça a análise completa sem necessidade. |
| **Java JDK** | **JDK 21 x64** para executar Ghidra 12.2. JDK 21 estava instalado neste PC; prefira JDK em vez de JRE. |
| **Visual Studio Build Tools (C++)** | Instale o workload **Desktop development with C++**, com MSVC x86/x64 e Windows SDK. O harness de referência precisa compilar e executar código x86 nativo. O script procura `vswhere.exe` e `vcvarsall.bat`. |
| **Android SDK Platform-Tools** | Necessário para `adb` comunicar com o telefone. O caminho usado pelos scripts é `C:\Users\wesll\AppData\Local\Android\Sdk\platform-tools\adb.exe`. |
| **Android NDK** | Instale a versão **29.0.14206865** pelo Android SDK Manager. O script Android usa o `clang++` ARM64 nesse NDK; ter só o NDK 28 não basta para reproduzir o caminho registrado. |
| **CMake** | O projeto contém `CMakeLists.txt` com requisito mínimo **3.16**. Instale CMake 3.16 ou superior para os alvos CMake existentes. |
| **Steam e Spore** | Necessários para restaurar o executável original de referência. Preserve a instalação e confira o SHA-256 antes de testes x86; não use outro executável/build como referência sem atualizar e documentar a identidade. |
| **Telefone Android físico ARM64** | Não é programa para baixar, mas é necessário para repetir execução nativa no aparelho. Ative Depuração USB e autorize o computador no prompt do Android. |

O **Android Studio é opcional**: pode ser usado para instalar/atualizar
Platform-Tools e NDK pelo SDK Manager, mas os testes de harness documentados
chamam diretamente `adb.exe` e `clang++` do NDK; não é necessário criar outro
aplicativo Android para esse fluxo. O Ninja também não é requisito comprovado
para os scripts de comparação. Se o Windows não reconhecer o telefone via ADB,
instale o driver USB OEM correspondente ao aparelho.

## Arquivos principais

- `BATCH_STATIC_LIFT_PILOT.md` — procedimento, métricas e evidências do piloto.
- `BatchStaticLift.py` — lifter estático restrito e fail-closed.
- `test_static_batch_lift.py` — testes do lifter, incluindo `LEA`.
- `batch_static_lift_pilot_report_100_v2.json` — relatório da rodada v2.
- `batch_static_lift_comparison_30_to_100_v2.json` — comparação mantendo
  fixos os 30 endereços de regressão.
- `generated_batch_pilot_100_v2\` — as 53 funções C++ geradas.
- `batch_static_lift_007f30d0_comparison_v1.json` — comparação x86/Android
  para a função recém-aceita.
- `batch_static_lift_01180160_comparison_v1.json` — comparação anterior
  x86/Android.
- `ExportSporeFunctionBatch.java` — script de export seletivo para Ghidra 12.2.

Os logs e harnesses auxiliares das comparações estão listados em
`BATCH_STATIC_LIFT_PILOT.md`. Preserve os relatórios e logs existentes; use
novos nomes de saída ao repetir execuções para não sobrescrever evidências.

## Próximo passo recomendado

1. Restaurar o projeto e os exports; confirmar o SHA-256 do executável de
   referência antes de usar os dados do Ghidra.
2. Executar a suíte Python e guardar o resultado.
3. Confirmar que o lote v2 ainda reproduz os resultados registrados.
4. Investigar resolução e convenções das chamadas rejeitadas antes de alterar o
   lifter. Manter as rejeições explícitas quando a semântica não puder ser
   preservada.
5. Se implementar suporte a chamadas, rerodar exatamente o mesmo export de
   100 funções e comparar com v2, mantendo os mesmos 30 casos de regressão.
   Validar novas funções em x86 nativo e Android físico; não expandir para 300
   ou 1.000 funções antes dessas verificações.

**Não declarar equivalência comprovada** com base apenas em compilação ARM64,
nos testes de fixtures de instrução ou nestas duas comparações isoladas.
