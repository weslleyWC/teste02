import tempfile
import unittest
from pathlib import Path

import compare_batch_static_lift_branch_results as comparison


def make_log(architecture, failed_case=None):
    rows = []
    for name, result, flags in (
        ("null", "00000000", "00000044"),
        ("nonnull", "87654321", "00000004"),
    ):
        passed = 0 if name == failed_case else 1
        rows.append(
            f"{architecture} case={name} result={result} expected={result} "
            f"flags={flags} expected_flags={flags} esp_delta=00000004 "
            f"registers_match=1 memory_unchanged=1 PASS={passed}"
        )
    failures = 1 if failed_case else 0
    summary = (
        f"{architecture} summary cases=2 failures={failures}"
        + (" memory_unchanged=1" if architecture == "x86" else "")
    )
    return "\n".join(rows + [summary]) + "\n"


class BranchFunctionComparisonTests(unittest.TestCase):
    def test_requires_exact_nonempty_two_case_matrix(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "empty.log"
            path.write_text("x86 summary cases=0 failures=0 memory_unchanged=1\n")
            with self.assertRaisesRegex(ValueError, "null/non-null matrix"):
                comparison.parse_log(path, "x86")

    def test_accepts_both_cases_and_rejects_failed_semantic_assertion(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "x86.log"
            path.write_text(make_log("x86"), encoding="utf-8")
            cases = comparison.parse_log(path, "x86")
            self.assertEqual(set(cases), {"null", "nonnull"})

            path.write_text(make_log("x86", failed_case="nonnull"), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "semantic assertions"):
                comparison.parse_log(path, "x86")

    def test_rejects_summary_missing_native_memory_confirmation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "x86.log"
            path.write_text(
                make_log("x86").replace(
                    " memory_unchanged=1\n", "\n"
                ),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "invalid x86 summary"):
                comparison.parse_log(path, "x86")


if __name__ == "__main__":
    unittest.main()
