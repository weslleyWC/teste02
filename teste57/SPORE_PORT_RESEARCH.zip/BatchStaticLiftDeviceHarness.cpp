#include "BatchStaticLiftRuntime.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>

BatchLiftStatus spore_lift_00922a80(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00a02bd0(BatchLiftMemory&, BatchLiftState&);
BatchLiftStatus spore_lift_00ef72c0(BatchLiftMemory&, BatchLiftState&);

namespace {

constexpr std::uint32_t kReceiverAddress = 0x10000000u;
constexpr std::uint32_t kNodeAddress = 0x20000000u;
constexpr std::uint32_t kObjectAddress = 0x30000000u;

void store_le32(std::uint8_t* bytes, std::size_t offset, std::uint32_t value) {
    for (unsigned index = 0; index < 4; ++index) {
        bytes[offset + index] = static_cast<std::uint8_t>(value >> (index * 8u));
    }
}

bool run_case(
    const char* label,
    BatchLiftStatus (*function)(BatchLiftMemory&, BatchLiftState&),
    std::uint32_t expected,
    std::uint32_t initial_eflags,
    std::uint32_t receiver_address,
    std::uint8_t* receiver_bytes,
    std::size_t receiver_size,
    std::uint32_t node_address,
    std::uint8_t* node_bytes,
    std::size_t node_size) {
    BatchLiftMemory memory;
    if (!memory.map_region(receiver_address, receiver_bytes, receiver_size, true) ||
        (node_bytes != nullptr &&
         !memory.map_region(node_address, node_bytes, node_size, true))) {
        std::fprintf(stderr, "case=%s could not map test memory\n", label);
        return false;
    }

    BatchLiftState state{};
    state.regs[1] = receiver_address;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.eflags = initial_eflags;
    const BatchLiftStatus status = function(memory, state);
    const bool passed =
        status == BatchLiftStatus::returned &&
        state.regs[0] == expected &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf(
        "case=%s result=%08x expected=%08x status=%u eip=%08x esp=%08x PASS=%u\n",
        label,
        state.regs[0],
        expected,
        static_cast<unsigned>(status),
        state.eip,
        state.regs[4],
        passed ? 1u : 0u);
    return passed;
}

bool run_effect_case(
    const char* label,
    std::uint32_t expected_effect,
    std::uint8_t initial_value,
    std::uint32_t status_value) {
    alignas(4) std::array<std::uint8_t, 0x40> object{};
    store_le32(object.data(), 0x30, status_value);
    object[0x3f] = initial_value;

    BatchLiftMemory memory;
    if (!memory.map_region(
            kObjectAddress, object.data(), object.size(), true)) {
        std::fprintf(stderr, "case=%s could not map writable test object\n", label);
        return false;
    }

    BatchLiftState state{};
    state.regs[1] = kObjectAddress;
    state.regs[4] = BatchLiftMemory::kEntryEsp;
    state.eflags = 0x202u;
    const BatchLiftStatus status = spore_lift_00ef72c0(memory, state);
    const std::uint32_t effect = object[0x3f];
    const bool passed =
        status == BatchLiftStatus::returned &&
        effect == expected_effect &&
        state.eip == BatchLiftMemory::kReturnSentinel &&
        state.regs[4] == BatchLiftMemory::kEntryEsp + 4u;
    std::printf(
        "case=%s result=%08x expected=%08x status=%u eip=%08x esp=%08x PASS=%u\n",
        label,
        effect,
        expected_effect,
        static_cast<unsigned>(status),
        state.eip,
        state.regs[4],
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main() {
    std::size_t failures = 0;
    alignas(4) std::array<std::uint8_t, 4> root{};
    alignas(4) std::array<std::uint8_t, 4> pointed{};
    store_le32(root.data(), 0, kNodeAddress);
    store_le32(pointed.data(), 0, 0x87654321u);
    failures += !run_case(
        "00922a80_value",
        spore_lift_00922a80,
        0x87654321u,
        0x202u,
        kReceiverAddress,
        root.data(),
        root.size(),
        kNodeAddress,
        pointed.data(),
        pointed.size());
    store_le32(root.data(), 0, 0);
    failures += !run_case(
        "00922a80_null",
        spore_lift_00922a80,
        0,
        0x202u,
        kReceiverAddress,
        root.data(),
        root.size(),
        0,
        nullptr,
        0);

    alignas(4) std::array<std::uint8_t, 0x58> object{};
    store_le32(object.data(), 0x54, 3);
    store_le32(object.data(), 0x50, 0xabcdef01u);
    failures += !run_case(
        "00a02bd0_nonfour",
        spore_lift_00a02bd0,
        3,
        0x202u,
        kObjectAddress,
        object.data(),
        object.size(),
        0,
        nullptr,
        0);
    store_le32(object.data(), 0x54, 4);
    failures += !run_case(
        "00a02bd0_four",
        spore_lift_00a02bd0,
        0xabcdef01u,
        0x202u,
        kObjectAddress,
        object.data(),
        object.size(),
        0,
        nullptr,
        0);
    store_le32(object.data(), 0x54, 0xffffffffu);
    failures += !run_case(
        "00a02bd0_max",
        spore_lift_00a02bd0,
        0xffffffffu,
        0x202u,
        kObjectAddress,
        object.data(),
        object.size(),
        0,
        nullptr,
        0);

    failures += !run_effect_case("00ef72c0_write", 1, 0x7a, 0);
    failures += !run_effect_case("00ef72c0_skip", 0x7a, 0x7a, 0xffffffffu);

    std::printf("arm64 summary cases=7 failures=%zu\n", failures);
    return failures == 0 ? 0 : 1;
}
