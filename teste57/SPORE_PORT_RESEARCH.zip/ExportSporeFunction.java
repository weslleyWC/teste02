// Ghidra 12.2 Script Manager export for one selected Spore function.
// The script is intentionally read-only and does not trigger program analysis.
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.decompiler.DecompileResults;
import ghidra.program.model.address.Address;
import ghidra.program.model.block.BasicBlockModel;
import ghidra.program.model.block.CodeBlock;
import ghidra.program.model.block.CodeBlockIterator;
import ghidra.program.model.block.CodeBlockReference;
import ghidra.program.model.block.CodeBlockReferenceIterator;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.listing.Variable;
import ghidra.program.model.symbol.Reference;
import ghidra.program.model.symbol.ReferenceIterator;
import ghidra.program.model.symbol.ReferenceManager;

public class ExportSporeFunction extends GhidraScript {
    private static final String LOCKED_SHA256 =
        "290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74";
    private static final String PHASE4_SHA256 =
        "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b";
    private static final String OUTPUT_DIRECTORY = "C:\\SporeAnalysis";
    private static final long MAX_INPUT_BYTES = 256L * 1024L * 1024L;
    private static final long MAX_RUNTIME_MILLIS = 180_000L;
    private static final int MAX_INSTRUCTIONS = 2_048;
    private static final int MAX_BLOCKS = 128;
    private static final int MAX_REFERENCES = 4_096;
    private static final int MAX_PSEUDOCODE_CHARS = 131_072;
    private static final int MAX_DECOMPILER_PAYLOAD_MIB = 64;
    private static final int DECOMPILER_TIMEOUT_SECONDS = 20;

    private long deadline;
    private int referenceCount;
    private boolean referencesTruncated;

    @Override
    protected void run() throws Exception {
        if (currentProgram == null) {
            throw new IllegalStateException("Open the Spore program in Ghidra before running this script.");
        }

        String targetText = askString(
            "Function entry address",
            "Enter the function VA in hexadecimal (for example, 00479C00)"
        );
        long targetVa = parseTargetVa(targetText);
        Address target = toAddr(targetVa);

        File sourceFile = askFile(
            "Select the exact SporeApp.exe imported into the open Ghidra program",
            "Select"
        );
        if (sourceFile == null || !sourceFile.isFile()) {
            throw new IllegalArgumentException("The selected source executable is not a regular file.");
        }
        if (sourceFile.length() > MAX_INPUT_BYTES) {
            throw new IllegalArgumentException("The selected executable exceeds the 256 MiB input limit.");
        }

        boolean sourceConfirmed = askYesNo(
            "Confirm source identity",
            "Is this the exact original SporeApp.exe file used to create the currently open Ghidra program?"
        );
        String targetFileName = String.format("%08x", targetVa);
        File outputFile = new File(
            OUTPUT_DIRECTORY,
            "spore_function_" + targetFileName + ".json"
        );
        if (!outputFile.getParentFile().isDirectory()) {
            throw new IllegalStateException("Output directory does not exist: "
                + outputFile.getParentFile().getCanonicalPath());
        }
        if (outputFile.exists() && !askYesNo(
                "Overwrite existing export?",
                "Replace " + outputFile.getCanonicalPath() + "?")) {
            throw new IllegalStateException("Export cancelled to preserve the existing output file.");
        }

        deadline = System.currentTimeMillis() + MAX_RUNTIME_MILLIS;
        monitor.initialize(MAX_RUNTIME_MILLIS);
        monitor.setMessage("Hashing selected SporeApp.exe");
        String sourceSha256 = sha256(sourceFile);

        Function function = currentProgram.getFunctionManager().getFunctionAt(target);
        if (function == null) {
            function = currentProgram.getFunctionManager().getFunctionContaining(target);
        }

        StringBuilder json = new StringBuilder(32_768);
        json.append("{\n");
        appendField(json, "schema", "spore-ghidra-function-export-v1", true);
        appendField(json, "target_va_requested", address(target), true);
        appendField(json, "program_name", currentProgram.getName(), true);
        appendField(json, "project_file", currentProgram.getDomainFile().getName(), true);
        appendField(json, "language_id", currentProgram.getLanguageID().toString(), true);
        appendField(json, "compiler_spec_id",
            currentProgram.getCompilerSpec().getCompilerSpecID().toString(), true);
        appendField(json, "image_base", address(currentProgram.getImageBase()), true);
        appendField(json, "selected_source_path", sourceFile.getCanonicalPath(), true);
        appendField(json, "selected_source_sha256", sourceSha256, true);
        appendBoolean(json, "selected_source_is_locked_build",
            LOCKED_SHA256.equalsIgnoreCase(sourceSha256), true);
        appendBoolean(json, "selected_source_is_phase4_build",
            PHASE4_SHA256.equalsIgnoreCase(sourceSha256), true);
        appendBoolean(json, "user_confirmed_source_for_open_program", sourceConfirmed, true);
        appendField(json, "locked_build_sha256", LOCKED_SHA256, true);
        appendField(json, "phase4_build_sha256", PHASE4_SHA256, true);
        json.append("  \"limits\": {\n");
        json.append("    \"functions\": 1,\n");
        json.append("    \"runtime_seconds\": 180,\n");
        json.append("    \"max_input_bytes\": ").append(MAX_INPUT_BYTES).append(",\n");
        json.append("    \"max_instructions\": ").append(MAX_INSTRUCTIONS).append(",\n");
        json.append("    \"max_basic_blocks\": ").append(MAX_BLOCKS).append(",\n");
        json.append("    \"max_references\": ").append(MAX_REFERENCES).append(",\n");
        json.append("    \"decompiler_timeout_seconds\": ").append(DECOMPILER_TIMEOUT_SECONDS).append(",\n");
        json.append("    \"decompiler_payload_mib\": ").append(MAX_DECOMPILER_PAYLOAD_MIB).append(",\n");
        json.append("    \"max_pseudocode_chars\": ").append(MAX_PSEUDOCODE_CHARS).append("\n");
        json.append("  },\n");

        if (function == null) {
            json.append("  \"function_found\": false,\n");
            json.append("  \"function\": null,\n");
            appendField(json, "error", "No defined function contains VA " + address(target), false);
        } else {
            json.append("  \"function_found\": true,\n");
            json.append("  \"function_starts_at_requested_address\": ")
                .append(function.getEntryPoint().equals(target)).append(",\n");
            appendFunction(json, function);
        }
        json.append("}\n");

        checkDeadline();
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(outputFile), StandardCharsets.UTF_8))) {
            writer.write(json.toString());
        }
        println("Exported " + (function == null ? "function-not-found report" : "one function")
            + " to " + outputFile.getCanonicalPath());
        println("Selected executable SHA-256: " + sourceSha256);
        println("This script did not execute the target or trigger whole-program analysis.");
    }

    private long parseTargetVa(String value) {
        if (value == null) {
            throw new IllegalArgumentException("A function VA is required.");
        }
        String normalized = value.trim();
        if (normalized.startsWith("0x") || normalized.startsWith("0X")) {
            normalized = normalized.substring(2);
        }
        if (!normalized.matches("[0-9a-fA-F]{1,8}")) {
            throw new IllegalArgumentException(
                "Enter a 32-bit hexadecimal VA, such as 00479C00 or 0x00479C00."
            );
        }
        return Long.parseLong(normalized, 16);
    }

    private void appendFunction(StringBuilder json, Function function) throws Exception {
        json.append("  \"function\": {\n");
        appendField(json, "entry", address(function.getEntryPoint()), true, 4);
        appendField(json, "name", function.getName(), true, 4);
        appendField(json, "calling_convention", function.getCallingConventionName(), true, 4);
        appendField(json, "return_type", function.getReturnType().getDisplayName(), true, 4);
        appendField(json, "body_min", address(function.getBody().getMinAddress()), true, 4);
        appendField(json, "body_max", address(function.getBody().getMaxAddress()), true, 4);
        appendField(json, "body_address_count",
            Long.toString(function.getBody().getNumAddresses()), true, 4);
        appendVariables(json, "parameters", function.getParameters(), true);
        appendVariables(json, "locals", function.getLocalVariables(), true);
        appendInstructions(json, function);
        appendBlocks(json, function);
        appendIncomingReferences(json, function);
        appendPseudocode(json, function);
        json.append("  }\n");
    }

    private void appendVariables(StringBuilder json, String field, Variable[] variables, boolean comma)
        throws Exception {
        json.append("    ").append(quote(field)).append(": [\n");
        for (int i = 0; i < variables.length; i++) {
            checkDeadline();
            Variable variable = variables[i];
            json.append("      {");
            json.append("\"name\": ").append(quote(variable.getName())).append(", ");
            json.append("\"type\": ").append(quote(variable.getDataType().getDisplayName())).append(", ");
            json.append("\"storage\": ").append(quote(variable.getVariableStorage().toString()));
            json.append("}");
            json.append(i + 1 == variables.length ? "\n" : ",\n");
        }
        json.append("    ]").append(comma ? ",\n" : "\n");
    }

    private void appendInstructions(StringBuilder json, Function function) throws Exception {
        json.append("    \"instructions\": [\n");
        InstructionIterator iterator = currentProgram.getListing()
            .getInstructions(function.getBody(), true);
        int count = 0;
        boolean truncated = false;
        while (iterator.hasNext()) {
            checkDeadline();
            if (count >= MAX_INSTRUCTIONS) {
                truncated = true;
                break;
            }
            Instruction instruction = iterator.next();
            if (count > 0) {
                json.append(",\n");
            }
            json.append("      {");
            json.append("\"address\": ").append(quote(address(instruction.getAddress()))).append(", ");
            json.append("\"bytes\": ").append(quote(bytesHex(instruction.getBytes()))).append(", ");
            json.append("\"length\": ").append(instruction.getLength()).append(", ");
            json.append("\"mnemonic\": ").append(quote(instruction.getMnemonicString())).append(", ");
            json.append("\"operands\": [");
            for (int operand = 0; operand < instruction.getNumOperands(); operand++) {
                if (operand > 0) {
                    json.append(", ");
                }
                json.append(quote(instruction.getDefaultOperandRepresentation(operand)));
            }
            json.append("], \"flow\": ").append(quote(instruction.getFlowType().toString()));
            json.append(", \"flows_to\": [");
            Address[] flows = instruction.getFlows();
            for (int i = 0; i < flows.length; i++) {
                if (i > 0) {
                    json.append(", ");
                }
                json.append(quote(address(flows[i])));
            }
            json.append("], \"references\": ");
            appendInstructionReferences(json, instruction.getAddress());
            json.append("}");
            count++;
        }
        json.append("\n    ],\n");
        json.append("    \"instruction_count_exported\": ").append(count).append(",\n");
        appendBoolean(json, "instructions_truncated", truncated, true, 4);
    }

    private void appendInstructionReferences(StringBuilder json, Address from) throws Exception {
        Reference[] refs = currentProgram.getReferenceManager().getReferencesFrom(from);
        json.append("[");
        for (int i = 0; i < refs.length; i++) {
            checkDeadline();
            if (referenceCount >= MAX_REFERENCES) {
                referencesTruncated = true;
                break;
            }
            if (i > 0) {
                json.append(", ");
            }
            Reference reference = refs[i];
            json.append("{\"to\": ").append(quote(address(reference.getToAddress())));
            json.append(", \"type\": ").append(quote(reference.getReferenceType().toString()));
            json.append(", \"operand_index\": ").append(reference.getOperandIndex());
            json.append(", \"is_call\": ").append(reference.getReferenceType().isCall());
            json.append("}");
            referenceCount++;
        }
        json.append("]");
    }

    private void appendBlocks(StringBuilder json, Function function) throws Exception {
        json.append("    \"basic_blocks\": [\n");
        BasicBlockModel model = new BasicBlockModel(currentProgram);
        CodeBlockIterator iterator = model.getCodeBlocksContaining(function.getBody(), monitor);
        int count = 0;
        boolean truncated = false;
        while (iterator.hasNext()) {
            checkDeadline();
            if (count >= MAX_BLOCKS) {
                truncated = true;
                break;
            }
            CodeBlock block = iterator.next();
            if (count > 0) {
                json.append(",\n");
            }
            json.append("      {\"start\": ")
                .append(quote(address(block.getFirstStartAddress())));
            json.append(", \"end\": ").append(quote(address(block.getMaxAddress())));
            json.append(", \"successors\": [");
            CodeBlockReferenceIterator destinations = block.getDestinations(monitor);
            int successor = 0;
            while (destinations.hasNext()) {
                checkDeadline();
                if (referenceCount >= MAX_REFERENCES) {
                    referencesTruncated = true;
                    break;
                }
                CodeBlockReference reference = destinations.next();
                if (successor++ > 0) {
                    json.append(", ");
                }
                json.append("{\"address\": ")
                    .append(quote(address(reference.getDestinationAddress())));
                json.append(", \"flow\": ").append(quote(reference.getFlowType().toString()))
                    .append("}");
                referenceCount++;
            }
            json.append("]}");
            count++;
        }
        json.append("\n    ],\n");
        json.append("    \"basic_block_count_exported\": ").append(count).append(",\n");
        appendBoolean(json, "basic_blocks_truncated", truncated, true, 4);
    }

    private void appendIncomingReferences(StringBuilder json, Function function) throws Exception {
        json.append("    \"incoming_references\": [\n");
        ReferenceManager manager = currentProgram.getReferenceManager();
        ReferenceIterator iterator = manager.getReferencesTo(function.getEntryPoint());
        int count = 0;
        while (iterator.hasNext()) {
            checkDeadline();
            if (referenceCount >= MAX_REFERENCES) {
                referencesTruncated = true;
                break;
            }
            Reference reference = iterator.next();
            if (count++ > 0) {
                json.append(",\n");
            }
            json.append("      {\"from\": ")
                .append(quote(address(reference.getFromAddress())));
            json.append(", \"type\": ").append(quote(reference.getReferenceType().toString()));
            json.append(", \"is_call\": ").append(reference.getReferenceType().isCall())
                .append("}");
            referenceCount++;
        }
        json.append("\n    ],\n");
        json.append("    \"incoming_reference_count_exported\": ").append(count).append(",\n");
        appendBoolean(json, "references_truncated", referencesTruncated, true, 4);
    }

    private void appendPseudocode(StringBuilder json, Function function) throws Exception {
        DecompInterface decompiler = new DecompInterface();
        String status;
        String pseudocode = null;
        try {
            DecompileOptions options = new DecompileOptions();
            options.setMaxPayloadMBytes(MAX_DECOMPILER_PAYLOAD_MIB);
            options.setMaxInstructions(MAX_INSTRUCTIONS);
            options.setDefaultTimeout(DECOMPILER_TIMEOUT_SECONDS);
            decompiler.setOptions(options);
            decompiler.openProgram(currentProgram);
            DecompileResults result = decompiler.decompileFunction(
                function, DECOMPILER_TIMEOUT_SECONDS, monitor);
            if (result != null && result.decompileCompleted()
                    && result.getDecompiledFunction() != null) {
                status = "completed";
                pseudocode = result.getDecompiledFunction().getC();
            } else {
                status = result == null ? "no_result" : result.getErrorMessage();
            }
        } catch (Exception error) {
            status = "exception: " + error.getClass().getSimpleName() + ": " + error.getMessage();
        } finally {
            decompiler.dispose();
        }
        appendField(json, "decompiler_status", status, true, 4);
        if (pseudocode != null) {
            boolean truncated = pseudocode.length() > MAX_PSEUDOCODE_CHARS;
            if (truncated) {
                pseudocode = pseudocode.substring(0, MAX_PSEUDOCODE_CHARS);
            }
            appendField(json, "pseudocode", pseudocode, true, 4);
            appendBoolean(json, "pseudocode_truncated", truncated, false, 4);
        } else {
            json.append("    \"pseudocode\": null,\n");
            json.append("    \"pseudocode_truncated\": false\n");
        }
    }

    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[64 * 1024];
        long total = 0;
        try (InputStream input = new BufferedInputStream(new FileInputStream(file))) {
            int read;
            while ((read = input.read(buffer)) != -1) {
                checkDeadline();
                total += read;
                if (total > MAX_INPUT_BYTES) {
                    throw new IllegalArgumentException("Input exceeded the configured 256 MiB limit.");
                }
                digest.update(buffer, 0, read);
            }
        }
        StringBuilder result = new StringBuilder(64);
        for (byte value : digest.digest()) {
            result.append(String.format("%02x", value & 0xff));
        }
        return result.toString();
    }

    private void checkDeadline() throws Exception {
        monitor.checkCancelled();
        if (System.currentTimeMillis() > deadline) {
            throw new IllegalStateException("Export exceeded its 180-second time limit.");
        }
    }

    private String address(Address address) {
        return address == null ? null : "0x" + address.toString();
    }

    private String bytesHex(byte[] bytes) {
        StringBuilder result = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            result.append(String.format("%02x", value & 0xff));
        }
        return result.toString();
    }

    private void appendField(StringBuilder json, String key, String value, boolean comma) {
        appendField(json, key, value, comma, 2);
    }

    private void appendField(StringBuilder json, String key, String value, boolean comma, int indent) {
        json.append(" ".repeat(indent)).append(quote(key)).append(": ").append(quote(value));
        json.append(comma ? ",\n" : "\n");
    }

    private void appendBoolean(StringBuilder json, String key, boolean value, boolean comma) {
        appendBoolean(json, key, value, comma, 2);
    }

    private void appendBoolean(StringBuilder json, String key, boolean value, boolean comma, int indent) {
        json.append(" ".repeat(indent)).append(quote(key)).append(": ").append(value);
        json.append(comma ? ",\n" : "\n");
    }

    private String quote(String value) {
        if (value == null) {
            return "null";
        }
        StringBuilder result = new StringBuilder(value.length() + 2);
        result.append('"');
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '"': result.append("\\\""); break;
                case '\\': result.append("\\\\"); break;
                case '\b': result.append("\\b"); break;
                case '\f': result.append("\\f"); break;
                case '\n': result.append("\\n"); break;
                case '\r': result.append("\\r"); break;
                case '\t': result.append("\\t"); break;
                default:
                    if (character < 0x20) {
                        result.append(String.format("\\u%04x", (int) character));
                    } else {
                        result.append(character);
                    }
            }
        }
        result.append('"');
        return result.toString();
    }
}
