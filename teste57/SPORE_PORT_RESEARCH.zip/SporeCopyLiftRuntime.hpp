#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>

enum class CopyLiftStatus {
    ok,
    invalid_memory,
    invalid_control_flow,
};

inline std::uint32_t x87_roundtrip_f32_bits(std::uint32_t bits) {
    const std::uint32_t exponent = bits & 0x7f800000u;
    const std::uint32_t fraction = bits & 0x007fffffu;
    if (exponent == 0x7f800000u && fraction != 0u) {
        bits |= 0x00400000u;
    }
    return bits;
}

class CopyLiftMemory {
public:
    static constexpr std::uint32_t kStackBase = 0x70000000u;
    static constexpr std::uint32_t kEntryEsp = 0x70000200u;
    static constexpr std::uint32_t kReturnSentinel = 0xf00dcafeu;
    static constexpr std::size_t kStackBytes = 0x400;

    CopyLiftMemory() {
        regions_[0] = {kStackBase, kStackBytes, stack_.data(), true};
        region_count_ = 1;
    }

    bool map_region(
        std::uint32_t base,
        std::uint8_t* data,
        std::size_t size,
        bool writable) {
        if (data == nullptr || size == 0 || region_count_ >= regions_.size()) {
            return false;
        }
        const std::uint64_t end = static_cast<std::uint64_t>(base) + size;
        if (end > (std::uint64_t{1} << 32u)) {
            return false;
        }
        for (std::size_t i = 0; i < region_count_; ++i) {
            const std::uint64_t existing_start = regions_[i].base;
            const std::uint64_t existing_end = existing_start + regions_[i].size;
            if (static_cast<std::uint64_t>(base) < existing_end && existing_start < end) {
                return false;
            }
        }
        regions_[region_count_++] = {base, size, data, writable};
        return true;
    }

    bool initialize_call_frame(
        std::uint32_t out_pointer,
        std::uint32_t source_begin,
        std::uint32_t source_end,
        std::uint32_t destination) {
        return store32(kEntryEsp, kReturnSentinel) &&
            store32(kEntryEsp + 4u, out_pointer) &&
            store32(kEntryEsp + 8u, source_begin) &&
            store32(kEntryEsp + 12u, source_end) &&
            store32(kEntryEsp + 16u, destination);
    }

    bool initialize_thiscall_frame(std::uint32_t argument) {
        return store32(kEntryEsp, kReturnSentinel) &&
            store32(kEntryEsp + 4u, argument);
    }

    bool load32(std::uint32_t address, std::uint32_t& value) const {
        const Region* region = find_region(address, sizeof(value));
        if (region == nullptr) {
            return false;
        }
        const std::size_t offset = static_cast<std::size_t>(address - region->base);
        const std::uint8_t* bytes = region->data + offset;
        value = static_cast<std::uint32_t>(bytes[0]) |
            (static_cast<std::uint32_t>(bytes[1]) << 8u) |
            (static_cast<std::uint32_t>(bytes[2]) << 16u) |
            (static_cast<std::uint32_t>(bytes[3]) << 24u);
        return true;
    }

    bool store32(std::uint32_t address, std::uint32_t value) {
        Region* region = find_region(address, sizeof(value));
        if (region == nullptr || !region->writable) {
            return false;
        }
        const std::size_t offset = static_cast<std::size_t>(address - region->base);
        std::uint8_t* bytes = region->data + offset;
        bytes[0] = static_cast<std::uint8_t>(value);
        bytes[1] = static_cast<std::uint8_t>(value >> 8u);
        bytes[2] = static_cast<std::uint8_t>(value >> 16u);
        bytes[3] = static_cast<std::uint8_t>(value >> 24u);
        return true;
    }

private:
    struct Region {
        std::uint32_t base;
        std::size_t size;
        std::uint8_t* data;
        bool writable;
    };

    const Region* find_region(std::uint32_t address, std::size_t size) const {
        for (std::size_t i = 0; i < region_count_; ++i) {
            const Region& region = regions_[i];
            const std::uint64_t offset =
                static_cast<std::uint64_t>(address) - region.base;
            if (address >= region.base && offset + size <= region.size) {
                return &region;
            }
        }
        return nullptr;
    }

    Region* find_region(std::uint32_t address, std::size_t size) {
        for (std::size_t i = 0; i < region_count_; ++i) {
            Region& region = regions_[i];
            const std::uint64_t offset =
                static_cast<std::uint64_t>(address) - region.base;
            if (address >= region.base && offset + size <= region.size) {
                return &region;
            }
        }
        return nullptr;
    }

    std::array<Region, 8> regions_{};
    std::array<std::uint8_t, kStackBytes> stack_{};
    std::size_t region_count_ = 0;
};
