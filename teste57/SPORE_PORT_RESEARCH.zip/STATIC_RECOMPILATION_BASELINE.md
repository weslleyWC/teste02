# Static recompilation baseline

## Locked build

- Executable: `SPOREFILES/SporeBin/SporeApp.exe`
- Format: PE32 x86
- SHA-256: `290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74`
- Entry RVA/VA: `0xDE11A0` / `0x11E11A0`
- Image base: `0x00400000`
- Image size: `0x014D2000`
- Subsystem: Windows GUI (`2`)

## Static boundaries

The `.text` section is approximately 15.8 MB and the executable has a separate `.rdata` section, TLS, resources, relocations and a large import table. Direct static replacement of the executable is not supported by the observed snapshot alone.

Observed compatibility boundaries:

| Area | Static evidence | Impact |
|---|---|---|
| CRT/C++ runtime | MSVCR90, 159 imports | Runtime ABI and exceptions/locale/threading |
| Graphics | d3d9 + d3dx9_27 | D3D9 device, resources, shader behavior and DX math |
| Input | DirectInput 8 + user32 | Touch/game-controller mapping |
| Audio | DirectSound and Windows multimedia | Mixing, device enumeration and timing |
| Platform | Kernel32/User32/GDI/IMM | Windows handles, windowing, files, paths and UI |
| Files/data | DBPF packages read independently | Local assets remain supplied by the user |
| Networking | WSOCK32/WS2_32 | Steam/offline behavior outside the first milestone |

## Entry probe

The entry address begins with CRT-style wrappers:

```text
call 0x11E1548
jmp  0x11E0EE0
cmp ecx, [0x15CFE70]
jne  0x11E11B4
jmp  0x11E15DE
```

This does not identify a gameplay entry point. The executable entry point is a bootstrap/CRT boundary, not a useful target for the first lifted function.

## First experiment gate

Before lifting the executable, prove one small x86 function with a reproducible toolchain:

1. Lift an isolated function containing only integer arithmetic or memory operations.
2. Produce ARM64 code and execute it through a host harness.
3. Compare the x86 and ARM64 outputs across edge cases and bad pointers.
4. Add one Win32 API shim and rerun the same harness.
5. Only then lift calls reached by a controlled game-bootstrap path.

The first experiment must not depend on DirectX, Steam, threads, assets, windowing or the full 15.8 MB `.text` section.

## Tooling added

- `tools/pe_snapshot.py`: hashes the executable and records sections, directories and imports.
- `tools/entry_probe.py`: records x86 instructions at the executable entry RVA.
- `tools/sporeapp-pe-snapshot.json`: deterministic PE/import snapshot.
- `tools/sporeapp-entry-probe.json`: entry-point instruction probe.

## Current decision

Static recompilation of the original x86 executable to native ARM64 is the approved primary architecture. Box64, Wine, Winlator, and other emulation or dynamic-translation solutions are out of scope, including for testing. The initial target is only the locked base-game executable above; other Spore executables and expansions are excluded until separately approved.

The Android launcher and user-provided game files may be reused, but the current compatibility runtime is not the target architecture. The port requires a function discovery/lifting pipeline, an ARM64 runtime for the lifted program, and native replacements or shims for the Windows APIs and graphics, input, and audio interfaces the game actually uses. The current evidence does not establish that full recompilation is feasible.

## 2026-11-01 continuation

The next gate is a closed arithmetic harness in `tools/lifting_harness.cpp`.
It is explicitly not a lifted implementation of `SporeApp.exe`. Its purpose is to prove:

- the Android NDK can compile integer and memory operations for ARM64;
- wraparound and shifting semantics can be asserted reproducibly;
- generated ARM64 code can be tested against host-side reference values;
- failures in later PE-lifting work can be distinguished from toolchain failures.

The harness must remain separate from any proprietary game function until an isolated
x86 procedure has been decompiled, mapped to source-level semantics, and approved for a
generated-ARM64 implementation.

## Toolchain gate status

- PASS: Android NDK clang++ produces an ELF64/AArch64 object.
- PASS: the ARM64 disassembly contains expected 32-bit add, multiply, shift, XOR and loop operations.
- PASS: the ARM64 PIE executable ran on a physical `arm64-v8a` Android device via ADB.
- PASS: `add`, `mul`, `mix` and `accumulate` matched the independent Python reference values.
- PASS: the independent AArch64 array kernel returned `array_multiply_add=4AEFF165` on the device.
- PASS: the independent AArch64 lower-bound reference ran on the device for first-element, middle, absent and end boundary cases.
- HISTORICAL ONLY (not accepted for current validation): the exact x86 candidate at VA `0x422430` was executed under Unicorn; boundary and interpolation lower-bound cases matched an independent Python oracle.
- HISTORICAL ONLY (not accepted for current validation): the exact x86 array candidate at VA `0x1158BE0` was executed under Unicorn for counts 0, 1, 3, 4, 5, 7 and 9; all float32 outputs matched an independent oracle.
- HISTORICAL ONLY (not accepted for current validation): the expanded lower-bound matrix contains 142 cases with `failed: 0`, including duplicate keys and arrays through 256 records.
- HISTORICAL ONLY (not accepted for current validation): the expanded array-kernel matrix contains 13 cases with `failed: 0`, including count 257, zero, subnormal, max finite, infinity and NaN values.
- PASS: the connected `arm64-v8a` physical device executed the standalone ARM64 harnesses successfully. This confirms native toolchain/device execution, not equivalence to the original x86 code.
- PASS: lower-bound indices 0, 1, 1, 2, 2, 3, 4 and 4 matched the independent model on the device.
- PASS: the array kernel checksum `4AEFF165` matched the independent float32 Python oracle on the device.
- NOTE: the Android harness executable is ELF64/AArch64 and uses Android system libraries; this describes the harness, not `SporeApp.exe`.
- PASS: native device ABI is `arm64-v8a`, Android API level 34 / Android 14, kernel architecture `aarch64`.
- PASS: generated code from `SporeApp.exe` has been compared with the original implementation on native x86
  hardware for two isolated functions and with the generated code on a physical ARM64 Android device; see the
  Phase 4 and second-function reports for the bounded test vectors and remaining limitations.
- NOTE: full Ghidra auto-analysis previously timed out, but a Ghidra function-table export is now available; see the 2026-11-02 inventory below.
- ADDITION: the candidate at `.text` RVA `0x79C00` / VA `0x0479C00` was selectively exported from Ghidra,
  statically translated and validated on native x86 and physical ARM64 hardware; details are in
  `SECOND_STATIC_RECOMPILATION_STATUS.md`.
- BLOCKED: whole-program instruction coverage, indirect-call resolution, caller conventions, and dynamic
  import/runtime coverage remain incomplete.

## 2026-11-02 Ghidra function inventory

The user confirms that `C:\SporeAnalysis\spore_functions.csv` was exported from `SporeApp.exe`. The CSV contains 57,922 rows and three columns: `address`, `name`, and `size`. The export itself does not include the input executable's SHA-256, so the source identity is user-confirmed rather than independently bound by metadata to the locked hash above.

Observed inventory metrics:

- 57,922 unique function entry addresses, sorted, all within the locked executable's `.text` address range.
- 54,363 default `FUN_` names, 84 `thunk_` names, and 3,475 other names.
- Reported sizes have a median of 92 bytes and a maximum of 57,671 bytes.
- Treating `size` as a decimal byte count and each function as one contiguous interval gives a union of 13,161,148 bytes, or about 79.48% of the 16,559,914-byte `.text` virtual size. The sum of sizes is about 79.49%. There are 34 overlapping intervals under that model.

These are inventory-derived estimates, not verified instruction coverage. Function bodies can contain non-contiguous blocks, overlap may reflect Ghidra analysis artifacts or shared code, and the CSV does not identify undecoded bytes, instruction support, callers, indirect branches, or dynamically loaded modules. It is useful for prioritizing analysis and measuring future lifter results, but it does not by itself prove that the game is fully understood or liftable.

Current analysis order:

1. Keep the base-game hash as the target identity; retain the user's CSV provenance confirmation and bind future exports to a recorded executable hash.
2. Use the function list to select a small candidate, inspect its exact bytes and callers, and establish its calling convention and semantics statically.
3. Build and validate an ARM64 implementation without running Unicorn, QEMU, Box64, Wine, Winlator, or another emulator/translator. Where comparison is needed, use an x86-native host and the physical ARM64 device.
4. Measure instruction coverage and rejected functions before considering whole-executable generation; keep Windows API and graphics/audio/input replacement as separate feasibility gates.

## 2026-11-02 Phase 4 target selection

The user explicitly selected the executable in `SPOREFILES/SporeBin`, not the other `SporeApp.exe` copies elsewhere in the Steam installation:

- Selected target: `SPOREFILES/SporeBin/SporeApp.exe`
- SHA-256 currently present at that path: `6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b`
- Previously locked SHA-256: `290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74`

The selected file's hash differs from the earlier locked hash. The earlier identity and its historical results remain unchanged; Phase 4 uses the user-selected file and its current hash. The Ghidra CSV has no embedded source hash. The user ran `ExportSporeFunction.java` on the selected source, and its export records the matching SHA-256 and confirms the open program's source file.

The selective Ghidra identity/function gate is now met for this one function. This does not establish a full-game port or remove the limitations recorded in `FIRST_STATIC_RECOMPILATION_STATUS.md`.

### Second single-function target

The inventory lists `FUN_00479c00` at 128 bytes. The read-only `ExportSporeFunction.java` exporter was generalized to prompt for one 32-bit VA; `C:\SporeAnalysis\spore_function_00479c00.json` confirms the selected executable hash, all 47 instructions, eight blocks, seven incoming call references, and completed pseudocode. `GenerateStaticCopyLift.py` statically lowered the function; 47/47 instructions and 128/128 bytes were accepted. Native x86 and physical-device ARM64 results match for five shared cases. Details and limits are in `SPORE_PORT_RESEARCH/SECOND_STATIC_RECOMPILATION_STATUS.md`.

### Third function: isolated ARM64 comparison passed

`FUN_00404460` is a 30-byte leaf routine in `.text` at file offset `0x3860`.
Selective Ghidra export `C:\SporeAnalysis\spore_function_00404460.json`
confirms the executable hash, 13 instructions, one block, and complete
pseudocode; it records no incoming references and leaves the calling
convention unknown. `GenerateStaticEqualLift.py` statically lowered all 13
instructions and 30/30 bytes. The original bytes passed eight native x86
cases. On 2026-11-02, the generated code linked as ELF64/AArch64 PIE and ran on
physical device `2303ERA42L` (`arm64-v8a`). All eight `uint32` input-pair
results matched the native x86 run. The report is
`SPORE_PORT_RESEARCH/third_static_lift_cross_arch_comparison_v2.json`; details
and limitations are in
`SPORE_PORT_RESEARCH/THIRD_STATIC_RECOMPILATION_STATUS.md`. This is isolated
return-value evidence, not proof of caller integration or whole-game behavior.

### Phase 4 result

The user ran `ExportSporeFunction.java` in Ghidra 12.2. The single-function export verified the selected source SHA-256, function `0x00422430`, its 122-byte body, 47 instructions, seven basic blocks, three callers, and completed pseudocode. Ghidra inferred `uint * FUN_00422430(uint *param_1, int param_2, uint *param_3)` but left the calling convention unknown.

`GenerateStaticLift.py` now verifies the exported identity and instruction bytes against the selected PE and emits a statically lowered C++ body. The instruction coverage report records 47/47 instructions and 122/122 bytes accepted; unsupported operations and control-flow targets outside the export are rejected. The generated PIE builds as ELF64/AArch64.

The original function bytes were executed from a read-only-executable memory page in an x86 harness on the physical Ryzen host, and the generated ARM64 harness ran on the user's physical `arm64-v8a` phone. The 16 shared input cases matched across both outputs; the x86 harness additionally passed 342 stress keys over 256 records. See `SPORE_PORT_RESEARCH/FIRST_STATIC_RECOMPILATION_STATUS.md` for test scope, logs, scripts, hashes, and remaining limitations.

This is a demonstrated first-function translation for the tested valid inputs, not an integration with the Spore boot path or proof of behavior for invalid pointers, abnormal ranges, or all possible inputs.

## 2026-11-02 bounded batch-lifter pilot

The next measurement step is a deterministic 30-function export, not another
manually selected single function. `ExportSporeFunctionBatch.java` selects 10
non-thunk functions in each of three reproducible strata: 1–32 body bytes,
33–128 body bytes, and conditional-branch functions up to 512 body bytes.
Selection is ordered by body size and VA. It reads the current Ghidra listing,
does not execute the program, and does not trigger a new whole-program analysis.

`BatchStaticLift.py` validates each export against the selected executable,
the confirmed SHA-256, the Ghidra CSV, and exact PE instruction bytes. Its
initial backend statically emits a restricted 32-bit integer/control-flow
subset and rejects an entire function when any instruction or edge is not
implemented. Calls, unknown instructions, ambiguous memory widths, unsupported
addressing, and unresolved branches are reported rather than silently ignored.

The export also performs bounded static reachability from Ghidra external
entry-point symbols through direct call references. Indirect/dynamic calls and
other unmodeled roots remain unresolved; if the 50,000-function cap is reached,
unvisited pilot targets are marked unknown rather than unreachable.

**Pilot result (2026-11-02):** the user-provided export matches the selected
executable SHA-256. The deterministic batch contained 30 functions (10 per
stratum); 12 passed the static backend and 18 were rejected. Accepted complete
functions contain 66/454 unique exported instruction bytes (14.54%). Rejections
include 13 calls, 15 unsupported operand forms, one unsupported opcode, one
out-of-function branch, and one incomplete one-byte function. The report
records every instruction-level blocker.

The export's direct-call reachability traversed 606 functions from Ghidra's
sole external entry point; one pilot function is in that graph. This does not
account for indirect calls or dynamic runtime reachability. All 12 generated
files passed Android ARM64 C++ compilation with each generated lift template
instantiated, but they have not been linked into an app, run on device, or
compared against x86. This is measured static
translation coverage, not semantic equivalence or whole-game coverage. See
`BATCH_STATIC_LIFT_PILOT.md` and `batch_static_lift_pilot_report_v2.json` for
details.

## Repeated pilot and Android execution comparison

The lifter was improved and rerun against the same 30-function export and
build hash. Comparison of v2 with v4 confirmed the same 10/10/10 stratified
addresses: acceptance increased from 12 to 15 functions and from 66 to 99 of
454 exported instruction bytes (14.54% to 21.81%). Direct-call graph
reachability remained 1/30. The three newly accepted addresses are
`0x008de220`, `0x00e82130`, and `0x00ef72c0`. See
`BATCH_STATIC_LIFT_PILOT.md` and `batch_static_lift_comparison_v2_v4.json`.

All 15 generated v4 sources passed Android ARM64 syntax compilation. Three
were linked and executed on physical ARM64 device `2303ERA42L`; their original
PE bytes were independently checked and executed in a native x86 process on
the physical x86-64 host. Across seven shared vectors, all seven `EAX` results
or specified memory-byte effects matched. The comparison records build hash,
device identity, cases, and logs in `batch_static_lift_execution_comparison_v2.json`.
This is bounded isolated-function evidence, not proof of full register/flag
equivalence for every input or integration into Spore.

The attempt to select `0x00485900` for the cross-architecture harness exposed
a two-byte unexported gap within its 33-byte instruction body span. It was
excluded rather than treating the per-instruction byte checks as proof of
contiguous range coverage. Future pilot reports should surface instruction
span gaps as a separate audit metric.
