# Import report: SporeApp.exe

- Input: `.\SPOREFILES\SporeBin\SporeApp.exe`
- SHA-256: `290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74`
- PE image base: `0x00400000`
- Imported functions/ordinals: **495**
- Imported DLLs: **20**
- Ordinal imports: **26** (26 resolved by local export name; 0 unresolved)
- Scope: static PE import table only; delay-loaded/dynamically resolved APIs are not included.
- Effort values are rough person-hours for a compatibility layer, not a sum of independent tasks.
- An API shim does not imply the complete subsystem can be implemented in that time.

## Summary by DLL

| DLL | Imports |
|---|---:|
| `ADVAPI32.dll` | 12 |
| `d3d9.dll` | 1 |
| `d3dx9_27.dll` | 9 |
| `dbghelp.dll` | 7 |
| `DINPUT8.dll` | 1 |
| `DSOUND.dll` | 2 |
| `GDI32.dll` | 6 |
| `IMM32.dll` | 12 |
| `KERNEL32.dll` | 148 |
| `MSVCR90.dll` | 159 |
| `ole32.dll` | 6 |
| `PSAPI.DLL` | 1 |
| `SHELL32.dll` | 3 |
| `steam_api.dll` | 3 |
| `USER32.dll` | 89 |
| `USP10.dll` | 2 |
| `VERSION.dll` | 5 |
| `WINMM.dll` | 3 |
| `WS2_32.dll` | 3 |
| `WSOCK32.dll` | 23 |

## Function-by-function inventory

### `ADVAPI32.dll` (12)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `GetUserNameW` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegQueryValueExA` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegOpenKeyExA` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegSetValueExA` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegEnumKeyExW` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegQueryValueExW` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegisterEventSourceA` | medium | 3-10 h | Windows Event Log has no direct Android equivalent |
| `ReportEventA` | medium | 3-10 h | Windows Event Log has no direct Android equivalent |
| `DeregisterEventSource` | medium | 3-10 h | Windows Event Log has no direct Android equivalent |
| `RegOpenKeyExW` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `RegCloseKey` | low-medium | 1-6 h | Registry/user identity persistence adapter |
| `GetUserNameA` | low-medium | 1-6 h | Registry/user identity persistence adapter |

### `d3d9.dll` (1)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `Direct3DCreate9` | very high | 16-80 h | D3D9 device/resource/format semantics |

### `d3dx9_27.dll` (9)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `D3DXVec3Transform` | low-medium | 1-4 h | Math routine; verify matrix convention |
| `D3DXVec3TransformNormal` | low-medium | 1-4 h | Math routine; verify matrix convention |
| `D3DXCheckVersion` | low | 0.5-2 h | Version compatibility check |
| `D3DXGetPixelShaderProfile` | medium | 2-8 h | Return supported profile based on selected backend capabilities |
| `D3DXGetVertexShaderProfile` | medium | 2-8 h | Return supported profile based on selected backend capabilities |
| `D3DXMatrixMultiplyTranspose` | low-medium | 1-4 h | Math routine; verify matrix convention |
| `D3DXMatrixTranspose` | low-medium | 1-4 h | Math routine; verify matrix convention |
| `D3DXMatrixMultiply` | low-medium | 1-4 h | Math routine; verify matrix convention |
| `D3DXCompileShader` | very high | 16-80 h | D3D9 shader compiler/profile to GLES/Vulkan |

### `dbghelp.dll` (7)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `UnDecorateSymbolName` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |
| `SymLoadModule64` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |
| `SymInitialize` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |
| `SymSetOptions` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |
| `SymCleanup` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |
| `SymGetSymFromAddr64` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |
| `SymGetLineFromAddr64` | low-medium | 1-6 h | Debug symbol stack; likely diagnostic-only |

### `DINPUT8.dll` (1)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `DirectInput8Create` | high | 8-32 h | DirectInput device enumeration, state and event mapping |

### `DSOUND.dll` (2)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `DirectSoundCreate (ordinal #1)` | high | 8-32 h | DirectSound buffers, mixing, timing and device semantics |
| `GetDeviceID (ordinal #9)` | high | 8-32 h | DirectSound buffers, mixing, timing and device semantics |

### `GDI32.dll` (6)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `CreateSolidBrush` | medium-high | 4-16 h | GDI device contexts/objects need a renderer adapter |
| `DeleteObject` | medium-high | 4-16 h | GDI device contexts/objects need a renderer adapter |
| `ExtEscape` | high | 8-24 h | Driver escape has no direct Android equivalent |
| `DeleteDC` | medium-high | 4-16 h | GDI device contexts/objects need a renderer adapter |
| `GetDeviceCaps` | medium-high | 4-16 h | GDI device contexts/objects need a renderer adapter |
| `CreateDCA` | medium-high | 4-16 h | GDI device contexts/objects need a renderer adapter |

### `IMM32.dll` (12)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `ImmDisableTextFrameService` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmGetCompositionStringW` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmSetCompositionStringW` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmNotifyIME` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmSetOpenStatus` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmSimulateHotKey` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmReleaseContext` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmGetConversionStatus` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmGetContext` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmGetOpenStatus` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmGetCandidateListW` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |
| `ImmSetConversionStatus` | medium-high | 4-16 h | IME composition and candidate UI need Android input connection |

### `KERNEL32.dll` (148)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `GlobalMemoryStatusEx` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `QueryPerformanceFrequency` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SetThreadPriority` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `SetPriorityClass` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetPriorityClass` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetThreadPriority` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetCurrentThread` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `SetThreadAffinityMask` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetProcessAffinityMask` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetProcAddress` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetModuleHandleA` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `CloseHandle` | medium | 2-8 h | Win32 environment, path, process or system API |
| `DeviceIoControl` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `CreateFileA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `LocalFree` | medium | 2-8 h | Win32 environment, path, process or system API |
| `LocalAlloc` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetModuleFileNameA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetSystemInfo` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetVersionExA` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `FreeLibrary` | medium | 2-8 h | Win32 environment, path, process or system API |
| `LoadLibraryA` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetComputerNameExA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `CompareStringW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `LCMapStringW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `InterlockedIncrement` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `InterlockedDecrement` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetSystemDirectoryW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetVersionExW` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `IsDebuggerPresent` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SetProcessAffinityMask` | medium | 2-8 h | Win32 environment, path, process or system API |
| `OpenProcess` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetCurrentProcessId` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SetThreadExecutionState` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetLocaleInfoW` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `SetLastError` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `EnumResourceNamesA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetSystemDefaultLCID` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetWindowsDirectoryW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetTickCount` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `VirtualQuery` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `ResumeThread` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetCurrentThreadId` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `CreateEventA` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `FormatMessageA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `FlushFileBuffers` | medium | 2-8 h | Win32 environment, path, process or system API |
| `TerminateProcess` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `SetUnhandledExceptionFilter` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetComputerNameA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SystemTimeToFileTime` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetSystemTime` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetModuleFileNameW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `OutputDebugStringA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetExitCodeThread` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `TlsAlloc` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `TlsSetValue` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `DuplicateHandle` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SetThreadIdealProcessor` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `SleepEx` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `CreateMutexA` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `WaitForSingleObject` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `TryEnterCriticalSection` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `ReleaseMutex` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `InterlockedExchangeAdd` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `InterlockedCompareExchange` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `CreateSemaphoreA` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `ReleaseSemaphore` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `InterlockedExchange` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `TlsFree` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `RaiseException` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `QueueUserAPC` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `CreateThread` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `HeapAlloc` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetProcessHeap` | medium | 2-8 h | Win32 environment, path, process or system API |
| `HeapFree` | medium | 2-8 h | Win32 environment, path, process or system API |
| `InitializeCriticalSectionAndSpinCount` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `VirtualFree` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `VirtualAlloc` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetSystemTimeAsFileTime` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GlobalFree` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GlobalUnlock` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GlobalLock` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GlobalAlloc` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GlobalSize` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetVersion` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetModuleHandleW` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `FindFirstFileW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `FindNextFileW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `FindClose` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SetEvent` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `CancelIo` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetLongPathNameW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `WaitForMultipleObjectsEx` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `FindCloseChangeNotification` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `FindNextChangeNotification` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `WaitForMultipleObjects` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `FindFirstChangeNotificationW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `CreateFileW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetVolumeInformationW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `MultiByteToWideChar` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `WideCharToMultiByte` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetLastError` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetFileSize` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `SetEndOfFile` | medium | 2-8 h | Win32 environment, path, process or system API |
| `SetFilePointer` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `ReadFile` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `WriteFile` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetFileAttributesW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `DeleteFileW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `MoveFileExW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `CopyFileW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `SetFileAttributesW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetTempPathW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetVolumePathNameW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `CreateDirectoryW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetFullPathNameW` | medium | 2-8 h | Win32 environment, path, process or system API |
| `RemoveDirectoryW` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `SetEnvironmentVariableA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetEnvironmentVariableA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `LoadLibraryW` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetACP` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetFullPathNameA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetProcessTimes` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetCommandLineA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `Sleep` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `MoveFileA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `CreateDirectoryA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `RemoveDirectoryA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetCurrentDirectoryA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `UnhandledExceptionFilter` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetStartupInfoA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `FlushConsoleInputBuffer` | medium | 2-8 h | Win32 environment, path, process or system API |
| `FindFirstFileA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `FindNextFileA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GlobalMemoryStatus` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `GetStdHandle` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetFileType` | medium | 2-8 h | Win32 environment, path, process or system API |
| `QueryPerformanceCounter` | low-medium | 1-4 h | Direct Bionic/POSIX or small compatibility wrapper |
| `TlsGetValue` | high | 8-24 h | Process, loader, exception, VM or thread semantics |
| `GetDiskFreeSpaceExA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetVolumeInformationA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetDriveTypeA` | medium | 2-8 h | Win32 environment, path, process or system API |
| `GetLogicalDrives` | medium | 2-8 h | Win32 environment, path, process or system API |
| `InitializeCriticalSection` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `DeleteCriticalSection` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `EnterCriticalSection` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `LeaveCriticalSection` | medium-high | 4-16 h | Synchronization primitive and wait semantics |
| `DeleteFileA` | medium | 3-12 h | Windows handles, paths and async/error semantics |
| `GetCurrentProcess` | medium | 2-8 h | Win32 environment, path, process or system API |

### `MSVCR90.dll` (159)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `tolower` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_controlfp_s` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_invoke_watson` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `?_type_info_dtor_internal_method@type_info@@QAEXXZ` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_except_handler4_common` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_time32` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__set_app_type` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__p__fmode` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__p__commode` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_adjust_fdiv` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__setusermatherr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_configthreadlocale` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `_initterm_e` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_initterm` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_acmdln` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_ismbblead` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_XcptFilter` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_exit` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_cexit` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__getmainargs` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_amsg_exit` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `?terminate@@YAXXZ` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_decode_pointer` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_onexit` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_lock` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_encode_pointer` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__dllonexit` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_unlock` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_getch` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `signal` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `isupper` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strcmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `vfprintf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `ldexp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `vsprintf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_aligned_free` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_aligned_malloc` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcsncat` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_control87` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcscspn` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strncat` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_controlfp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_ultoa` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_strlwr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `fputs` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_isnan` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_finite` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_searchenv` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wsearchenv` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_spawnv` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wspawnv` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_strtoui64` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wgetcwd` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wstat64i32` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `_getdrive` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wgetdcwd` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_fcvt` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_ecvt` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_beginthreadex` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_mktime64` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strftime` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_localtime64` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strtol` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strpbrk` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `isprint` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `atof` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `atoi` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `towupper` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `setlocale` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `_setmbcp` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `_wcslwr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_ltow` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `strrchr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_gmtime64` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `abort` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_snprintf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `ftell` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `fflush` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_vsnprintf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_errno` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `ferror` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `longjmp` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `getenv` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `tmpfile` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `fseek` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `_setjmp3` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_ltoa` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `fgets` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_stat64i32` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `strspn` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strcspn` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcsrchr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__iob_func` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_aligned_realloc` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `exit` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_purecall` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `_CIcos` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIsin` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIsqrt` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `memset` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `memcpy` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `memmove` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIasin` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIfmod` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIacos` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `fclose` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `fprintf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `fopen` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `fwrite` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `sprintf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIpow` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcstoul` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_ultow` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `strtod` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CIlog` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `floor` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `ceil` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `modf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `__CxxFrameHandler3` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `atol` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `isdigit` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_strnicmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_CxxThrowException` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `sscanf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_stricmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `swscanf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcstol` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcsncmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wtol` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcsncpy` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strncpy` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strtoul` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strncmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `toupper` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strchr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `isspace` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wcsicmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `isalnum` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcstod` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `isalpha` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcsstr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `wcschr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_wcsnicmp` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `towlower` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `iswctype` | medium | 2-8 h | Locale and multibyte behavior differs by platform |
| `isxdigit` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `memchr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `strstr` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `printf` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `qsort` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_except_handler3` | high | 8-32 h | C++ ABI, exception or CRT startup semantics |
| `fread` | low-medium | 1-4 h | CRT file/stdio wrapper |
| `feof` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `free` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `realloc` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `malloc` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_time64` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `rand` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |
| `_crt_debugger_hook` | low | 0.5-2 h | Standard CRT routine; ABI and edge cases still need tests |

### `ole32.dll` (6)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `OleInitialize` | high | 8-32 h | COM/OLE lifetime, drag-drop and storage-medium semantics |
| `RegisterDragDrop` | high | 8-32 h | COM/OLE lifetime, drag-drop and storage-medium semantics |
| `RevokeDragDrop` | high | 8-32 h | COM/OLE lifetime, drag-drop and storage-medium semantics |
| `CoLockObjectExternal` | high | 8-32 h | COM/OLE lifetime, drag-drop and storage-medium semantics |
| `OleUninitialize` | high | 8-32 h | COM/OLE lifetime, drag-drop and storage-medium semantics |
| `ReleaseStgMedium` | high | 8-32 h | COM/OLE lifetime, drag-drop and storage-medium semantics |

### `PSAPI.DLL` (1)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `GetModuleInformation` | low-medium | 1-4 h | Module metadata/process API adapter |

### `SHELL32.dll` (3)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `SHGetFolderPathW` | medium-high | 4-16 h | Special folders, drag/drop and external intents |
| `DragQueryFileW` | medium-high | 4-16 h | Special folders, drag/drop and external intents |
| `ShellExecuteW` | medium-high | 4-16 h | Special folders, drag/drop and external intents |

### `steam_api.dll` (3)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `SteamApps` | low-medium | 1-6 h | Offline stub is easy; real Steam semantics are not |
| `SteamAPI_Shutdown` | low-medium | 1-6 h | Offline stub is easy; real Steam semantics are not |
| `SteamAPI_Init` | low-medium | 1-6 h | Offline stub is easy; real Steam semantics are not |

### `USER32.dll` (89)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `SetWindowLongW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `CreateWindowExW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetWindowPos` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetWindowLongA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetSystemMetrics` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `GetClientRect` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `SetWindowTextW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `DestroyWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetDesktopWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `IsDlgButtonChecked` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `CheckDlgButton` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `GetDoubleClickTime` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `wsprintfA` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `RegisterClassA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `CreateWindowExA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetClipboardViewer` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `IsClipboardFormatAvailable` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetClipboardData` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `TranslateMessage` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `EmptyClipboard` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetClipboardData` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `CloseClipboard` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `ChangeClipboardChain` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `wsprintfW` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `GetCursorPos` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetKeyboardState` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `DefWindowProcA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `PeekMessageA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetKeyboardLayout` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `RegisterClassExW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetTimer` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `SetCursor` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetCursorPos` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `IntersectRect` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `ReleaseCapture` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `SetCapture` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `GetMenu` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `AdjustWindowRectEx` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `MoveWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `BeginPaint` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `EndPaint` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `EnumDisplayMonitors` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `PeekMessageW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `DispatchMessageW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `ClientToScreen` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `KillTimer` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `UnregisterClassA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetKeyState` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `PostMessageA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `ShowCursor` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetWindowRect` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `MonitorFromWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `IsZoomed` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `GetAncestor` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `IsIconic` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `IsWindowVisible` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetActiveWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetActiveWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `FillRect` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `UpdateWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `ValidateRect` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `InvalidateRect` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `LoadIconA` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `DestroyCursor` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetIconInfo` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `LoadImageW` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `UnhookWindowsHookEx` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetWindowsHookExA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetAsyncKeyState` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `CallNextHookEx` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetForegroundWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetWindowThreadProcessId` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetMonitorInfoA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `ScreenToClient` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `SendMessageA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `LoadCursorA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetWindowLongA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `SetFocus` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `DefWindowProcW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetDC` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `ReleaseDC` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `SystemParametersInfoA` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `GetProcessWindowStation` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `GetUserObjectInformationW` | medium | 2-10 h | UI state or platform behavior needs adaptation |
| `ShowWindow` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `MessageBoxW` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `MessageBoxA` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `OpenClipboard` | high | 6-24 h | Window-system/input behavior needs Android mapping |
| `PostQuitMessage` | high | 6-24 h | Window-system/input behavior needs Android mapping |

### `USP10.dll` (2)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `ScriptItemize` | high | 8-24 h | Uniscribe shaping/layout must be replaced with Android text stack |
| `ScriptBreak` | high | 8-24 h | Uniscribe shaping/layout must be replaced with Android text stack |

### `VERSION.dll` (5)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `GetFileVersionInfoSizeA` | low | 1-3 h | Version-resource query or packaged metadata adapter |
| `GetFileVersionInfoA` | low | 1-3 h | Version-resource query or packaged metadata adapter |
| `VerQueryValueA` | low | 1-3 h | Version-resource query or packaged metadata adapter |
| `VerQueryValueW` | low | 1-3 h | Version-resource query or packaged metadata adapter |
| `GetFileVersionInfoW` | low | 1-3 h | Version-resource query or packaged metadata adapter |

### `WINMM.dll` (3)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `timeEndPeriod` | low-medium | 1-5 h | Timer resolution/monotonic clock adapter |
| `timeBeginPeriod` | low-medium | 1-5 h | Timer resolution/monotonic clock adapter |
| `timeGetTime` | low-medium | 1-5 h | Timer resolution/monotonic clock adapter |

### `WS2_32.dll` (3)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `WSAIoctl` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `WSASetLastError (ordinal #112)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `WSASocketA` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |

### `WSOCK32.dll` (23)

| Imported symbol | Effort | Estimate | Shim notes |
|---|---|---:|---|
| `send (ordinal #19)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `listen (ordinal #13)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `connect (ordinal #4)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `accept (ordinal #1)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `getsockname (ordinal #6)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `getsockopt (ordinal #7)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `__WSAFDIsSet (ordinal #151)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `select (ordinal #18)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `recv (ordinal #16)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `inet_addr (ordinal #10)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `gethostbyname (ordinal #52)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `closesocket (ordinal #3)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `WSAStartup (ordinal #115)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `WSACleanup (ordinal #116)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `WSAGetLastError (ordinal #111)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `sendto (ordinal #20)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `recvfrom (ordinal #17)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `ioctlsocket (ordinal #12)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `socket (ordinal #23)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `bind (ordinal #2)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `shutdown (ordinal #22)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `getpeername (ordinal #5)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |
| `setsockopt (ordinal #21)` | medium-high | 4-16 h | Socket ABI, errors, nonblocking I/O and network policy |

## Interpretation

The estimates are not additive: many imported functions share one underlying adapter (for example file handles, UI message dispatch, COM, D3D9, or CRT startup). The largest architectural risks are not the number of imports but pointer-width/ABI translation, exception and TLS behavior, dynamic loading, window/message semantics, and D3D9-to-GLES/Vulkan resource and shader mapping.

Ordinals are resolved against the local Windows `SysWOW64` export tables where available. That is a local OS mapping, not proof the game was built against that exact DLL revision; unresolved ordinals remain explicitly named.
