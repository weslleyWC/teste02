// Ghidra 12.2 exporter for the current internal Spore function inventory.
// The script reads existing Ghidra analysis and does not trigger re-analysis.
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Map;
import java.util.TreeMap;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;

public class ExportSporeFunctionInventory extends GhidraScript {
    private static final String EXPECTED_SHA256 =
        "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b";
    private static final String OUTPUT_DIRECTORY = "C:\\SporeAnalysis";
    private static final String OUTPUT_NAME = "spore_functions_current.csv";
    private static final long MAX_INPUT_BYTES = 256L * 1024L * 1024L;
    private static final long MAX_RUNTIME_MILLIS = 600_000L;

    private long deadline;

    @Override
    protected void run() throws Exception {
        if (currentProgram == null) {
            throw new IllegalStateException("Open the selected Spore program in Ghidra first.");
        }
        if (!"x86:LE:32:default".equals(currentProgram.getLanguageID().toString())) {
            throw new IllegalStateException(
                "The open program is not the expected x86-32 Spore executable."
            );
        }

        File source = askFile(
            "Select the exact SporeApp.exe imported into the open Ghidra program",
            "Select"
        );
        if (source == null || !source.isFile() || source.length() > MAX_INPUT_BYTES) {
            throw new IllegalArgumentException("Select a regular SporeApp.exe under 256 MiB.");
        }
        boolean confirmed = askYesNo(
            "Confirm source identity",
            "Is this the exact original SporeApp.exe used to create the currently open Ghidra program?"
        );
        if (!confirmed) {
            throw new IllegalStateException("Source identity was not confirmed; no inventory was exported.");
        }

        String sourceHash = sha256(source);
        if (!EXPECTED_SHA256.equalsIgnoreCase(sourceHash)) {
            throw new IllegalArgumentException(
                "Selected SporeApp.exe SHA-256 does not match the approved Phase 4 build: "
                    + sourceHash
            );
        }

        File outputDirectory = new File(OUTPUT_DIRECTORY);
        File output = new File(outputDirectory, OUTPUT_NAME);
        if (!outputDirectory.isDirectory()) {
            throw new IllegalStateException("Output directory does not exist: " + OUTPUT_DIRECTORY);
        }
        if (output.exists()) {
            throw new IllegalStateException(
                "Output already exists; preserve it and move it before rerunning: "
                    + output.getCanonicalPath()
            );
        }

        deadline = System.currentTimeMillis() + MAX_RUNTIME_MILLIS;
        monitor.initialize(MAX_RUNTIME_MILLIS);
        Map<Long, Function> functions = collectFunctions();
        Path temporaryFile = Files.createTempFile(
            outputDirectory.toPath(),
            "spore_functions_current_",
            ".tmp"
        );
        boolean published = false;
        try {
            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(temporaryFile.toFile()), StandardCharsets.UTF_8))) {
                writer.write("address,name,size\n");
                for (Map.Entry<Long, Function> entry : functions.entrySet()) {
                    checkDeadline();
                    Function function = entry.getValue();
                    writer.write("\"");
                    writer.write(String.format("%08x", entry.getKey()));
                    writer.write("\",\"");
                    writer.write(csvEscape(function.getName()));
                    writer.write("\",");
                    writer.write(Long.toString(function.getBody().getNumAddresses()));
                    writer.write("\n");
                }
            }
            Files.move(temporaryFile, output.toPath());
            published = true;
        } finally {
            if (!published) {
                Files.deleteIfExists(temporaryFile);
            }
        }

        println("Exported " + functions.size() + " internal, non-thunk functions to "
            + output.getCanonicalPath());
        println("Selected executable SHA-256: " + sourceHash);
        println("No target code was executed and no whole-program analysis was triggered.");
    }

    private Map<Long, Function> collectFunctions() throws Exception {
        Map<Long, Function> result = new TreeMap<>();
        FunctionIterator iterator = currentProgram.getFunctionManager().getFunctions(true);
        while (iterator.hasNext()) {
            checkDeadline();
            Function function = iterator.next();
            if (function.isExternal() || function.isThunk()) {
                continue;
            }
            long entry = function.getEntryPoint().getOffset();
            if (result.put(entry, function) != null) {
                throw new IllegalStateException(
                    String.format("Duplicate function entry 0x%08x.", entry)
                );
            }
        }
        return result;
    }

    private String csvEscape(String value) {
        return value.replace("\"", "\"\"");
    }

    private String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] buffer = new byte[1024 * 1024];
        try (InputStream input = new BufferedInputStream(new FileInputStream(file))) {
            int count;
            while ((count = input.read(buffer)) != -1) {
                digest.update(buffer, 0, count);
            }
        }
        StringBuilder result = new StringBuilder(64);
        for (byte value : digest.digest()) {
            result.append(String.format("%02x", value & 0xff));
        }
        return result.toString();
    }

    private void checkDeadline() throws Exception {
        if (System.currentTimeMillis() > deadline || monitor.isCancelled()) {
            throw new IllegalStateException("Inventory export cancelled or timed out.");
        }
    }
}
