#include "FirstStaticLiftRuntime.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>

LiftStatus spore_lift_00422430(
    const std::uint32_t* records,
    std::size_t record_count,
    const std::uint32_t* key,
    std::size_t* result_index);

struct Record {
    std::uint32_t key;
    std::uint32_t payload_a;
    std::uint32_t payload_b;
};

static_assert(sizeof(Record) == 12, "Spore record layout must be 12 bytes.");

static std::size_t reference_lower_bound(const Record* records, std::size_t count,
                                         std::uint32_t key) {
    std::size_t low = 0;
    std::size_t high = count;
    while (low < high) {
        const std::size_t middle = low + ((high - low) >> 1u);
        if (records[middle].key < key) {
            low = middle + 1u;
        } else {
            high = middle;
        }
    }
    return low;
}

static bool run_case(const Record* records, std::size_t count, std::uint32_t key,
                     std::size_t expected, const char* label) {
    std::size_t actual = static_cast<std::size_t>(-1);
    const LiftStatus status = spore_lift_00422430(
        reinterpret_cast<const std::uint32_t*>(records),
        count,
        &key,
        &actual);
    const std::size_t oracle = count == 0 ? 0 : reference_lower_bound(records, count, key);
    const bool passed = status == LiftStatus::ok && actual == expected && actual == oracle;
    std::printf(
        "%s status=%u actual=%zu expected=%zu oracle=%zu %s\n",
        label,
        static_cast<unsigned>(status),
        actual,
        expected,
        oracle,
        passed ? "PASS" : "FAIL");
    return passed;
}

int main() {
    constexpr std::array<Record, 8> records{{
        {0x00000000u, 10u, 20u},
        {0x00000008u, 11u, 21u},
        {0x00000008u, 12u, 22u},
        {0x00000010u, 13u, 23u},
        {0x00000020u, 14u, 24u},
        {0x7fffffffu, 15u, 25u},
        {0x80000000u, 16u, 26u},
        {0xffffffffu, 17u, 27u},
    }};
    constexpr std::array<std::uint32_t, 12> keys{{
        0x00000000u, 0x00000001u, 0x00000007u, 0x00000008u,
        0x00000009u, 0x00000010u, 0x00000018u, 0x00000020u,
        0x7fffffffu, 0x80000000u, 0xfffffffeu, 0xffffffffu,
    }};

    std::size_t failures = 0;
    for (std::size_t i = 0; i < keys.size(); ++i) {
        const std::size_t expected = reference_lower_bound(records.data(), records.size(), keys[i]);
        failures += !run_case(records.data(), records.size(), keys[i], expected, "populated");
    }
    failures += !run_case(nullptr, 0, 0u, 0, "empty");

    std::array<Record, 1> singleton{{{0x80000000u, 1u, 2u}}};
    failures += !run_case(singleton.data(), singleton.size(), 0x7fffffffu, 0, "singleton-before");
    failures += !run_case(singleton.data(), singleton.size(), 0x80000000u, 0, "singleton-equal");
    failures += !run_case(singleton.data(), singleton.size(), 0xffffffffu, 1, "singleton-after");

    std::printf("summary cases=%zu failures=%zu\n", keys.size() + 4u, failures);
    return failures == 0 ? 0 : 1;
}
