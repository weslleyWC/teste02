$ErrorActionPreference = "Stop"

$executable = "C:\Program Files (x86)\Steam\steamapps\common\Spore\SPOREFILES\SporeBin\SporeApp.exe"
$expectedHash = "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b"
$harness = Join-Path $PSScriptRoot "FirstNativeEqualX86Reference.cpp"
$output = Join-Path $PSScriptRoot "FirstNativeEqualX86Reference.exe"
$log = Join-Path $PSScriptRoot "native_equal_x86_reference.log"
$vswhere = "C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"

$hash = (Get-FileHash -LiteralPath $executable -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne $expectedHash) {
    throw "Selected SporeApp.exe hash changed: $hash"
}
if (-not (Test-Path $vswhere)) {
    throw "Visual Studio vswhere.exe not found."
}
$processor = Get-CimInstance Win32_Processor | Select-Object -First 1
if ($processor.Architecture -ne 9 -and $processor.Architecture -ne 0) {
    throw "Native x86 reference requires physical x86/x86-64 hardware."
}
$vsPath = & $vswhere -products "*" -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vsPath) {
    throw "Visual Studio C++ x86/x64 build tools were not found."
}
$vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvarsall.bat"
if (-not (Test-Path $vcvars)) {
    throw "vcvarsall.bat not found: $vcvars"
}

$command = 'call "' + $vcvars + '" x86 >nul && cd /d "' + $PSScriptRoot +
    '" && cl /nologo /EHsc /std:c++17 /O2 /W4 FirstNativeEqualX86Reference.cpp /Fe:"' +
    $output + '" && "' + $output + '" "' + $executable + '" > "' + $log + '" 2>&1'
& $env:ComSpec /d /s /c $command
if ($LASTEXITCODE -ne 0) {
    if (Test-Path $log) {
        Get-Content -LiteralPath $log
    }
    throw "Native x86 equality-reference harness build or execution failed."
}
Select-String -LiteralPath $log -Pattern "FAIL|summary"
Write-Output "Full native x86 equality log: $log"
