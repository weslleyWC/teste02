// prop_dump file.bin [file2.bin ...]   decode and print PROP resources
// prop_dump --scan <SPOREFILES>        parse every PROP in every .package,
//                                      print failures and a (type, flags) census
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

#include "prop_reader.hpp"

namespace fs = std::filesystem;
using namespace spore;

namespace {

bool parse_hex_uint(const std::string& text, std::size_t start, std::size_t end,
                    unsigned& value) {
    if (start >= end) return false;
    value = 0;
    for (std::size_t i = start; i < end; ++i) {
        const char c = text[i];
        unsigned digit;
        if (c >= '0' && c <= '9') {
            digit = static_cast<unsigned>(c - '0');
        } else if (c >= 'A' && c <= 'F') {
            digit = static_cast<unsigned>(c - 'A' + 10);
        } else if (c >= 'a' && c <= 'f') {
            digit = static_cast<unsigned>(c - 'a' + 10);
        } else {
            return false;
        }
        if (value > (std::numeric_limits<unsigned>::max() - digit) / 16) return false;
        value = value * 16 + digit;
    }
    return true;
}

std::string preview(const PropValue& v) {
    char buf[96];
    std::string out;
    if (v.is_string_array) {
        return "<" + std::to_string(v.count) + " strings, " +
               std::to_string(v.bytes.size()) + " encoded bytes>";
    }
    if (v.type == prop_type::kString8) {
        std::string s;
        prop_string8(v, s);
        return "\"" + s + "\"";
    }
    if (v.type == prop_type::kString16) {
        std::string s;
        prop_string16(v, s);
        return "\"" + s + "\"";
    }
    const std::size_t shown = v.count < 4 ? v.count : 4;
    for (std::size_t i = 0; i < shown; ++i) {
        if (i) out += ", ";
        float f[3];
        std::int32_t si;
        std::uint32_t ui;
        Tgi k;
        if (prop_float(v, i, f[0])) {
            std::snprintf(buf, sizeof(buf), "%g", f[0]);
        } else if (prop_int32(v, i, si)) {
            std::snprintf(buf, sizeof(buf), "%d", si);
        } else if (prop_uint32(v, i, ui)) {
            std::snprintf(buf, sizeof(buf), "0x%08X", ui);
        } else if (prop_key(v, i, k)) {
            std::snprintf(buf, sizeof(buf), "key{inst=%08X type=%08X group=%08X}",
                          k.instance, k.type, k.group);
        } else if (prop_vec3(v, i, f)) {
            std::snprintf(buf, sizeof(buf), "(%g, %g, %g)", f[0], f[1], f[2]);
        } else {
            std::string hex;
            for (std::size_t b = 0; b < v.item_size && b < 12; ++b) {
                std::snprintf(buf, sizeof(buf), "%02x", v.bytes[i * v.item_size + b]);
                hex += buf;
            }
            std::snprintf(buf, sizeof(buf), "raw:%s", hex.c_str());
        }
        out += buf;
    }
    if (v.count > shown) out += ", ...";
    return out;
}

std::vector<std::uint8_t> read_file(const fs::path& p) {
    std::ifstream f(p, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open " + p.string());
    return {std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>()};
}

int dump_file(const fs::path& path) {
    try {
        const PropList list = parse_prop(read_file(path));
        std::printf("== %s : %zu properties\n", path.string().c_str(), list.values.size());
        for (const PropValue& v : list.values) {
            const char* kind = v.is_string_array ? "str-array" :
                               (v.is_string ? "str" :
                               (v.is_array ? "array" : "scalar"));
            std::printf("  id=%08X type=0x%04X flags=0x%04X %s count=%u item=%u  %s\n", v.id,
                        v.type, v.flags, kind,
                        v.count, v.item_size, preview(v).c_str());
        }
        return 0;
    } catch (const std::exception& e) {
        std::printf("== %s : FAIL %s\n", path.string().c_str(), e.what());
        return 1;
    }
}

int scan(const fs::path& root) {
    std::map<std::string, std::size_t> census;
    std::map<std::string, std::pair<std::size_t, std::string>> failures;  // msg -> count, example
    std::size_t total = 0, ok = 0, package_errors = 0;

    for (const auto& de : fs::recursive_directory_iterator(root)) {
        if (!de.is_regular_file() || de.path().extension() != ".package") continue;
        try {
            DbpfPackage pkg(de.path());
            const auto& entries = pkg.entries();
            for (std::size_t i = 0; i < entries.size(); ++i) {
                if (entries[i].key.type != kPropTypeId) continue;
                ++total;
                try {
                    const PropList list = parse_prop(pkg.read_entry(i));
                    ++ok;
                    for (const PropValue& v : list.values) {
                        char buf[64];
                        std::snprintf(buf, sizeof(buf), "type=0x%04X flags=0x%04X %s", v.type,
                                      v.flags, v.is_string_array ? "str-array" :
                                      (v.is_string ? "str" : (v.is_array ? "array" : "scalar")));
                        ++census[buf];
                    }
                } catch (const std::exception& e) {
                    std::string msg = e.what();
                    // group by the message text without the offset to keep the list short
                    const std::size_t cut = msg.find(" (offset");
                    std::string key = cut == std::string::npos ? msg : msg.substr(0, cut);
                    if (key == "PROP: unknown scalar type") {
                        const std::size_t offset = msg.find("(offset ");
                        const std::size_t comma =
                            offset == std::string::npos ? std::string::npos : msg.find(',', offset);
                        const std::size_t type_start =
                            comma == std::string::npos ? std::string::npos : msg.find("0x", comma);
                        const std::size_t type_end =
                            type_start == std::string::npos ? std::string::npos :
                            msg.find(',', type_start);
                        unsigned type = 0;
                        if (type_end != std::string::npos &&
                            parse_hex_uint(msg, type_start + 2, type_end, type)) {
                            char details[64];
                            std::snprintf(details, sizeof(details), " type=0x%04X", type);
                            key += details;
                        }
                    }
                    auto& slot = failures[key];
                    if (slot.first++ == 0) {
                        slot.second = de.path().filename().string() + " g=" +
                                      hex32(entries[i].key.group) + " i=" +
                                      hex32(entries[i].key.instance) + "  " + msg;
                    }
                }
            }
        } catch (const std::exception& e) {
            ++package_errors;
            std::fprintf(stderr, "warn: %s: %s\n", de.path().string().c_str(), e.what());
        }
    }

    std::printf("PROP resources: %zu parsed ok / %zu total\n\n", ok, total);
    std::printf("Property census (type, flags, kind):\n");
    for (const auto& [k, n] : census) std::printf("  %-44s %zu\n", k.c_str(), n);
    if (!failures.empty()) {
        std::printf("\nFailures (grouped by reason):\n");
        for (const auto& [k, v] : failures) {
            std::printf("  x%zu  %s\n      e.g. %s\n", v.first, k.c_str(), v.second.c_str());
        }
    }
    if (package_errors != 0) {
        std::printf("\nPackage read/parse errors: %zu\n", package_errors);
    }
    return ok == total && package_errors == 0 ? 0 : 1;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc == 3 && std::string(argv[1]) == "--scan") return scan(argv[2]);
    if (argc < 2) {
        std::fprintf(stderr, "usage: prop_dump file.bin...   |   prop_dump --scan <SPOREFILES>\n");
        return 2;
    }
    int rc = 0;
    for (int i = 1; i < argc; ++i) rc |= dump_file(argv[i]);
    return rc;
}
