$ErrorActionPreference = "Stop"

$adb = Join-Path $env:LOCALAPPDATA "Android\Sdk\platform-tools\adb.exe"
$binary = Join-Path $PSScriptRoot "spore_00404460_arm64"
$remote = "/data/local/tmp/spore_00404460_arm64"
$log = Join-Path $PSScriptRoot "arm64_equal_device_validation.log"

if (-not (Test-Path $adb)) {
    throw "ADB not found: $adb"
}
if (-not (Test-Path $binary)) {
    throw "ARM64 binary not found. Run build_third_static_lift.ps1 first."
}

$devices = @(& $adb devices -l | Select-Object -Skip 1 | Where-Object { $_ -match "\S" })
if ($devices.Count -ne 1 -or $devices[0] -notmatch "\sdevice\s") {
    throw "Connect exactly one authorized physical Android device; no emulator will be used."
}
$serial = ($devices[0] -split "\s+")[0]
if ($serial -like "emulator-*") {
    throw "Emulator serial detected; execution is prohibited for this phase."
}
$qemu = (& $adb -s $serial shell getprop ro.kernel.qemu).Trim()
$model = (& $adb -s $serial shell getprop ro.product.model).Trim()
if ($qemu -eq "1" -or $model -match "(?i)emulator|sdk_gphone|virtual") {
    throw "The connected target appears to be an emulator, not a physical device."
}
$abi = (& $adb -s $serial shell getprop ro.product.cpu.abi).Trim()
if ($abi -ne "arm64-v8a") {
    throw "Expected physical arm64-v8a device, got '$abi'."
}

Write-Output "Physical device: $model ($abi), serial $serial"
& $adb -s $serial push $binary $remote
if ($LASTEXITCODE -ne 0) {
    throw "Failed to push generated ARM64 harness."
}
& $adb -s $serial shell chmod 755 $remote
if ($LASTEXITCODE -ne 0) {
    throw "Failed to mark generated ARM64 harness executable."
}
& $adb -s $serial shell $remote 2>&1 | Tee-Object -FilePath $log
if ($LASTEXITCODE -ne 0) {
    throw "Generated ARM64 harness failed on the physical device."
}
Write-Output "Full ARM64 equality test log: $log"
