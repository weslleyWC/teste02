$ErrorActionPreference = "Stop"

$adb = "C:\Users\wesll\AppData\Local\Android\Sdk\platform-tools\adb.exe"
$ndk = "C:\Users\wesll\AppData\Local\Android\Sdk\ndk\29.0.14206865"
$compiler = Join-Path $ndk "toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe"
$root = $PSScriptRoot
$generated = "C:\SporeAnalysis\generated_all"
$harness = Join-Path $root "BatchStaticLiftReachableArm64Harness.cpp"
$outputDirectory = Join-Path $root "reachable_arm64_harness"
$binary = Join-Path $outputDirectory "BatchStaticLiftReachableArm64Harness"
$serial = "PJMZAEJRX4YLFIDI"
$remote = "/data/local/tmp/spore-static-lift/BatchStaticLiftReachableArm64Harness"

New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null
$sources = @(
    (Join-Path $generated "spore_00c2e4e0_arm64.cpp"),
    (Join-Path $generated "spore_00a6ca00_arm64.cpp"),
    (Join-Path $generated "spore_006bb640_arm64.cpp"),
    (Join-Path $generated "spore_00b3d220_arm64.cpp"),
    (Join-Path $generated "spore_011861a0_arm64.cpp"),
    (Join-Path $generated "spore_0118a790_arm64.cpp"),
    (Join-Path $generated "spore_011e13c0_arm64.cpp"),
    (Join-Path $generated "spore_00921580_arm64.cpp"),
    (Join-Path $generated "spore_009215c0_arm64.cpp"),
    (Join-Path $generated "spore_00edba80_arm64.cpp"),
    (Join-Path $generated "spore_005d67f0_arm64.cpp"),
    (Join-Path $generated "spore_0119afe0_arm64.cpp"),
    (Join-Path $generated "spore_0041e920_arm64.cpp"),
    (Join-Path $generated "spore_0041e990_arm64.cpp"),
    (Join-Path $generated "spore_0041ea00_arm64.cpp"),
    (Join-Path $generated "spore_0041ea70_arm64.cpp"),
    (Join-Path $generated "spore_00423890_arm64.cpp"),
    (Join-Path $generated "spore_0117dde0_arm64.cpp"),
    (Join-Path $generated "spore_011874d0_arm64.cpp"),
    (Join-Path $generated "spore_00743b50_arm64.cpp"),
    (Join-Path $generated "spore_0077f010_arm64.cpp"),
    (Join-Path $generated "spore_011895f0_arm64.cpp"),
    (Join-Path $generated "spore_0093c710_arm64.cpp"),
    (Join-Path $generated "spore_0119af70_arm64.cpp"),
    (Join-Path $generated "spore_0091e020_arm64.cpp"),
    (Join-Path $generated "spore_006b5870_arm64.cpp"),
    (Join-Path $generated "spore_009267a0_arm64.cpp"),
    (Join-Path $generated "spore_0119b160_arm64.cpp"),
    (Join-Path $generated "spore_0088b850_arm64.cpp"),
    (Join-Path $generated "spore_0092ea70_arm64.cpp"),
    (Join-Path $generated "spore_005c1cc0_arm64.cpp"),
    (Join-Path $generated "spore_0117afe0_arm64.cpp")
    (Join-Path $generated "spore_011e8b20_arm64.cpp")
    (Join-Path $generated "spore_0117e310_arm64.cpp")
    (Join-Path $generated "spore_008db8c0_arm64.cpp")
    (Join-Path $generated "spore_00a0fdf0_arm64.cpp")
    (Join-Path $generated "spore_00925f30_arm64.cpp")
    (Join-Path $generated "spore_00926a30_arm64.cpp")
    (Join-Path $generated "spore_00705250_arm64.cpp"),
    (Join-Path $generated "spore_00c7ea30_arm64.cpp"),
    (Join-Path $generated "spore_005728f0_arm64.cpp"),
    (Join-Path $generated "spore_00e5c780_arm64.cpp"),
    (Join-Path $generated "spore_011849c0_arm64.cpp"),
    (Join-Path $generated "spore_005e8ff0_arm64.cpp"),
    (Join-Path $generated "spore_009216a0_arm64.cpp")
)
foreach ($required in @($adb, $compiler, $harness) + $sources) {
    if (-not (Test-Path -LiteralPath $required)) { throw "Missing input: $required" }
}
$arguments = @("--target=aarch64-linux-android35", "-std=c++17", "-O2",
    "-Wall", "-Wextra", "-fPIE", "-pie", "-I$root", "-I$generated",
    $harness) + $sources + @("-o", $binary)
& $compiler @arguments
if ($LASTEXITCODE -ne 0) { throw "ARM64 harness compilation failed." }
& $adb -s $serial shell "mkdir -p /data/local/tmp/spore-static-lift"
& $adb -s $serial push $binary $remote
& $adb -s $serial shell "chmod 700 $remote; $remote"
if ($LASTEXITCODE -ne 0) { throw "ARM64 device harness failed." }
