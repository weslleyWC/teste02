param(
    [string]$LogPath,
    [string]$DeviceSerial
)

$ErrorActionPreference = "Stop"

$root = $PSScriptRoot
$adb = "C:\Users\wesll\AppData\Local\Android\Sdk\platform-tools\adb.exe"
$compiler = "C:\Users\wesll\AppData\Local\Android\Sdk\ndk\29.0.14206865\toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe"
$generatedSource = Join-Path $root "generated_batch_pilot_100_v2\spore_007f30d0_arm64.cpp"
$harnessSource = Join-Path $root "BatchStaticLiftLeaReference.cpp"
$log = if ($LogPath) {
    [System.IO.Path]::GetFullPath($LogPath)
} else {
    Join-Path $root "batch_static_lift_007f30d0_arm64_v1.log"
}
$tempDirectory = Join-Path $env:TEMP ("spore-lea-arm64-" + [Guid]::NewGuid().ToString("N"))
$binary = Join-Path $tempDirectory "BatchStaticLiftLeaReference"
$serial = $DeviceSerial
$remoteBinary = "/data/local/tmp/BatchStaticLiftLeaReference-" +
    [Guid]::NewGuid().ToString("N")
$remoteBinaryPushed = $false

if (Test-Path -LiteralPath $log) {
    throw "ARM64 log already exists; preserve it before rerunning: $log"
}
foreach ($required in @($adb, $compiler, $generatedSource, $harnessSource)) {
    if (-not (Test-Path -LiteralPath $required)) {
        throw "Required ARM64 comparison input not found: $required"
    }
}

$deviceList = & $adb devices
if ($LASTEXITCODE -ne 0) {
    throw "ADB could not list attached devices."
}
$attachedDevices = @(
    $deviceList |
        Select-String -Pattern "^\s*(\S+)\s+device(?:\s|$)" |
        ForEach-Object { $_.Matches[0].Groups[1].Value }
)
if ($serial) {
    if ($serial -notin $attachedDevices) {
        throw "Requested ADB device '$serial' is not attached and authorized. Attached devices: $($attachedDevices -join ', ')."
    }
} elseif ($attachedDevices.Count -eq 1) {
    $serial = $attachedDevices[0]
} else {
    throw "Expected exactly one attached, authorized ADB device or pass -DeviceSerial. Found $($attachedDevices.Count): $($attachedDevices -join ', ')."
}

$model = & $adb -s $serial shell getprop ro.product.model
$modelExitCode = $LASTEXITCODE
$abi = & $adb -s $serial shell getprop ro.product.cpu.abi
$abiExitCode = $LASTEXITCODE
$isEmulator = & $adb -s $serial shell getprop ro.kernel.qemu
$emulatorExitCode = $LASTEXITCODE
if ($modelExitCode -ne 0 -or $abiExitCode -ne 0 -or $emulatorExitCode -ne 0) {
    throw "ADB could not query device properties for $serial."
}
$model = ($model | Out-String).Trim()
$abi = ($abi | Out-String).Trim()
$isEmulator = ($isEmulator | Out-String).Trim()
if ($abi -ne "arm64-v8a" -or $isEmulator -eq "1") {
    throw "Expected a physical ARM64 device; got model=$model abi=$abi emulator=$isEmulator"
}

New-Item -ItemType Directory -Path $tempDirectory | Out-Null
try {
    $arguments = @(
        "--target=aarch64-linux-android35",
        "-std=c++17",
        "-O2",
        "-Wall",
        "-Wextra",
        "-Wno-unused-variable",
        "-Wno-unused-label",
        "-I$root",
        $generatedSource,
        $harnessSource,
        "-o",
        $binary
    )
    & $compiler @arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Android ARM64 LEA comparison build failed."
    }

    & $adb -s $serial push $binary $remoteBinary
    if ($LASTEXITCODE -ne 0) {
        throw "Could not copy the ARM64 comparison harness to $model."
    }
    $remoteBinaryPushed = $true
    & $adb -s $serial shell "chmod 700 $remoteBinary && $remoteBinary" 2>&1 |
        Tee-Object -FilePath $log
    if ($LASTEXITCODE -ne 0) {
        throw "ARM64 LEA comparison failed on $model."
    }
    Write-Output "Device: $model ($abi), physical device"
    Write-Output "Full ARM64 comparison log: $log"
} finally {
    if ($remoteBinaryPushed) {
        & $adb -s $serial shell "rm -f $remoteBinary" | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Write-Warning "Could not remove temporary ARM64 harness: $remoteBinary"
        }
    }
    if (Test-Path -LiteralPath $tempDirectory) {
        Remove-Item -LiteralPath $tempDirectory -Recurse -Force
    }
}
