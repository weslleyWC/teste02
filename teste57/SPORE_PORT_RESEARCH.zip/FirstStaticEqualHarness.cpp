#include "SporeCopyLiftRuntime.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>

enum class EqualLiftStatus { ok, invalid_memory, invalid_control_flow };

EqualLiftStatus spore_lift_00404460(
    CopyLiftMemory& memory,
    std::uint32_t receiver,
    std::uint32_t argument,
    std::uint32_t* result);

namespace {

constexpr std::uint32_t kReceiverBase = 0x10000000u;
constexpr std::uint32_t kArgumentBase = 0x20000000u;

struct TestObject {
    std::uint32_t ignored;
    std::uint32_t value;
};

static_assert(sizeof(TestObject) == 8, "Function compares the dword at offset +4.");

bool run_case(const char* label, std::uint32_t left, std::uint32_t right) {
    TestObject receiver{0x11111111u, left};
    TestObject argument{0x22222222u, right};
    CopyLiftMemory memory;
    if (!memory.map_region(
            kReceiverBase,
            reinterpret_cast<std::uint8_t*>(&receiver),
            sizeof(receiver),
            false) ||
        !memory.map_region(
            kArgumentBase,
            reinterpret_cast<std::uint8_t*>(&argument),
            sizeof(argument),
            false)) {
        std::fprintf(stderr, "failed to configure mappings for %s\n", label);
        return false;
    }

    std::uint32_t result = 0xfeedfaceu;
    const EqualLiftStatus status = spore_lift_00404460(
        memory, kReceiverBase, kArgumentBase, &result);
    const std::uint32_t expected = left == right ? 1u : 0u;
    const bool passed = status == EqualLiftStatus::ok && result == expected;
    std::printf(
        "arm64 case=%s status=%u result=%u expected=%u PASS=%u\n",
        label,
        static_cast<unsigned>(status),
        result,
        expected,
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main() {
    constexpr std::array<std::array<std::uint32_t, 2>, 8> values{{
        {{0u, 0u}},
        {{0u, 1u}},
        {{1u, 0u}},
        {{0x7fffffffu, 0x7fffffffu}},
        {{0x80000000u, 0x80000000u}},
        {{0xffffffffu, 0xffffffffu}},
        {{0x00000000u, 0xffffffffu}},
        {{0xdeadbeefu, 0xdeadbeeeu}},
    }};
    std::size_t failures = 0;
    for (std::size_t index = 0; index < values.size(); ++index) {
        char label[32]{};
        std::snprintf(label, sizeof(label), "pair_%02zu", index);
        failures += !run_case(label, values[index][0], values[index][1]);
    }
    std::printf("arm64 summary cases=%zu failures=%zu\n", values.size(), failures);
    return failures == 0 ? 0 : 1;
}
