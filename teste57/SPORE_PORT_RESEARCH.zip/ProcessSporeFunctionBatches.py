#!/usr/bin/env python3

import argparse
import hashlib
import json
from pathlib import Path

import BatchStaticLift as lifter


SCHEMA = "spore-ghidra-function-batch-v1"
STATE_SCHEMA = "spore-static-lift-incremental-state-v1"


def file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def function_key(function, source_hash, lifter_hash):
    encoded = json.dumps(
        {
            "source": source_hash,
            "lifter": lifter_hash,
            "entry": function["entry"],
            "name": function["name"],
            "body_address_count": function["body_address_count"],
            "instructions": function["instructions"],
        },
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def validate_batch(batch, expected_hash):
    if batch.get("schema") != SCHEMA:
        raise ValueError(f"unsupported batch schema in {batch}")
    if batch.get("selected_source_sha256") != expected_hash:
        raise ValueError("batch source hash differs from the selected executable")
    if batch.get("selected_source_is_phase4_build") is not True:
        raise ValueError("batch does not identify the approved executable")
    if batch.get("user_confirmed_source_for_open_program") is not True:
        raise ValueError("batch lacks source confirmation")
    if batch.get("language_id") != lifter.EXPECTED_LANGUAGE:
        raise ValueError("batch language is not x86:LE:32:default")
    if batch.get("functions_truncated") is not False:
        raise ValueError("batch function list is truncated")
    functions = batch.get("functions")
    if not isinstance(functions, list):
        raise ValueError("batch has no function list")
    return functions


def load_state(path, source_hash, lifter_hash):
    if not path.exists():
        return {
            "schema": STATE_SCHEMA,
            "source_sha256": source_hash,
            "lifter_sha256": lifter_hash,
            "functions": {},
        }
    state = load_json(path)
    if (
        state.get("schema") != STATE_SCHEMA
        or state.get("source_sha256") != source_hash
        or state.get("lifter_sha256") != lifter_hash
    ):
        raise ValueError("existing state belongs to another executable or lifter")
    return state


def process_function(inventory, entry, output_dir, pe):
    function = entry["function"]
    address = lifter.parse_address(function["entry"])
    if address not in inventory:
        raise ValueError(f"0x{address:08x} is absent from the inventory")
    if inventory[address]["name"] != function.get("name"):
        raise ValueError(f"inventory name differs at 0x{address:08x}")
    if int(inventory[address]["size"], 0) != int(function["body_address_count"]):
        raise ValueError(f"inventory/body size differs at 0x{address:08x}")
    try:
        lifter.validate_function_bytes(function, pe)
    except ValueError as error:
        return {
            "address": f"0x{address:08x}",
            "name": function["name"],
            "status": "rejected",
            "rejection_reasons": [str(error)],
            "instruction_diagnostics": [],
        }
    try:
        source, diagnostics = lifter.translate_function(function)
    except lifter.LiftRejected as error:
        return {
            "address": f"0x{address:08x}",
            "name": function["name"],
            "status": "rejected",
            "rejection_reasons": error.reasons,
            "instruction_diagnostics": error.instruction_diagnostics,
        }
    filename = f"spore_{address:08x}_arm64.cpp"
    target = output_dir / filename
    if not target.exists():
        target.write_text(source + "\n", encoding="utf-8")
    return {
        "address": f"0x{address:08x}",
        "name": function["name"],
        "status": "accepted",
        "generated_source": filename,
        "instruction_diagnostics": diagnostics,
    }


def main():
    parser = argparse.ArgumentParser(description="Incrementally process all Spore Ghidra batches.")
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--batch-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    source_hash = file_hash(args.exe)
    if source_hash != lifter.EXPECTED_SHA256:
        raise ValueError("selected executable does not match the approved build")
    lifter_hash = file_hash(Path(__file__))
    inventory = lifter.load_inventory(args.csv)
    batches = sorted(args.batch_dir.glob("spore_batch_all_*.json"))
    if not batches:
        raise ValueError("no spore_batch_all_*.json files found")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    state = load_state(args.state, source_hash, lifter_hash)
    process_function.pe = lifter.parse_pe(args.exe)
    processed = 0
    reused = 0
    for batch_path in batches:
        for entry in validate_batch(load_json(batch_path), source_hash):
            function = entry["function"]
            key = function_key(function, source_hash, lifter_hash)
            cached = state["functions"].get(key)
            if cached and (
                cached.get("status") != "accepted"
                or (args.output_dir / cached.get("generated_source", "")).is_file()
            ):
                reused += 1
                continue
            result = process_function(inventory, entry, args.output_dir, process_function.pe)
            result["key"] = key
            result["batch"] = batch_path.name
            state["functions"][key] = result
            processed += 1
        args.state.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")

    results = list(state["functions"].values())
    report = {
        "schema": "spore-static-lift-incremental-report-v1",
        "source_sha256": source_hash,
        "lifter_sha256": lifter_hash,
        "batch_count": len(batches),
        "function_result_count": len(results),
        "processed_this_run": processed,
        "reused_this_run": reused,
        "accepted_function_count": sum(item["status"] == "accepted" for item in results),
        "rejected_function_count": sum(item["status"] == "rejected" for item in results),
        "generated_source_count": len(list(args.output_dir.glob("*.cpp"))),
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
