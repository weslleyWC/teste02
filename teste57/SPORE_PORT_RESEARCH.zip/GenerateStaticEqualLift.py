#!/usr/bin/env python3

import argparse
import csv
import hashlib
import json
import re
import struct
import sys
from pathlib import Path


EXPECTED_SHA256 = "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b"
EXPECTED_VA = 0x00404460
EXPECTED_SIZE = 30
EXPECTED_LANGUAGE = "x86:LE:32:default"
EXPECTED_INSTRUCTIONS = 13
REGISTERS = {"EAX", "ECX", "EDX", "EBX", "ESP", "EBP", "ESI", "EDI"}
MEMORY_OPERAND = re.compile(
    r"^(?:dword ptr )?"
    r"\[\s*(EAX|ECX|EDX|EBX|ESP|EBP|ESI|EDI)"
    r"(?:\s*\+\s*(-?(?:0x[0-9a-f]+|[0-9]+)))?\s*\]$",
    re.IGNORECASE,
)


def parse_int(value):
    return int(value, 0)


def load_pe_section_offset(exe_path, va, length):
    image = exe_path.read_bytes()
    if image[:2] != b"MZ":
        raise ValueError("Selected input is not a PE executable (missing MZ signature).")
    pe_offset = struct.unpack_from("<I", image, 0x3C)[0]
    if image[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise ValueError("Selected input is not a PE executable (missing PE signature).")
    machine, section_count, _, _, _, optional_size, _ = struct.unpack_from(
        "<HHIIIHH", image, pe_offset + 4
    )
    if machine != 0x14C:
        raise ValueError(f"Expected PE32 x86 machine 0x14c, got 0x{machine:x}.")
    optional = pe_offset + 24
    if struct.unpack_from("<H", image, optional)[0] != 0x10B:
        raise ValueError("Expected PE32 optional header.")
    image_base = struct.unpack_from("<I", image, optional + 28)[0]
    rva = va - image_base
    section_offset = optional + optional_size
    for index in range(section_count):
        off = section_offset + index * 40
        name = image[off:off + 8].split(b"\0", 1)[0].decode("ascii", "replace")
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", image, off + 8
        )
        span = max(virtual_size, raw_size)
        if virtual_address <= rva and rva + length <= virtual_address + span:
            file_offset = raw_offset + (rva - virtual_address)
            raw = image[file_offset:file_offset + length]
            if len(raw) != length:
                raise ValueError("PE section does not contain the full function byte range.")
            return name, file_offset, raw
    raise ValueError(f"VA 0x{va:08x} is not backed by a PE section.")


def verify_inventory(csv_path, va):
    with csv_path.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            if int(row["address"], 16) == va:
                if int(row["size"], 0) != EXPECTED_SIZE:
                    raise ValueError("Inventory size does not match the 30-byte function.")
                return row
    raise ValueError(f"Function 0x{va:08x} is absent from the Ghidra CSV.")


def parse_operand(text):
    token = text.strip().upper()
    if token in REGISTERS or token in {"AL", "CL", "DL"}:
        return ("reg", token)
    if token.startswith("0X") or token.isdecimal():
        return ("imm", int(token, 0))
    match = MEMORY_OPERAND.fullmatch(text.strip())
    if match:
        base = match.group(1).upper()
        displacement = int(match.group(2), 0) if match.group(2) else 0
        return ("mem", base, displacement)
    raise ValueError(f"unsupported operand syntax: {text!r}")


def c_u32(value):
    return f"0x{value & 0xffffffff:08x}u"


def memory_address(base, displacement):
    return f"static_cast<std::uint32_t>({base.lower()} + {c_u32(displacement)})"


def load_operand(operand):
    if operand[0] == "reg":
        register = operand[1]
        if register == "AL":
            return ["operand_value = eax & 0xffu;"]
        if register == "CL":
            return ["operand_value = ecx & 0xffu;"]
        if register == "DL":
            return ["operand_value = edx & 0xffu;"]
        return [f"operand_value = {register.lower()};"]
    if operand[0] == "imm":
        return [f"operand_value = {c_u32(operand[1])};"]
    _, base, displacement = operand
    return [
        f"if (!memory.load32({memory_address(base, displacement)}, operand_value)) "
        "return EqualLiftStatus::invalid_memory;"
    ]


def store_operand(operand, value):
    if operand[0] == "reg":
        register = operand[1]
        if register == "AL":
            return [f"eax = (eax & 0xffffff00u) | ({value} & 0xffu);"]
        if register == "CL":
            return [f"ecx = (ecx & 0xffffff00u) | ({value} & 0xffu);"]
        if register == "DL":
            return [f"edx = (edx & 0xffffff00u) | ({value} & 0xffu);"]
        return [f"{register.lower()} = {value};"]
    if operand[0] == "mem":
        _, base, displacement = operand
        return [
            f"if (!memory.store32({memory_address(base, displacement)}, {value})) "
            "return EqualLiftStatus::invalid_memory;"
        ]
    raise ValueError("immediate cannot be an instruction destination")


def instruction_body(instruction):
    mnemonic = instruction["mnemonic"].upper()
    operands = [parse_operand(value) for value in instruction["operands"]]
    lines = []

    def require(count):
        if len(operands) != count:
            raise ValueError(f"{mnemonic} expects {count} operands, got {len(operands)}")

    def load(index):
        lines.extend(load_operand(operands[index]))
        return "operand_value"

    if mnemonic in {"PUSH", "POP"}:
        require(1)
        if mnemonic == "PUSH":
            value = load(0)
            lines += [
                "esp = static_cast<std::uint32_t>(esp - 4u);",
                f"if (!memory.store32(esp, {value})) return EqualLiftStatus::invalid_memory;",
            ]
        else:
            lines.append(
                "if (!memory.load32(esp, operand_value)) "
                "return EqualLiftStatus::invalid_memory;"
            )
            lines.extend(store_operand(operands[0], "operand_value"))
            lines.append("esp = static_cast<std::uint32_t>(esp + 4u);")
    elif mnemonic == "MOV":
        require(2)
        value = load(1)
        lines.extend(store_operand(operands[0], value))
    elif mnemonic == "XOR":
        require(2)
        left = load(0)
        lines.append("left_value = operand_value;")
        right = load(1)
        lines.append("right_value = operand_value;")
        lines.append("result_value = left_value ^ right_value;")
        lines.append("zero_flag = result_value == 0;")
        lines.extend(store_operand(operands[0], "result_value"))
    elif mnemonic == "CMP":
        require(2)
        left = load(0)
        lines.append("left_value = operand_value;")
        right = load(1)
        lines.extend([
            "right_value = operand_value;",
            "zero_flag = left_value == right_value;",
        ])
    elif mnemonic == "SETZ":
        require(1)
        if operands[0] != ("reg", "AL"):
            raise ValueError("SETZ destination must be AL")
        lines.extend(store_operand(operands[0], "zero_flag ? 1u : 0u"))
    elif mnemonic == "RET":
        if len(operands) not in {0, 1}:
            raise ValueError("RET expects zero or one immediate operand")
        cleanup = operands[0][1] if operands else 0
        if operands and operands[0][0] != "imm":
            raise ValueError("RET cleanup size must be an immediate")
        if cleanup > 0xffff:
            raise ValueError("RET cleanup size exceeds the x86 immediate width")
        lines.extend([
            "if (!memory.load32(esp, return_address) || "
            "return_address != CopyLiftMemory::kReturnSentinel)",
            "    return EqualLiftStatus::invalid_control_flow;",
            f"esp = static_cast<std::uint32_t>(esp + 4u + {cleanup}u);",
            "if (esp != expected_return_esp) return EqualLiftStatus::invalid_control_flow;",
            "*result = eax & 0xffu;",
            "return EqualLiftStatus::ok;",
        ])
    else:
        raise ValueError(f"unsupported instruction: {mnemonic}")
    return lines


class UnsupportedInstructions(Exception):
    def __init__(self, rejected, accepted):
        super().__init__("One or more instructions were rejected by the static lifter.")
        self.rejected = rejected
        self.accepted = accepted


def generate_source(export, raw, csv_row):
    function = export["function"]
    instructions = function["instructions"]
    accepted = []
    rejected = []
    bodies = []
    addresses = set()
    next_address = EXPECTED_VA
    byte_stream = bytearray()

    if function["entry"] != f"0x{EXPECTED_VA:08x}":
        raise ValueError("Ghidra function entry differs from requested VA.")
    if function["body_min"] != f"0x{EXPECTED_VA:08x}" or \
            parse_int(function["body_max"]) != EXPECTED_VA + EXPECTED_SIZE - 1:
        raise ValueError("Ghidra body bounds do not match the exported target.")
    if int(function["body_address_count"]) != EXPECTED_SIZE:
        raise ValueError("Ghidra body byte count is not 30.")
    if len(instructions) != EXPECTED_INSTRUCTIONS or function["instructions_truncated"]:
        raise ValueError("Expected 13 complete instructions.")
    if function["basic_blocks_truncated"] or len(function["basic_blocks"]) != 1:
        raise ValueError("Expected one complete basic block.")
    if function["references_truncated"] or function["pseudocode_truncated"]:
        raise ValueError("Ghidra references or pseudocode are truncated.")
    if function["decompiler_status"] != "completed":
        raise ValueError("Ghidra pseudocode is absent.")
    if function["calling_convention"] != "unknown":
        raise ValueError("Unexpected Ghidra calling-convention metadata.")
    if csv_row["name"] != "FUN_00404460":
        raise ValueError(f"Unexpected inventory name: {csv_row['name']}")

    for instruction in instructions:
        address = parse_int(instruction["address"])
        encoded = bytes.fromhex(instruction["bytes"])
        if address != next_address or len(encoded) != instruction["length"]:
            raise ValueError(f"Non-contiguous or malformed instruction at {instruction['address']}.")
        addresses.add(address)
        try:
            body = instruction_body(instruction)
        except ValueError as error:
            rejected.append({
                "address": instruction["address"],
                "mnemonic": instruction["mnemonic"],
                "reason": str(error),
            })
            body = []
        else:
            accepted.append({
                "address": instruction["address"],
                "bytes": instruction["bytes"],
                "mnemonic": instruction["mnemonic"].upper(),
            })
        bodies.append((instruction, body))
        next_address += instruction["length"]
        byte_stream.extend(encoded)

    if rejected:
        raise UnsupportedInstructions(rejected, accepted)
    if bytes(byte_stream) != raw:
        raise ValueError("Ghidra instruction encodings differ from selected PE bytes.")
    if next_address - EXPECTED_VA != EXPECTED_SIZE:
        raise ValueError("Instructions do not cover the complete 30-byte function.")
    if "in_ECX" not in function["pseudocode"]:
        raise ValueError("Ghidra pseudocode does not identify the ECX receiver.")
    if instructions[-1]["mnemonic"].upper() != "RET" or instructions[-1]["operands"] != ["0x4"]:
        raise ValueError("Expected callee-cleanup RET 4 at function exit.")

    generated = [
        "// Generated from the verified Ghidra instruction export; do not hand-edit.",
        "// Source: SporeApp.exe!0x00404460; static lowering, no x86 interpreter.",
        '#include "SporeCopyLiftRuntime.hpp"',
        "",
        "enum class EqualLiftStatus { ok, invalid_memory, invalid_control_flow };",
        "",
        "EqualLiftStatus spore_lift_00404460(",
        "    CopyLiftMemory& memory,",
        "    std::uint32_t receiver,",
        "    std::uint32_t argument,",
        "    std::uint32_t* result) {",
        "    if (result == nullptr) return EqualLiftStatus::invalid_memory;",
        "    std::uint32_t eax = 0, ecx = receiver, edx = 0, ebx = 0;",
        "    std::uint32_t esp = CopyLiftMemory::kEntryEsp, ebp = 0, esi = 0, edi = 0;",
        "    std::uint32_t operand_value = 0, left_value = 0, right_value = 0;",
        "    std::uint32_t result_value = 0, return_address = 0;",
        "    bool zero_flag = false;",
        "    const std::uint32_t expected_return_esp = esp + 8u;",
        "    if (!memory.initialize_thiscall_frame(argument))",
        "        return EqualLiftStatus::invalid_memory;",
        "",
    ]
    for instruction, body in bodies:
        address = parse_int(instruction["address"])
        generated.append(
            f"L_{address:08x}: // {instruction['bytes']} "
            f"{instruction['mnemonic']} {' '.join(instruction['operands'])}".rstrip()
        )
        generated.extend("    " + line for line in body)
    generated.extend([
        "    return EqualLiftStatus::invalid_control_flow;",
        "}",
        "",
    ])
    return "\n".join(generated), accepted, rejected


def main():
    parser = argparse.ArgumentParser(
        description="Statically lower one verified Spore x86-32 equality function."
    )
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--coverage", type=Path, required=True)
    args = parser.parse_args()

    coverage = {
        "target_va": f"0x{EXPECTED_VA:08X}",
        "source_sha256_expected": EXPECTED_SHA256,
        "accepted_instruction_count": 0,
        "rejected_instruction_count": 0,
        "accepted_instructions": [],
        "rejected_instructions": [],
        "status": "blocked",
    }
    try:
        source_hash = hashlib.sha256(args.exe.read_bytes()).hexdigest()
        coverage["source_sha256_actual"] = source_hash
        if source_hash != EXPECTED_SHA256:
            raise ValueError("Selected executable SHA-256 does not match expected build.")
        export = json.loads(args.export.read_text(encoding="utf-8"))
        if export.get("selected_source_sha256") != EXPECTED_SHA256:
            raise ValueError("Ghidra export hash differs from selected executable.")
        if not export.get("selected_source_is_phase4_build") or \
                not export.get("user_confirmed_source_for_open_program"):
            raise ValueError("Ghidra source confirmation is missing.")
        if export.get("language_id") != EXPECTED_LANGUAGE:
            raise ValueError(f"Unexpected Ghidra language: {export.get('language_id')!r}")
        if export.get("target_va_requested") != f"0x{EXPECTED_VA:08x}":
            raise ValueError("Ghidra export VA differs from requested function.")
        if not export.get("function_found") or \
                not export.get("function_starts_at_requested_address"):
            raise ValueError("Ghidra did not identify a function at the requested VA.")

        csv_row = verify_inventory(args.csv, EXPECTED_VA)
        section_name, file_offset, raw = load_pe_section_offset(
            args.exe, EXPECTED_VA, EXPECTED_SIZE
        )
        coverage.update({
            "function_name": export["function"]["name"],
            "inventory_size": int(csv_row["size"], 0),
            "section": section_name,
            "file_offset": f"0x{file_offset:x}",
            "body_bytes_sha256": hashlib.sha256(raw).hexdigest(),
            "instructions_total": len(export["function"]["instructions"]),
        })
        if section_name != ".text":
            raise ValueError(f"Function is in unexpected section {section_name!r}.")

        generated, accepted, rejected = generate_source(export, raw, csv_row)
        coverage.update({
            "accepted_instructions": accepted,
            "rejected_instructions": rejected,
            "accepted_instruction_count": len(accepted),
            "rejected_instruction_count": len(rejected),
            "covered_instruction_bytes": sum(
                len(bytes.fromhex(item["bytes"])) for item in accepted
            ),
            "instruction_byte_coverage_percent": 100.0,
            "generated_source_sha256": hashlib.sha256(generated.encode("utf-8")).hexdigest(),
            "status": "generated",
        })
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(generated, encoding="utf-8", newline="\n")
        print(f"Generated {len(accepted)} instructions to {args.output}")
        print(f"Verified source SHA-256: {source_hash}")
    except UnsupportedInstructions as error:
        coverage["accepted_instructions"] = error.accepted
        coverage["rejected_instructions"] = error.rejected
        coverage["accepted_instruction_count"] = len(error.accepted)
        coverage["rejected_instruction_count"] = len(error.rejected)
        coverage["status"] = "rejected"
        print(str(error), file=sys.stderr)
    except Exception as error:
        coverage["error"] = f"{type(error).__name__}: {error}"
        print(coverage["error"], file=sys.stderr)
    finally:
        args.coverage.parent.mkdir(parents=True, exist_ok=True)
        args.coverage.write_text(json.dumps(coverage, indent=2) + "\n", encoding="utf-8")
        print(f"Coverage report: {args.coverage}")

    return 0 if coverage["status"] == "generated" else 1


if __name__ == "__main__":
    raise SystemExit(main())
