#pragma once

#include <cstddef>
#include <cstdint>
#include <cstring>

enum class LiftStatus {
    ok,
    invalid_argument,
    invalid_memory,
    divide_error,
    invalid_return,
    invalid_control_flow,
};

struct X86Flags {
    bool cf = false;
    bool zf = false;
    bool sf = false;
    bool of = false;
};

inline void set_logic_flags(std::uint32_t result, X86Flags& flags) {
    flags.zf = result == 0;
    flags.sf = (result & 0x80000000u) != 0;
}

inline void set_add_flags(
    std::uint32_t left,
    std::uint32_t right,
    std::uint32_t result,
    std::uint64_t wide_result,
    X86Flags& flags) {
    flags.cf = (wide_result >> 32u) != 0;
    flags.zf = result == 0;
    flags.sf = (result & 0x80000000u) != 0;
    flags.of = ((~(left ^ right) & (left ^ result)) & 0x80000000u) != 0;
}

inline void set_sub_flags(
    std::uint32_t left,
    std::uint32_t right,
    std::uint32_t result,
    bool borrow,
    X86Flags& flags) {
    flags.cf = borrow;
    flags.zf = result == 0;
    flags.sf = (result & 0x80000000u) != 0;
    flags.of = (((left ^ right) & (left ^ result)) & 0x80000000u) != 0;
}

inline void set_sbb_flags(
    std::uint32_t left,
    std::uint32_t right,
    bool borrow_in,
    std::uint32_t result,
    X86Flags& flags) {
    const std::uint64_t subtrahend =
        static_cast<std::uint64_t>(right) + static_cast<std::uint64_t>(borrow_in);
    const std::int64_t signed_result =
        static_cast<std::int64_t>(static_cast<std::int32_t>(left)) -
        static_cast<std::int64_t>(static_cast<std::int32_t>(right)) -
        static_cast<std::int64_t>(borrow_in);
    flags.cf = static_cast<std::uint64_t>(left) < subtrahend;
    flags.zf = result == 0;
    flags.sf = (result & 0x80000000u) != 0;
    flags.of = signed_result < INT32_MIN || signed_result > INT32_MAX;
}

inline std::uint32_t arithmetic_shift_right(std::uint32_t value, std::uint32_t count) {
    count &= 0x1fu;
    if (count == 0) {
        return value;
    }
    const std::uint32_t shifted = value >> count;
    if ((value & 0x80000000u) == 0) {
        return shifted;
    }
    return shifted | (~std::uint32_t{0} << (32u - count));
}

struct FirstStaticLiftMemory {
    static constexpr std::uint32_t kGuestRecordsBase = 0x10000000u;
    static constexpr std::uint32_t kGuestKeyAddress = 0x30000000u;
    static constexpr std::uint32_t kStackBase = 0x70000f00u;
    static constexpr std::uint32_t kEntryEsp = 0x70001000u;
    static constexpr std::uint32_t kReturnSentinel = 0xf00dcafeu;
    static constexpr std::size_t kStackBytes = 0x200;
    static constexpr std::size_t kMaxRecordCount =
        (kGuestKeyAddress - kGuestRecordsBase) / 12u;

    FirstStaticLiftMemory(
        const std::uint32_t* records,
        std::size_t record_count,
        const std::uint32_t* key)
        : records_(reinterpret_cast<const std::uint8_t*>(records)),
          record_bytes_(record_count * 12u),
          key_(reinterpret_cast<const std::uint8_t*>(key)),
          end_address_(kGuestRecordsBase + static_cast<std::uint32_t>(record_bytes_)) {}

    bool initialize_call_frame() {
        return store32(kEntryEsp, kReturnSentinel) &&
            store32(kEntryEsp + 4u, kGuestRecordsBase) &&
            store32(kEntryEsp + 8u, end_address_) &&
            store32(kEntryEsp + 12u, kGuestKeyAddress);
    }

    bool load32(std::uint32_t address, std::uint32_t& value) const {
        if (address >= kGuestRecordsBase) {
            const std::uint64_t offset =
                static_cast<std::uint64_t>(address - kGuestRecordsBase);
            if (offset + 4u <= record_bytes_ && records_ != nullptr) {
                value = decode_le32(records_ + offset);
                return true;
            }
        }
        if (address == kGuestKeyAddress && key_ != nullptr) {
            value = decode_le32(key_);
            return true;
        }
        if (address >= kStackBase) {
            const std::uint64_t offset =
                static_cast<std::uint64_t>(address - kStackBase);
            if (offset + 4u <= kStackBytes) {
                value = decode_le32(stack_ + offset);
                return true;
            }
        }
        return false;
    }

    bool store32(std::uint32_t address, std::uint32_t value) {
        if (address < kStackBase) {
            return false;
        }
        const std::uint64_t offset = static_cast<std::uint64_t>(address - kStackBase);
        if (offset + 4u > kStackBytes) {
            return false;
        }
        encode_le32(stack_ + offset, value);
        return true;
    }

    bool to_record_index(
        std::uint32_t address,
        std::size_t record_count,
        std::size_t& result_index) const {
        if (address < kGuestRecordsBase || address > end_address_) {
            return false;
        }
        const std::uint32_t byte_offset = address - kGuestRecordsBase;
        if (byte_offset % 12u != 0) {
            return false;
        }
        const std::size_t index = byte_offset / 12u;
        if (index > record_count) {
            return false;
        }
        result_index = index;
        return true;
    }

private:
    static std::uint32_t decode_le32(const std::uint8_t* bytes) {
        return static_cast<std::uint32_t>(bytes[0]) |
            (static_cast<std::uint32_t>(bytes[1]) << 8u) |
            (static_cast<std::uint32_t>(bytes[2]) << 16u) |
            (static_cast<std::uint32_t>(bytes[3]) << 24u);
    }

    static void encode_le32(std::uint8_t* bytes, std::uint32_t value) {
        bytes[0] = static_cast<std::uint8_t>(value);
        bytes[1] = static_cast<std::uint8_t>(value >> 8u);
        bytes[2] = static_cast<std::uint8_t>(value >> 16u);
        bytes[3] = static_cast<std::uint8_t>(value >> 24u);
    }

    const std::uint8_t* records_;
    std::size_t record_bytes_;
    const std::uint8_t* key_;
    std::uint32_t end_address_;
    std::uint8_t stack_[kStackBytes]{};
};
