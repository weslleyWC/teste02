#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>

#if !defined(_M_IX86)
#error This reference harness must run as a native 32-bit x86 process.
#endif

namespace {

constexpr std::array<std::uint8_t, 13> kExpectedBytes{{
    0x8b, 0x49, 0x5c, 0x85, 0xc9, 0x74, 0x05, 0xe9,
    0x24, 0x16, 0x62, 0x00, 0xc3,
}};

bool load_function(const char* path, void** code) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return false;
    IMAGE_DOS_HEADER dos{};
    input.read(reinterpret_cast<char*>(&dos), sizeof(dos));
    if (!input || dos.e_magic != IMAGE_DOS_SIGNATURE) return false;
    input.seekg(dos.e_lfanew, std::ios::beg);
    DWORD signature = 0;
    IMAGE_FILE_HEADER file{};
    IMAGE_OPTIONAL_HEADER32 optional{};
    input.read(reinterpret_cast<char*>(&signature), sizeof(signature));
    input.read(reinterpret_cast<char*>(&file), sizeof(file));
    input.read(reinterpret_cast<char*>(&optional), sizeof(optional));
    if (!input || signature != IMAGE_NT_SIGNATURE ||
        file.Machine != IMAGE_FILE_MACHINE_I386 ||
        optional.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) {
        return false;
    }
    const std::uint32_t rva = 0x0060ceb0u - optional.ImageBase;
    std::uint32_t raw = 0;
    bool found = false;
    for (unsigned index = 0; index < file.NumberOfSections; ++index) {
        IMAGE_SECTION_HEADER section{};
        input.read(reinterpret_cast<char*>(&section), sizeof(section));
        const std::uint32_t span = (std::max)(section.Misc.VirtualSize, section.SizeOfRawData);
        if (section.VirtualAddress <= rva &&
            rva - section.VirtualAddress + kExpectedBytes.size() <= span) {
            raw = section.PointerToRawData + rva - section.VirtualAddress;
            found = true;
            break;
        }
    }
    if (!found) return false;
    std::array<std::uint8_t, kExpectedBytes.size()> bytes{};
    input.seekg(raw, std::ios::beg);
    input.read(reinterpret_cast<char*>(bytes.data()), bytes.size());
    if (std::memcmp(bytes.data(), kExpectedBytes.data(), bytes.size()) != 0) return false;
    void* memory = VirtualAlloc(
        nullptr, bytes.size() + 1u, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == nullptr) return false;
    std::memcpy(memory, bytes.data(), bytes.size());
    // Relocate the verified tail jump to a local RET stub; the original target
    // is known to contain only RET and cannot be reached after copying.
    auto* relocated = static_cast<std::uint8_t*>(memory);
    relocated[13] = 0xc3;
    const std::int32_t local_return_displacement = 1;
    std::memcpy(relocated + 8, &local_return_displacement, sizeof(local_return_displacement));
    DWORD old_protection = 0;
    if (!VirtualProtect(memory, bytes.size() + 1u, PAGE_EXECUTE_READ, &old_protection)) {
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    *code = memory;
    return true;
}

} // namespace

using TailFunction = void(__thiscall*)(std::uint8_t*);

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    void* code = nullptr;
    if (!load_function(argv[1], &code)) {
        std::fprintf(stderr, "could not verify or load 0x0060ceb0 bytes\n");
        return 2;
    }
    const auto function = reinterpret_cast<TailFunction>(code);
    alignas(4) std::array<std::uint8_t, 0x60> object{};
    auto run = [&](const char* label, std::uint32_t value) {
        std::memcpy(object.data() + 0x5c, &value, sizeof(value));
        function(object.data());
        std::uint32_t observed = 0;
        std::memcpy(&observed, object.data() + 0x5c, sizeof(observed));
        const bool passed = observed == value;
        std::printf(
            "case=%s ecx_member=%08x expected=%08x PASS=%u\n",
            label, observed, value, passed ? 1u : 0u);
        return passed;
    };
    const bool null_case = run("tail_null", 0u);
    const bool value_case = run("tail_value", 0x20000000u);
    VirtualFree(code, 0, MEM_RELEASE);
    std::printf(
        "x86 tail-call summary cases=2 failures=%u\n",
        static_cast<unsigned>(!null_case + !value_case));
    return null_case && value_case ? 0 : 1;
}
