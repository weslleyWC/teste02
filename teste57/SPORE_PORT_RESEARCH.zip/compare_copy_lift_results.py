#!/usr/bin/env python3

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LINE = re.compile(
    r"^(x86|arm64) case=(\S+) "
    r"(?:status=\d+ )?end_offset=(0x[0-9a-fA-F]+) "
    r"copy_hash=([0-9a-fA-F]+) "
    r"(?:copied=\d+ guard=\d+ )?PASS=?(\d+)$"
)


def parse_log(path, architecture):
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16")
    else:
        text = raw.decode("utf-8-sig")
    cases = {}
    for line in text.splitlines():
        match = LINE.match(line.strip())
        if not match:
            continue
        arch, name, end_offset, copy_hash, passed = match.groups()
        if arch != architecture:
            continue
        if name in cases:
            raise ValueError(f"duplicate {architecture} result for {name}")
        if passed != "1":
            raise ValueError(f"{architecture} test failed for {name}")
        cases[name] = (end_offset.lower(), copy_hash.lower())
    if not cases:
        raise ValueError(f"no {architecture} test results found in {path}")
    return cases


def main():
    x86 = parse_log(ROOT / "native_copy_x86_reference.log", "x86")
    arm64 = parse_log(ROOT / "arm64_copy_device_validation.log", "arm64")
    differences = {
        name: {"x86": x86.get(name), "arm64": arm64.get(name)}
        for name in sorted(set(x86) | set(arm64))
        if x86.get(name) != arm64.get(name)
    }
    result = {
        "x86_cases": len(x86),
        "arm64_cases": len(arm64),
        "shared_cases": len(set(x86) & set(arm64)),
        "outputs_match": not differences and set(x86) == set(arm64),
        "differences": differences,
        "scope": "tested source/destination regions and float32 bit patterns only",
    }
    (ROOT / "copy_lift_cross_arch_comparison.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    return 0 if result["outputs_match"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
