import tempfile
import unittest
from pathlib import Path

import compare_batch_lift_dec_semantic_results as comparison


def make_log(architecture, failed_case=None):
    lines = []
    for index, name in enumerate(sorted(comparison.EXPECTED_CASES)):
        result = index
        flags = 0x202
        passed = 0 if name == failed_case else 1
        lines.append(
            f"{architecture} case={name} initial_eax={index:08x} "
            f"carry_in={index % 2} result={result:08x} expected={result:08x} "
            f"flags={flags:08x} expected_flags={flags:08x} "
            f"flags_match=1 registers_match=1 PASS={passed}"
        )
    failures = 1 if failed_case else 0
    lines.append(
        f"{architecture} semantic summary cases={len(lines)} failures={failures}"
    )
    return "\n".join(lines) + "\n"


class DecSemanticComparisonTests(unittest.TestCase):
    def test_requires_exact_nonempty_case_matrix(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "empty.log"
            path.write_text(
                "x86 semantic summary cases=0 failures=0\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "42-vector matrix"):
                comparison.parse_log(path, "x86")

    def test_accepts_all_42_cases_and_rejects_failed_case(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "x86.log"
            path.write_text(make_log("x86"), encoding="utf-8")
            cases = comparison.parse_log(path, "x86")
            self.assertEqual(len(cases), 42)

            path.write_text(
                make_log("x86", failed_case=sorted(comparison.EXPECTED_CASES)[0]),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "semantic test failed"):
                comparison.parse_log(path, "x86")


if __name__ == "__main__":
    unittest.main()
