#!/usr/bin/env python3

import argparse
import json
import re
import sys
from pathlib import Path


CASE_PATTERN = re.compile(r"^case=(\S+) result=([0-9a-fA-F]{8}).* PASS=([01])$")
EXPECTED_CASES = {
    "00922a80_null",
    "00922a80_value",
    "00a02bd0_four",
    "00a02bd0_max",
    "00a02bd0_nonfour",
    "00ef72c0_skip",
    "00ef72c0_write",
}


def parse_log(path, architecture):
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16")
    elif raw.count(b"\x00") > max(2, len(raw) // 8):
        text = raw.decode("utf-16-le")
    else:
        text = raw.decode("utf-8-sig", errors="replace")
    text = text.replace("\r", "")
    summary = re.search(
        rf"^{architecture} summary cases=(\d+) failures=(\d+)$",
        text,
        re.MULTILINE,
    )
    if summary is None:
        raise ValueError(f"{architecture} completion summary missing from {path}")
    if len(re.findall(
        rf"^{architecture} summary cases=\d+ failures=\d+$",
        text,
        re.MULTILINE,
    )) != 1:
        raise ValueError(f"expected exactly one {architecture} completion summary in {path}")
    cases = {}
    for line in text.splitlines():
        match = CASE_PATTERN.match(line.strip())
        if match is None:
            continue
        name, result, passed = match.groups()
        if name in cases:
            raise ValueError(f"duplicate test case {name} in {path}")
        if passed != "1":
            raise ValueError(f"{architecture} case {name} failed its expected-value check")
        cases[name] = int(result, 16)
    if len(cases) != int(summary.group(1)):
        raise ValueError(
            f"{architecture} summary says {summary.group(1)} cases, "
            f"but only {len(cases)} passing case records were found"
        )
    if int(summary.group(2)) != 0:
        raise ValueError(f"{architecture} reports {summary.group(2)} failures")
    if not cases:
        raise ValueError(f"{architecture} log contains no test cases")
    if set(cases) != EXPECTED_CASES:
        raise ValueError(
            f"{architecture} cases differ from the expected set; "
            f"missing={sorted(EXPECTED_CASES - set(cases))}, "
            f"unexpected={sorted(set(cases) - EXPECTED_CASES)}"
        )
    return cases


def main():
    parser = argparse.ArgumentParser(
        description="Compare the original x86 function results with ARM64 device results."
    )
    parser.add_argument("--x86", type=Path, required=True)
    parser.add_argument("--arm64", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-sha256", required=True)
    parser.add_argument("--device-model", required=True)
    parser.add_argument("--device-serial", required=True)
    args = parser.parse_args()
    if args.output.exists():
        print(f"output already exists; preserve it before rerunning: {args.output}", file=sys.stderr)
        return 1
    if not re.fullmatch(r"[0-9a-fA-F]{64}", args.source_sha256):
        print("source SHA-256 must contain exactly 64 hexadecimal characters", file=sys.stderr)
        return 1
    try:
        x86 = parse_log(args.x86, "x86")
        arm64 = parse_log(args.arm64, "arm64")
        if set(x86) != set(arm64):
            raise ValueError(
                f"test cases differ; x86-only={sorted(set(x86) - set(arm64))}, "
                f"ARM64-only={sorted(set(arm64) - set(x86))}"
            )
        cases = []
        tested_functions = {}
        for case in sorted(x86):
            address = re.match(r"^([0-9a-fA-F]{8})_", case)
            if address is None:
                raise ValueError(f"test case lacks its function entry address: {case}")
            entry = "0x" + address.group(1).lower()
            tested_functions.setdefault(entry, []).append(case)
            cases.append({
                "case": case,
                "x86_result": f"0x{x86[case]:08x}",
                "arm64_result": f"0x{arm64[case]:08x}",
                "observed_value": (
                    "memory byte [ECX+0x3f]"
                    if entry == "0x00ef72c0"
                    else "EAX"
                ),
            })
        mismatches = [
            {"case": case, "x86_result": f"0x{x86[case]:08x}",
             "arm64_result": f"0x{arm64[case]:08x}"}
            for case in sorted(x86)
            if x86[case] != arm64[case]
        ]
        result = {
            "schema": "spore-static-lift-execution-comparison-v1",
            "source_binary_sha256": args.source_sha256.lower(),
            "x86_reference_log": str(args.x86),
            "arm64_device_log": str(args.arm64),
            "x86_hardware_execution": True,
            "arm64_physical_device_execution": True,
            "arm64_device": {
                "model": args.device_model,
                "serial": args.device_serial,
                "abi": "arm64-v8a",
            },
            "tested_functions": [
                {"entry": entry, "cases": function_cases}
                for entry, function_cases in sorted(tested_functions.items())
            ],
            "case_count": len(x86),
            "matching_case_count": len(x86) - len(mismatches),
            "cases": cases,
            "mismatches": mismatches,
            "result": "pass" if not mismatches else "fail",
            "scope": (
                "Observed return values for the listed isolated test vectors only; "
                "not whole-game equivalence or ABI/dependency validation."
            ),
        }
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"execution comparison failed: {error}", file=sys.stderr)
        return 1
    print(
        f"Cross-architecture results: {result['matching_case_count']}/"
        f"{result['case_count']} cases match; {result['result']}."
    )
    print(f"Comparison report: {args.output}")
    return 0 if not mismatches else 1


if __name__ == "__main__":
    raise SystemExit(main())
