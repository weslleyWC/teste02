#!/usr/bin/env python3

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
X86_LOG = ROOT / "native_x86_reference.log"
ARM64_LOG = ROOT / "arm64_device_validation.log"
OUTPUT = ROOT / "cross_arch_comparison.json"
CASE_LABELS = {
    "populated",
    "empty",
    "singleton-before",
    "singleton-equal",
    "singleton-after",
}

X86_PATTERN = re.compile(
    r"^x86\s+(?P<label>\S+)\s+(?:key=0x[0-9a-fA-F]+\s+)?"
    r"actual=(?P<actual>\d+)\s+expected=(?P<expected>\d+)"
    r".*\s(?P<result>PASS|FAIL)$"
)
ARM64_PATTERN = re.compile(
    r"^(?P<label>\S+)\s+status=(?P<status>\d+)\s+"
    r"actual=(?P<actual>\d+)\s+expected=(?P<expected>\d+)"
    r"(?:\s+oracle=(?P<oracle>\d+))?\s+(?P<result>PASS|FAIL)$"
)


def parse_lines(path, pattern, include_stress=False):
    results = []
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = raw.decode("utf-16")
    else:
        text = raw.decode("utf-8-sig")
    for line in text.splitlines():
        match = pattern.match(line)
        if not match:
            continue
        item = match.groupdict()
        if item["label"] not in CASE_LABELS and not include_stress:
            continue
        item["actual"] = int(item["actual"])
        item["expected"] = int(item["expected"])
        if item.get("status") is not None:
            item["status"] = int(item["status"])
        if item.get("oracle") is not None:
            item["oracle"] = int(item["oracle"])
        results.append(item)
    return results


def main():
    x86_all = parse_lines(X86_LOG, X86_PATTERN, include_stress=True)
    x86_shared = [item for item in x86_all if item["label"] in CASE_LABELS]
    arm64 = parse_lines(ARM64_LOG, ARM64_PATTERN)
    differences = []
    if len(x86_shared) != 16 or len(arm64) != 16:
        differences.append({
            "reason": "expected 16 shared cases",
            "x86_shared_count": len(x86_shared),
            "arm64_count": len(arm64),
        })
    for index, (x86_case, arm_case) in enumerate(zip(x86_shared, arm64)):
        if (
            x86_case["label"] != arm_case["label"]
            or x86_case["actual"] != arm_case["actual"]
            or x86_case["expected"] != arm_case["expected"]
            or x86_case["result"] != "PASS"
            or arm_case["result"] != "PASS"
            or arm_case.get("status") != 0
            or arm_case.get("oracle") != arm_case["expected"]
        ):
            differences.append({
                "index": index,
                "x86": x86_case,
                "arm64": arm_case,
            })

    report = {
        "x86_total_cases": len(x86_all),
        "x86_shared_cases": len(x86_shared),
        "arm64_cases": len(arm64),
        "shared_outputs_match": not differences,
        "differences": differences,
        "scope": "defined valid arrays and keys; invalid pointer behavior excluded",
    }
    OUTPUT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if not differences else 1


if __name__ == "__main__":
    raise SystemExit(main())
