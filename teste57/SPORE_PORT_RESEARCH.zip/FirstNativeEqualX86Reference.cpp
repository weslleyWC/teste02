#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>

#if !defined(_M_IX86)
#error This reference harness must be compiled as a native 32-bit x86 process.
#endif

namespace {

constexpr std::size_t kFunctionOffset = 0x3860;
constexpr std::size_t kFunctionSize = 30;
constexpr char kExpectedBytes[] =
    "558bec51894dfc8b45088b4dfc8b500433c03b51040f94c08be55dc20400";

using OriginalFunction =
    bool (__thiscall*)(const std::uint32_t* receiver, const std::uint32_t* argument);

int hex_digit(char value) {
    if (value >= '0' && value <= '9') return value - '0';
    if (value >= 'a' && value <= 'f') return value - 'a' + 10;
    return -1;
}

bool load_original_function(const char* executable_path, void** code) {
    if (std::strlen(kExpectedBytes) != kFunctionSize * 2u) {
        std::fprintf(stderr, "internal expected-byte string has an invalid size\n");
        return false;
    }
    std::ifstream input(executable_path, std::ios::binary);
    if (!input) {
        std::fprintf(stderr, "cannot open selected SporeApp.exe\n");
        return false;
    }
    input.seekg(static_cast<std::streamoff>(kFunctionOffset), std::ios::beg);
    std::array<std::uint8_t, kFunctionSize> original_bytes{};
    input.read(reinterpret_cast<char*>(original_bytes.data()), original_bytes.size());
    if (input.gcount() != static_cast<std::streamsize>(original_bytes.size())) {
        std::fprintf(stderr, "failed to read the complete function byte range\n");
        return false;
    }
    for (std::size_t i = 0; i < original_bytes.size(); ++i) {
        const int high = hex_digit(kExpectedBytes[i * 2u]);
        const int low = hex_digit(kExpectedBytes[i * 2u + 1u]);
        if (high < 0 || low < 0 ||
            original_bytes[i] != static_cast<std::uint8_t>((high << 4) | low)) {
            std::fprintf(stderr, "function bytes differ from the Ghidra export at +0x%zx\n", i);
            return false;
        }
    }

    void* memory = VirtualAlloc(
        nullptr, original_bytes.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == nullptr) {
        std::fprintf(stderr, "VirtualAlloc failed: %lu\n", GetLastError());
        return false;
    }
    std::memcpy(memory, original_bytes.data(), original_bytes.size());
    DWORD old_protection = 0;
    if (!VirtualProtect(memory, original_bytes.size(), PAGE_EXECUTE_READ, &old_protection) ||
        !FlushInstructionCache(GetCurrentProcess(), memory, original_bytes.size())) {
        std::fprintf(stderr, "failed to make the verified function executable: %lu\n", GetLastError());
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    *code = memory;
    return true;
}

bool run_case(
    OriginalFunction function,
    const char* label,
    std::uint32_t left,
    std::uint32_t right) {
    const std::array<std::uint32_t, 2> receiver{{0x11111111u, left}};
    const std::array<std::uint32_t, 2> argument{{0x22222222u, right}};
    const bool actual = function(receiver.data(), argument.data());
    const bool expected = left == right;
    const bool passed = actual == expected;
    std::printf(
        "x86 case=%s result=%u expected=%u PASS=%u\n",
        label,
        actual ? 1u : 0u,
        expected ? 1u : 0u,
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: FirstNativeEqualX86Reference.exe <selected SporeApp.exe>\n");
        return 2;
    }
    SYSTEM_INFO system_info{};
    GetNativeSystemInfo(&system_info);
    if (system_info.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_AMD64 &&
        system_info.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_INTEL) {
        std::fprintf(stderr, "host processor is not x86/x86-64\n");
        return 2;
    }

    void* code = nullptr;
    if (!load_original_function(argv[1], &code)) return 2;
    const auto function = reinterpret_cast<OriginalFunction>(code);
    constexpr std::array<std::array<std::uint32_t, 2>, 8> values{{
        {{0u, 0u}},
        {{0u, 1u}},
        {{1u, 0u}},
        {{0x7fffffffu, 0x7fffffffu}},
        {{0x80000000u, 0x80000000u}},
        {{0xffffffffu, 0xffffffffu}},
        {{0x00000000u, 0xffffffffu}},
        {{0xdeadbeefu, 0xdeadbeeeu}},
    }};
    std::size_t failures = 0;
    for (std::size_t index = 0; index < values.size(); ++index) {
        char label[32]{};
        std::snprintf(label, sizeof(label), "pair_%02zu", index);
        failures += !run_case(
            function, label, values[index][0], values[index][1]);
    }
    std::printf("x86 summary cases=%zu failures=%zu\n", values.size(), failures);
    VirtualFree(code, 0, MEM_RELEASE);
    return failures == 0 ? 0 : 1;
}
