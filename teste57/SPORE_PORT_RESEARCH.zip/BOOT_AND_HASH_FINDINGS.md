# SporeApp boot and hash findings

Target: `SPOREFILES\SporeBin\SporeApp.exe`, SHA-256
`290703b34fe4573b242c3e271cc90568992abe6fb3fa9333a7341044a759fc74`.

## Boot trace

### Verified by static disassembly

1. The PE entry point is RVA `0xDE11A0` (VA `0x11E11A0`). The entry stub
   initializes the security cookie and transfers control into CRT startup.
2. CRT startup calls the application entry at VA `0xF48A20` with arguments
   consistent with a WinMain signature.
3. VA `0xF48A20` reads the command-line argument, passes it to
   `0x92C1B0`, calls `0xF48850` with the resulting local object, then calls
   `0x5D7450` to clean up that object and returns the worker's result.
4. `0xF48850` references the string `Global\SporeEditorOrGame`. On the
   detected-existing-instance path it reaches the message
   `Another instance of the game is already running` and returns `-1`.
5. On the other path, `0xF48850` allocates `0x48` bytes and passes the
   embedded string `App` to the allocator/constructor helper. It initializes
   object fields, makes an indirect call through a vtable, calls `0xF47ED0`,
   conditionally calls `0xF47580` and `0xF47700`, then calls another virtual
   method and returns a result.
6. The static vtable data referenced in that setup contains code addresses
   including `0xF47670`, `0x804910`, `0x834200`, `0x4535B0`, `0xF47AF0` and
   `0xF47B10`. The code also references the string `AppShutdown`.

### Inferred, not yet proved

- `0x92C1B0` appears to initialize a command-line-related object because
  WinMain passes its command-line argument. Its exact type and parsed options
  have not been established.
- The `App` allocation and virtual calls are the first application object
  setup after the single-instance check. The meaning and ordering of the
  subsystems behind its virtual calls are not yet mapped.
- `0xF47580` has a loop that repeatedly queries an object while a byte field
  remains set; calling it a message pump or wait loop would be speculation.
- The exact startup order for configuration files, package mounting,
  graphics/audio, and simulator initialization remains unresolved.

### Analysis limitation

The REA binary session identified the PE, but its available deep-analysis
providers are not configured on this Windows host (Ghidra unavailable;
Hopper unsupported; IDA unconfigured). The trace above therefore uses local
Capstone disassembly and direct byte/string references, not decompiler
pseudocode or runtime observation. No game code was executed.

## Hash findings

### Verified in the binary

- Function VA `0x50EA00` initializes the accumulator to `0x811C9DC5`, then
  repeats `hash = hash * 0x01000193 XOR byte` for three bytes read from a
  pointer argument. This is the **FNV-1 update order** for that three-byte
  key. Its byte traversal is from the highest addressed byte to the lowest.
- Function VA `0x50E850` calls `0x50EA00`, mixes the result with another
  32-bit input using the same multiply-then-XOR order, then selects from
  `0x8000` buckets of 12-byte entries and probes for a matching key pair.
  This supports the previously observed in-memory hash-table behavior.
- The little-endian bytes for `0xDFAD9F51` occur 41 times in this PE:
  38 offsets are in `.text`, one in `.rdata`, and two in `.data`. A decoded
  `.text` switch at VA `0x432F10` accepts a 32-bit value, compares it with
  `0xDFAD9F51` at `0x432FFC`, returns `0x1D2EC0A4` for that case, and returns
  `-1` for an unrecognized value. The switch's purpose and the meaning of its
  output ID are unknown. The output value does not match FNV-1 or FNV-1a, with
  either raw or lowercase ASCII input, for any of the 41,912 extracted
  identifier tokens. The match test does not cover strings absent from the PE
  or transformations other than those four candidates.
- At VA `0x4E9CA0`, a caller pushes `0xDFAD9F51`, calls `0x432F10`, stores the
  returned ID, and later passes that value to a virtual call. This confirms
  the numeric ID participates in code-side dispatch; it does not identify the
  corresponding DBPF payload format.

### Cross-file FNV candidate validation

- The function above hashes a three-byte key; it does not demonstrate that
  resource **names** are hashed to form DBPF type IDs.
- No name-lowercasing operation is present in this three-byte helper.
- Static comparison of 41,912 distinct ASCII identifier tokens embedded in
  this `SporeApp.exe` with IDs in the 23 package indexes found 28 distinct
  identifier strings whose
  lowercase FNV-1 values match 21 of the 90 observed DBPF type IDs. Examples
  include `Cell` -> `0xDFAD9F51` (489 entries), `animation` ->
  `0xEE17C6AD` (5,022), `World` -> `0x9B8E862F` (37), and `structure` ->
  `0x4B9EF6DC` (376). The same sweep found no lowercase FNV-1a type matches.
- For the focal type, 11 of 79 distinct `cell_*` strings in the executable
  hash under lowercase FNV-1 to instance IDs present in its DBPF records. Four
  mixed-case names match only after lowercasing; none of the 79 matches under
  lowercase FNV-1a. Nine matching records also contain a UTF-16LE
  `PLACEHOLDER_...` label:

  | Embedded name | EXE file offset | Instance ID | Payload label |
  |---|---:|---:|---|
  | `cell_Eggkid` | `0x1084738` | `0x7ADE24E1` | `PLACEHOLDER_Junior` |
  | `cell_EggkidSmall` | `0x1084744` | `0xB5064646` | `PLACEHOLDER_Junior` |
  | `cell_Megamouth` | `0x1082F3C` | `0x4BC9336F` | `PLACEHOLDER_Megamouth` |
  | `cell_StabberAlpha` | `0x1082F78` | `0xEFE530A1` | `PLACEHOLDER_Stabber` |
  | `cell_ducky` | `0x1082F6C` | `0x9B100A94` | `PLACEHOLDER_Ducky` |
  | `cell_jawhead` | `0x1082F5C` | `0x7D00E384` | `PLACEHOLDER_Jawhead` |
  | `cell_poker` | `0xFEB438` | `0x7712E0BB` | `PLACEHOLDER_Bloato` |
  | `cell_puffish` | `0x1082F4C` | `0x2DFC83CF` | `PLACEHOLDER_Puffish` |
  | `cell_squid` | `0x1082F30` | `0x4BC16582` | `PLACEHOLDER_Snorf` |
  | `cell_mate` | `0x1082F24` | `0x9FA0EDCB` | none found |
  | `cell_puncture` | `0x1082F14` | `0x7177EBB2` | none found |

  All rows above refer to type `0xDFAD9F51`, group `0`, and instance IDs
  observed in the local package indexes. The payload labels are observations;
  whether each string is the UI display name is not established.
- These independent type and instance correlations strongly support
  lowercase FNV-1 as the name-to-ID convention for the tested strings and
  disfavor FNV-1a. The binary helper at `0x50EA00` still only proves hashing
  of a three-byte key, not the general string-to-ID call path.

### How to close the gap

Confirm the resource-name association from an independent registry or trace a
binary call site that passes a resource-name string into the candidate hash
routine. The current name/ID pairs come from executable string literals,
package index IDs, and matching payload labels; the statistical agreement is
strong, but the exact string-to-ID call path and normalization outside the
tested ASCII names remain unverified.

## Focal-type dispatch and payload consumer trace

### Verified static observations

- Function VA `0x4E9CA0` pushes type `0xDFAD9F51` at `0x4E9CAD` and calls
  the switch at `0x432F10` at `0x4E9CB2`. It stores the returned
  `0x1D2EC0A4` in a local and passes it as the first stack argument to the
  singleton object's virtual method at `0x4E9CEA`. Immediately before the
  call, `ECX` is loaded from the singleton returned by `0x67DE30`, its first
  word is treated as a vtable pointer, and the function pointer is loaded from
  vtable offset `+0x2C`. The other stack arguments are the value read from
  global `0x15DAA00` and a null pointer.
- The null argument is returned from local slot `[EBP-8]`, which the function
  initialized to zero at `0x4E9CA6`. Before using the returned value,
  `0x41D870` only clears and releases that slot if it was non-null; in this
  call site it remains null. This establishes the call's observed argument
  values, but not the callee implementation or the meanings of the other
  arguments.
- In the same routine, the value returned through a local is passed to
  helper `0x6A1250` with key `0xF5CBE065` (`0x4E9D1E`). The helper invokes
  vtable slot `+0x24` with the key and an address to a local object-pointer
  slot. If that virtual call succeeds and the returned object's 16-bit tag at
  `+0x12` is `0x20`, the helper copies three 32-bit words from `0x6A1030` to
  the caller's output buffer.
- `0x6A1030` accepts tags `0x10` and `0x20`. A byte mask `0x30` at object
  offset `+0x10` selects whether it returns the pointer stored at offset `0`
  or the object pointer itself. For other tags it returns the static address
  `0x1531CDC`; the file-backed bytes there begin with `0xFFFFFFFF`, and the
  word at `+0x12` is `0xFFFF`. The observed `0x6A1250` success path filters
  for tag `0x20` before calling this accessor.
- The object used by `0x4E9CA0` comes from getter `0x67DE30`, which loads
  global `0x15FD8A8`; setter `0x67E040` stores its argument to that same
  global. The global lies in the zero-fill tail of `.data`, so its runtime
  value and concrete class are not present in the file. `0x4E9CA0` also passes
  global `0x15DAA00` as another argument to the `+0x2C` virtual call; this
  address is likewise not file-backed.
- The getter is exactly `mov eax, [0x15FD8A8]; ret`; the setter is
  `mov eax, [esp+4]; mov [0x15FD8A8], eax; ret`. A linear Capstone scan of
  `.text` found many direct calls to the getter, but no direct call to the
  setter. This does not exclude indirect calls or references outside `.text`,
  and does not identify who initializes the global.
- The PE section table places `0x15FD8A8` in the zero-fill tail of `.data`:
  `.data` raw-backed bytes end at VA `0x15D0C00`, before this slot. A raw
  little-endian address search found exactly two file occurrences of
  `0x15FD8A8`, both in the getter/setter instructions. This rules out another
  direct absolute-address reference encoded in the PE file, not runtime writes,
  indirect access through a computed pointer, or external code.
- The routine later uses the same lookup helper repeatedly with additional
  constants: `0x3A3B9D21`, `0x18C1DBE0` and `0x0F48EB09`. If a query succeeds,
  it passes the resulting 12-byte buffer and a caller argument to `0x4E9C40`.
  That helper makes another typed lookup using `0xF45F59D7` and passes the
  buffer onward to `0x4E19A0`. The observed call sites establish data flow,
  not names or semantics for these keys or words.
- None of the four keys queried by `0x4E9CA0` matched the scanned embedded
  ASCII identifier tokens under FNV-1, lowercase FNV-1, or lowercase FNV-1a.
  This bounded negative result does not rule out names absent from the PE,
  non-ASCII names, or a different hash/normalization.
- A byte search for all five query constants (`0xF5CBE065`, `0x3A3B9D21`,
  `0x18C1DBE0`, `0x0F48EB09`, `0xF45F59D7`), in both byte orders, found no
  matches in the 224 representative, decoded 796-byte payloads cataloged for
  this type. This is only a negative result for that selected sample; it does
  not show that the keys are absent from other resource types or all 225
  distinct payload variants.
- The DBPF payload sample for the focal type is 796 bytes. A reproducible byte/word
  profile is in `DBPF_RESOURCE_CATALOG.md`: for example, bytes
  `0x037–0x0A3` are zero across all 224 selected TGI payloads, and words at
  `0x304`/`0x308` decode to plausible finite IEEE-754 values. Those offsets
  are structural observations, not named fields.

### Interpretation limits

- The call chain confirms code-side dispatch associated with the focal type
  and a typed-value lookup path. It does **not** prove this function directly
  deserializes a DBPF record, nor what the values or tag `0x20` mean.
- The 12-byte copy is a concrete size observation. Calling it a `float3`,
  position, color, or any named property would be speculation without a
  confirmed type registry, the virtual method implementation, and runtime
  initialization of the singleton.
- Deep provider decompilation is unavailable in this Windows session; these
  observations come from local Capstone disassembly of the SHA-256-identified
  PE above. REA is connected, but its current binary session has no usable
  analysis provider: Ghidra is not configured, Hopper is unsupported on
  Windows, and IDA is not configured. The attempted REA function analysis
  returned `provider_unavailable`. No game code was run.

## Reproduction

From `SPORE_PORT_RESEARCH`, run:

```powershell
python .\validate_dbpf_name_hash.py --root ..\SPOREFILES --binary ..\SPOREFILES\SporeBin\SporeApp.exe
```

The script reads package indexes and only the selected type's payloads. It
does not modify the executable or packages.
