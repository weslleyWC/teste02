#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "dbpf_reader.hpp"

namespace spore {

// Binary property list resource, DBPF type 0x00B1B104.
//
// Grammar inferred from sample resources (all samples consume exactly their
// size). Everything numeric in the header is big-endian:
//
//   u32 count
//   count x {
//     u32 id; u16 type; u16 flags;
//     flags == 0  -> inline scalar:
//         int32/uint32/float : 4 bytes
//         key / vec3         : 12 bytes + 4 bytes of padding (padding is junk)
//     string type, flags == 0x000D -> u32 length, then length bytes/code units
//         (byte string for 0x0012; UTF-16LE code units for 0x0013)
//     string type, flags == 0x009C -> count/item_size, then count
//         length-prefixed strings (byte strings for 0x0012, UTF-16LE for 0x0013)
//     otherwise (flags != 0)  -> array: u32 count, u32 item_size, count*item_size bytes
//   }
//
// Element byte order, as observed: primitives (int32/uint32/float) are
// big-endian; compound values (key, vec3, bbox, text) are little-endian.
// Unknown scalar types make the parser throw instead of guessing a size.

constexpr std::uint32_t kPropTypeId = 0x00B1B104;

namespace prop_type {
constexpr std::uint16_t kInt32 = 0x0009;
constexpr std::uint16_t kUInt32 = 0x000A;
constexpr std::uint16_t kFloat = 0x000D;
constexpr std::uint16_t kString8 = 0x0012;   // length-prefixed byte string
constexpr std::uint16_t kString16 = 0x0013;  // length-prefixed UTF-16LE
constexpr std::uint16_t kKey = 0x0020;       // instance, type, group (u32 LE each)
constexpr std::uint16_t kText = 0x0022;      // 520-byte items seen, layout not decoded
constexpr std::uint16_t kVec2 = 0x0030;      // 8-byte items, not decoded
constexpr std::uint16_t kVec3 = 0x0031;      // 3 x float LE
constexpr std::uint16_t kType38 = 0x0038;    // 56-byte items, layout unknown
constexpr std::uint16_t kBBox = 0x0039;      // 24-byte items (6 floats LE)
}  // namespace prop_type

struct PropValue {
    std::uint32_t id{};
    std::uint16_t type{};
    std::uint16_t flags{};
    bool is_array{};   // stored with count/item_size header
    bool is_string{};  // length-prefixed string
    bool is_string_array{};  // array of length-prefixed byte or UTF-16LE strings
    std::uint32_t count{1};
    std::uint32_t item_size{};  // declared item size/stride; meaning may be format-specific
    std::vector<std::uint8_t> bytes;  // exact encoded payload, including string-array lengths
};

struct PropList {
    std::vector<PropValue> values;
    const PropValue* find(std::uint32_t id) const noexcept;
};

// Throws std::runtime_error (message includes the byte offset) on any
// malformed/unknown construct, including trailing bytes.
PropList parse_prop(const std::uint8_t* data, std::size_t size);
inline PropList parse_prop(const std::vector<std::uint8_t>& v) {
    return parse_prop(v.data(), v.size());
}

// Decoders: return false if the type/size/index does not match.
bool prop_float(const PropValue& v, std::size_t index, float& out);
bool prop_int32(const PropValue& v, std::size_t index, std::int32_t& out);
bool prop_uint32(const PropValue& v, std::size_t index, std::uint32_t& out);
bool prop_key(const PropValue& v, std::size_t index, Tgi& out);
bool prop_vec3(const PropValue& v, std::size_t index, float out[3]);
bool prop_string8(const PropValue& v, std::string& bytes_out);
bool prop_string16(const PropValue& v, std::string& utf8_out);

}  // namespace spore
