// Generated from the verified Ghidra instruction export; do not edit by hand.
// Source function: SporeApp.exe!0x00422430; static lowering, no x86 interpreter.
#include "FirstStaticLiftRuntime.hpp"

LiftStatus spore_lift_00422430(const std::uint32_t* records,
                               std::size_t record_count,
                               const std::uint32_t* key,
                               std::size_t* result_index) {
    if (result_index == nullptr ||
        record_count > FirstStaticLiftMemory::kMaxRecordCount ||
        (record_count != 0 && records == nullptr)) {
        return LiftStatus::invalid_argument;
    }
    if (record_count != 0 && key == nullptr) return LiftStatus::invalid_argument;
    FirstStaticLiftMemory memory(records, record_count, key);
    std::uint32_t eax = 0, ecx = 0, edx = 0, ebx = 0;
    std::uint32_t esp = FirstStaticLiftMemory::kEntryEsp;
    std::uint32_t ebp = 0, esi = 0, edi = 0;
    std::size_t result_index_local = 0;
    X86Flags flags{};
    std::uint32_t tmp0_a = 0, tmp0_b = 0, tmp0_divisor = 0,
        tmp0_result = 0, tmp0_return = 0;
    std::uint64_t tmp0_wide = 0, tmp0_bits = 0,
        tmp0_subtrahend = 0;
    std::int64_t tmp0_dividend = 0, tmp0_quotient = 0,
        tmp0_remainder = 0, tmp0_product = 0;
    std::int32_t tmp0_signed_divisor = 0;
    std::uint32_t tmp1_a = 0, tmp1_b = 0, tmp1_divisor = 0,
        tmp1_result = 0, tmp1_return = 0;
    std::uint64_t tmp1_wide = 0, tmp1_bits = 0,
        tmp1_subtrahend = 0;
    std::int64_t tmp1_dividend = 0, tmp1_quotient = 0,
        tmp1_remainder = 0, tmp1_product = 0;
    std::int32_t tmp1_signed_divisor = 0;
    std::uint32_t tmp2_a = 0, tmp2_b = 0, tmp2_divisor = 0,
        tmp2_result = 0, tmp2_return = 0;
    std::uint64_t tmp2_wide = 0, tmp2_bits = 0,
        tmp2_subtrahend = 0;
    std::int64_t tmp2_dividend = 0, tmp2_quotient = 0,
        tmp2_remainder = 0, tmp2_product = 0;
    std::int32_t tmp2_signed_divisor = 0;
    std::uint32_t tmp3_a = 0, tmp3_b = 0, tmp3_divisor = 0,
        tmp3_result = 0, tmp3_return = 0;
    std::uint64_t tmp3_wide = 0, tmp3_bits = 0,
        tmp3_subtrahend = 0;
    std::int64_t tmp3_dividend = 0, tmp3_quotient = 0,
        tmp3_remainder = 0, tmp3_product = 0;
    std::int32_t tmp3_signed_divisor = 0;
    std::uint32_t tmp4_a = 0, tmp4_b = 0, tmp4_divisor = 0,
        tmp4_result = 0, tmp4_return = 0;
    std::uint64_t tmp4_wide = 0, tmp4_bits = 0,
        tmp4_subtrahend = 0;
    std::int64_t tmp4_dividend = 0, tmp4_quotient = 0,
        tmp4_remainder = 0, tmp4_product = 0;
    std::int32_t tmp4_signed_divisor = 0;
    std::uint32_t tmp5_a = 0, tmp5_b = 0, tmp5_divisor = 0,
        tmp5_result = 0, tmp5_return = 0;
    std::uint64_t tmp5_wide = 0, tmp5_bits = 0,
        tmp5_subtrahend = 0;
    std::int64_t tmp5_dividend = 0, tmp5_quotient = 0,
        tmp5_remainder = 0, tmp5_product = 0;
    std::int32_t tmp5_signed_divisor = 0;
    std::uint32_t tmp6_a = 0, tmp6_b = 0, tmp6_divisor = 0,
        tmp6_result = 0, tmp6_return = 0;
    std::uint64_t tmp6_wide = 0, tmp6_bits = 0,
        tmp6_subtrahend = 0;
    std::int64_t tmp6_dividend = 0, tmp6_quotient = 0,
        tmp6_remainder = 0, tmp6_product = 0;
    std::int32_t tmp6_signed_divisor = 0;
    std::uint32_t tmp7_a = 0, tmp7_b = 0, tmp7_divisor = 0,
        tmp7_result = 0, tmp7_return = 0;
    std::uint64_t tmp7_wide = 0, tmp7_bits = 0,
        tmp7_subtrahend = 0;
    std::int64_t tmp7_dividend = 0, tmp7_quotient = 0,
        tmp7_remainder = 0, tmp7_product = 0;
    std::int32_t tmp7_signed_divisor = 0;
    std::uint32_t tmp8_a = 0, tmp8_b = 0, tmp8_divisor = 0,
        tmp8_result = 0, tmp8_return = 0;
    std::uint64_t tmp8_wide = 0, tmp8_bits = 0,
        tmp8_subtrahend = 0;
    std::int64_t tmp8_dividend = 0, tmp8_quotient = 0,
        tmp8_remainder = 0, tmp8_product = 0;
    std::int32_t tmp8_signed_divisor = 0;
    std::uint32_t tmp9_a = 0, tmp9_b = 0, tmp9_divisor = 0,
        tmp9_result = 0, tmp9_return = 0;
    std::uint64_t tmp9_wide = 0, tmp9_bits = 0,
        tmp9_subtrahend = 0;
    std::int64_t tmp9_dividend = 0, tmp9_quotient = 0,
        tmp9_remainder = 0, tmp9_product = 0;
    std::int32_t tmp9_signed_divisor = 0;
    std::uint32_t tmp10_a = 0, tmp10_b = 0, tmp10_divisor = 0,
        tmp10_result = 0, tmp10_return = 0;
    std::uint64_t tmp10_wide = 0, tmp10_bits = 0,
        tmp10_subtrahend = 0;
    std::int64_t tmp10_dividend = 0, tmp10_quotient = 0,
        tmp10_remainder = 0, tmp10_product = 0;
    std::int32_t tmp10_signed_divisor = 0;
    std::uint32_t tmp11_a = 0, tmp11_b = 0, tmp11_divisor = 0,
        tmp11_result = 0, tmp11_return = 0;
    std::uint64_t tmp11_wide = 0, tmp11_bits = 0,
        tmp11_subtrahend = 0;
    std::int64_t tmp11_dividend = 0, tmp11_quotient = 0,
        tmp11_remainder = 0, tmp11_product = 0;
    std::int32_t tmp11_signed_divisor = 0;
    std::uint32_t tmp12_a = 0, tmp12_b = 0, tmp12_divisor = 0,
        tmp12_result = 0, tmp12_return = 0;
    std::uint64_t tmp12_wide = 0, tmp12_bits = 0,
        tmp12_subtrahend = 0;
    std::int64_t tmp12_dividend = 0, tmp12_quotient = 0,
        tmp12_remainder = 0, tmp12_product = 0;
    std::int32_t tmp12_signed_divisor = 0;
    std::uint32_t tmp13_a = 0, tmp13_b = 0, tmp13_divisor = 0,
        tmp13_result = 0, tmp13_return = 0;
    std::uint64_t tmp13_wide = 0, tmp13_bits = 0,
        tmp13_subtrahend = 0;
    std::int64_t tmp13_dividend = 0, tmp13_quotient = 0,
        tmp13_remainder = 0, tmp13_product = 0;
    std::int32_t tmp13_signed_divisor = 0;
    std::uint32_t tmp14_a = 0, tmp14_b = 0, tmp14_divisor = 0,
        tmp14_result = 0, tmp14_return = 0;
    std::uint64_t tmp14_wide = 0, tmp14_bits = 0,
        tmp14_subtrahend = 0;
    std::int64_t tmp14_dividend = 0, tmp14_quotient = 0,
        tmp14_remainder = 0, tmp14_product = 0;
    std::int32_t tmp14_signed_divisor = 0;
    std::uint32_t tmp15_a = 0, tmp15_b = 0, tmp15_divisor = 0,
        tmp15_result = 0, tmp15_return = 0;
    std::uint64_t tmp15_wide = 0, tmp15_bits = 0,
        tmp15_subtrahend = 0;
    std::int64_t tmp15_dividend = 0, tmp15_quotient = 0,
        tmp15_remainder = 0, tmp15_product = 0;
    std::int32_t tmp15_signed_divisor = 0;
    std::uint32_t tmp16_a = 0, tmp16_b = 0, tmp16_divisor = 0,
        tmp16_result = 0, tmp16_return = 0;
    std::uint64_t tmp16_wide = 0, tmp16_bits = 0,
        tmp16_subtrahend = 0;
    std::int64_t tmp16_dividend = 0, tmp16_quotient = 0,
        tmp16_remainder = 0, tmp16_product = 0;
    std::int32_t tmp16_signed_divisor = 0;
    std::uint32_t tmp17_a = 0, tmp17_b = 0, tmp17_divisor = 0,
        tmp17_result = 0, tmp17_return = 0;
    std::uint64_t tmp17_wide = 0, tmp17_bits = 0,
        tmp17_subtrahend = 0;
    std::int64_t tmp17_dividend = 0, tmp17_quotient = 0,
        tmp17_remainder = 0, tmp17_product = 0;
    std::int32_t tmp17_signed_divisor = 0;
    std::uint32_t tmp18_a = 0, tmp18_b = 0, tmp18_divisor = 0,
        tmp18_result = 0, tmp18_return = 0;
    std::uint64_t tmp18_wide = 0, tmp18_bits = 0,
        tmp18_subtrahend = 0;
    std::int64_t tmp18_dividend = 0, tmp18_quotient = 0,
        tmp18_remainder = 0, tmp18_product = 0;
    std::int32_t tmp18_signed_divisor = 0;
    std::uint32_t tmp19_a = 0, tmp19_b = 0, tmp19_divisor = 0,
        tmp19_result = 0, tmp19_return = 0;
    std::uint64_t tmp19_wide = 0, tmp19_bits = 0,
        tmp19_subtrahend = 0;
    std::int64_t tmp19_dividend = 0, tmp19_quotient = 0,
        tmp19_remainder = 0, tmp19_product = 0;
    std::int32_t tmp19_signed_divisor = 0;
    std::uint32_t tmp20_a = 0, tmp20_b = 0, tmp20_divisor = 0,
        tmp20_result = 0, tmp20_return = 0;
    std::uint64_t tmp20_wide = 0, tmp20_bits = 0,
        tmp20_subtrahend = 0;
    std::int64_t tmp20_dividend = 0, tmp20_quotient = 0,
        tmp20_remainder = 0, tmp20_product = 0;
    std::int32_t tmp20_signed_divisor = 0;
    std::uint32_t tmp21_a = 0, tmp21_b = 0, tmp21_divisor = 0,
        tmp21_result = 0, tmp21_return = 0;
    std::uint64_t tmp21_wide = 0, tmp21_bits = 0,
        tmp21_subtrahend = 0;
    std::int64_t tmp21_dividend = 0, tmp21_quotient = 0,
        tmp21_remainder = 0, tmp21_product = 0;
    std::int32_t tmp21_signed_divisor = 0;
    std::uint32_t tmp22_a = 0, tmp22_b = 0, tmp22_divisor = 0,
        tmp22_result = 0, tmp22_return = 0;
    std::uint64_t tmp22_wide = 0, tmp22_bits = 0,
        tmp22_subtrahend = 0;
    std::int64_t tmp22_dividend = 0, tmp22_quotient = 0,
        tmp22_remainder = 0, tmp22_product = 0;
    std::int32_t tmp22_signed_divisor = 0;
    std::uint32_t tmp23_a = 0, tmp23_b = 0, tmp23_divisor = 0,
        tmp23_result = 0, tmp23_return = 0;
    std::uint64_t tmp23_wide = 0, tmp23_bits = 0,
        tmp23_subtrahend = 0;
    std::int64_t tmp23_dividend = 0, tmp23_quotient = 0,
        tmp23_remainder = 0, tmp23_product = 0;
    std::int32_t tmp23_signed_divisor = 0;
    std::uint32_t tmp24_a = 0, tmp24_b = 0, tmp24_divisor = 0,
        tmp24_result = 0, tmp24_return = 0;
    std::uint64_t tmp24_wide = 0, tmp24_bits = 0,
        tmp24_subtrahend = 0;
    std::int64_t tmp24_dividend = 0, tmp24_quotient = 0,
        tmp24_remainder = 0, tmp24_product = 0;
    std::int32_t tmp24_signed_divisor = 0;
    std::uint32_t tmp25_a = 0, tmp25_b = 0, tmp25_divisor = 0,
        tmp25_result = 0, tmp25_return = 0;
    std::uint64_t tmp25_wide = 0, tmp25_bits = 0,
        tmp25_subtrahend = 0;
    std::int64_t tmp25_dividend = 0, tmp25_quotient = 0,
        tmp25_remainder = 0, tmp25_product = 0;
    std::int32_t tmp25_signed_divisor = 0;
    std::uint32_t tmp26_a = 0, tmp26_b = 0, tmp26_divisor = 0,
        tmp26_result = 0, tmp26_return = 0;
    std::uint64_t tmp26_wide = 0, tmp26_bits = 0,
        tmp26_subtrahend = 0;
    std::int64_t tmp26_dividend = 0, tmp26_quotient = 0,
        tmp26_remainder = 0, tmp26_product = 0;
    std::int32_t tmp26_signed_divisor = 0;
    std::uint32_t tmp27_a = 0, tmp27_b = 0, tmp27_divisor = 0,
        tmp27_result = 0, tmp27_return = 0;
    std::uint64_t tmp27_wide = 0, tmp27_bits = 0,
        tmp27_subtrahend = 0;
    std::int64_t tmp27_dividend = 0, tmp27_quotient = 0,
        tmp27_remainder = 0, tmp27_product = 0;
    std::int32_t tmp27_signed_divisor = 0;
    std::uint32_t tmp28_a = 0, tmp28_b = 0, tmp28_divisor = 0,
        tmp28_result = 0, tmp28_return = 0;
    std::uint64_t tmp28_wide = 0, tmp28_bits = 0,
        tmp28_subtrahend = 0;
    std::int64_t tmp28_dividend = 0, tmp28_quotient = 0,
        tmp28_remainder = 0, tmp28_product = 0;
    std::int32_t tmp28_signed_divisor = 0;
    std::uint32_t tmp29_a = 0, tmp29_b = 0, tmp29_divisor = 0,
        tmp29_result = 0, tmp29_return = 0;
    std::uint64_t tmp29_wide = 0, tmp29_bits = 0,
        tmp29_subtrahend = 0;
    std::int64_t tmp29_dividend = 0, tmp29_quotient = 0,
        tmp29_remainder = 0, tmp29_product = 0;
    std::int32_t tmp29_signed_divisor = 0;
    std::uint32_t tmp30_a = 0, tmp30_b = 0, tmp30_divisor = 0,
        tmp30_result = 0, tmp30_return = 0;
    std::uint64_t tmp30_wide = 0, tmp30_bits = 0,
        tmp30_subtrahend = 0;
    std::int64_t tmp30_dividend = 0, tmp30_quotient = 0,
        tmp30_remainder = 0, tmp30_product = 0;
    std::int32_t tmp30_signed_divisor = 0;
    std::uint32_t tmp31_a = 0, tmp31_b = 0, tmp31_divisor = 0,
        tmp31_result = 0, tmp31_return = 0;
    std::uint64_t tmp31_wide = 0, tmp31_bits = 0,
        tmp31_subtrahend = 0;
    std::int64_t tmp31_dividend = 0, tmp31_quotient = 0,
        tmp31_remainder = 0, tmp31_product = 0;
    std::int32_t tmp31_signed_divisor = 0;
    std::uint32_t tmp32_a = 0, tmp32_b = 0, tmp32_divisor = 0,
        tmp32_result = 0, tmp32_return = 0;
    std::uint64_t tmp32_wide = 0, tmp32_bits = 0,
        tmp32_subtrahend = 0;
    std::int64_t tmp32_dividend = 0, tmp32_quotient = 0,
        tmp32_remainder = 0, tmp32_product = 0;
    std::int32_t tmp32_signed_divisor = 0;
    std::uint32_t tmp33_a = 0, tmp33_b = 0, tmp33_divisor = 0,
        tmp33_result = 0, tmp33_return = 0;
    std::uint64_t tmp33_wide = 0, tmp33_bits = 0,
        tmp33_subtrahend = 0;
    std::int64_t tmp33_dividend = 0, tmp33_quotient = 0,
        tmp33_remainder = 0, tmp33_product = 0;
    std::int32_t tmp33_signed_divisor = 0;
    std::uint32_t tmp34_a = 0, tmp34_b = 0, tmp34_divisor = 0,
        tmp34_result = 0, tmp34_return = 0;
    std::uint64_t tmp34_wide = 0, tmp34_bits = 0,
        tmp34_subtrahend = 0;
    std::int64_t tmp34_dividend = 0, tmp34_quotient = 0,
        tmp34_remainder = 0, tmp34_product = 0;
    std::int32_t tmp34_signed_divisor = 0;
    std::uint32_t tmp35_a = 0, tmp35_b = 0, tmp35_divisor = 0,
        tmp35_result = 0, tmp35_return = 0;
    std::uint64_t tmp35_wide = 0, tmp35_bits = 0,
        tmp35_subtrahend = 0;
    std::int64_t tmp35_dividend = 0, tmp35_quotient = 0,
        tmp35_remainder = 0, tmp35_product = 0;
    std::int32_t tmp35_signed_divisor = 0;
    std::uint32_t tmp36_a = 0, tmp36_b = 0, tmp36_divisor = 0,
        tmp36_result = 0, tmp36_return = 0;
    std::uint64_t tmp36_wide = 0, tmp36_bits = 0,
        tmp36_subtrahend = 0;
    std::int64_t tmp36_dividend = 0, tmp36_quotient = 0,
        tmp36_remainder = 0, tmp36_product = 0;
    std::int32_t tmp36_signed_divisor = 0;
    std::uint32_t tmp37_a = 0, tmp37_b = 0, tmp37_divisor = 0,
        tmp37_result = 0, tmp37_return = 0;
    std::uint64_t tmp37_wide = 0, tmp37_bits = 0,
        tmp37_subtrahend = 0;
    std::int64_t tmp37_dividend = 0, tmp37_quotient = 0,
        tmp37_remainder = 0, tmp37_product = 0;
    std::int32_t tmp37_signed_divisor = 0;
    std::uint32_t tmp38_a = 0, tmp38_b = 0, tmp38_divisor = 0,
        tmp38_result = 0, tmp38_return = 0;
    std::uint64_t tmp38_wide = 0, tmp38_bits = 0,
        tmp38_subtrahend = 0;
    std::int64_t tmp38_dividend = 0, tmp38_quotient = 0,
        tmp38_remainder = 0, tmp38_product = 0;
    std::int32_t tmp38_signed_divisor = 0;
    std::uint32_t tmp39_a = 0, tmp39_b = 0, tmp39_divisor = 0,
        tmp39_result = 0, tmp39_return = 0;
    std::uint64_t tmp39_wide = 0, tmp39_bits = 0,
        tmp39_subtrahend = 0;
    std::int64_t tmp39_dividend = 0, tmp39_quotient = 0,
        tmp39_remainder = 0, tmp39_product = 0;
    std::int32_t tmp39_signed_divisor = 0;
    std::uint32_t tmp40_a = 0, tmp40_b = 0, tmp40_divisor = 0,
        tmp40_result = 0, tmp40_return = 0;
    std::uint64_t tmp40_wide = 0, tmp40_bits = 0,
        tmp40_subtrahend = 0;
    std::int64_t tmp40_dividend = 0, tmp40_quotient = 0,
        tmp40_remainder = 0, tmp40_product = 0;
    std::int32_t tmp40_signed_divisor = 0;
    std::uint32_t tmp41_a = 0, tmp41_b = 0, tmp41_divisor = 0,
        tmp41_result = 0, tmp41_return = 0;
    std::uint64_t tmp41_wide = 0, tmp41_bits = 0,
        tmp41_subtrahend = 0;
    std::int64_t tmp41_dividend = 0, tmp41_quotient = 0,
        tmp41_remainder = 0, tmp41_product = 0;
    std::int32_t tmp41_signed_divisor = 0;
    std::uint32_t tmp42_a = 0, tmp42_b = 0, tmp42_divisor = 0,
        tmp42_result = 0, tmp42_return = 0;
    std::uint64_t tmp42_wide = 0, tmp42_bits = 0,
        tmp42_subtrahend = 0;
    std::int64_t tmp42_dividend = 0, tmp42_quotient = 0,
        tmp42_remainder = 0, tmp42_product = 0;
    std::int32_t tmp42_signed_divisor = 0;
    std::uint32_t tmp43_a = 0, tmp43_b = 0, tmp43_divisor = 0,
        tmp43_result = 0, tmp43_return = 0;
    std::uint64_t tmp43_wide = 0, tmp43_bits = 0,
        tmp43_subtrahend = 0;
    std::int64_t tmp43_dividend = 0, tmp43_quotient = 0,
        tmp43_remainder = 0, tmp43_product = 0;
    std::int32_t tmp43_signed_divisor = 0;
    std::uint32_t tmp44_a = 0, tmp44_b = 0, tmp44_divisor = 0,
        tmp44_result = 0, tmp44_return = 0;
    std::uint64_t tmp44_wide = 0, tmp44_bits = 0,
        tmp44_subtrahend = 0;
    std::int64_t tmp44_dividend = 0, tmp44_quotient = 0,
        tmp44_remainder = 0, tmp44_product = 0;
    std::int32_t tmp44_signed_divisor = 0;
    std::uint32_t tmp45_a = 0, tmp45_b = 0, tmp45_divisor = 0,
        tmp45_result = 0, tmp45_return = 0;
    std::uint64_t tmp45_wide = 0, tmp45_bits = 0,
        tmp45_subtrahend = 0;
    std::int64_t tmp45_dividend = 0, tmp45_quotient = 0,
        tmp45_remainder = 0, tmp45_product = 0;
    std::int32_t tmp45_signed_divisor = 0;
    std::uint32_t tmp46_a = 0, tmp46_b = 0, tmp46_divisor = 0,
        tmp46_result = 0, tmp46_return = 0;
    std::uint64_t tmp46_wide = 0, tmp46_bits = 0,
        tmp46_subtrahend = 0;
    std::int64_t tmp46_dividend = 0, tmp46_quotient = 0,
        tmp46_remainder = 0, tmp46_product = 0;
    std::int32_t tmp46_signed_divisor = 0;
    if (!memory.initialize_call_frame()) return LiftStatus::invalid_memory;

L_00422430: // 55 PUSH EBP
    tmp0_a = ebp;
    esp = static_cast<std::uint32_t>(esp - 4u);
    if (!memory.store32(static_cast<std::uint32_t>(esp + 0x00000000u), tmp0_a)) return LiftStatus::invalid_memory;
L_00422431: // 8bec MOV EBP ESP
    tmp1_a = esp;
    ebp = tmp1_a;
L_00422433: // 83ec10 SUB ESP 0x10
    tmp2_a = esp;
    tmp2_b = 0x00000010u;
    tmp2_result = static_cast<std::uint32_t>(tmp2_a - tmp2_b);
    set_sub_flags(tmp2_a, tmp2_b, tmp2_result, tmp2_a < tmp2_b, flags);
    esp = tmp2_result;
L_00422436: // 8b450c MOV EAX dword ptr [EBP + 0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x0000000cu), tmp3_a)) return LiftStatus::invalid_memory;
    eax = tmp3_a;
L_00422439: // 2b4508 SUB EAX dword ptr [EBP + 0x8]
    tmp4_a = eax;
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000008u), tmp4_b)) return LiftStatus::invalid_memory;
    tmp4_result = static_cast<std::uint32_t>(tmp4_a - tmp4_b);
    set_sub_flags(tmp4_a, tmp4_b, tmp4_result, tmp4_a < tmp4_b, flags);
    eax = tmp4_result;
L_0042243c: // 99 CDQ
    edx = (eax & 0x80000000u) ? 0xffffffffu : 0u;
L_0042243d: // b90c000000 MOV ECX 0xc
    tmp6_a = 0x0000000cu;
    ecx = tmp6_a;
L_00422442: // f7f9 IDIV ECX
    tmp7_divisor = ecx;
    if (tmp7_divisor == 0u) return LiftStatus::divide_error;
    tmp7_bits = (static_cast<std::uint64_t>(edx) << 32u) | eax;
    std::memcpy(&tmp7_dividend, &tmp7_bits, sizeof(tmp7_dividend));
    tmp7_signed_divisor = static_cast<std::int32_t>(tmp7_divisor);
    if (tmp7_dividend == INT64_MIN && tmp7_signed_divisor == -1) return LiftStatus::divide_error;
    tmp7_quotient = tmp7_dividend / tmp7_signed_divisor;
    if (tmp7_quotient < INT32_MIN || tmp7_quotient > INT32_MAX) return LiftStatus::divide_error;
    tmp7_remainder = tmp7_dividend % tmp7_signed_divisor;
    eax = static_cast<std::uint32_t>(static_cast<std::int32_t>(tmp7_quotient));
    edx = static_cast<std::uint32_t>(static_cast<std::int32_t>(tmp7_remainder));
L_00422444: // 8945fc MOV dword ptr [EBP + -0x4] EAX
    tmp8_a = eax;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), tmp8_a)) return LiftStatus::invalid_memory;
L_00422447: // 837dfc00 CMP dword ptr [EBP + -0x4] 0x0
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), tmp9_a)) return LiftStatus::invalid_memory;
    tmp9_b = 0x00000000u;
    tmp9_result = static_cast<std::uint32_t>(tmp9_a - tmp9_b);
    set_sub_flags(tmp9_a, tmp9_b, tmp9_result, tmp9_a < tmp9_b, flags);
L_0042244b: // 7e56 JLE 0x004224a3
    if ((flags.zf || (flags.sf != flags.of))) goto L_004224a3;
L_0042244d: // 8b5508 MOV EDX dword ptr [EBP + 0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000008u), tmp11_a)) return LiftStatus::invalid_memory;
    edx = tmp11_a;
L_00422450: // 8955f8 MOV dword ptr [EBP + -0x8] EDX
    tmp12_a = edx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp12_a)) return LiftStatus::invalid_memory;
L_00422453: // 8b45fc MOV EAX dword ptr [EBP + -0x4]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), tmp13_a)) return LiftStatus::invalid_memory;
    eax = tmp13_a;
L_00422456: // d1f8 SAR EAX 0x1
    tmp14_a = eax;
    tmp14_b = 0x00000001u;
    tmp14_result = arithmetic_shift_right(tmp14_a, tmp14_b & 0x1fu);
    set_logic_flags(tmp14_result, flags);
    eax = tmp14_result;
L_00422458: // 8945f4 MOV dword ptr [EBP + -0xc] EAX
    tmp15_a = eax;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff4u), tmp15_a)) return LiftStatus::invalid_memory;
L_0042245b: // 8b4df4 MOV ECX dword ptr [EBP + -0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff4u), tmp16_a)) return LiftStatus::invalid_memory;
    ecx = tmp16_a;
L_0042245e: // 6bc90c IMUL ECX ECX 0xc
    tmp17_a = ecx;
    tmp17_b = 0x0000000cu;
    tmp17_product = static_cast<std::int64_t>(static_cast<std::int32_t>(tmp17_a)) * static_cast<std::int64_t>(static_cast<std::int32_t>(tmp17_b));
    tmp17_result = static_cast<std::uint32_t>(tmp17_product);
    flags.cf = flags.of = (tmp17_product < INT32_MIN || tmp17_product > INT32_MAX);
    ecx = tmp17_result;
L_00422461: // 034df8 ADD ECX dword ptr [EBP + -0x8]
    tmp18_a = ecx;
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp18_b)) return LiftStatus::invalid_memory;
    tmp18_wide = static_cast<std::uint64_t>(tmp18_a) + tmp18_b;
    tmp18_result = static_cast<std::uint32_t>(tmp18_wide);
    set_add_flags(tmp18_a, tmp18_b, tmp18_result, tmp18_wide, flags);
    ecx = tmp18_result;
L_00422464: // 894df8 MOV dword ptr [EBP + -0x8] ECX
    tmp19_a = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp19_a)) return LiftStatus::invalid_memory;
L_00422467: // 8b55f8 MOV EDX dword ptr [EBP + -0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp20_a)) return LiftStatus::invalid_memory;
    edx = tmp20_a;
L_0042246a: // 8b4510 MOV EAX dword ptr [EBP + 0x10]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000010u), tmp21_a)) return LiftStatus::invalid_memory;
    eax = tmp21_a;
L_0042246d: // 8b0a MOV ECX dword ptr [EDX]
    if (!memory.load32(static_cast<std::uint32_t>(edx + 0x00000000u), tmp22_a)) return LiftStatus::invalid_memory;
    ecx = tmp22_a;
L_0042246f: // 3b08 CMP ECX dword ptr [EAX]
    tmp23_a = ecx;
    if (!memory.load32(static_cast<std::uint32_t>(eax + 0x00000000u), tmp23_b)) return LiftStatus::invalid_memory;
    tmp23_result = static_cast<std::uint32_t>(tmp23_a - tmp23_b);
    set_sub_flags(tmp23_a, tmp23_b, tmp23_result, tmp23_a < tmp23_b, flags);
L_00422471: // 1bd2 SBB EDX EDX
    tmp24_a = edx;
    tmp24_b = edx;
    tmp24_subtrahend = static_cast<std::uint64_t>(tmp24_b) + static_cast<std::uint64_t>(flags.cf);
    tmp24_result = static_cast<std::uint32_t>(static_cast<std::uint64_t>(tmp24_a) - tmp24_subtrahend);
    set_sbb_flags(tmp24_a, tmp24_b, flags.cf, tmp24_result, flags);
    edx = tmp24_result;
L_00422473: // f7da NEG EDX
    tmp25_a = edx;
    tmp25_result = static_cast<std::uint32_t>(0u - tmp25_a);
    flags.cf = (tmp25_a != 0u);
    flags.of = (tmp25_a == 0x80000000u);
    set_logic_flags(tmp25_result, flags);
    edx = tmp25_result;
L_00422475: // 0fb6c2 MOVZX EAX DL
    tmp26_a = edx & 0xffu;
    eax = tmp26_a;
L_00422478: // 85c0 TEST EAX EAX
    tmp27_a = eax;
    tmp27_b = eax;
    tmp27_result = tmp27_a & tmp27_b;
    flags.cf = false;
    flags.of = false;
    set_logic_flags(tmp27_result, flags);
L_0042247a: // 741f JZ 0x0042249b
    if (flags.zf) goto L_0042249b;
L_0042247c: // 8b4df8 MOV ECX dword ptr [EBP + -0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp29_a)) return LiftStatus::invalid_memory;
    ecx = tmp29_a;
L_0042247f: // 83c10c ADD ECX 0xc
    tmp30_a = ecx;
    tmp30_b = 0x0000000cu;
    tmp30_wide = static_cast<std::uint64_t>(tmp30_a) + tmp30_b;
    tmp30_result = static_cast<std::uint32_t>(tmp30_wide);
    set_add_flags(tmp30_a, tmp30_b, tmp30_result, tmp30_wide, flags);
    ecx = tmp30_result;
L_00422482: // 894df8 MOV dword ptr [EBP + -0x8] ECX
    tmp31_a = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp31_a)) return LiftStatus::invalid_memory;
L_00422485: // 8b55f8 MOV EDX dword ptr [EBP + -0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), tmp32_a)) return LiftStatus::invalid_memory;
    edx = tmp32_a;
L_00422488: // 895508 MOV dword ptr [EBP + 0x8] EDX
    tmp33_a = edx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0x00000008u), tmp33_a)) return LiftStatus::invalid_memory;
L_0042248b: // 8b45f4 MOV EAX dword ptr [EBP + -0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff4u), tmp34_a)) return LiftStatus::invalid_memory;
    eax = tmp34_a;
L_0042248e: // 83c001 ADD EAX 0x1
    tmp35_a = eax;
    tmp35_b = 0x00000001u;
    tmp35_wide = static_cast<std::uint64_t>(tmp35_a) + tmp35_b;
    tmp35_result = static_cast<std::uint32_t>(tmp35_wide);
    set_add_flags(tmp35_a, tmp35_b, tmp35_result, tmp35_wide, flags);
    eax = tmp35_result;
L_00422491: // 8b4dfc MOV ECX dword ptr [EBP + -0x4]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), tmp36_a)) return LiftStatus::invalid_memory;
    ecx = tmp36_a;
L_00422494: // 2bc8 SUB ECX EAX
    tmp37_a = ecx;
    tmp37_b = eax;
    tmp37_result = static_cast<std::uint32_t>(tmp37_a - tmp37_b);
    set_sub_flags(tmp37_a, tmp37_b, tmp37_result, tmp37_a < tmp37_b, flags);
    ecx = tmp37_result;
L_00422496: // 894dfc MOV dword ptr [EBP + -0x4] ECX
    tmp38_a = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), tmp38_a)) return LiftStatus::invalid_memory;
L_00422499: // eb06 JMP 0x004224a1
    goto L_004224a1;
L_0042249b: // 8b55f4 MOV EDX dword ptr [EBP + -0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff4u), tmp40_a)) return LiftStatus::invalid_memory;
    edx = tmp40_a;
L_0042249e: // 8955fc MOV dword ptr [EBP + -0x4] EDX
    tmp41_a = edx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), tmp41_a)) return LiftStatus::invalid_memory;
L_004224a1: // eba4 JMP 0x00422447
    goto L_00422447;
L_004224a3: // 8b4508 MOV EAX dword ptr [EBP + 0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000008u), tmp43_a)) return LiftStatus::invalid_memory;
    eax = tmp43_a;
L_004224a6: // 8be5 MOV ESP EBP
    tmp44_a = ebp;
    esp = tmp44_a;
L_004224a8: // 5d POP EBP
    if (!memory.load32(static_cast<std::uint32_t>(esp + 0x00000000u), tmp45_a)) return LiftStatus::invalid_memory;
    ebp = tmp45_a;
    esp = static_cast<std::uint32_t>(esp + 4u);
L_004224a9: // c3 RET
    if (!memory.load32(esp, tmp0_return) || tmp0_return != FirstStaticLiftMemory::kReturnSentinel) return LiftStatus::invalid_memory;
    if (!memory.to_record_index(eax, record_count, result_index_local)) return LiftStatus::invalid_return;
    esp = static_cast<std::uint32_t>(esp + 4u);
    *result_index = result_index_local;
    return LiftStatus::ok;
    return LiftStatus::invalid_control_flow;
}
