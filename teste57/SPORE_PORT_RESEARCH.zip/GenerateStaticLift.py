#!/usr/bin/env python3

import argparse
import csv
import hashlib
import json
import re
import struct
import sys
from pathlib import Path


EXPECTED_SHA256 = "6aec99cb2dc7fd08851a1718e92a60f359fb3fccca3b244a890ae07e93cbe59b"
EXPECTED_VA = 0x00422430
EXPECTED_SIZE = 122
EXPECTED_LANGUAGE = "x86:LE:32:default"
EXPECTED_MNEMONICS = {
    "PUSH", "POP", "MOV", "SUB", "CDQ", "IDIV", "CMP", "JLE", "SAR",
    "IMUL", "ADD", "SBB", "NEG", "MOVZX", "TEST", "JZ", "JMP", "RET",
}
REGISTERS = {"EAX", "ECX", "EDX", "EBX", "ESP", "EBP", "ESI", "EDI"}
MEMORY_OPERAND = re.compile(
    r"^(?:dword ptr )?\[\s*(EAX|ECX|EDX|EBX|ESP|EBP|ESI|EDI)"
    r"(?:\s*\+\s*(-?(?:0x[0-9a-f]+|[0-9]+)))?\s*\]$",
    re.IGNORECASE,
)


def parse_int(value):
    return int(value, 0)


def load_pe_section_offset(exe_path, va, length):
    image = exe_path.read_bytes()
    if image[:2] != b"MZ":
        raise ValueError("Selected input is not a PE executable (missing MZ signature).")
    pe_offset = struct.unpack_from("<I", image, 0x3C)[0]
    if image[pe_offset:pe_offset + 4] != b"PE\0\0":
        raise ValueError("Selected input is not a PE executable (missing PE signature).")
    machine, section_count, _, _, _, optional_size, _ = struct.unpack_from(
        "<HHIIIHH", image, pe_offset + 4
    )
    if machine != 0x14C:
        raise ValueError(f"Expected PE32 x86 machine 0x14c, got 0x{machine:x}.")
    optional = pe_offset + 24
    if struct.unpack_from("<H", image, optional)[0] != 0x10B:
        raise ValueError("Expected PE32 optional header.")
    image_base = struct.unpack_from("<I", image, optional + 28)[0]
    rva = va - image_base
    section_offset = optional + optional_size
    for index in range(section_count):
        off = section_offset + index * 40
        name = image[off:off + 8].split(b"\0", 1)[0].decode("ascii", "replace")
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", image, off + 8
        )
        span = max(virtual_size, raw_size)
        if virtual_address <= rva and rva + length <= virtual_address + span:
            file_offset = raw_offset + (rva - virtual_address)
            raw = image[file_offset:file_offset + length]
            if len(raw) != length:
                raise ValueError("PE section does not contain the full function byte range.")
            return image, name, file_offset, raw
    raise ValueError(f"VA 0x{va:08x} is not backed by a PE section.")


def verify_inventory(csv_path, va):
    with csv_path.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            if int(row["address"], 16) == va:
                size = int(row["size"], 0)
                if size != EXPECTED_SIZE:
                    raise ValueError(f"Ghidra inventory size changed: expected 122, got {size}.")
                return row
    raise ValueError(f"Function 0x{va:08x} is absent from the Ghidra CSV.")


def parse_operand(text):
    token = text.strip().upper()
    if token in REGISTERS or token == "DL":
        return ("reg", token)
    if token.startswith("0X") or token.isdecimal():
        return ("imm", int(token, 0))
    match = MEMORY_OPERAND.fullmatch(text.strip())
    if match:
        base = match.group(1).upper()
        displacement = int(match.group(2), 0) if match.group(2) else 0
        return ("mem", base, displacement)
    raise ValueError(f"unsupported operand syntax: {text!r}")


def c_u32(value):
    return f"0x{value & 0xffffffff:08x}u"


def mem_address(base, displacement):
    return f"static_cast<std::uint32_t>({base.lower()} + {c_u32(displacement)})"


def load_operand(operand, temp):
    kind = operand[0]
    if kind == "reg":
        reg = operand[1]
        if reg == "DL":
            return [f"{temp} = edx & 0xffu;"]
        return [f"{temp} = {reg.lower()};"]
    if kind == "imm":
        return [f"{temp} = {c_u32(operand[1])};"]
    _, base, displacement = operand
    return [
        f"if (!memory.load32({mem_address(base, displacement)}, {temp})) "
        "return LiftStatus::invalid_memory;"
    ]


def store_operand(operand, value):
    kind = operand[0]
    if kind == "reg":
        reg = operand[1]
        if reg == "DL":
            return [f"edx = (edx & 0xffffff00u) | ({value} & 0xffu);"]
        return [f"{reg.lower()} = {value};"]
    if kind == "mem":
        _, base, displacement = operand
        return [
            f"if (!memory.store32({mem_address(base, displacement)}, {value})) "
            "return LiftStatus::invalid_memory;"
        ]
    raise ValueError("immediate cannot be an instruction destination")


def instruction_body(instruction, index, addresses):
    mnemonic = instruction["mnemonic"].upper()
    operands = [parse_operand(value) for value in instruction["operands"]]
    temp = f"tmp{index}"
    lines = []

    def require(count):
        if len(operands) != count:
            raise ValueError(f"{mnemonic} expects {count} operands, got {len(operands)}")

    def load(operand_index, suffix):
        target = f"{temp}_{suffix}"
        lines.extend(load_operand(operands[operand_index], target))
        return target

    def branch_target(operand_index=0):
        if operands[operand_index][0] != "imm":
            raise ValueError(f"{mnemonic} branch target is not an immediate address")
        target = operands[operand_index][1]
        if target not in addresses:
            raise ValueError(f"branch target 0x{target:08x} is not an exported instruction")
        return f"L_{target:08x}"

    if mnemonic == "PUSH":
        require(1)
        value = load(0, "a")
        lines += [f"esp = static_cast<std::uint32_t>(esp - 4u);"]
        lines += store_operand(("mem", "ESP", 0), value)
    elif mnemonic == "POP":
        require(1)
        lines += load_operand(("mem", "ESP", 0), f"{temp}_a")
        lines += store_operand(operands[0], f"{temp}_a")
        lines += ["esp = static_cast<std::uint32_t>(esp + 4u);"]
    elif mnemonic == "MOV":
        require(2)
        value = load(1, "a")
        lines += store_operand(operands[0], value)
    elif mnemonic in {"ADD", "SUB", "CMP"}:
        require(2)
        left = load(0, "a")
        right = load(1, "b")
        if mnemonic == "ADD":
            lines += [
                f"{temp}_wide = static_cast<std::uint64_t>({left}) + {right};",
                f"{temp}_result = static_cast<std::uint32_t>({temp}_wide);",
                f"set_add_flags({left}, {right}, {temp}_result, {temp}_wide, flags);",
            ]
            lines += store_operand(operands[0], f"{temp}_result")
        else:
            lines += [
                f"{temp}_result = static_cast<std::uint32_t>({left} - {right});",
                f"set_sub_flags({left}, {right}, {temp}_result, {left} < {right}, flags);",
            ]
            if mnemonic == "SUB":
                lines += store_operand(operands[0], f"{temp}_result")
    elif mnemonic == "CDQ":
        require(0)
        lines += ["edx = (eax & 0x80000000u) ? 0xffffffffu : 0u;"]
    elif mnemonic == "IDIV":
        require(1)
        divisor = load(0, "divisor")
        lines += [
            f"if ({divisor} == 0u) return LiftStatus::divide_error;",
            f"{temp}_bits = (static_cast<std::uint64_t>(edx) << 32u) | eax;",
            f"std::memcpy(&{temp}_dividend, &{temp}_bits, sizeof({temp}_dividend));",
            f"{temp}_signed_divisor = static_cast<std::int32_t>({divisor});",
            f"if ({temp}_dividend == INT64_MIN && {temp}_signed_divisor == -1) "
            "return LiftStatus::divide_error;",
            f"{temp}_quotient = {temp}_dividend / {temp}_signed_divisor;",
            f"if ({temp}_quotient < INT32_MIN || {temp}_quotient > INT32_MAX) "
            "return LiftStatus::divide_error;",
            f"{temp}_remainder = {temp}_dividend % {temp}_signed_divisor;",
            f"eax = static_cast<std::uint32_t>(static_cast<std::int32_t>({temp}_quotient));",
            f"edx = static_cast<std::uint32_t>(static_cast<std::int32_t>({temp}_remainder));",
        ]
    elif mnemonic == "SAR":
        require(2)
        value = load(0, "a")
        shift = load(1, "b")
        lines += [
            f"{temp}_result = arithmetic_shift_right({value}, {shift} & 0x1fu);",
            f"set_logic_flags({temp}_result, flags);",
        ]
        lines += store_operand(operands[0], f"{temp}_result")
    elif mnemonic == "IMUL":
        require(3)
        left = load(1, "a")
        right = load(2, "b")
        lines += [
            f"{temp}_product = static_cast<std::int64_t>(static_cast<std::int32_t>({left})) * "
            f"static_cast<std::int64_t>(static_cast<std::int32_t>({right}));",
            f"{temp}_result = static_cast<std::uint32_t>({temp}_product);",
            f"flags.cf = flags.of = ({temp}_product < INT32_MIN || {temp}_product > INT32_MAX);",
        ]
        lines += store_operand(operands[0], f"{temp}_result")
    elif mnemonic == "SBB":
        require(2)
        left = load(0, "a")
        right = load(1, "b")
        lines += [
            f"{temp}_subtrahend = static_cast<std::uint64_t>({right}) + "
            "static_cast<std::uint64_t>(flags.cf);",
            f"{temp}_result = static_cast<std::uint32_t>(static_cast<std::uint64_t>({left}) - "
            f"{temp}_subtrahend);",
            f"set_sbb_flags({left}, {right}, flags.cf, {temp}_result, flags);",
        ]
        lines += store_operand(operands[0], f"{temp}_result")
    elif mnemonic == "NEG":
        require(1)
        value = load(0, "a")
        lines += [
            f"{temp}_result = static_cast<std::uint32_t>(0u - {value});",
            f"flags.cf = ({value} != 0u);",
            f"flags.of = ({value} == 0x80000000u);",
            f"set_logic_flags({temp}_result, flags);",
        ]
        lines += store_operand(operands[0], f"{temp}_result")
    elif mnemonic == "MOVZX":
        require(2)
        value = load(1, "a")
        lines += store_operand(operands[0], value)
    elif mnemonic == "TEST":
        require(2)
        left = load(0, "a")
        right = load(1, "b")
        lines += [
            f"{temp}_result = {left} & {right};",
            "flags.cf = false;",
            "flags.of = false;",
            f"set_logic_flags({temp}_result, flags);",
        ]
    elif mnemonic in {"JLE", "JZ"}:
        require(1)
        target = branch_target()
        if mnemonic == "JLE":
            condition = "(flags.zf || (flags.sf != flags.of))"
        else:
            condition = "flags.zf"
        lines += [f"if ({condition}) goto {target};"]
    elif mnemonic == "JMP":
        require(1)
        lines += [f"goto {branch_target()};"]
    elif mnemonic == "RET":
        require(0)
        lines += [
            "if (!memory.load32(esp, tmp0_return) || "
            "tmp0_return != FirstStaticLiftMemory::kReturnSentinel) "
            "return LiftStatus::invalid_memory;",
            "if (!memory.to_record_index(eax, record_count, result_index_local)) "
            "return LiftStatus::invalid_return;",
            "esp = static_cast<std::uint32_t>(esp + 4u);",
            "*result_index = result_index_local;",
            "return LiftStatus::ok;",
        ]
    else:
        raise ValueError(f"unsupported instruction: {mnemonic}")
    return lines


def generate_source(export, raw, csv_row):
    function = export["function"]
    instructions = function["instructions"]
    addresses = {parse_int(item["address"]) for item in instructions}
    accepted = []
    rejected = []
    bodies = []
    expected_next = EXPECTED_VA
    byte_stream = bytearray()

    if function["entry"] != f"0x{EXPECTED_VA:08x}":
        raise ValueError(f"Unexpected function entry: {function['entry']}")
    if function["body_address_count"] != str(EXPECTED_SIZE):
        raise ValueError("Ghidra body byte count does not equal the CSV size of 122.")
    if len(instructions) != 47 or function["instructions_truncated"]:
        raise ValueError("Expected exactly 47 complete instructions.")
    if function["basic_blocks_truncated"] or len(function["basic_blocks"]) != 7:
        raise ValueError("Expected exactly seven complete basic blocks.")
    if function["references_truncated"]:
        raise ValueError("Ghidra reference export is truncated.")
    if len(function["incoming_references"]) != 3:
        raise ValueError("Expected the three statically recorded incoming references.")
    if function["decompiler_status"] != "completed" or function["pseudocode_truncated"]:
        raise ValueError("Ghidra pseudocode is absent or truncated.")

    for index, instruction in enumerate(instructions):
        address = parse_int(instruction["address"])
        length = instruction["length"]
        encoded = bytes.fromhex(instruction["bytes"])
        if address != expected_next or len(encoded) != length:
            raise ValueError(f"Non-contiguous or malformed instruction at {instruction['address']}.")
        if instruction["mnemonic"].upper() not in EXPECTED_MNEMONICS:
            rejected.append({
                "address": instruction["address"],
                "mnemonic": instruction["mnemonic"],
                "reason": "opcode is outside the configured translation subset",
            })
        else:
            accepted.append({
                "address": instruction["address"],
                "bytes": instruction["bytes"],
                "mnemonic": instruction["mnemonic"],
            })
        try:
            body = instruction_body(instruction, index, addresses)
        except ValueError as error:
            rejected.append({
                "address": instruction["address"],
                "mnemonic": instruction["mnemonic"],
                "reason": str(error),
            })
            body = []
        bodies.append((instruction, body))
        expected_next += length
        byte_stream.extend(encoded)

    if rejected:
        raise UnsupportedInstructions(rejected, accepted)
    if bytes(byte_stream) != raw:
        raise ValueError("Instruction encodings from Ghidra do not match the selected PE bytes.")
    if expected_next - EXPECTED_VA != EXPECTED_SIZE:
        raise ValueError("Decoded instructions do not cover the full function size.")
    if csv_row["name"] != "FUN_00422430":
        raise ValueError(f"Unexpected Ghidra inventory name: {csv_row['name']}")
    if function["calling_convention"] != "unknown":
        raise ValueError("This first generator expects the current unknown Ghidra convention.")

    generated = [
        "// Generated from the verified Ghidra instruction export; do not edit by hand.",
        "// Source function: SporeApp.exe!0x00422430; static lowering, no x86 interpreter.",
        '#include "FirstStaticLiftRuntime.hpp"',
        "",
        "LiftStatus spore_lift_00422430(const std::uint32_t* records,",
        "                               std::size_t record_count,",
        "                               const std::uint32_t* key,",
        "                               std::size_t* result_index) {",
        "    if (result_index == nullptr ||",
        "        record_count > FirstStaticLiftMemory::kMaxRecordCount ||",
        "        (record_count != 0 && records == nullptr)) {",
        "        return LiftStatus::invalid_argument;",
        "    }",
        "    if (record_count != 0 && key == nullptr) return LiftStatus::invalid_argument;",
        "    FirstStaticLiftMemory memory(records, record_count, key);",
        "    std::uint32_t eax = 0, ecx = 0, edx = 0, ebx = 0;",
        "    std::uint32_t esp = FirstStaticLiftMemory::kEntryEsp;",
        "    std::uint32_t ebp = 0, esi = 0, edi = 0;",
        "    std::size_t result_index_local = 0;",
        "    X86Flags flags{};",
    ]
    for index, _ in enumerate(instructions):
        generated.extend([
            f"    std::uint32_t tmp{index}_a = 0, tmp{index}_b = 0, tmp{index}_divisor = 0,",
            f"        tmp{index}_result = 0, tmp{index}_return = 0;",
            f"    std::uint64_t tmp{index}_wide = 0, tmp{index}_bits = 0,",
            f"        tmp{index}_subtrahend = 0;",
            f"    std::int64_t tmp{index}_dividend = 0, tmp{index}_quotient = 0,",
            f"        tmp{index}_remainder = 0, tmp{index}_product = 0;",
            f"    std::int32_t tmp{index}_signed_divisor = 0;",
        ])
    generated.extend([
        "    if (!memory.initialize_call_frame()) return LiftStatus::invalid_memory;",
        "",
    ])
    for instruction, body in bodies:
        address = parse_int(instruction["address"])
        generated.append(
            f"L_{address:08x}: // {instruction['bytes']} "
            f"{instruction['mnemonic']} {' '.join(instruction['operands'])}".rstrip()
        )
        for line in body:
            generated.append("    " + line)
    generated.extend([
        "    return LiftStatus::invalid_control_flow;",
        "}",
        "",
    ])
    return "\n".join(generated), accepted, rejected


class UnsupportedInstructions(Exception):
    def __init__(self, rejected, accepted):
        super().__init__("One or more instructions were rejected by the static lifter.")
        self.rejected = rejected
        self.accepted = accepted


def main():
    parser = argparse.ArgumentParser(
        description="Statically lower one verified Ghidra x86 function export to C++."
    )
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--export", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--coverage", type=Path, required=True)
    args = parser.parse_args()

    coverage = {
        "target_va": f"0x{EXPECTED_VA:08X}",
        "source_sha256_expected": EXPECTED_SHA256,
        "accepted_instruction_count": 0,
        "rejected_instruction_count": 0,
        "accepted_instructions": [],
        "rejected_instructions": [],
        "status": "blocked",
    }

    try:
        sha256 = hashlib.sha256(args.exe.read_bytes()).hexdigest()
        coverage["source_sha256_actual"] = sha256
        if sha256 != EXPECTED_SHA256:
            raise ValueError("Selected executable SHA-256 does not match the exported target.")
        with args.export.open(encoding="utf-8") as stream:
            export = json.load(stream)
        if export.get("selected_source_sha256") != EXPECTED_SHA256:
            raise ValueError("Ghidra export source SHA-256 does not match the selected PE.")
        if not export.get("selected_source_is_phase4_build"):
            raise ValueError("Ghidra did not mark the source as the Phase 4 build.")
        if not export.get("user_confirmed_source_for_open_program"):
            raise ValueError("User did not confirm the source file for the open Ghidra program.")
        if export.get("language_id") != EXPECTED_LANGUAGE:
            raise ValueError(f"Unexpected Ghidra language: {export.get('language_id')!r}")
        if export.get("target_va_requested") != f"0x{EXPECTED_VA:08x}":
            raise ValueError("Ghidra export VA does not match the requested function.")
        if not export.get("function_found") or not export.get("function_starts_at_requested_address"):
            raise ValueError("Ghidra did not identify a function beginning at the requested VA.")
        csv_row = verify_inventory(args.csv, EXPECTED_VA)
        image, section_name, file_offset, raw = load_pe_section_offset(
            args.exe, EXPECTED_VA, EXPECTED_SIZE
        )
        coverage.update({
            "function_name": export["function"]["name"],
            "inventory_size": int(csv_row["size"], 0),
            "section": section_name,
            "file_offset": f"0x{file_offset:x}",
            "body_bytes_sha256": hashlib.sha256(raw).hexdigest(),
            "instructions_total": len(export["function"]["instructions"]),
        })
        if section_name != ".text":
            raise ValueError(f"Function is in unexpected section {section_name!r}.")
        generated, accepted, rejected = generate_source(export, raw, csv_row)
        coverage["accepted_instructions"] = accepted
        coverage["rejected_instructions"] = rejected
        coverage["accepted_instruction_count"] = len(accepted)
        coverage["rejected_instruction_count"] = len(rejected)
        coverage["covered_instruction_bytes"] = sum(
            len(bytes.fromhex(item["bytes"])) for item in accepted
        )
        coverage["instruction_byte_coverage_percent"] = 100.0
        coverage["generated_source_sha256"] = hashlib.sha256(
            generated.encode("utf-8")
        ).hexdigest()
        coverage["status"] = "generated"
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(generated, encoding="utf-8", newline="\n")
        print(f"Generated {len(accepted)} instructions to {args.output}")
        print(f"Verified source SHA-256: {sha256}")
    except UnsupportedInstructions as error:
        coverage["accepted_instructions"] = error.accepted
        coverage["rejected_instructions"] = error.rejected
        coverage["accepted_instruction_count"] = len(error.accepted)
        coverage["rejected_instruction_count"] = len(error.rejected)
        coverage["status"] = "rejected"
        print(str(error), file=sys.stderr)
    except Exception as error:
        coverage["error"] = f"{type(error).__name__}: {error}"
        print(coverage["error"], file=sys.stderr)
    finally:
        args.coverage.parent.mkdir(parents=True, exist_ok=True)
        args.coverage.write_text(json.dumps(coverage, indent=2) + "\n", encoding="utf-8")
        print(f"Coverage report: {args.coverage}")

    return 0 if coverage["status"] == "generated" else 1


if __name__ == "__main__":
    raise SystemExit(main())
