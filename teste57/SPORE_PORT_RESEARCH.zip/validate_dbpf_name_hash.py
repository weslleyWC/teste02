#!/usr/bin/env python3
"""Compare candidate FNV name hashes with IDs in local Spore DBPF packages."""

import argparse
import collections
import hashlib
import os
import re

import catalog_dbpf_resources as catalog


IDENTIFIER_RE = re.compile(rb"[A-Za-z0-9_./-]{1,128}")
PLACEHOLDER_RE = re.compile(
    r"PLACEHOLDER_[A-Za-z0-9][A-Za-z0-9 _-]{2,}"
)


def fnv1(data):
    value = 0x811C9DC5
    for byte in data:
        value = ((value * 0x01000193) & 0xFFFFFFFF) ^ byte
    return value


def fnv1a(data):
    value = 0x811C9DC5
    for byte in data:
        value = ((value ^ byte) * 0x01000193) & 0xFFFFFFFF
    return value


def create_state():
    return {
        "package_count": 0,
        "types": collections.Counter(),
        "groups": collections.Counter(),
        "pairs": collections.Counter(),
        "type_groups": collections.defaultdict(set),
        "type_packages": collections.defaultdict(set),
        "group_packages": collections.defaultdict(set),
        "type_output_bytes": collections.Counter(),
        "type_compressed": collections.Counter(),
        "tgi_packages": collections.defaultdict(set),
        "package_stats": {},
        "focus": collections.defaultdict(dict),
    }


def package_paths(root):
    paths = []
    for directory, _, filenames in os.walk(root):
        for filename in filenames:
            if filename.lower().endswith(".package"):
                paths.append(os.path.join(directory, filename))
    return sorted(paths, key=str.casefold)


def read_binary_strings(binary):
    with open(binary, "rb") as executable:
        data = executable.read()
    identifiers = set()
    cell_name_offsets = collections.defaultdict(set)
    for match in re.finditer(rb"[\x20-\x7e]{4,}", data):
        raw = match.group()
        for token in IDENTIFIER_RE.finditer(raw):
            name = token.group().decode("ascii")
            identifiers.add(name)
            if name.lower().startswith("cell_"):
                cell_name_offsets[name].add(match.start() + token.start())
    return data, identifiers, cell_name_offsets


def collect_focus_labels(state, focus_type):
    labels_by_instance = collections.defaultdict(set)
    packages_by_instance = collections.defaultdict(set)
    for package_name, entries in state["focus"].items():
        for (type_id, _, instance_id), item in entries.items():
            if type_id != focus_type:
                continue
            text = item["decoded"].decode("utf-16le", errors="ignore")
            labels_by_instance[instance_id].update(
                label.strip() for label in PLACEHOLDER_RE.findall(text)
            )
            packages_by_instance[instance_id].add(package_name)
    return labels_by_instance, packages_by_instance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, help="SPOREFILES directory")
    parser.add_argument("--binary", required=True, help="SporeApp.exe path")
    parser.add_argument(
        "--focus-type",
        default="0xDFAD9F51",
        help="DBPF type ID for instance-name comparisons",
    )
    args = parser.parse_args()

    root = os.path.abspath(args.root)
    binary = os.path.abspath(args.binary)
    focus_type = int(args.focus_type, 0)
    if not os.path.isdir(root):
        parser.error(f"package root does not exist: {root}")
    if not os.path.isfile(binary):
        parser.error(f"binary does not exist: {binary}")

    paths = package_paths(root)
    if not paths:
        parser.error(f"no .package files found under {root}")

    state = create_state()
    for path in paths:
        catalog.parse_package(path, root, state, focus_type)

    binary_data, identifiers, cell_name_offsets = read_binary_strings(binary)
    cell_names = set(cell_name_offsets)
    type_ids = set(state["types"])
    focus_ids = {
        instance_id
        for entries in state["focus"].values()
        for type_id, _, instance_id in entries
        if type_id == focus_type
    }

    fnv1_original_types = {
        name: fnv1(name.encode("ascii"))
        for name in identifiers
        if fnv1(name.encode("ascii")) in type_ids
    }
    fnv1_lower_types = {
        name: fnv1(name.lower().encode("ascii"))
        for name in identifiers
        if fnv1(name.lower().encode("ascii")) in type_ids
    }
    fnv1a_lower_types = {
        name: fnv1a(name.lower().encode("ascii"))
        for name in identifiers
        if fnv1a(name.lower().encode("ascii")) in type_ids
    }

    labels_by_instance, packages_by_instance = collect_focus_labels(
        state, focus_type
    )
    fnv1_original_instances = {
        name: fnv1(name.encode("ascii"))
        for name in cell_names
        if fnv1(name.encode("ascii")) in focus_ids
    }
    fnv1_lower_instances = {
        name: fnv1(name.lower().encode("ascii"))
        for name in cell_names
        if fnv1(name.lower().encode("ascii")) in focus_ids
    }
    fnv1a_lower_instances = {
        name: fnv1a(name.lower().encode("ascii"))
        for name in cell_names
        if fnv1a(name.lower().encode("ascii")) in focus_ids
    }

    print(f"binary_sha256={hashlib.sha256(binary_data).hexdigest()}")
    print(f"packages={state['package_count']} type_ids={len(type_ids)}")
    print(f"binary_identifier_tokens={len(identifiers)}")
    print(
        "type_matches: "
        f"FNV1_original={len(fnv1_original_types)} names/"
        f"{len(set(fnv1_original_types.values()))} IDs; "
        f"FNV1_lower={len(fnv1_lower_types)} names/"
        f"{len(set(fnv1_lower_types.values()))} IDs; "
        f"FNV1a_lower={len(fnv1a_lower_types)} names/"
        f"{len(set(fnv1a_lower_types.values()))} IDs"
    )
    print(
        f"cell_name_tokens={len(cell_names)} "
        f"focus_instances={len(focus_ids)}"
    )
    print(
        "instance_matches: "
        f"FNV1_original={len(fnv1_original_instances)}; "
        f"FNV1_lower={len(fnv1_lower_instances)}; "
        f"FNV1a_lower={len(fnv1a_lower_instances)}"
    )

    print("\nType candidates (lowercase FNV-1):")
    for name, type_id in sorted(fnv1_lower_types.items()):
        print(
            f"{name}\t0x{type_id:08X}\t"
            f"{state['types'][type_id]} entries"
        )

    print("\nCell instance candidates (lowercase FNV-1):")
    print("Name\tEXE file offset\tInstance ID\tPayload label\tPackages")
    for name, instance_id in sorted(fnv1_lower_instances.items()):
        labels = sorted(labels_by_instance[instance_id])
        packages = sorted(packages_by_instance[instance_id])
        print(
            f"{name}\t0x{min(cell_name_offsets[name]):X}\t"
            f"0x{instance_id:08X}\t"
            f"{', '.join(labels) if labels else '(no placeholder label)'}\t"
            f"{', '.join(packages)}"
        )


if __name__ == "__main__":
    main()
