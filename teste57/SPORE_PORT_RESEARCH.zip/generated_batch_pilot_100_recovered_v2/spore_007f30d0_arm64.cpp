#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_007f30d0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;

    L_007f30d0: // 85c9 TEST
        t0a = state.regs[1];
        t0b = state.regs[1];
        t0r = (t0a & t0b) & 0xffffffffu;
        batch_set_logic_flags(state, t0r, 32u);
    L_007f30d2: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_007f30d8;
    L_007f30d4: // 8d4104 LEA
        t2 = static_cast<std::uint32_t>(state.regs[1] + 0x00000004u);
        state.regs[0] = t2;
    L_007f30d7: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    L_007f30d8: // 33c0 XOR
        t4a = state.regs[0];
        t4b = state.regs[0];
        t4r = (t4a ^ t4b) & 0xffffffffu;
        batch_set_logic_flags(state, t4r, 32u);
        state.regs[0] = t4r;
    L_007f30da: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
