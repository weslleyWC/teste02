#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_005f79b0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;
    std::uint32_t t7 = 0, t7a = 0, t7b = 0, t7r = 0;
    std::uint32_t t8 = 0, t8a = 0, t8b = 0, t8r = 0;
    std::uint32_t t9 = 0, t9a = 0, t9b = 0, t9r = 0;
    std::uint32_t t10 = 0, t10a = 0, t10b = 0, t10r = 0;
    std::uint32_t t11 = 0, t11a = 0, t11b = 0, t11r = 0;
    std::uint32_t t12 = 0, t12a = 0, t12b = 0, t12r = 0;
    std::uint32_t t13 = 0, t13a = 0, t13b = 0, t13r = 0;

    L_005f79b0: // 8bc1 MOV
        t0 = state.regs[1];
        state.regs[0] = t0;
    L_005f79b2: // 8b08 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x00000000u), t1)) return BatchLiftStatus::invalid_memory;
        state.regs[1] = t1;
    L_005f79b4: // 8b491c MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x0000001cu), t2)) return BatchLiftStatus::invalid_memory;
        state.regs[1] = t2;
    L_005f79b7: // 8908 MOV
        t3 = state.regs[1];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[0] + 0x00000000u), t3)) return BatchLiftStatus::invalid_memory;
    L_005f79b9: // 85c9 TEST
        t4a = state.regs[1];
        t4b = state.regs[1];
        t4r = (t4a & t4b) & 0xffffffffu;
        batch_set_logic_flags(state, t4r, 32u);
    L_005f79bb: // 7513 JNZ
        if (!((state.eflags & 0x040u) != 0u)) goto L_005f79d0;
    L_005f79bd: // ba04000000 MOV
        t6 = 0x00000004u;
        state.regs[2] = t6;
    L_005f79c2: // 015004 ADD
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x00000004u), t7a)) return BatchLiftStatus::invalid_memory;
        t7b = state.regs[2];
        t7r = static_cast<std::uint32_t>(t7a + t7b) & 0xffffffffu;
        batch_set_add_flags(state, t7a, t7b, t7r, 32u);
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[0] + 0x00000004u), t7r)) return BatchLiftStatus::invalid_memory;
    L_005f79c5: // 8b4804 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x00000004u), t8)) return BatchLiftStatus::invalid_memory;
        state.regs[1] = t8;
    L_005f79c8: // 8b09 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000000u), t9)) return BatchLiftStatus::invalid_memory;
        state.regs[1] = t9;
    L_005f79ca: // 8908 MOV
        t10 = state.regs[1];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[0] + 0x00000000u), t10)) return BatchLiftStatus::invalid_memory;
    L_005f79cc: // 85c9 TEST
        t11a = state.regs[1];
        t11b = state.regs[1];
        t11r = (t11a & t11b) & 0xffffffffu;
        batch_set_logic_flags(state, t11r, 32u);
    L_005f79ce: // 74f2 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_005f79c2;
    L_005f79d0: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
