#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_005aa580(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;

    L_005aa580: // 8b442404 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[4] + 0x00000004u), t0)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t0;
    L_005aa584: // 8b542408 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[4] + 0x00000008u), t1)) return BatchLiftStatus::invalid_memory;
        state.regs[2] = t1;
    L_005aa588: // 898138010000 MOV
        t2 = state.regs[0];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[1] + 0x00000138u), t2)) return BatchLiftStatus::invalid_memory;
    L_005aa58e: // 8b44240c MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[4] + 0x0000000cu), t3)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t3;
    L_005aa592: // 89913c010000 MOV
        t4 = state.regs[2];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[1] + 0x0000013cu), t4)) return BatchLiftStatus::invalid_memory;
    L_005aa598: // 898140010000 MOV
        t5 = state.regs[0];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[1] + 0x00000140u), t5)) return BatchLiftStatus::invalid_memory;
    L_005aa59e: // c20c00 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 12u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
