#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_0054ddc0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;
    std::uint32_t t7 = 0, t7a = 0, t7b = 0, t7r = 0;
    std::uint32_t t8 = 0, t8a = 0, t8b = 0, t8r = 0;
    std::uint32_t t9 = 0, t9a = 0, t9b = 0, t9r = 0;
    std::uint32_t t10 = 0, t10a = 0, t10b = 0, t10r = 0;
    std::uint32_t t11 = 0, t11a = 0, t11b = 0, t11r = 0;

    L_0054ddc0: // 55 PUSH
        t0a = state.regs[5];
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] - 4u);
        if (!memory.store32(state.regs[4], t0a)) return BatchLiftStatus::invalid_memory;
    L_0054ddc1: // 8bec MOV
        t1 = state.regs[4];
        state.regs[5] = t1;
    L_0054ddc3: // 51 PUSH
        t2a = state.regs[1];
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] - 4u);
        if (!memory.store32(state.regs[4], t2a)) return BatchLiftStatus::invalid_memory;
    L_0054ddc4: // 894dfc MOV
        t3 = state.regs[1];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[5] + 0xfffffffcu), t3)) return BatchLiftStatus::invalid_memory;
    L_0054ddc7: // 837d0c00 CMP
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[5] + 0x0000000cu), t4a)) return BatchLiftStatus::invalid_memory;
        t4b = 0x00000000u;
        t4r = static_cast<std::uint32_t>(t4a - t4b) & 0xffffffffu;
        batch_set_sub_flags(state, t4a, t4b, t4r, 32u);
    L_0054ddcb: // 7609 JBE
        if (((state.eflags & 0x001u) != 0u) || ((state.eflags & 0x040u) != 0u)) goto L_0054ddd6;
    L_0054ddcd: // 8b4508 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[5] + 0x00000008u), t6)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t6;
    L_0054ddd0: // c700e3de0b03 MOV
        t7 = 0x030bdee3u;
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[0] + 0x00000000u), t7)) return BatchLiftStatus::invalid_memory;
    L_0054ddd6: // b801000000 MOV
        t8 = 0x00000001u;
        state.regs[0] = t8;
    L_0054dddb: // 8be5 MOV
        t9 = state.regs[5];
        state.regs[4] = t9;
    L_0054dddd: // 5d POP
        if (!memory.load32(state.regs[4], t10a)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u);
        state.regs[5] = t10a;
    L_0054ddde: // c20800 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 8u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
