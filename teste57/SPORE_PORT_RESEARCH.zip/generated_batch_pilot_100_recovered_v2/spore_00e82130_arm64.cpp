#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_00e82130(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;

    L_00e82130: // 8b01 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000000u), t0)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t0;
    L_00e82132: // 85c0 TEST
        t1a = state.regs[0];
        t1b = state.regs[0];
        t1r = (t1a & t1b) & 0xffffffffu;
        batch_set_logic_flags(state, t1r, 32u);
    L_00e82134: // 7403 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_00e82139;
    L_00e82136: // ff480c DEC
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x0000000cu), t3a)) return BatchLiftStatus::invalid_memory;
        t3r = static_cast<std::uint32_t>(t3a - 1u) & 0xffffffffu;
        batch_set_dec_flags(state, t3a, t3r, 32u);
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[0] + 0x0000000cu), t3r)) return BatchLiftStatus::invalid_memory;
    L_00e82139: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
