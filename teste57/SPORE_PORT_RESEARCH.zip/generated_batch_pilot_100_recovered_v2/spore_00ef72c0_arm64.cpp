#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_00ef72c0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;

    L_00ef72c0: // 837930ff CMP
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000030u), t0a)) return BatchLiftStatus::invalid_memory;
        t0b = 0xffffffffu;
        t0r = static_cast<std::uint32_t>(t0a - t0b) & 0xffffffffu;
        batch_set_sub_flags(state, t0a, t0b, t0r, 32u);
    L_00ef72c4: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_00ef72ca;
    L_00ef72c6: // c6413f01 MOV
        t2 = 0x00000001u;
        if (!memory.store8(static_cast<std::uint32_t>(state.regs[1] + 0x0000003fu), t2)) return BatchLiftStatus::invalid_memory;
    L_00ef72ca: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
