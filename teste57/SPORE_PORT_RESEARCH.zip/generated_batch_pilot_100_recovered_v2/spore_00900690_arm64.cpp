#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_00900690(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;

    L_00900690: // 8b4140 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000040u), t0)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t0;
    L_00900693: // 85c0 TEST
        t1a = state.regs[0];
        t1b = state.regs[0];
        t1r = (t1a & t1b) & 0xffffffffu;
        batch_set_logic_flags(state, t1r, 32u);
    L_00900695: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_0090069b;
    L_00900697: // 8b4008 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x00000008u), t3)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t3;
    L_0090069a: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    L_0090069b: // 33c0 XOR
        t5a = state.regs[0];
        t5b = state.regs[0];
        t5r = (t5a ^ t5b) & 0xffffffffu;
        batch_set_logic_flags(state, t5r, 32u);
        state.regs[0] = t5r;
    L_0090069d: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
