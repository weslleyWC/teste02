#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_00485900(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;
    std::uint32_t t7 = 0, t7a = 0, t7b = 0, t7r = 0;
    std::uint32_t t8 = 0, t8a = 0, t8b = 0, t8r = 0;
    std::uint32_t t9 = 0, t9a = 0, t9b = 0, t9r = 0;
    std::uint32_t t10 = 0, t10a = 0, t10b = 0, t10r = 0;
    std::uint32_t t11 = 0, t11a = 0, t11b = 0, t11r = 0;
    std::uint32_t t12 = 0, t12a = 0, t12b = 0, t12r = 0;
    std::uint32_t t13 = 0, t13a = 0, t13b = 0, t13r = 0;
    std::uint32_t t14 = 0, t14a = 0, t14b = 0, t14r = 0;

    L_00485900: // 55 PUSH
        t0a = state.regs[5];
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] - 4u);
        if (!memory.store32(state.regs[4], t0a)) return BatchLiftStatus::invalid_memory;
    L_00485901: // 8bec MOV
        t1 = state.regs[4];
        state.regs[5] = t1;
    L_00485903: // 51 PUSH
        t2a = state.regs[1];
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] - 4u);
        if (!memory.store32(state.regs[4], t2a)) return BatchLiftStatus::invalid_memory;
    L_00485904: // 894dfc MOV
        t3 = state.regs[1];
        if (!memory.store32(static_cast<std::uint32_t>(state.regs[5] + 0xfffffffcu), t3)) return BatchLiftStatus::invalid_memory;
    L_00485907: // 8b45fc MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[5] + 0xfffffffcu), t4)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t4;
    L_0048590a: // 83780400 CMP
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[0] + 0x00000004u), t5a)) return BatchLiftStatus::invalid_memory;
        t5b = 0x00000000u;
        t5r = static_cast<std::uint32_t>(t5a - t5b) & 0xffffffffu;
        batch_set_sub_flags(state, t5a, t5b, t5r, 32u);
    L_0048590e: // 740d JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_0048591d;
    L_00485910: // 8b4dfc MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[5] + 0xfffffffcu), t7)) return BatchLiftStatus::invalid_memory;
        state.regs[1] = t7;
    L_00485913: // 8b5104 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000004u), t8)) return BatchLiftStatus::invalid_memory;
        state.regs[2] = t8;
    L_00485916: // 8b4204 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[2] + 0x00000004u), t9)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t9;
    L_00485919: // eb04 JMP
        goto L_0048591f;
    L_0048591d: // 33c0 XOR
        t11a = state.regs[0];
        t11b = state.regs[0];
        t11r = (t11a ^ t11b) & 0xffffffffu;
        batch_set_logic_flags(state, t11r, 32u);
        state.regs[0] = t11r;
    L_0048591f: // 8be5 MOV
        t12 = state.regs[5];
        state.regs[4] = t12;
    L_00485921: // 5d POP
        if (!memory.load32(state.regs[4], t13a)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u);
        state.regs[5] = t13a;
    L_00485922: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
