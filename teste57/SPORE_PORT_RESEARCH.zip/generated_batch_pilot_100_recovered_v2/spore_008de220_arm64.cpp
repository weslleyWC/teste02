#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_008de220(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;

    L_008de220: // 80790400 CMP
        if (!memory.load8(static_cast<std::uint32_t>(state.regs[1] + 0x00000004u), t0a)) return BatchLiftStatus::invalid_memory;
        t0b = 0x00000000u;
        t0r = static_cast<std::uint32_t>(t0a - t0b) & 0x000000ffu;
        batch_set_sub_flags(state, t0a, t0b, t0r, 8u);
    L_008de224: // b001 MOV
        t1 = 0x00000001u;
        state.regs[0] = (state.regs[0] & 0xffffff00u) | ((t1 << 0u) & 0x000000ffu);
    L_008de226: // 7503 JNZ
        if (!((state.eflags & 0x040u) != 0u)) goto L_008de22b;
    L_008de228: // 884104 MOV
        t3 = state.regs[0] & 0x000000ffu;
        if (!memory.store8(static_cast<std::uint32_t>(state.regs[1] + 0x00000004u), t3)) return BatchLiftStatus::invalid_memory;
    L_008de22b: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
