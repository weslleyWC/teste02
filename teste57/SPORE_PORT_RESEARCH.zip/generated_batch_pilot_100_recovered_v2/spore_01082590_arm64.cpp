#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_01082590(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;

    L_01082590: // 6683790400 CMP
        if (!memory.load16(static_cast<std::uint32_t>(state.regs[1] + 0x00000004u), t0a)) return BatchLiftStatus::invalid_memory;
        t0b = 0x00000000u;
        t0r = static_cast<std::uint32_t>(t0a - t0b) & 0x0000ffffu;
        batch_set_sub_flags(state, t0a, t0b, t0r, 16u);
    L_01082595: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_0108259b;
    L_01082597: // 66ff4106 INC
        if (!memory.load16(static_cast<std::uint32_t>(state.regs[1] + 0x00000006u), t2a)) return BatchLiftStatus::invalid_memory;
        t2r = static_cast<std::uint32_t>(t2a + 1u) & 0x0000ffffu;
        batch_set_inc_flags(state, t2a, t2r, 16u);
        if (!memory.store16(static_cast<std::uint32_t>(state.regs[1] + 0x00000006u), t2r)) return BatchLiftStatus::invalid_memory;
    L_0108259b: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
