#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_01133b60(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;

    L_01133b60: // 83791000 CMP
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000010u), t0a)) return BatchLiftStatus::invalid_memory;
        t0b = 0x00000000u;
        t0r = static_cast<std::uint32_t>(t0a - t0b) & 0xffffffffu;
        batch_set_sub_flags(state, t0a, t0b, t0r, 32u);
    L_01133b64: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_01133b6a;
    L_01133b66: // 8b4110 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000010u), t2)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t2;
    L_01133b69: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    L_01133b6a: // 33c0 XOR
        t4a = state.regs[0];
        t4b = state.regs[0];
        t4r = (t4a ^ t4b) & 0xffffffffu;
        batch_set_logic_flags(state, t4r, 32u);
        state.regs[0] = t4r;
    L_01133b6c: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
