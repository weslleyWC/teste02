#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_005c2cd0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;
    std::uint32_t t5 = 0, t5a = 0, t5b = 0, t5r = 0;
    std::uint32_t t6 = 0, t6a = 0, t6b = 0, t6r = 0;

    L_005c2cd0: // 8b416c MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x0000006cu), t0)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t0;
    L_005c2cd3: // 85c0 TEST
        t1a = state.regs[0];
        t1b = state.regs[0];
        t1r = (t1a & t1b) & 0xffffffffu;
        batch_set_logic_flags(state, t1r, 32u);
    L_005c2cd5: // 7404 JZ
        if (((state.eflags & 0x040u) != 0u)) goto L_005c2cdb;
    L_005c2cd7: // 8a4050 MOV
        if (!memory.load8(static_cast<std::uint32_t>(state.regs[0] + 0x00000050u), t3)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = (state.regs[0] & 0xffffff00u) | ((t3 << 0u) & 0x000000ffu);
    L_005c2cda: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    L_005c2cdb: // 32c0 XOR
        t5a = state.regs[0] & 0x000000ffu;
        t5b = state.regs[0] & 0x000000ffu;
        t5r = (t5a ^ t5b) & 0x000000ffu;
        batch_set_logic_flags(state, t5r, 8u);
        state.regs[0] = (state.regs[0] & 0xffffff00u) | ((t5r << 0u) & 0x000000ffu);
    L_005c2cdd: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
