#include "BatchStaticLiftRuntime.hpp"


BatchLiftStatus spore_lift_00a02bd0(BatchLiftMemory& memory, BatchLiftState& state) {
    std::uint32_t t0 = 0, t0a = 0, t0b = 0, t0r = 0;
    std::uint32_t t1 = 0, t1a = 0, t1b = 0, t1r = 0;
    std::uint32_t t2 = 0, t2a = 0, t2b = 0, t2r = 0;
    std::uint32_t t3 = 0, t3a = 0, t3b = 0, t3r = 0;
    std::uint32_t t4 = 0, t4a = 0, t4b = 0, t4r = 0;

    L_00a02bd0: // 8b4154 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000054u), t0)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t0;
    L_00a02bd3: // 83f804 CMP
        t1a = state.regs[0];
        t1b = 0x00000004u;
        t1r = static_cast<std::uint32_t>(t1a - t1b) & 0xffffffffu;
        batch_set_sub_flags(state, t1a, t1b, t1r, 32u);
    L_00a02bd6: // 7503 JNZ
        if (!((state.eflags & 0x040u) != 0u)) goto L_00a02bdb;
    L_00a02bd8: // 8b4150 MOV
        if (!memory.load32(static_cast<std::uint32_t>(state.regs[1] + 0x00000050u), t3)) return BatchLiftStatus::invalid_memory;
        state.regs[0] = t3;
    L_00a02bdb: // c3 RET
        if (!memory.load32(state.regs[4], state.eip)) return BatchLiftStatus::invalid_memory;
        state.regs[4] = static_cast<std::uint32_t>(state.regs[4] + 4u + 0u);
        return BatchLiftStatus::returned;
    return BatchLiftStatus::invalid_control_flow;
}
