#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>

#if !defined(_M_IX86)
#error This reference harness must run as a native 32-bit x86 process.
#endif

namespace {

constexpr std::array<std::uint8_t, 12> kPointerReadBytes{{
    0x8b, 0x01, 0x85, 0xc0, 0x74, 0x03, 0x8b, 0x00, 0xc3, 0x33, 0xc0, 0xc3,
}};
constexpr std::array<std::uint8_t, 12> kStateValueBytes{{
    0x8b, 0x41, 0x54, 0x83, 0xf8, 0x04, 0x75, 0x03, 0x8b, 0x41, 0x50, 0xc3,
}};
constexpr std::array<std::uint8_t, 11> kStateWriteBytes{{
    0x83, 0x79, 0x30, 0xff, 0x74, 0x04, 0xc6, 0x41, 0x3f, 0x01, 0xc3,
}};

using ThiscallFunction = std::uint32_t(__thiscall*)(std::uint32_t*);
using StateFunction = std::uint32_t(__thiscall*)(std::uint8_t*);
using VoidStateFunction = void(__thiscall*)(std::uint8_t*);

bool read_function_bytes(
    const char* executable_path,
    std::uint32_t va,
    const std::uint8_t* expected,
    std::size_t length,
    void** executable_code) {
    std::ifstream input(executable_path, std::ios::binary);
    if (!input) {
        std::fprintf(stderr, "cannot open selected SporeApp.exe\n");
        return false;
    }

    IMAGE_DOS_HEADER dos{};
    input.read(reinterpret_cast<char*>(&dos), sizeof(dos));
    if (!input || dos.e_magic != IMAGE_DOS_SIGNATURE || dos.e_lfanew <= 0) {
        std::fprintf(stderr, "invalid PE DOS header\n");
        return false;
    }
    input.seekg(dos.e_lfanew, std::ios::beg);
    DWORD signature = 0;
    IMAGE_FILE_HEADER file_header{};
    IMAGE_OPTIONAL_HEADER32 optional_header{};
    input.read(reinterpret_cast<char*>(&signature), sizeof(signature));
    input.read(reinterpret_cast<char*>(&file_header), sizeof(file_header));
    input.read(reinterpret_cast<char*>(&optional_header), sizeof(optional_header));
    if (!input || signature != IMAGE_NT_SIGNATURE ||
        file_header.Machine != IMAGE_FILE_MACHINE_I386 ||
        optional_header.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) {
        std::fprintf(stderr, "selected executable is not a PE32 x86 image\n");
        return false;
    }

    const std::uint32_t rva = va - optional_header.ImageBase;
    input.seekg(
        dos.e_lfanew + static_cast<std::streamoff>(sizeof(DWORD) + sizeof(IMAGE_FILE_HEADER)) +
            file_header.SizeOfOptionalHeader,
        std::ios::beg);
    std::uint32_t raw_offset = 0;
    bool found_section = false;
    for (unsigned index = 0; index < file_header.NumberOfSections; ++index) {
        IMAGE_SECTION_HEADER section{};
        input.read(reinterpret_cast<char*>(&section), sizeof(section));
        if (!input) {
            std::fprintf(stderr, "truncated PE section table\n");
            return false;
        }
        const std::uint32_t span = (std::max)(
            section.Misc.VirtualSize, section.SizeOfRawData);
        if (section.VirtualAddress <= rva &&
            static_cast<std::uint64_t>(rva - section.VirtualAddress) + length <= span) {
            if (rva - section.VirtualAddress + length > section.SizeOfRawData) {
                std::fprintf(stderr, "function VA is not fully backed by PE raw data\n");
                return false;
            }
            raw_offset = section.PointerToRawData + rva - section.VirtualAddress;
            found_section = true;
            break;
        }
    }
    if (!found_section) {
        std::fprintf(stderr, "function VA is not in a PE section\n");
        return false;
    }

    std::array<std::uint8_t, 64> original{};
    if (length > original.size()) {
        std::fprintf(stderr, "unexpected function size\n");
        return false;
    }
    input.seekg(raw_offset, std::ios::beg);
    input.read(reinterpret_cast<char*>(original.data()), static_cast<std::streamsize>(length));
    if (input.gcount() != static_cast<std::streamsize>(length) ||
        std::memcmp(original.data(), expected, length) != 0) {
        std::fprintf(stderr, "PE bytes differ from the verified Ghidra export at 0x%08x\n", va);
        return false;
    }

    void* memory = VirtualAlloc(
        nullptr, length, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == nullptr) {
        std::fprintf(stderr, "VirtualAlloc failed: %lu\n", GetLastError());
        return false;
    }
    std::memcpy(memory, original.data(), length);
    DWORD previous_protection = 0;
    if (!VirtualProtect(memory, length, PAGE_EXECUTE_READ, &previous_protection) ||
        !FlushInstructionCache(GetCurrentProcess(), memory, length)) {
        std::fprintf(stderr, "could not protect original code RX: %lu\n", GetLastError());
        VirtualFree(memory, 0, MEM_RELEASE);
        return false;
    }
    *executable_code = memory;
    return true;
}

bool check_case(const char* label, std::uint32_t actual, std::uint32_t expected) {
    const bool passed = actual == expected;
    std::printf(
        "case=%s result=%08x expected=%08x PASS=%u\n",
        label,
        actual,
        expected,
        passed ? 1u : 0u);
    return passed;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: BatchStaticLiftX86Reference.exe <selected SporeApp.exe>\n");
        return 2;
    }

    std::array<void*, 3> code{};
    if (!read_function_bytes(
            argv[1], 0x00922a80u, kPointerReadBytes.data(), kPointerReadBytes.size(), &code[0]) ||
        !read_function_bytes(
            argv[1], 0x00a02bd0u, kStateValueBytes.data(), kStateValueBytes.size(), &code[1]) ||
        !read_function_bytes(
            argv[1], 0x00ef72c0u, kStateWriteBytes.data(), kStateWriteBytes.size(), &code[2])) {
        for (void* address : code) {
            if (address != nullptr) VirtualFree(address, 0, MEM_RELEASE);
        }
        return 2;
    }

    const auto pointer_read = reinterpret_cast<ThiscallFunction>(code[0]);
    const auto state_value = reinterpret_cast<StateFunction>(code[1]);
    const auto state_write = reinterpret_cast<VoidStateFunction>(code[2]);
    std::size_t failures = 0;

    std::uint32_t root_value = 0;
    std::uint32_t pointed_value = 0x87654321u;
    root_value = reinterpret_cast<std::uint32_t>(&pointed_value);
    failures += !check_case(
        "00922a80_value",
        pointer_read(&root_value),
        pointed_value);
    root_value = 0;
    failures += !check_case("00922a80_null", pointer_read(&root_value), 0);

    alignas(4) std::array<std::uint8_t, 0x58> object{};
    auto* state = reinterpret_cast<std::uint32_t*>(object.data());
    state[0x54 / 4] = 3;
    state[0x50 / 4] = 0xabcdef01u;
    failures += !check_case("00a02bd0_nonfour", state_value(object.data()), 3);
    state[0x54 / 4] = 4;
    failures += !check_case(
        "00a02bd0_four", state_value(object.data()), 0xabcdef01u);
    state[0x54 / 4] = 0xffffffffu;
    failures += !check_case(
        "00a02bd0_max", state_value(object.data()), 0xffffffffu);

    alignas(4) std::array<std::uint8_t, 0x40> writable_object{};
    std::uint32_t status = 0;
    std::memcpy(writable_object.data() + 0x30, &status, sizeof(status));
    writable_object[0x3f] = 0x7a;
    state_write(writable_object.data());
    failures += !check_case("00ef72c0_write", writable_object[0x3f], 1);
    status = 0xffffffffu;
    std::memcpy(writable_object.data() + 0x30, &status, sizeof(status));
    writable_object[0x3f] = 0x7a;
    state_write(writable_object.data());
    failures += !check_case("00ef72c0_skip", writable_object[0x3f], 0x7a);

    std::printf("x86 summary cases=7 failures=%zu\n", failures);
    for (void* address : code) VirtualFree(address, 0, MEM_RELEASE);
    return failures == 0 ? 0 : 1;
}
