import json
import tempfile
import unittest
from pathlib import Path

import compare_batch_lift_execution as execution_comparison
import compare_static_lift_reports as report_comparison


class StaticLiftComparisonTests(unittest.TestCase):
    def make_report(self, accepted_count, accepted_bytes, addresses=None):
        addresses = addresses or list(range(0x401000, 0x401000 + 30 * 0x10, 0x10))
        functions = []
        if len(addresses) == 30:
            boundaries = (10, 20, 30)
            selection_counts = {
                "small": 10,
                "medium": 10,
                "conditional_branch": 10,
            }
        elif len(addresses) == 100:
            boundaries = (30, 60, 100)
            selection_counts = {
                "small": 30,
                "medium": 30,
                "conditional_branch": 40,
            }
        else:
            raise ValueError(f"unsupported fixture pilot size: {len(addresses)}")
        strata = ("small", "medium", "conditional_branch")
        for index, address in enumerate(addresses):
            status = "accepted" if index < accepted_count else "rejected"
            stratum_index = next(
                position for position, boundary in enumerate(boundaries)
                if index < boundary
            )
            functions.append({
                "address": f"0x{address:08x}",
                "name": f"FUN_{address:08x}",
                "selection_stratum": strata[stratum_index],
                "status": status,
                "rejection_reasons": [] if status == "accepted" else ["fixture rejection"],
                "instruction_bytes": 4,
                "verified_bytes": [],
            })
        return {
            "schema": "spore-static-lift-batch-report-v1",
            "source_sha256": "a" * 64,
            "pilot_size": len(functions),
            "accepted_function_count": accepted_count,
            "rejected_function_count": len(functions) - accepted_count,
            "accepted_unique_instruction_bytes": accepted_bytes,
            "exported_unique_instruction_bytes": 454,
            "accepted_bytes_percent_of_pilot_export": round(
                accepted_bytes * 100.0 / 454, 2
            ),
            "selection_counts": selection_counts,
            "rejection_counts_by_kind": {},
            "functions": functions,
        }

    def test_comparison_requires_same_fixed_pilot_and_reports_delta(self):
        baseline = self.make_report(12, 66)
        candidate = self.make_report(15, 99)
        with tempfile.TemporaryDirectory(prefix="spore_lift_compare_") as temporary:
            root = Path(temporary)
            old_path = root / "old.json"
            new_path = root / "new.json"
            old_path.write_text(json.dumps(baseline), encoding="utf-8")
            new_path.write_text(json.dumps(candidate), encoding="utf-8")

            result = report_comparison.compare_reports(old_path, new_path)

        self.assertEqual(result["same_pilot_function_count"], 30)
        self.assertEqual(result["accepted_functions"]["delta"], 3)
        self.assertEqual(result["accepted_unique_instruction_bytes"]["delta"], 33)

    def test_comparison_rejects_different_function_sets(self):
        baseline = self.make_report(12, 66)
        changed_addresses = list(range(0x401000, 0x401000 + 29 * 0x10, 0x10))
        changed_addresses.append(0x402000)
        candidate = self.make_report(15, 99, changed_addresses)
        with tempfile.TemporaryDirectory(prefix="spore_lift_compare_") as temporary:
            root = Path(temporary)
            old_path = root / "old.json"
            new_path = root / "new.json"
            old_path.write_text(json.dumps(baseline), encoding="utf-8")
            new_path.write_text(json.dumps(candidate), encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "same pilot addresses"):
                report_comparison.compare_reports(old_path, new_path)

    def test_comparison_accepts_nested_30_to_100_export(self):
        small = list(range(0x401000, 0x401000 + 30 * 0x10, 0x10))
        medium = list(range(0x402000, 0x402000 + 30 * 0x10, 0x10))
        branches = list(range(0x403000, 0x403000 + 40 * 0x10, 0x10))
        baseline_addresses = small[:10] + medium[:10] + branches[:10]
        candidate_addresses = small + medium + branches
        baseline = self.make_report(12, 66, baseline_addresses)
        candidate = self.make_report(0, 0, candidate_addresses)
        baseline_by_address = {
            function["address"]: function for function in baseline["functions"]
        }
        improved_addresses = {
            function["address"]
            for function in baseline["functions"][12:15]
        }
        new_accepted = 0
        for index, function in enumerate(candidate["functions"]):
            previous = baseline_by_address.get(function["address"])
            accepted = (
                previous is not None and previous["status"] == "accepted"
            ) or function["address"] in improved_addresses
            if previous is None and new_accepted < 15:
                accepted = True
                new_accepted += 1
            function["status"] = "accepted" if accepted else "rejected"
            function["rejection_reasons"] = [] if accepted else ["fixture rejection"]
        candidate["accepted_function_count"] = 30
        candidate["rejected_function_count"] = 70

        with tempfile.TemporaryDirectory(prefix="spore_lift_compare_") as temporary:
            root = Path(temporary)
            old_path = root / "old.json"
            new_path = root / "new.json"
            old_path.write_text(json.dumps(baseline), encoding="utf-8")
            new_path.write_text(json.dumps(candidate), encoding="utf-8")

            result = report_comparison.compare_reports(old_path, new_path)

        self.assertEqual(result["relationship"], "nested_expansion")
        self.assertEqual(result["same_pilot_function_count"], 30)
        self.assertEqual(result["added_function_count"], 70)
        self.assertEqual(result["shared_function_acceptance"]["baseline"], 12)
        self.assertEqual(result["shared_function_acceptance"]["candidate"], 15)
        self.assertEqual(result["shared_function_acceptance"]["delta"], 3)
        self.assertEqual(result["added_functions"]["accepted"], 15)

    def test_execution_log_parser_accepts_utf16_device_output(self):
        output = "".join(
            f"case={case} result=00000000 expected=00000000 status=0 PASS=1\r\n"
            for case in sorted(execution_comparison.EXPECTED_CASES)
        ) + "arm64 summary cases=7 failures=0\r\n"
        with tempfile.TemporaryDirectory(prefix="spore_lift_log_") as temporary:
            log_path = Path(temporary) / "device.log"
            log_path.write_bytes(output.encode("utf-16"))

            result = execution_comparison.parse_log(log_path, "arm64")

        self.assertEqual(set(result), execution_comparison.EXPECTED_CASES)

    def test_execution_log_parser_rejects_empty_or_incomplete_cases(self):
        with tempfile.TemporaryDirectory(prefix="spore_lift_log_") as temporary:
            log_path = Path(temporary) / "device.log"
            log_path.write_text(
                "arm64 summary cases=0 failures=0\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "no test cases"):
                execution_comparison.parse_log(log_path, "arm64")

            log_path.write_text(
                "case=00922a80_null result=00000000 expected=00000000 "
                "status=0 PASS=1\narm64 summary cases=1 failures=0\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "expected set"):
                execution_comparison.parse_log(log_path, "arm64")


if __name__ == "__main__":
    unittest.main()
