// Generated from the verified Ghidra instruction export; do not hand-edit.
// Source: SporeApp.exe!0x00479c00; static lowering, no x86 interpreter.
#include "SporeCopyLiftRuntime.hpp"

CopyLiftStatus spore_lift_00479c00(
    CopyLiftMemory& memory,
    std::uint32_t out_pointer,
    std::uint32_t source_begin,
    std::uint32_t source_end,
    std::uint32_t destination,
    std::uint32_t* returned_out_pointer) {
    std::uint32_t eax = 0, ecx = 0, edx = 0, ebx = 0;
    std::uint32_t esp = CopyLiftMemory::kEntryEsp, ebp = 0, esi = 0, edi = 0;
    std::uint32_t op_value = 0, op_left = 0, op_right = 0;
    std::uint32_t op_result = 0, op_return = 0, x87_top = 0, x87_depth = 0;
    std::uint64_t op_wide = 0;
    std::array<std::uint32_t, 8> x87{};
    bool zf = false;
    (void)source_begin; (void)source_end; (void)destination; (void)out_pointer;
    if (!memory.initialize_call_frame(out_pointer, source_begin, source_end, destination))
        return CopyLiftStatus::invalid_memory;

L_00479c00: // 55 PUSH EBP
    op_value = ebp;
    esp = static_cast<std::uint32_t>(esp - 4u);
    if (!memory.store32(esp, op_value)) return CopyLiftStatus::invalid_memory;
L_00479c01: // 8bec MOV EBP ESP
    op_value = esp;
    ebp = op_value;
L_00479c03: // 83ec14 SUB ESP 0x14
    op_value = esp;
    op_left = op_value;
    op_value = 0x00000014u;
    op_right = op_value;
    op_result = static_cast<std::uint32_t>(op_left - op_right);
    zf = op_result == 0;
    esp = op_result;
L_00479c06: // 8b4514 MOV EAX dword ptr [EBP + 0x14]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000014u), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c09: // 8945fc MOV dword ptr [EBP + -0x4] EAX
    op_value = eax;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c0c: // eb12 JMP 0x00479c20
    goto L_00479c20;
L_00479c0e: // 8b4d0c MOV ECX dword ptr [EBP + 0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x0000000cu), op_value)) return CopyLiftStatus::invalid_memory;
    ecx = op_value;
L_00479c11: // 83c108 ADD ECX 0x8
    op_value = ecx;
    op_left = op_value;
    op_value = 0x00000008u;
    op_right = op_value;
    op_wide = static_cast<std::uint64_t>(op_left) + op_right;
    op_result = static_cast<std::uint32_t>(op_wide);
    zf = op_result == 0;
    ecx = op_result;
L_00479c14: // 894d0c MOV dword ptr [EBP + 0xc] ECX
    op_value = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0x0000000cu), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c17: // 8b55fc MOV EDX dword ptr [EBP + -0x4]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), op_value)) return CopyLiftStatus::invalid_memory;
    edx = op_value;
L_00479c1a: // 83c208 ADD EDX 0x8
    op_value = edx;
    op_left = op_value;
    op_value = 0x00000008u;
    op_right = op_value;
    op_wide = static_cast<std::uint64_t>(op_left) + op_right;
    op_result = static_cast<std::uint32_t>(op_wide);
    zf = op_result == 0;
    edx = op_result;
L_00479c1d: // 8955fc MOV dword ptr [EBP + -0x4] EDX
    op_value = edx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c20: // 8b450c MOV EAX dword ptr [EBP + 0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x0000000cu), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c23: // 33c9 XOR ECX ECX
    op_value = ecx;
    op_left = op_value;
    op_value = ecx;
    op_right = op_value;
    op_result = op_left & op_right;
    zf = op_result == 0;
    ecx = op_result;
L_00479c25: // 3b4510 CMP EAX dword ptr [EBP + 0x10]
    op_value = eax;
    op_left = op_value;
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000010u), op_value)) return CopyLiftStatus::invalid_memory;
    op_right = op_value;
    op_result = static_cast<std::uint32_t>(op_left - op_right);
    zf = op_result == 0;
L_00479c28: // 0f95c1 SETNZ CL
    ecx = (ecx & 0xffffff00u) | (!zf ? 1u : 0u & 0xffu);
L_00479c2b: // 0fb6d1 MOVZX EDX CL
    op_value = ecx & 0xffu;
    edx = op_value;
L_00479c2e: // 85d2 TEST EDX EDX
    op_value = edx;
    op_left = op_value;
    op_value = edx;
    op_right = op_value;
    op_result = op_left & op_right;
    zf = op_result == 0;
L_00479c30: // 743f JZ 0x00479c71
    if (zf) goto L_00479c71;
L_00479c32: // 8b45fc MOV EAX dword ptr [EBP + -0x4]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c35: // 8945f4 MOV dword ptr [EBP + -0xc] EAX
    op_value = eax;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff4u), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c38: // 8b4df4 MOV ECX dword ptr [EBP + -0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff4u), op_value)) return CopyLiftStatus::invalid_memory;
    ecx = op_value;
L_00479c3b: // 894df8 MOV dword ptr [EBP + -0x8] ECX
    op_value = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c3e: // 837df800 CMP dword ptr [EBP + -0x8] 0x0
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), op_value)) return CopyLiftStatus::invalid_memory;
    op_left = op_value;
    op_value = 0x00000000u;
    op_right = op_value;
    op_result = static_cast<std::uint32_t>(op_left - op_right);
    zf = op_result == 0;
L_00479c42: // 7424 JZ 0x00479c68
    if (zf) goto L_00479c68;
L_00479c44: // 8b550c MOV EDX dword ptr [EBP + 0xc]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x0000000cu), op_value)) return CopyLiftStatus::invalid_memory;
    edx = op_value;
L_00479c47: // 8955f0 MOV dword ptr [EBP + -0x10] EDX
    op_value = edx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xfffffff0u), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c4a: // 8b45f8 MOV EAX dword ptr [EBP + -0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c4d: // 8b4df0 MOV ECX dword ptr [EBP + -0x10]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff0u), op_value)) return CopyLiftStatus::invalid_memory;
    ecx = op_value;
L_00479c50: // d901 FLD float ptr [ECX]
    if (!memory.load32(static_cast<std::uint32_t>(ecx + 0x00000000u), op_value)) return CopyLiftStatus::invalid_memory;
    if (x87_depth >= 8u) return CopyLiftStatus::invalid_control_flow;
    x87_top = (x87_top + 7u) & 7u;
    x87[x87_top] = x87_roundtrip_f32_bits(op_value);
    ++x87_depth;
L_00479c52: // d918 FSTP float ptr [EAX]
    if (x87_depth == 0u) return CopyLiftStatus::invalid_control_flow;
    if (!memory.store32(static_cast<std::uint32_t>(eax + 0x00000000u), x87[x87_top])) return CopyLiftStatus::invalid_memory;
    x87_top = (x87_top + 1u) & 7u;
    --x87_depth;
L_00479c54: // 8b55f8 MOV EDX dword ptr [EBP + -0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), op_value)) return CopyLiftStatus::invalid_memory;
    edx = op_value;
L_00479c57: // 8b45f0 MOV EAX dword ptr [EBP + -0x10]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff0u), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c5a: // d94004 FLD float ptr [EAX + 0x4]
    if (!memory.load32(static_cast<std::uint32_t>(eax + 0x00000004u), op_value)) return CopyLiftStatus::invalid_memory;
    if (x87_depth >= 8u) return CopyLiftStatus::invalid_control_flow;
    x87_top = (x87_top + 7u) & 7u;
    x87[x87_top] = x87_roundtrip_f32_bits(op_value);
    ++x87_depth;
L_00479c5d: // d95a04 FSTP float ptr [EDX + 0x4]
    if (x87_depth == 0u) return CopyLiftStatus::invalid_control_flow;
    if (!memory.store32(static_cast<std::uint32_t>(edx + 0x00000004u), x87[x87_top])) return CopyLiftStatus::invalid_memory;
    x87_top = (x87_top + 1u) & 7u;
    --x87_depth;
L_00479c60: // 8b4df8 MOV ECX dword ptr [EBP + -0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffff8u), op_value)) return CopyLiftStatus::invalid_memory;
    ecx = op_value;
L_00479c63: // 894dec MOV dword ptr [EBP + -0x14] ECX
    op_value = ecx;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xffffffecu), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c66: // eb07 JMP 0x00479c6f
    goto L_00479c6f;
L_00479c68: // c745ec00000000 MOV dword ptr [EBP + -0x14] 0x0
    op_value = 0x00000000u;
    if (!memory.store32(static_cast<std::uint32_t>(ebp + 0xffffffecu), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c6f: // eb9d JMP 0x00479c0e
    goto L_00479c0e;
L_00479c71: // 8b5508 MOV EDX dword ptr [EBP + 0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000008u), op_value)) return CopyLiftStatus::invalid_memory;
    edx = op_value;
L_00479c74: // 8b45fc MOV EAX dword ptr [EBP + -0x4]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0xfffffffcu), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c77: // 8902 MOV dword ptr [EDX] EAX
    op_value = eax;
    if (!memory.store32(static_cast<std::uint32_t>(edx + 0x00000000u), op_value)) return CopyLiftStatus::invalid_memory;
L_00479c79: // 8b4508 MOV EAX dword ptr [EBP + 0x8]
    if (!memory.load32(static_cast<std::uint32_t>(ebp + 0x00000008u), op_value)) return CopyLiftStatus::invalid_memory;
    eax = op_value;
L_00479c7c: // 8be5 MOV ESP EBP
    op_value = ebp;
    esp = op_value;
L_00479c7e: // 5d POP EBP
    if (!memory.load32(esp, op_value)) return CopyLiftStatus::invalid_memory;
    ebp = op_value;
    esp = static_cast<std::uint32_t>(esp + 4u);
L_00479c7f: // c3 RET
    if (!memory.load32(esp, op_return) || op_return != CopyLiftMemory::kReturnSentinel) return CopyLiftStatus::invalid_memory;
    if (x87_depth != 0u) return CopyLiftStatus::invalid_control_flow;
    if (returned_out_pointer == nullptr) return CopyLiftStatus::invalid_memory;
    *returned_out_pointer = eax;
    esp = static_cast<std::uint32_t>(esp + 4u);
    return CopyLiftStatus::ok;
    return CopyLiftStatus::invalid_control_flow;
}
