Correção candidata v4 — Box64/MangoHud.
Copie src/main/java/.../MainActivity.java e src/main/assets/sch1levo-runtime para app/src/main/ nas mesmas subpastas, compile e instale. Execute RUN COMPATIBILITY CHECK.
Define MANGOHUD_CONFIG=no_display somente quando ausente/vazio. Evita consulta automática de usuário no Box64; não altera HOME do ambiente.
Evidência no libbox64.so fornecido: initialize consulta MANGOHUD_CONFIG em 0x34B32804 e MANGOHUD_CONFIGFILE em 0x34B32814; se presentes salta em 0x34B32820. Sem configuração e sem HOME, chama getpwuid em 0x34B32938 e lê [x0+0x20] sem verificar retorno nulo em 0x34B3293C. Endereços são os valores virtuais do ELF.
Isso explica uma possível falha antes do carregamento Wine; a causa no aparelho não foi confirmada por stack trace. Não houve execução Android aqui. Envie TESTE 1 e TESTE 2 após instalar. Display e game-launch continuam não implementados.
