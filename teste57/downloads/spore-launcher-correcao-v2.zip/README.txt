Correção candidata v2 — normalização LF/CRLF/BOM.
Copie os dois arquivos de src/main/ para as mesmas subpastas de app/src/main/ do projeto. Recompile e instale o APK atualizado. Execute RUN COMPATIBILITY CHECK. O Java normaliza o asset e substitui o script de staging em cada teste; não apague os saves.
O TESTE 1 deve mostrar: launcher path fix candidate 2 (LF normalized).
Esta alteração corrige o transporte do script; boot Wine, reexecução Box64 e gráficos ainda precisam de validação no aparelho. game-launch e display continuam não implementados.
