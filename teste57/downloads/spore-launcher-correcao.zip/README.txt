Correção candidata de caminhos e diagnóstico — não validada no Android.
Copie src/main/java/dev/sporeport/cellstage/MainActivity.java e src/main/assets/sch1levo-runtime para app/src/main/ nas mesmas subpastas. Recompile e instale o APK. O asset substitui o wrapper no staging a cada teste; não precisa apagar saves ou prefixo. bin/sch1levo-runtime é uma cópia para inspeção.
WINELOADER agora usa libwine-entry.so; WINEDLLPATH aponta à raiz wine/lib/wine. Reexecução via Box64, preloader e políticas Android ainda precisam de teste real.
Envie a saída completa de prefix-init após instalar. Não existe ponte de display ou implementação de game-launch neste runtime.
