Diagnóstico v3: regressão wine --version (exit 139).
Instale src/main/java/.../MainActivity.java e src/main/assets/sch1levo-runtime em app/src/main/, compile e instale o APK.
Ao falhar wine-version, TESTE 1 compara A: v2 com logs; B: caminhos anteriores; C: apenas LD_LIBRARY_PATH anterior; D: v2 sem dynarec. Somente --version é executado nestas comparações. Nenhum resultado alternativo libera boot/gráficos.
Envie o TESTE 1 completo, especialmente STEP_EXIT de A/B/C/D e as mensagens anteriores à falha. Logs completos por etapa ficam no diretório test-data/tmp do runtime de staging.
Não é uma correção comprovada do crash. Android não foi executado aqui. Não apague prefixo/saves.
